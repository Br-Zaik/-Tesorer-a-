Tesorería v0.8.1 – fix UI

Cambios hechos:
- Inicio: se quitó el selector de 3 resúmenes. Se dejó un solo diseño principal.
- Inicio: ahora los 3 diseños son solo para el cuadro de pagos 1–35 (A / B / C).
- Inicio: el aviso de comprobante rechazado subió arriba del bloque del cobro activo.
- Inicio: el motivo del rechazo ahora se ve más grande y claro.
- Movimientos: ajuste del LazyColumn para corregir la franja negra / recorte superior.
- Logo: rediseño del adaptive icon con balanza y paleta verde oscura más profesional.
- versionCode 12 / versionName 0.8.1-fix-ui.

Base usada: tesoreria-v0.8-rediseno-ui.zip
