package com.tesoreria.caja.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.EstadoPago
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.delay

@Composable
fun PantallaInicio(irASubir: () -> Unit) {
    val yo = Caja.sesion.value ?: return
    val cobro = Caja.cobroActivo()
    var detalle by remember { mutableStateOf<Int?>(null) }
    var ahora by remember { mutableStateOf(System.currentTimeMillis()) }
    var estiloCuadro by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            ahora = System.currentTimeMillis()
            Caja.revisarVencidos()
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Text("Resumen", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        ResumenInicioA()
        Spacer(Modifier.height(14.dp))

        if (cobro == null) {
            Tarjeta {
                Etiqueta("COBRO")
                Spacer(Modifier.height(7.dp))
                Titulo("No hay cobro abierto")
                Spacer(Modifier.height(6.dp))
                Text(
                    if (Caja.esAdmin) "Puedes abrir uno desde Panel > Cobro." else "Aparecerá aquí cuando el tesorero abra un cobro.",
                    color = Tenue, fontSize = 13.sp
                )
            }
            return@Column
        }

        val noEnviaron = Caja.noEnviaron(cobro.id)
        val porRevisar = Caja.porRevisar(cobro.id)
        val rechazados = Caja.rechazados(cobro.id)
        val pagaron = Caja.aprobados(cobro.id)
        val totalActivos = Caja.miembrosActivos().size
        val progreso = if (totalActivos == 0) 0f else pagaron.toFloat() / totalActivos.toFloat()
        val restante = cobro.cierra - ahora
        val miEstado = Caja.estadoDe(cobro.id, yo.numero)
        val miPago = Caja.pagoDe(cobro.id, yo.numero)

        if (miEstado == EstadoPago.RECHAZADO) {
            AlertaImportanteRechazo(
                motivo = miPago?.nota?.ifBlank { "Debes reenviar el comprobante." } ?: "Debes reenviar el comprobante.",
                reenviar = irASubir
            )
            Spacer(Modifier.height(12.dp))
        }

        Tarjeta(borde = if (restante > 0) Borde else Rojo.copy(alpha = 0.55f)) {
            FilaEntre {
                Column(Modifier.weight(1f)) {
                    Etiqueta("COBRO ACTIVO", Cian)
                    Spacer(Modifier.height(4.dp))
                    Text(cobro.titulo, color = Texto, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                }
                Text(soles(cobro.monto), color = Cian, fontSize = 18.sp, style = cifra)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (restante > 0) "Cierra en ${cuenta(restante)}" else "Plazo vencido",
                color = if (restante > 0) Ambar else Rojo,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(12.dp))
            BarraProgreso(progreso)
            Spacer(Modifier.height(8.dp))
            FilaEntre {
                Pastilla("$pagaron / $totalActivos aprobados", Verde)
                Text(soles(Caja.recaudado(cobro.id)), color = Verde, fontSize = 12.sp, style = cifra)
            }
            if (cobro.extensionTexto.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Pastilla("↗ ${cobro.extensionTexto}", Ambar)
            }
        }

        Spacer(Modifier.height(10.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (noEnviaron.isNotEmpty()) AlertaEstado(
                "No enviaron",
                "${noEnviaron.size} pendientes",
                noEnviaron.joinToString(", "),
                Rojo
            )
            if (porRevisar.isNotEmpty()) AlertaEstado(
                "Esperando revisión",
                "${porRevisar.size} comprobantes",
                porRevisar.joinToString(", "),
                Ambar
            )
            if (rechazados.isNotEmpty()) AlertaEstado(
                "Deben reenviar",
                "${rechazados.size} observados",
                rechazados.joinToString(", "),
                Rojo
            )
            if (noEnviaron.isEmpty() && porRevisar.isEmpty() && rechazados.isEmpty()) {
                AlertaEstado("Todo al día", "Sin pendientes", "Todos los pagos están confirmados.", Verde)
            }
        }

        Spacer(Modifier.height(14.dp))

        Tarjeta {
            FilaEntre {
                Etiqueta("ESTADO DE PAGOS")
                Text("$pagaron/$totalActivos", color = Cian, fontSize = 15.sp, style = cifra)
            }
            Spacer(Modifier.height(8.dp))
            Text("Diseño del cuadro", color = Tenue, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Panel, RoundedCornerShape(13.dp))
                    .border(BorderStroke(1.dp, Borde), RoundedCornerShape(13.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Pestana("A", estiloCuadro == 0, Cian, Modifier.weight(1f)) { estiloCuadro = 0 }
                Pestana("B", estiloCuadro == 1, Verde, Modifier.weight(1f)) { estiloCuadro = 1 }
                Pestana("C", estiloCuadro == 2, Ambar, Modifier.weight(1f)) { estiloCuadro = 2 }
            }
            Spacer(Modifier.height(12.dp))
            Cuadro(cobro.id, estiloCuadro) { numero -> if (Caja.esAdmin || numero == yo.numero) detalle = numero }
            Spacer(Modifier.height(14.dp))
            LeyendaCompleta()

            if (miEstado != EstadoPago.RECHAZADO) {
                Spacer(Modifier.height(14.dp))
                EstadoPropio(miEstado, cobro.id, yo.numero)
            }

            if (miEstado == EstadoPago.SIN_ENVIAR || miEstado == EstadoPago.RECHAZADO) {
                Spacer(Modifier.height(12.dp))
                Boton(
                    if (miEstado == EstadoPago.RECHAZADO) "Volver a enviar comprobante" else "Subir mi comprobante",
                    Modifier.fillMaxWidth()
                ) { irASubir() }
            }
        }
    }

    if (cobro == null) return
    detalle?.let { n ->
        Dialog(onDismissRequest = { detalle = null }) {
            Tarjeta(borde = Borde, fondo = PanelAlto) {
                val s = Caja.socio(n)
                val p = Caja.pagoDe(cobro.id, n)
                val estado = Caja.estadoDe(cobro.id, n)

                FilaEntre {
                    Column(Modifier.weight(1f)) {
                        Etiqueta("N.º $n")
                        Spacer(Modifier.height(4.dp))
                        Text(s?.nombre ?: "", color = Texto, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Pastilla(textoEstado(estado), colorDe(estado))
                }

                Spacer(Modifier.height(14.dp))
                if (p == null) {
                    Text("Todavía no ha enviado un comprobante.", color = Tenue, fontSize = 13.sp)
                } else {
                    Text("Monto · ${soles(p.monto)}", color = Texto, fontSize = 14.sp, style = cifra)
                    Spacer(Modifier.height(4.dp))
                    Text("Enviado · ${fechaHora(p.enviado)}", color = Tenue, fontSize = 12.sp)
                    if (yo.rol == Rol.TESORERO || yo.numero == n) {
                        Spacer(Modifier.height(4.dp))
                        Text("Operación · ${p.operacion}", color = Tenue, fontSize = 12.sp)
                    }
                    if (estado == EstadoPago.RECHAZADO && p.nota.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .background(Rojo.copy(alpha = 0.09f), RoundedCornerShape(10.dp))
                                .border(BorderStroke(1.dp, Rojo.copy(alpha = 0.25f)), RoundedCornerShape(10.dp))
                                .padding(10.dp)
                        ) {
                            Text("Motivo: ${p.nota}", color = Rojo, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false) { detalle = null }
            }
        }
    }
}

@Composable
private fun ResumenInicioA() {
    TarjetaPremium {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Etiqueta("SALDO DISPONIBLE", Cian)
                Spacer(Modifier.height(5.dp))
                Text(soles(Caja.saldo()), color = Texto, fontSize = 34.sp, style = cifra)
            }
            Pastilla("CALCULADO", Cian)
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) { MiniDato("INGRESOS", soles(Caja.ingresos()), Verde) }
            Box(Modifier.weight(1f)) { MiniDato("GASTOS", soles(Caja.egresos()), Rojo) }
        }
    }
}

@Composable
private fun ResumenInicioB() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TarjetaPremium {
            Etiqueta("SALDO ACTUAL", Verde)
            Spacer(Modifier.height(6.dp))
            Text(soles(Caja.saldo()), color = Texto, fontSize = 32.sp, style = cifra)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tarjeta(Modifier.weight(1f), borde = Verde.copy(alpha = .3f)) {
                Etiqueta("INGRESOS", Verde)
                Spacer(Modifier.height(6.dp))
                Text(soles(Caja.ingresos()), color = Verde, fontSize = 20.sp, style = cifra)
            }
            Tarjeta(Modifier.weight(1f), borde = Rojo.copy(alpha = .3f)) {
                Etiqueta("GASTOS", Rojo)
                Spacer(Modifier.height(6.dp))
                Text(soles(Caja.egresos()), color = Rojo, fontSize = 20.sp, style = cifra)
            }
        }
    }
}

@Composable
private fun ResumenInicioC() {
    TarjetaPremium {
        FilaEntre {
            Column(Modifier.weight(1f)) {
                Etiqueta("TABLERO", Ambar)
                Spacer(Modifier.height(4.dp))
                Text(soles(Caja.saldo()), color = Texto, fontSize = 28.sp, style = cifra)
            }
            Column(horizontalAlignment = Alignment.End) {
                Pastilla("Ingreso ${soles(Caja.ingresos())}", Verde)
                Spacer(Modifier.height(6.dp))
                Pastilla("Gasto ${soles(Caja.egresos())}", Rojo)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ResumenChip("Cobros", Caja.cobros.count { !it.cerrado }.toString(), Cian, Modifier.weight(1f))
            ResumenChip("Pagos", Caja.pagos.count { it.estado == EstadoPago.APROBADO }.toString(), Verde, Modifier.weight(1f))
            ResumenChip("Actas", Caja.actas.size.toString(), Ambar, Modifier.weight(1f))
        }
    }
}

@Composable
private fun ResumenChip(titulo: String, valor: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier
            .background(color.copy(alpha = .1f), RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = .3f)), RoundedCornerShape(12.dp))
            .padding(vertical = 10.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(valor, color = color, fontSize = 16.sp, style = cifra, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(2.dp))
            Text(titulo, color = Tenue, fontSize = 10.sp)
        }
    }
}

@Composable
private fun AlertaEstado(titulo: String, contador: String, detalle: String, color: Color) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.085f), RoundedCornerShape(14.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.28f)), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            Modifier.size(34.dp).background(color.copy(alpha = 0.14f), RoundedCornerShape(11.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(if (color == Ambar) "•" else if (color == Verde) "✓" else "!", color = color, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f)) {
            Text(titulo, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(detalle, color = Texto, fontSize = 11.sp)
        }
        Pastilla(contador, color)
    }
}

@Composable
private fun AlertaImportanteRechazo(motivo: String, reenviar: () -> Unit) {
    Tarjeta(borde = Rojo.copy(alpha = .45f), fondo = PanelAlto) {
        Etiqueta("AVISO IMPORTANTE", Rojo)
        Spacer(Modifier.height(8.dp))
        Text("Tu comprobante fue rechazado", color = Texto, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("Motivo", color = Rojo, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .background(Rojo.copy(alpha = 0.10f), RoundedCornerShape(12.dp))
                .border(BorderStroke(1.dp, Rojo.copy(alpha = 0.28f)), RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text(motivo, color = Texto, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(14.dp))
        Boton("Reenviar ahora", Modifier.fillMaxWidth(), color = Rojo) { reenviar() }
    }
}

@Composable
private fun BarraProgreso(valor: Float) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(8.dp)
            .background(Borde.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
    ) {
        Box(
            Modifier
                .fillMaxWidth(valor.coerceIn(0f, 1f))
                .height(8.dp)
                .background(Verde, RoundedCornerShape(8.dp))
        )
    }
}

@Composable
fun Cuadro(cobroId: Int, estilo: Int, alTocar: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        (1..35).toList().chunked(5).forEach { fila ->
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                fila.forEach { numero ->
                    val asignado = Caja.socio(numero) != null
                    val estado = if (asignado) Caja.estadoDe(cobroId, numero) else null
                    val c = estado?.let { colorDe(it) } ?: Tenue
                    val marca = estado?.let { marcaDe(it) } ?: "LIBRE"
                    val cellModifier = Modifier.weight(1f).height(if (estilo == 1) 54.dp else 50.dp)
                    when (estilo) {
                        0 -> CeldaCuadroA(cellModifier, numero, asignado, c, marca, estado, alTocar)
                        1 -> CeldaCuadroB(cellModifier, numero, asignado, c, marca, estado, alTocar)
                        else -> CeldaCuadroC(cellModifier, numero, asignado, c, marca, estado, alTocar)
                    }
                }
            }
        }
    }
}

@Composable
private fun CeldaCuadroA(modifier: Modifier, numero: Int, asignado: Boolean, color: Color, marca: String, estado: EstadoPago?, alTocar: (Int) -> Unit) {
    val bg = if (!asignado) Tenue.copy(alpha = 0.05f) else color.copy(alpha = if (estado == EstadoPago.RECHAZADO) 0.18f else 0.10f)
    val border = if (!asignado) Borde.copy(alpha = 0.55f) else if (estado == EstadoPago.RECHAZADO) color else color.copy(alpha = 0.42f)
    Box(
        modifier
            .background(bg, RoundedCornerShape(10.dp))
            .border(BorderStroke(if (estado == EstadoPago.RECHAZADO) 2.dp else 1.dp, border), RoundedCornerShape(10.dp))
            .clickable(enabled = asignado) { alTocar(numero) },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$numero", color = if (asignado) Texto else Tenue, fontSize = 12.sp, style = cifra)
            Text(if (asignado) marca else "LIBRE", color = if (asignado) color else Tenue, fontSize = if (asignado) 13.sp else 7.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun CeldaCuadroB(modifier: Modifier, numero: Int, asignado: Boolean, color: Color, marca: String, estado: EstadoPago?, alTocar: (Int) -> Unit) {
    Box(
        modifier
            .background(if (asignado) PanelAlto else Suave, RoundedCornerShape(13.dp))
            .border(BorderStroke(1.dp, if (asignado) color.copy(alpha = 0.45f) else Borde.copy(alpha = 0.55f)), RoundedCornerShape(13.dp))
            .clickable(enabled = asignado) { alTocar(numero) },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .background(if (asignado) color.copy(alpha = 0.14f) else Tenue.copy(alpha = 0.08f), RoundedCornerShape(99.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(if (asignado) marca else "-", color = if (asignado) color else Tenue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(4.dp))
            Text("$numero", color = if (asignado) Texto else Tenue, fontSize = 13.sp, style = cifra)
            if (!asignado) Text("LIBRE", color = Tenue, fontSize = 7.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun CeldaCuadroC(modifier: Modifier, numero: Int, asignado: Boolean, color: Color, marca: String, estado: EstadoPago?, alTocar: (Int) -> Unit) {
    Box(
        modifier
            .background(if (asignado) color.copy(alpha = 0.12f) else Suave, RoundedCornerShape(9.dp))
            .border(BorderStroke(if (estado == EstadoPago.RECHAZADO) 2.dp else 1.dp, if (asignado) color.copy(alpha = 0.55f) else Borde.copy(alpha = 0.55f)), RoundedCornerShape(9.dp))
            .clickable(enabled = asignado) { alTocar(numero) }
            .padding(6.dp)
    ) {
        if (!asignado) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.align(Alignment.Center)) {
                Text("$numero", color = Tenue, fontSize = 12.sp, style = cifra)
                Text("LIBRE", color = Tenue, fontSize = 7.sp, fontWeight = FontWeight.SemiBold)
            }
        } else {
            Text("$numero", color = Texto, fontSize = 11.sp, style = cifra, modifier = Modifier.align(Alignment.TopStart))
            Text(marca, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomEnd))
        }
    }
}

@Composable
private fun LeyendaCompleta() {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Leyenda(Verde, "✓ Aprobado")
            Leyenda(Ambar, "• Por revisar")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Leyenda(Rojo, "✕ No envió")
            Leyenda(Rojo, "▣ Rechazado")
        }
    }
}

@Composable
private fun Leyenda(color: Color, texto: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(color, RoundedCornerShape(3.dp)))
        Spacer(Modifier.width(6.dp))
        Text(texto, color = Tenue, fontSize = 10.sp)
    }
}

@Composable
private fun EstadoPropio(estado: EstadoPago, cobroId: Int, numero: Int) {
    val p = Caja.pagoDe(cobroId, numero)
    val color = colorDe(estado)
    Box(
        Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.24f)), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Column {
            Text("Tu estado · ${textoEstado(estado)}", color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                when (estado) {
                    EstadoPago.APROBADO -> "Pago confirmado."
                    EstadoPago.PENDIENTE -> "Comprobante enviado. Falta revisión."
                    EstadoPago.RECHAZADO -> "Debes volver a enviar. ${p?.nota.orEmpty()}"
                    EstadoPago.SIN_ENVIAR -> "Aún no enviaste tu comprobante."
                },
                color = Tenue,
                fontSize = 11.sp
            )
        }
    }
}

fun colorDe(estado: EstadoPago): Color = when (estado) {
    EstadoPago.APROBADO -> Verde
    EstadoPago.PENDIENTE -> Ambar
    EstadoPago.RECHAZADO -> Rojo
    EstadoPago.SIN_ENVIAR -> Rojo
}

fun marcaDe(estado: EstadoPago): String = when (estado) {
    EstadoPago.APROBADO -> "✓"
    EstadoPago.PENDIENTE -> "•"
    EstadoPago.RECHAZADO -> "!"
    EstadoPago.SIN_ENVIAR -> "✕"
}

fun textoEstado(estado: EstadoPago): String = when (estado) {
    EstadoPago.APROBADO -> "Aprobado"
    EstadoPago.PENDIENTE -> "Por revisar"
    EstadoPago.RECHAZADO -> "Rechazado"
    EstadoPago.SIN_ENVIAR -> "No enviado"
}

fun cuenta(ms: Long): String {
    val s = ms.coerceAtLeast(0L) / 1000
    val d = s / 86400
    val h = (s % 86400) / 3600
    val m = (s % 3600) / 60
    val seg = s % 60
    return if (d > 0) "$d d $h h $m min" else "$h h $m min $seg s"
}
