package com.tesoreria.caja.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.parseCentavos
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.delay

private enum class PasoSubida { VACIO, LEYENDO, REVISAR, ENVIANDO, ENVIADO }

@Composable
fun PantallaSubir(alVolver: () -> Unit) {
    val yo = Caja.sesion.value ?: return
    val cobro = Caja.cobroActivo()

    var paso by remember { mutableStateOf(PasoSubida.VACIO) }
    var monto by remember { mutableStateOf("") }
    var operacion by remember { mutableStateOf("") }
    var fechaDetectada by remember { mutableStateOf("") }
    var horaDetectada by remember { mutableStateOf("") }
    var codigoSeguridad by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }

    if (cobro == null) {
        Tarjeta {
            Titulo("No hay cobro abierto")
            Spacer(Modifier.height(6.dp))
            Text("No puedes subir un comprobante hasta que exista un cobro activo.", color = Tenue, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            Boton("Volver", Modifier.fillMaxWidth(), relleno = false) { alVolver() }
        }
        return
    }

    LaunchedEffect(paso) {
        when (paso) {
            PasoSubida.LEYENDO -> {
                delay(1500)
                // Aquí irá ML Kit. En la maqueta simulamos una lectura realista.
                monto = "${cobro.monto / 100}.${(cobro.monto % 100).toString().padStart(2, '0')}"
                operacion = "0091${300 + yo.numero}"
                val ahoraLectura = System.currentTimeMillis()
                fechaDetectada = com.tesoreria.caja.data.fechaCorta(ahoraLectura)
                horaDetectada = java.text.SimpleDateFormat("HH:mm", com.tesoreria.caja.data.PE).format(java.util.Date(ahoraLectura))
                codigoSeguridad = (100 + (yo.numero * 17) % 900).toString()
                paso = PasoSubida.REVISAR
            }
            PasoSubida.ENVIANDO -> {
                // La animación es visual. El registro se ejecuta una sola vez al finalizar.
                delay(1050)
                val centavos = parseCentavos(monto) ?: 0L
                Caja.registrarPago(cobro.id, yo.numero, centavos, operacion, centavos, fechaDetectada, horaDetectada, codigoSeguridad)
                paso = PasoSubida.ENVIADO
            }
            else -> Unit
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Etiqueta("SUBIR COMPROBANTE")
        Spacer(Modifier.height(8.dp))
        Pasos(paso)
        Spacer(Modifier.height(12.dp))

        Tarjeta(borde = Cian.copy(alpha = 0.28f)) {
            FilaEntre {
                Column(Modifier.weight(1f)) {
                    Etiqueta("COBRO")
                    Spacer(Modifier.height(4.dp))
                    Text(cobro.titulo, color = Texto, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                }
                Text(soles(cobro.monto), color = Cian, fontSize = 17.sp, style = cifra)
            }
            Spacer(Modifier.height(7.dp))
            Text("Quedará pendiente hasta que el tesorero confirme el depósito.", color = Tenue, fontSize = 11.sp)
        }

        Spacer(Modifier.height(12.dp))

        when (paso) {
            PasoSubida.VACIO -> Tarjeta {
                Titulo("Elige la captura de Yape")
                Spacer(Modifier.height(6.dp))
                Text("En la versión final podrás subir una captura real de Yape.", color = Tenue, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                MarcoVacio()
                Spacer(Modifier.height(16.dp))
                Boton("Simular captura", Modifier.fillMaxWidth()) { paso = PasoSubida.LEYENDO }
                Spacer(Modifier.height(8.dp))
                Boton("Volver", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { alVolver() }
            }

            PasoSubida.LEYENDO -> Tarjeta(borde = Cian.copy(alpha = 0.35f)) {
                Titulo("Leyendo la captura")
                Spacer(Modifier.height(5.dp))
                Text("Buscando monto y operación", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                ConstanciaFalsa(escaneando = true, monto = cobro.monto)
                Spacer(Modifier.height(14.dp))
                Pastilla("Procesando en el dispositivo", Cian)
            }

            PasoSubida.REVISAR -> {
                val centavos = parseCentavos(monto) ?: 0L
                val vencido = System.currentTimeMillis() >= cobro.cierra

                Tarjeta {
                    Titulo("Confirma los datos")
                    Spacer(Modifier.height(5.dp))
                    Text("Revisa los datos antes de enviar.", color = Tenue, fontSize = 12.sp)
                    Spacer(Modifier.height(14.dp))
                    ConstanciaFalsa(escaneando = false, monto = centavos.takeIf { it > 0 } ?: cobro.monto)
                    Spacer(Modifier.height(16.dp))

                    Etiqueta("MONTO DETECTADO")
                    Spacer(Modifier.height(6.dp))
                    Campo(monto, { monto = it; aviso = "" }, "4.00", numerico = true)
                    Spacer(Modifier.height(11.dp))

                    Etiqueta("NÚMERO DE OPERACIÓN")
                    Spacer(Modifier.height(6.dp))
                    Campo(
                        operacion,
                        { operacion = it.filter { c -> c.isDigit() }.take(20); aviso = "" },
                        "00000000",
                        numerico = true
                    )
                    Spacer(Modifier.height(11.dp))

                    Etiqueta("FECHA LEÍDA")
                    Spacer(Modifier.height(6.dp))
                    CajaDato(fechaDetectada)
                    Spacer(Modifier.height(11.dp))
                    Etiqueta("HORA LEÍDA")
                    Spacer(Modifier.height(6.dp))
                    CajaDato(horaDetectada)
                    Spacer(Modifier.height(11.dp))
                    Etiqueta("CÓDIGO DE SEGURIDAD · SI APARECE")
                    Spacer(Modifier.height(6.dp))
                    Campo(codigoSeguridad, { codigoSeguridad = it.filter(Char::isDigit).take(3) }, "Opcional", numerico = true)

                    if (centavos > 0 && centavos != cobro.monto) {
                        Spacer(Modifier.height(10.dp))
                        Pastilla("⚠ Monto distinto a ${soles(cobro.monto)}", Ambar)
                    }
                    if (vencido) {
                        Spacer(Modifier.height(10.dp))
                        Pastilla("✕ El plazo ya venció", Rojo)
                    }

                    Spacer(Modifier.height(16.dp))
                    Boton("Confirmar y enviar", Modifier.fillMaxWidth(), activo = !vencido) {
                        when {
                            centavos <= 0L -> aviso = "Escribe un monto válido"
                            operacion.length < 4 -> aviso = "Falta el número de operación"
                            Caja.operacionRepetida(operacion, socioActual = yo.numero) -> aviso = "Esa operación ya fue registrada por otro pago"
                            System.currentTimeMillis() >= cobro.cierra -> aviso = "El plazo cerró mientras subías. Habla con el tesorero."
                            else -> {
                                aviso = ""
                                paso = PasoSubida.ENVIANDO
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Boton("Cambiar captura", Modifier.fillMaxWidth(), relleno = false, color = Tenue) {
                        paso = PasoSubida.VACIO
                        aviso = ""
                    }

                    if (aviso.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text(aviso, color = Rojo, fontSize = 12.sp)
                    }
                }
            }

            PasoSubida.ENVIANDO -> AnimacionEnvioComprobante()

            PasoSubida.ENVIADO -> Tarjeta(borde = Ambar.copy(alpha = 0.50f), fondo = PanelAlto) {
                Box(Modifier.size(52.dp).background(Ambar.copy(alpha = 0.13f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.CheckCircle, null, tint = Ambar, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.height(12.dp))
                Titulo("Comprobante enviado")
                Spacer(Modifier.height(6.dp))
                Text("Tu comprobante ya fue enviado.", color = Tenue, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier.fillMaxWidth().background(Ambar.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                        .border(BorderStroke(1.dp, Ambar.copy(alpha = 0.25f)), RoundedCornerShape(12.dp)).padding(12.dp)
                ) {
                    Text("Pendiente de revisión.", color = Ambar, fontSize = 12.sp)
                }
                Spacer(Modifier.height(16.dp))
                Boton("Volver al inicio", Modifier.fillMaxWidth()) { alVolver() }
            }
        }
    }
}

@Composable
private fun AnimacionEnvioComprobante() {
    val progreso = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progreso.animateTo(1f, tween(950, easing = FastOutSlowInEasing))
    }
    val p = progreso.value

    TarjetaPremium {
        Text("Enviando comprobante", color = Texto, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text("Preparando el envío para revisión.", color = Tenue, fontSize = 11.sp)
        Spacer(Modifier.height(16.dp))

        Box(Modifier.fillMaxWidth().height(190.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val baseY = size.height * .72f
                val actualY = baseY - size.height * .47f * p
                drawLine(VerdeBrillante.copy(alpha = .16f + .32f * (1f - p)), Offset(cx, baseY), Offset(cx, actualY), strokeWidth = 4.dp.toPx())
                for (i in 0..4) {
                    val pp = (p - i * .09f).coerceIn(0f, 1f)
                    val y = baseY - size.height * .47f * pp
                    drawCircle(VerdeNeon.copy(alpha = (.26f - i * .04f).coerceAtLeast(.05f)), radius = (5 - i * .5f).dp.toPx(), center = Offset(cx, y + 28.dp.toPx()))
                }
                drawCircle(VerdeBrillante.copy(alpha = .14f), radius = 48.dp.toPx(), center = Offset(cx, actualY))
                drawCircle(VerdeBrillante.copy(alpha = .40f), radius = 34.dp.toPx(), center = Offset(cx, actualY), style = Stroke(width = 2.dp.toPx()))
            }

            Box(
                Modifier.offset(y = (46f - 90f * p).dp).scale(1f - .12f * p)
                    .size(68.dp).background(PanelAlto, RoundedCornerShape(18.dp)).border(1.dp, VerdeBrillante.copy(alpha = .6f), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.ReceiptLong, null, tint = VerdeBrillante, modifier = Modifier.size(36.dp))
            }

            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .alpha(((p - .78f) / .22f).coerceIn(0f, 1f)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.CheckCircle, null, tint = Verde, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text("Enviado", color = Verde, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Box(Modifier.fillMaxWidth().height(6.dp).background(Borde, RoundedCornerShape(99.dp))) {
            Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(GradientePrincipal, RoundedCornerShape(99.dp)))
        }
        Spacer(Modifier.height(8.dp))
        Text("Enviando...", color = Tenue, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun CajaDato(valor: String) {
    Box(
        Modifier.fillMaxWidth().background(Fondo, RoundedCornerShape(12.dp)).border(BorderStroke(1.dp, Borde), RoundedCornerShape(12.dp)).padding(14.dp)
    ) { Text(valor, color = Texto, fontSize = 13.sp) }
}

@Composable
private fun Pasos(paso: PasoSubida) {
    val actual = when (paso) {
        PasoSubida.VACIO, PasoSubida.LEYENDO -> 1
        PasoSubida.REVISAR -> 2
        PasoSubida.ENVIANDO, PasoSubida.ENVIADO -> 3
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("1 Captura", "2 Revisar", "3 Enviar").forEachIndexed { i, texto ->
            val activo = i + 1 <= actual
            val alpha by animateFloatAsState(if (activo) 1f else .55f, label = "pasoAlpha")
            Box(
                Modifier.weight(1f).alpha(alpha).background(if (activo) Cian.copy(alpha = 0.10f) else Panel, RoundedCornerShape(9.dp))
                    .border(BorderStroke(1.dp, if (activo) Cian.copy(alpha = 0.28f) else Borde), RoundedCornerShape(9.dp)).padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(texto, color = if (activo) Cian else Tenue, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun MarcoVacio() {
    val inf = rememberInfiniteTransition(label = "marco")
    val pulso by inf.animateFloat(.72f, 1f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "pulso")
    Column(
        Modifier.fillMaxWidth().height(165.dp).background(Fondo, RoundedCornerShape(14.dp))
            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(14.dp)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Rounded.ReceiptLong, null, tint = Cian.copy(alpha = pulso), modifier = Modifier.size(34.dp))
        Spacer(Modifier.height(8.dp))
        Text("Captura requerida", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(3.dp))
        Text("Sube una captura de Yape", color = Tenue, fontSize = 10.sp)
    }
}

/** Constancia visual de demo. Luego se sustituye por la imagen real del usuario. */
@Composable
private fun ConstanciaFalsa(escaneando: Boolean, monto: Long) {
    val t = rememberInfiniteTransition(label = "scan")
    val brillo by t.animateFloat(.28f, 1f, infiniteRepeatable(tween(850, easing = LinearEasing), RepeatMode.Reverse), label = "brillo")

    Column(
        Modifier.fillMaxWidth().background(Violeta.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
            .border(BorderStroke(1.dp, if (escaneando) Cian.copy(alpha = brillo) else Violeta.copy(alpha = 0.35f)), RoundedCornerShape(14.dp)).padding(16.dp)
    ) {
        FilaEntre {
            Text("Captura Yape · demo", color = Violeta, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Pastilla(if (escaneando) "LEYENDO" else "LISTA", if (escaneando) Cian else Verde)
        }
        Spacer(Modifier.height(12.dp))
        Text(soles(monto), color = Texto, fontSize = 27.sp, style = cifra, modifier = Modifier.alpha(if (escaneando) brillo else 1f))
        Spacer(Modifier.height(12.dp))
        LineaFalsa(0.78f)
        Spacer(Modifier.height(7.dp))
        LineaFalsa(0.56f)
        Spacer(Modifier.height(7.dp))
        LineaFalsa(0.66f)
    }
}

@Composable
private fun LineaFalsa(ancho: Float) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        Box(Modifier.fillMaxWidth(ancho).height(8.dp).background(Tenue.copy(alpha = 0.18f), RoundedCornerShape(4.dp)))
        Spacer(Modifier.width(1.dp))
    }
}
