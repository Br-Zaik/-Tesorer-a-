package com.tesoreria.caja.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.EstadoPago
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.soles

@Composable
fun PantallaMovimientos() {
    var verGastos by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(2.dp))
        Etiqueta("MOVIMIENTOS")
        Spacer(Modifier.height(5.dp))
        Titulo("Libro de caja")
        Spacer(Modifier.height(4.dp))
        Text("Ingresos y gastos del grupo.", color = Tenue, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(13.dp))
                .border(BorderStroke(1.dp, Borde), RoundedCornerShape(13.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Pestana("Ingresos", !verGastos, Verde, Modifier.weight(1f)) { verGastos = false }
            Pestana("Gastos", verGastos, Rojo, Modifier.weight(1f)) { verGastos = true }
        }

        Spacer(Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 8.dp)
        ) {
            if (!verGastos) {
                item { ResumenIngresosCard() }
                val lista = Caja.pagos.filter { it.estado == EstadoPago.APROBADO }.sortedByDescending { it.enviado }
                if (lista.isEmpty()) item { Vacio("Todavía no hay ingresos aprobados.") }
                items(lista) { p ->
                    MovimientoCard(
                        titulo = "N° ${p.socio} · ${Caja.socio(p.socio)?.nombre ?: "Socio"}",
                        detalle = "Op. ${p.operacion} · ${fechaHora(p.enviado)}",
                        monto = "+ ${soles(p.monto)}",
                        color = Verde,
                        estado = "APROBADO"
                    )
                }
            } else {
                item { ResumenGastosCard() }
                val gastos = Caja.gastos.sortedByDescending { it.fecha }
                if (gastos.isEmpty()) item { Vacio("Todavía no hay gastos registrados.") }
                items(gastos) { g ->
                    val estado = when {
                        g.anulado -> "ANULADO"
                        g.aprobado -> "2 FIRMAS"
                        else -> "FALTA 1 FIRMA"
                    }
                    val color = when {
                        g.anulado -> Tenue
                        g.aprobado -> Rojo
                        else -> Ambar
                    }
                    MovimientoCard(
                        titulo = g.concepto,
                        detalle = fechaHora(g.fecha),
                        monto = "− ${soles(g.monto)}",
                        color = color,
                        estado = estado
                    )
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
    }
}

@Composable
private fun ResumenIngresosCard() {
    val lista = Caja.pagos.filter { it.estado == EstadoPago.APROBADO }
    Tarjeta(borde = Verde.copy(alpha = 0.28f)) {
        FilaEntre {
            Column {
                Etiqueta("TOTAL INGRESADO", Verde)
                Spacer(Modifier.height(3.dp))
                Text("${lista.size} pagos aprobados", color = Tenue, fontSize = 11.sp)
            }
            Text(soles(Caja.ingresos()), color = Verde, fontSize = 21.sp, style = cifra)
        }
    }
}

@Composable
private fun ResumenGastosCard() {
    Tarjeta(borde = Rojo.copy(alpha = 0.24f)) {
        FilaEntre {
            Column {
                Etiqueta("TOTAL DESCONTADO", Rojo)
                Spacer(Modifier.height(3.dp))
                Text("Gastos con dos firmas", color = Tenue, fontSize = 11.sp)
            }
            Text(soles(Caja.egresos()), color = Rojo, fontSize = 21.sp, style = cifra)
        }
        if (Caja.comprometidoPendiente() > 0) {
            Spacer(Modifier.height(10.dp))
            Pastilla("Pendiente ${soles(Caja.comprometidoPendiente())}", Ambar)
        }
    }
}

@Composable
fun PantallaArchivo() {
    Column(Modifier.fillMaxWidth()) {
        Etiqueta("ARCHIVO")
        Spacer(Modifier.height(5.dp))
        Titulo("Actas y bitácora")
        Spacer(Modifier.height(4.dp))
        Text("Historial de cobros cerrados y eventos clave.", color = Tenue, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))

        if (Caja.actas.isEmpty()) Vacio("Aún no se cierra ningún cobro.")

        Caja.actas.sortedByDescending { it.cierre }.forEach { a ->
            Tarjeta(borde = Cian.copy(alpha = 0.22f)) {
                FilaEntre {
                    Column(Modifier.weight(1f)) {
                        Etiqueta("ACTA CERRADA", Cian)
                        Spacer(Modifier.height(3.dp))
                        Text(a.titulo, color = Texto, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Text(soles(a.recaudado), color = Verde, fontSize = 16.sp, style = cifra)
                }
                Spacer(Modifier.height(7.dp))
                Text("${fechaHora(a.cierre)} · cuota ${soles(a.monto)}", color = Tenue, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pastilla("${a.pagaron.size} pagaron", Verde)
                    Pastilla("${a.faltaron.size} faltaron", if (a.faltaron.isEmpty()) Verde else Rojo)
                }
                if (a.faltaron.isNotEmpty()) {
                    Spacer(Modifier.height(9.dp))
                    Text("Faltaron: ${a.faltaron.joinToString(", ")}", color = Rojo, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        Spacer(Modifier.height(8.dp))
        FilaEntre {
            Titulo("Bitácora")
            Pastilla("${if (Caja.esAdmin) Caja.bitacora.size else Caja.bitacoraPublica().size} eventos", Violeta)
        }
        Spacer(Modifier.height(4.dp))
        Text(if (Caja.esAdmin) "Vista completa." else "Eventos importantes.", color = Tenue, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))

        val eventos = if (Caja.esAdmin) Caja.bitacora.take(40) else Caja.bitacoraPublica().take(18)
        if (eventos.isEmpty()) {
            Vacio("Todavía no hay acciones registradas.")
        } else {
            eventos.forEach { evento ->
                EventoBitacoraCard(evento)
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun Pestana(
    texto: String,
    activa: Boolean,
    color: Color,
    modifier: Modifier = Modifier,
    alTocar: () -> Unit
) {
    Box(
        modifier
            .height(40.dp)
            .background(
                if (activa) color.copy(alpha = 0.13f) else Color.Transparent,
                RoundedCornerShape(10.dp)
            )
            .clickable { alTocar() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            texto,
            color = if (activa) color else Tenue,
            fontSize = 12.sp,
            fontWeight = if (activa) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
private fun MovimientoCard(titulo: String, detalle: String, monto: String, color: Color, estado: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(13.dp))
            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(13.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(titulo, color = Texto, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Text(detalle, color = Tenue, fontSize = 11.sp)
            Spacer(Modifier.height(7.dp))
            Pastilla(estado, color)
        }
        Text(monto, color = color, fontSize = 14.sp, style = cifra)
    }
}

@Composable
private fun EventoBitacoraCard(evento: String) {
    val visual = visualEvento(evento)
    Row(
        Modifier
            .fillMaxWidth()
            .background(visual.color.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
            .border(BorderStroke(1.dp, visual.color.copy(alpha = 0.24f)), RoundedCornerShape(14.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            Modifier
                .padding(top = 2.dp)
                .background(visual.color.copy(alpha = .15f), RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(visual.icono, color = visual.color, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f)) {
            Text(visual.titulo, color = visual.color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(evento, color = Texto, fontSize = 11.sp, style = cifra)
        }
    }
}

private data class EventoVisual(val titulo: String, val color: Color, val icono: String)

private fun visualEvento(evento: String): EventoVisual {
    val e = evento.lowercase()
    return when {
        "rechazó" in e || "anul" in e -> EventoVisual("Evento crítico", Rojo, "!")
        "corrig" in e || "ajustó" in e || "extend" in e || "liber" in e -> EventoVisual("Cambio importante", Ambar, "↺")
        "aprobó" in e || "pagó" in e || "envió comprobante" in e -> EventoVisual("Movimiento confirmado", Verde, "✓")
        "abrió el cobro" in e || "cerró el cobro" in e -> EventoVisual("Gestión de cobro", Cian, "▣")
        "sistema" in e -> EventoVisual("Sistema", Tenue, "•")
        else -> EventoVisual("Actividad", Cian, "•")
    }
}

@Composable
fun Vacio(texto: String) {
    Tarjeta(fondo = Suave) {
        Text("Todavía no hay datos", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(4.dp))
        Text(texto, color = Tenue, fontSize = 12.sp)
    }
}
