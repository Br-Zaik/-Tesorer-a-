package com.tesoreria.caja.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.R
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.EstadoCuenta
import com.tesoreria.caja.data.EstadoMiembro
import com.tesoreria.caja.data.Socio
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

private enum class Paso { SPLASH, NUMERO, CLAVE, ACTIVAR }

@Composable
fun PantallaLogin(avisoInicial: String? = null, alEntrar: (Socio) -> Unit) {
    var paso by remember { mutableStateOf(Paso.SPLASH) }
    var numero by remember { mutableStateOf("") }
    var clave by remember { mutableStateOf("") }
    var clave2 by remember { mutableStateOf("") }
    var codigo by remember { mutableStateOf("") }
    var cuenta by remember { mutableStateOf<EstadoCuenta?>(null) }
    var error by remember { mutableStateOf("") }
    var cargando by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current
    var mostrarSinConexion by remember { mutableStateOf(false) }

    LaunchedEffect(Caja.conectado.value) {
        if (Caja.conectado.value) {
            mostrarSinConexion = false
        } else {
            // Evita el falso "sin conexión" de los primeros milisegundos al abrir.
            delay(1500)
            if (!Caja.conectado.value) mostrarSinConexion = true
        }
    }

    LaunchedEffect(Unit) {
        // Splash corto: evita que el usuario sienta que la app quedó congelada.
        delay(520)
        paso = Paso.NUMERO
    }

    Box(Modifier.fillMaxSize().background(Fondo)) {
        FondoLogin()
        Crossfade(targetState = paso, animationSpec = tween(120), label = "login") { actual ->
            if (actual == Paso.SPLASH) {
                SplashPremium()
            } else {
                Column(
                    Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState())
                        .padding(horizontal = 22.dp, vertical = 18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (actual != Paso.NUMERO) {
                        Row(Modifier.fillMaxWidth()) {
                            Box(
                                Modifier.size(42.dp).background(Panel, CircleShape).border(1.dp, Borde, CircleShape)
                                    .clickable(enabled = !cargando) {
                                        keyboard?.hide(); focus.clearFocus()
                                        error = ""; clave = ""; clave2 = ""; codigo = ""; paso = Paso.NUMERO
                                    },
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Rounded.ArrowBack, "Volver", tint = Tenue) }
                        }
                        Spacer(Modifier.height(10.dp))
                    }

                    Box(
                        Modifier.size(82.dp).background(VerdeBrillante.copy(alpha = .07f), CircleShape)
                            .border(1.dp, VerdeBrillante.copy(alpha = .15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Shield, null, tint = VerdeBrillante, modifier = Modifier.size(42.dp))
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(
                        if (actual == Paso.NUMERO) "Bienvenido" else cuenta?.nombre ?: "Tesorería",
                        color = Texto, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(Modifier.height(5.dp))
                    Text(
                        when (actual) {
                            Paso.NUMERO -> "Inicia sesión para continuar"
                            Paso.CLAVE -> "N.º ${cuenta?.numero} · Escribe tu contraseña"
                            Paso.ACTIVAR -> "N.º ${cuenta?.numero} · Crea tu contraseña"
                            else -> ""
                        },
                        color = Tenue, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(16.dp))

                    if (!avisoInicial.isNullOrBlank()) {
                        Box(
                            Modifier.fillMaxWidth().background(Ambar.copy(alpha = .09f), RoundedCornerShape(14.dp))
                                .border(1.dp, Ambar.copy(alpha = .30f), RoundedCornerShape(14.dp)).padding(12.dp)
                        ) {
                            Text(avisoInicial, color = Texto, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        }
                        Spacer(Modifier.height(10.dp))
                    }

                    if (mostrarSinConexion && !cargando) {
                        Box(
                            Modifier.fillMaxWidth().background(Rojo.copy(alpha = .09f), RoundedCornerShape(14.dp))
                                .border(1.dp, Rojo.copy(alpha = .30f), RoundedCornerShape(14.dp)).padding(12.dp)
                        ) {
                            Text("Sin conexión a Internet", color = Rojo, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(10.dp))
                    }

                    Tarjeta(borde = VerdeBrillante.copy(alpha = .28f), fondo = PanelAlto) {
                        when (actual) {
                            Paso.NUMERO -> {
                                Etiqueta("ACCESO PERSONAL", VerdeBrillante)
                                Spacer(Modifier.height(12.dp))
                                Campo(numero, { numero = it.filter(Char::isDigit).take(2); error = "" }, "Número de lista · Ej. 22", numerico = true)
                                Spacer(Modifier.height(14.dp))
                                Boton(
                                    if (cargando) "Consultando…" else "Continuar →",
                                    Modifier.fillMaxWidth(),
                                    activo = !cargando
                                ) {
                                    val n = numero.toIntOrNull()
                                    if (n == null || n !in 1..35) { error = "Escribe un número válido del 1 al 35"; return@Boton }
                                    keyboard?.hide(); focus.clearFocus()
                                    cargando = true; error = ""
                                    scope.launch {
                                        try {
                                            val e = Caja.consultarCuenta(n)
                                            if (e.estado == EstadoMiembro.BLOQUEADO) throw IllegalStateException("Esta cuenta está bloqueada")
                                            if (e.estado == EstadoMiembro.RETIRADO) throw IllegalStateException("Esta cuenta ya no está activa")
                                            cuenta = e
                                            paso = if (!e.activada || e.reseteoActivo) Paso.ACTIVAR else Paso.CLAVE
                                        } catch (ex: Exception) {
                                            error = mensajeLogin(ex, "No se pudo consultar la cuenta")
                                        } finally {
                                            cargando = false
                                        }
                                    }
                                }
                            }

                            Paso.CLAVE -> {
                                Etiqueta("CONTRASEÑA")
                                Spacer(Modifier.height(10.dp))
                                Campo(clave, { clave = it; error = "" }, "Tu contraseña", clave = true)
                                Spacer(Modifier.height(14.dp))
                                Boton(
                                    if (cargando) "Entrando…" else "Entrar",
                                    Modifier.fillMaxWidth(),
                                    activo = !cargando
                                ) {
                                    val n = cuenta?.numero ?: return@Boton
                                    if (clave.length < 6) { error = "Escribe tu contraseña"; return@Boton }
                                    keyboard?.hide(); focus.clearFocus()
                                    cargando = true; error = ""
                                    scope.launch {
                                        try {
                                            alEntrar(Caja.iniciarSesion(n, clave))
                                        } catch (ex: Exception) {
                                            error = mensajeLogin(ex, "No se pudo iniciar sesión")
                                            cargando = false
                                        }
                                    }
                                }
                            }

                            Paso.ACTIVAR -> {
                                Etiqueta(if (cuenta?.activada == true) "RESTABLECER CONTRASEÑA" else "ACTIVAR CUENTA", VerdeBrillante)
                                Spacer(Modifier.height(6.dp))
                                Text("Usa el código temporal de 6 dígitos que te dio el tesorero.", color = Tenue, fontSize = 11.sp)
                                Spacer(Modifier.height(12.dp))
                                Campo(codigo, { codigo = it.filter(Char::isDigit).take(6); error = "" }, "Código temporal", numerico = true)
                                Spacer(Modifier.height(9.dp))
                                Campo(clave, { clave = it; error = "" }, "Nueva contraseña", clave = true)
                                Spacer(Modifier.height(9.dp))
                                Campo(clave2, { clave2 = it; error = "" }, "Repite la contraseña", clave = true)
                                Spacer(Modifier.height(14.dp))
                                Boton(
                                    if (cargando) "Guardando…" else "Guardar y entrar",
                                    Modifier.fillMaxWidth(),
                                    activo = !cargando
                                ) {
                                    val n = cuenta?.numero ?: return@Boton
                                    when {
                                        codigo.length != 6 -> error = "Escribe el código temporal de 6 dígitos"
                                        clave.length < 6 -> error = "La contraseña debe tener al menos 6 caracteres"
                                        clave != clave2 -> error = "Las contraseñas no coinciden"
                                        clave == n.toString() || clave == n.toString().padStart(2, '0') -> error = "No uses tu número de lista como contraseña"
                                        else -> {
                                            keyboard?.hide(); focus.clearFocus()
                                            cargando = true; error = ""
                                            scope.launch {
                                                try {
                                                    alEntrar(Caja.activarCuenta(n, codigo, clave))
                                                } catch (ex: Exception) {
                                                    error = mensajeLogin(ex, "No se pudo activar la cuenta")
                                                    cargando = false
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else -> Unit
                        }

                        if (error.isNotBlank()) {
                            Spacer(Modifier.height(10.dp))
                            Text(error, color = Rojo, fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("Conexión segura con Tesorería", color = Tenue.copy(alpha = .75f), fontSize = 10.sp)
                }
            }
        }
    }
}

private fun mensajeLogin(ex: Exception, fallback: String): String {
    val raw = ex.message.orEmpty()
    val n = raw.lowercase(Locale.ROOT)
    return when {
        "permission denied" in n || "row-level security" in n || "not authorized" in n -> "No tienes permiso"
        "sin conexión" in n -> "Sin conexión a Internet"
        "tardó" in n || "timeout" in n || "temporalmente" in n || "servidor" in n ->
            "El servidor tardó en responder. Inténtalo nuevamente"
        "contraseña incorrecta" in n || "invalid login" in n || "invalid credentials" in n ->
            "Número o contraseña incorrectos"
        raw.isBlank() -> fallback
        else -> raw
    }
}

@Composable
private fun SplashPremium() {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(R.drawable.tesoreria_logo_hd),
            contentDescription = "Tesorería",
            modifier = Modifier.size(164.dp)
        )
        Spacer(Modifier.height(20.dp))
        Text("Tesorería", color = Texto, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(6.dp))
        Text("Control · Orden · Transparencia", color = Tenue, fontSize = 13.sp)
        Spacer(Modifier.height(30.dp))
        BarraCarga()
        Spacer(Modifier.height(10.dp))
        Text("Conectando con el servidor…", color = Tenue, fontSize = 11.sp)
    }
}

@Composable
private fun FondoLogin() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawCircle(
            VerdeBrillante.copy(alpha = .032f),
            size.minDimension * .60f,
            center = androidx.compose.ui.geometry.Offset(w * .78f, h * .14f)
        )
        drawCircle(
            VerdeNeon.copy(alpha = .022f),
            size.minDimension * .46f,
            center = androidx.compose.ui.geometry.Offset(w * .06f, h * .88f)
        )
        val paso = w / 7f
        for (i in 1..6) {
            drawLine(
                VerdeBrillante.copy(alpha = .016f),
                androidx.compose.ui.geometry.Offset(i * paso, 0f),
                androidx.compose.ui.geometry.Offset(i * paso, h),
                1f
            )
        }
        drawArc(VerdeBrillante.copy(alpha = .08f), -30f, 160f, false, style = Stroke(width = 1.dp.toPx()))
    }
}

@Composable
private fun BarraCarga() {
    var p by remember { mutableFloatStateOf(.18f) }
    LaunchedEffect(Unit) {
        while (true) {
            p = if (p < .75f) .82f else .18f
            delay(650)
        }
    }
    val animated by androidx.compose.animation.core.animateFloatAsState(p, tween(600), label = "load")
    Box(
        Modifier.width(180.dp).height(5.dp)
            .background(Borde.copy(alpha = .55f), RoundedCornerShape(9.dp))
    ) {
        Box(
            Modifier.fillMaxWidth(animated).fillMaxHeight()
                .background(GradientePrincipal, RoundedCornerShape(9.dp))
        )
    }
}
