package com.tesoreria.caja.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.platform.LocalContext
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.ReceiptOcr
import com.tesoreria.caja.data.SinConexionException
import com.tesoreria.caja.data.parseCentavos
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.launch

private enum class PasoSubida { VACIO, LEYENDO, REVISAR, ENVIANDO, POR_VERIFICAR, ENVIADO }

@Composable
fun PantallaSubir(alVolver: () -> Unit) {
    Caja.sesion.value ?: return
    val cobro = Caja.cobroActivo()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var paso by remember { mutableStateOf(PasoSubida.VACIO) }
    var monto by remember { mutableStateOf("") }
    var operacion by remember { mutableStateOf("") }
    var fechaDetectada by remember { mutableStateOf("") }
    var horaDetectada by remember { mutableStateOf("") }
    var codigoSeguridad by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    var capturaUri by remember { mutableStateOf<Uri?>(null) }
    var capturaBytes by remember { mutableStateOf<ByteArray?>(null) }
    var capturaMime by remember { mutableStateOf("image/jpeg") }
    var capturaBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var verImagen by remember { mutableStateOf(false) }
    var progresoEnvio by remember { mutableIntStateOf(0) }
    var esComprobanteYape by remember { mutableStateOf(false) }
    var confianzaYape by remember { mutableIntStateOf(0) }
    var capturaDHash by remember { mutableLongStateOf(0L) }

    fun seleccionar(uri: Uri?) {
        if (uri == null) return
        capturaUri = uri
        aviso = ""
        paso = PasoSubida.LEYENDO
        scope.launch {
            try {
                val r = ReceiptOcr.leer(context, uri)
                if (!r.esYape) {
                    capturaBytes = null
                    capturaBitmap?.takeIf { !it.isRecycled }?.recycle()
                    capturaBitmap = null
                    esComprobanteYape = false
                    confianzaYape = r.confianzaYape
                    capturaDHash = 0L
                    aviso = "Esta imagen no parece un comprobante de Yape. Solo se aceptan capturas de comprobantes Yape."
                    if (!r.bitmap.isRecycled) r.bitmap.recycle()
                    paso = PasoSubida.VACIO
                    return@launch
                }
                capturaBytes = r.bytes
                capturaMime = r.mime
                capturaBitmap = r.bitmap
                monto = r.monto
                operacion = r.operacion
                fechaDetectada = r.fecha
                horaDetectada = r.hora
                codigoSeguridad = r.codigoSeguridad
                esComprobanteYape = true
                confianzaYape = r.confianzaYape
                capturaDHash = r.capturaDHash
                aviso = when {
                    r.textoDetectado.isBlank() -> "No se pudo leer bien el texto. La captura se conserva para revisión del tesorero."
                    r.monto.isBlank() || r.operacion.isBlank() -> "OCR incompleto: revisa los datos. El tesorero siempre verá la captura original."
                    else -> ""
                }
                paso = PasoSubida.REVISAR
            } catch (e: Exception) {
                aviso = e.message ?: "No se pudo leer la captura"
                paso = PasoSubida.VACIO
            }
        }
    }

    val selectorFotos = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { seleccionar(it) }
    val selectorArchivos = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        seleccionar(uri)
    }

    if (cobro == null) {
        Tarjeta {
            Titulo("No hay cobro abierto")
            Spacer(Modifier.height(6.dp))
            Text("No puedes subir un comprobante hasta que exista un cobro activo.", color = Tenue, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            Boton("Volver", Modifier.fillMaxWidth(), relleno = false) { alVolver() }
        }
        return
    }

    fun intentarEnviar() {
        val bytes = capturaBytes
        val centavos = parseCentavos(monto) ?: 0L
        when {
            !Caja.conectado.value -> aviso = "Sin conexión a Internet. Tu captura sigue aquí y no se enviará hasta que vuelvas a intentarlo."
            bytes == null || capturaUri == null -> aviso = "Selecciona la captura de Yape"
            !esComprobanteYape -> aviso = "Solo se aceptan comprobantes de Yape"
            centavos <= 0L -> aviso = "Escribe un monto válido"
            operacion.length < 6 -> aviso = "Falta el número de operación"
            System.currentTimeMillis() >= cobro.cierra -> aviso = "El plazo cerró mientras subías. Habla con el tesorero."
            else -> {
                aviso = ""
                progresoEnvio = 0
                paso = PasoSubida.ENVIANDO
                scope.launch {
                    try {
                        if (Caja.verificarEnvio(cobro, operacion)) {
                            progresoEnvio = 100
                            paso = PasoSubida.ENVIADO
                            return@launch
                        }
                        Caja.enviarComprobante(
                            cobro = cobro,
                            monto = centavos,
                            operacion = operacion,
                            bytes = bytes,
                            mime = capturaMime,
                            codigoSeguridad = codigoSeguridad,
                            fecha = fechaDetectada,
                            hora = horaDetectada,
                            capturaDHash = capturaDHash,
                            confianzaYape = confianzaYape
                        ) { progresoEnvio = it }
                        paso = PasoSubida.ENVIADO
                    } catch (e: SinConexionException) {
                        aviso = "La conexión se perdió durante el envío. No marcaré el pago como enviado hasta verificarlo."
                        paso = PasoSubida.POR_VERIFICAR
                    } catch (e: Exception) {
                        val confirmado = if (Caja.conectado.value) Caja.verificarEnvio(cobro, operacion) else false
                        if (confirmado) {
                            progresoEnvio = 100
                            paso = PasoSubida.ENVIADO
                        } else {
                            aviso = e.message ?: "No se pudo enviar el comprobante"
                            paso = PasoSubida.REVISAR
                        }
                    }
                }
            }
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Etiqueta("SUBIR COMPROBANTE")
        Spacer(Modifier.height(8.dp))
        Pasos(paso)
        Spacer(Modifier.height(12.dp))

        Tarjeta(borde = Cian.copy(alpha = 0.28f)) {
            FilaEntre {
                Column(Modifier.weight(1f)) {
                    Etiqueta("COBRO")
                    Spacer(Modifier.height(4.dp))
                    Text(cobro.titulo, color = Texto, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                }
                Text(soles(cobro.monto), color = Cian, fontSize = 17.sp, style = cifra)
            }
            Spacer(Modifier.height(7.dp))
            Text("Quedará pendiente hasta que el tesorero confirme el depósito.", color = Tenue, fontSize = 11.sp)
        }

        Spacer(Modifier.height(12.dp))

        when (paso) {
            PasoSubida.VACIO -> Tarjeta {
                Titulo("Selecciona tu comprobante")
                Spacer(Modifier.height(6.dp))
                Text("Puedes elegir una captura desde Fotos o buscarla en Archivos.", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                MarcoVacio()
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Boton("Fotos", Modifier.weight(1f), color = Verde) {
                        selectorFotos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    Boton("Archivos", Modifier.weight(1f), color = Cian, relleno = false) {
                        selectorArchivos.launch(arrayOf("image/*"))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Boton("Volver", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { alVolver() }
                if (aviso.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(aviso, color = Rojo, fontSize = 11.sp)
                }
            }

            PasoSubida.LEYENDO -> Tarjeta(borde = Cian.copy(alpha = .38f), fondo = PanelAlto) {
                Box(Modifier.size(50.dp).background(Cian.copy(alpha = .11f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.ReceiptLong, null, tint = Cian, modifier = Modifier.size(28.dp))
                }
                Spacer(Modifier.height(12.dp))
                Titulo("Preparando comprobante")
                Spacer(Modifier.height(5.dp))
                Text("Verificando que sea Yape y leyendo datos como ayuda. El OCR no aprueba el pago.", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(13.dp))
                Pastilla("Procesamiento local", Cian)
            }

            PasoSubida.REVISAR -> {
                val centavos = parseCentavos(monto) ?: 0L
                val vencido = System.currentTimeMillis() >= cobro.cierra
                Tarjeta {
                    Titulo("Revisa antes de enviar")
                    Spacer(Modifier.height(5.dp))
                    Text("La captura original es la prueba principal. El OCR solo completa datos como ayuda para tu revisión y la del tesorero.", color = Tenue, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Pastilla("✓ Comprobante compatible con Yape", Verde)
                    Spacer(Modifier.height(14.dp))
                    MiniaturaComprobante(capturaBitmap) { verImagen = true }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Boton("Cambiar foto", Modifier.weight(1f), relleno = false, color = Cian) {
                            selectorFotos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                        Boton("Quitar", Modifier.weight(1f), relleno = false, color = Rojo) {
                            capturaUri = null; capturaBytes = null; capturaBitmap = null
                            monto = ""; operacion = ""; fechaDetectada = ""; horaDetectada = ""; codigoSeguridad = ""
                            esComprobanteYape = false; confianzaYape = 0; capturaDHash = 0L
                            aviso = ""; paso = PasoSubida.VACIO
                        }
                    }

                    Spacer(Modifier.height(16.dp))
                    Etiqueta("MONTO")
                    Spacer(Modifier.height(6.dp))
                    Campo(monto, { monto = it; aviso = "" }, "No detectado", numerico = true)
                    Spacer(Modifier.height(11.dp))
                    Etiqueta("NÚMERO DE OPERACIÓN")
                    Spacer(Modifier.height(6.dp))
                    Campo(operacion, { operacion = it.filter(Char::isDigit).take(20); aviso = "" }, "No detectado", numerico = true)
                    Spacer(Modifier.height(11.dp))
                    Etiqueta("FECHA")
                    Spacer(Modifier.height(6.dp))
                    Campo(fechaDetectada, { fechaDetectada = it.take(10); aviso = "" }, "DD/MM/AAAA")
                    Spacer(Modifier.height(11.dp))
                    Etiqueta("HORA")
                    Spacer(Modifier.height(6.dp))
                    Campo(horaDetectada, { horaDetectada = it.take(5); aviso = "" }, "HH:mm")
                    Spacer(Modifier.height(11.dp))
                    Etiqueta("CÓDIGO DE SEGURIDAD · SI APARECE")
                    Spacer(Modifier.height(6.dp))
                    Campo(codigoSeguridad, { codigoSeguridad = it.filter(Char::isDigit).take(3); aviso = "" }, "No detectado", numerico = true)

                    if (centavos > 0 && centavos != cobro.monto) {
                        Spacer(Modifier.height(10.dp))
                        Pastilla("⚠ Monto distinto a ${soles(cobro.monto)}", Ambar)
                    }
                    if (!Caja.conectado.value) {
                        Spacer(Modifier.height(10.dp))
                        Pastilla("Sin conexión · no se enviará nada", Rojo)
                    }
                    if (vencido) {
                        Spacer(Modifier.height(10.dp))
                        Pastilla("Plazo vencido", Rojo)
                    }
                    if (aviso.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text(aviso, color = if (aviso.startsWith("Sin conexión")) Ambar else Rojo, fontSize = 11.sp)
                    }

                    Spacer(Modifier.height(16.dp))
                    Boton("Confirmar y enviar", Modifier.fillMaxWidth(), activo = !vencido) { intentarEnviar() }
                }
            }

            PasoSubida.ENVIANDO -> AnimacionEnvioComprobante(progresoEnvio, capturaBitmap)

            PasoSubida.POR_VERIFICAR -> Tarjeta(borde = Ambar.copy(alpha = .5f), fondo = PanelAlto) {
                Box(Modifier.size(54.dp).background(Ambar.copy(alpha = .12f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.CloudOff, null, tint = Ambar, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.height(12.dp))
                Titulo("Envío por verificar")
                Spacer(Modifier.height(6.dp))
                Text(aviso, color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                MiniaturaComprobante(capturaBitmap) { verImagen = true }
                Spacer(Modifier.height(12.dp))
                Boton("Verificar estado", Modifier.fillMaxWidth(), activo = Caja.conectado.value) {
                    scope.launch {
                        val ok = Caja.verificarEnvio(cobro, operacion)
                        if (ok) paso = PasoSubida.ENVIADO
                        else {
                            aviso = "El servidor no confirmó el envío. Revisa los datos y toca Confirmar y enviar cuando quieras reintentarlo."
                            paso = PasoSubida.REVISAR
                        }
                    }
                }
                Spacer(Modifier.height(7.dp))
                Boton("Volver a revisar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { paso = PasoSubida.REVISAR }
            }

            PasoSubida.ENVIADO -> Tarjeta(borde = Verde.copy(alpha = .48f), fondo = PanelAlto) {
                Box(Modifier.size(58.dp).background(Verde.copy(alpha = .12f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.CloudDone, null, tint = Verde, modifier = Modifier.size(34.dp))
                }
                Spacer(Modifier.height(12.dp))
                Titulo("¡Comprobante enviado!")
                Spacer(Modifier.height(5.dp))
                Text("El servidor confirmó el envío y ahora está pendiente de revisión del tesorero.", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                MiniaturaComprobante(capturaBitmap) { verImagen = true }
                Spacer(Modifier.height(12.dp))
                MiniDato("MONTO", if (monto.isBlank()) "No detectado" else "S/ $monto", Verde)
                Spacer(Modifier.height(7.dp))
                MiniDato("OPERACIÓN", operacion.ifBlank { "No detectada" }, Cian)
                if (fechaDetectada.isNotBlank() || horaDetectada.isNotBlank()) {
                    Spacer(Modifier.height(7.dp))
                    MiniDato("FECHA Y HORA", listOf(fechaDetectada, horaDetectada).filter { it.isNotBlank() }.joinToString(" · "), Ambar)
                }
                if (codigoSeguridad.isNotBlank()) {
                    Spacer(Modifier.height(7.dp))
                    MiniDato("CÓDIGO", codigoSeguridad, Violeta)
                }
                Spacer(Modifier.height(15.dp))
                Boton("Volver al inicio", Modifier.fillMaxWidth()) { alVolver() }
            }
        }
    }

    if (verImagen) capturaBitmap?.let { bitmap -> VisorBitmapDialog(bitmap) { verImagen = false } }
}

@Composable
private fun AnimacionEnvioComprobante(progreso: Int, bitmap: Bitmap?) {
    val p by animateFloatAsState(progreso.coerceIn(0, 100) / 100f, tween(350), label = "envioReal")
    val etapa = when {
        progreso < 12 -> "Preparando archivo"
        progreso < 62 -> "Subiendo imagen al servidor"
        progreso < 94 -> "Guardando datos del pago"
        progreso < 100 -> "Confirmando envío"
        else -> "Listo"
    }
    TarjetaPremium {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).background(VerdeBrillante.copy(alpha = .10f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.ReceiptLong, null, tint = VerdeBrillante, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Enviando comprobante", color = Texto, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(etapa, color = Tenue, fontSize = 11.sp)
            }
            Text("$progreso%", color = VerdeNeon, fontSize = 16.sp, style = cifra)
        }
        Spacer(Modifier.height(15.dp))
        if (bitmap != null) {
            Box(Modifier.height(135.dp)) { MiniaturaComprobante(bitmap) }
            Spacer(Modifier.height(13.dp))
        }
        Box(Modifier.fillMaxWidth().height(8.dp).background(Borde, RoundedCornerShape(99.dp))) {
            Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(GradientePrincipal, RoundedCornerShape(99.dp)))
        }
        Spacer(Modifier.height(12.dp))
        listOf(
            "Preparando archivo" to (progreso >= 12),
            "Subiendo al servidor" to (progreso >= 62),
            "Guardando datos" to (progreso >= 94),
            "Confirmando" to (progreso >= 100)
        ).forEach { (texto, listo) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.CheckCircle, null, tint = if (listo) Verde else Tenue.copy(alpha = .35f), modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(7.dp))
                Text(texto, color = if (listo) Texto else Tenue, fontSize = 11.sp)
            }
            Spacer(Modifier.height(5.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text("No cierres esta pantalla hasta que el servidor confirme.", color = Tenue, fontSize = 10.sp)
    }
}

@Composable
private fun Pasos(paso: PasoSubida) {
    val actual = when (paso) {
        PasoSubida.VACIO, PasoSubida.LEYENDO -> 1
        PasoSubida.REVISAR -> 2
        PasoSubida.ENVIANDO, PasoSubida.POR_VERIFICAR, PasoSubida.ENVIADO -> 3
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("1 Captura", "2 Revisar", "3 Enviar").forEachIndexed { i, texto ->
            val activo = i + 1 <= actual
            Box(
                Modifier.weight(1f).background(if (activo) Cian.copy(alpha = .10f) else Panel, RoundedCornerShape(9.dp))
                    .border(BorderStroke(1.dp, if (activo) Cian.copy(alpha = .32f) else Borde), RoundedCornerShape(9.dp)).padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) { Text(texto, color = if (activo) Cian else Tenue, fontSize = 9.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
private fun MarcoVacio() {
    Column(
        Modifier.fillMaxWidth().height(165.dp).background(FondoProfundo, RoundedCornerShape(16.dp))
            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(16.dp)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Icon(Icons.Rounded.PhotoLibrary, null, tint = VerdeBrillante, modifier = Modifier.size(34.dp))
            Icon(Icons.Rounded.FolderOpen, null, tint = Cian, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text("Foto del comprobante", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(3.dp))
        Text("Fotos o Archivos · JPG, PNG, WEBP", color = Tenue, fontSize = 10.sp)
    }
}
