plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val githubRepository = System.getenv("GITHUB_REPOSITORY") ?: ""
val signingStorePath = System.getenv("TESORERIA_KEYSTORE_PATH") ?: ""
val signingStorePassword = System.getenv("KEYSTORE_PASSWORD") ?: ""
val signingKeyAlias = System.getenv("KEY_ALIAS") ?: ""
val signingKeyPassword = System.getenv("KEY_PASSWORD") ?: ""
val signingConfigured = signingStorePath.isNotBlank() &&
    signingStorePassword.isNotBlank() &&
    signingKeyAlias.isNotBlank() &&
    signingKeyPassword.isNotBlank()

android {
    namespace = "com.tesoreria.caja"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.tesoreria.caja"
        minSdk = 24
        targetSdk = 35
        versionCode = 21
        versionName = "1.5.1"

        buildConfigField("String", "GITHUB_REPOSITORY", "\"$githubRepository\"")
    }

    signingConfigs {
        create("permanentRelease") {
            if (signingConfigured) {
                storeFile = file(signingStorePath)
                storePassword = signingStorePassword
                keyAlias = signingKeyAlias
                keyPassword = signingKeyPassword
            }
        }
    }

    buildTypes {
        debug {
            isDebuggable = false
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        release {
            isDebuggable = false
            isMinifyEnabled = true
            isShrinkResources = true
            if (signingConfigured) {
                signingConfig = signingConfigs.getByName("permanentRelease")
            }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("androidx.exifinterface:exifinterface:1.3.7")

    val compose = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(compose)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
}
