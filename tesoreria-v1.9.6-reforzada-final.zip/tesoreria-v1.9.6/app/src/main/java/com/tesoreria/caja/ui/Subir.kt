package com.tesoreria.caja.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.ComprobanteImagen
import com.tesoreria.caja.data.SinConexionException
import com.tesoreria.caja.data.EstadoPago
import com.tesoreria.caja.data.EstadoMiembro
import com.tesoreria.caja.data.TipoCobro
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.launch

private enum class PasoSubida { VACIO, CARGANDO, REVISAR, ENVIANDO, POR_VERIFICAR, ENVIADO }

@Composable
fun PantallaSubir(alVolver: () -> Unit) {
    val yo = Caja.sesion.value ?: return
    val cobro = Caja.cobroParaSubir()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var paso by remember { mutableStateOf(PasoSubida.VACIO) }
    var aviso by remember { mutableStateOf("") }
    var capturaUri by remember { mutableStateOf<Uri?>(null) }
    var capturaBytes by remember { mutableStateOf<ByteArray?>(null) }
    var capturaMime by remember { mutableStateOf("image/jpeg") }
    var capturaBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var capturaDHash by remember { mutableLongStateOf(0L) }
    var verImagen by remember { mutableStateOf(false) }
    var progresoEnvio by remember { mutableIntStateOf(0) }
    var numerosGrupo by remember(cobro?.id, yo.numero) { mutableStateOf<Set<Int>>(setOf(yo.numero)) }
    var elegirGrupo by remember { mutableStateOf(false) }
    var confirmarEnvioGrupo by remember { mutableStateOf(false) }

    fun seleccionar(uri: Uri?) {
        if (uri == null) return
        capturaUri = uri
        aviso = ""
        paso = PasoSubida.CARGANDO
        scope.launch {
            try {
                val r = ComprobanteImagen.leerParaYape(context, uri)
                capturaBitmap?.takeIf { !it.isRecycled }?.recycle()
                capturaBytes = r.bytes
                capturaMime = r.mime
                capturaBitmap = r.bitmap
                capturaDHash = r.capturaDHash
                paso = PasoSubida.REVISAR
            } catch (e: Exception) {
                capturaUri = null
                capturaBytes = null
                capturaBitmap = null
                capturaDHash = 0L
                aviso = e.message ?: "No se pudo abrir la imagen"
                paso = PasoSubida.VACIO
            }
        }
    }

    val selectorFotos = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { seleccionar(it) }
    val selectorArchivos = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        seleccionar(uri)
    }

    if (!yo.participaCobros) {
        Tarjeta(borde = Cian.copy(alpha = .35f)) {
            Titulo("Cuenta en modo solo visualización")
            Spacer(Modifier.height(7.dp))
            Text("No estás incluido en los cobros. El owner o un administrador autorizado puede habilitar tu participación.", color = Tenue, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Boton("Volver", Modifier.fillMaxWidth(), relleno = false) { alVolver() }
        }
        return
    }

    if (cobro == null) {
        Tarjeta {
            Titulo("No hay cobro abierto")
            Spacer(Modifier.height(12.dp))
            Boton("Volver", Modifier.fillMaxWidth(), relleno = false) { alVolver() }
        }
        return
    }

    fun enviar() {
        val bytes = capturaBytes
        when {
            !Caja.conectado.value -> aviso = "Sin conexión a Internet"
            bytes == null || capturaUri == null -> aviso = "Selecciona una foto del comprobante"
            System.currentTimeMillis() >= cobro.cierra -> aviso = "El cobro ya cerró"
            else -> {
                aviso = ""
                progresoEnvio = 0
                paso = PasoSubida.ENVIANDO
                scope.launch {
                    try {
                        if (Caja.verificarEnvio(cobro, numerosGrupo)) {
                            progresoEnvio = 100
                            paso = PasoSubida.ENVIADO
                            return@launch
                        }
                        Caja.enviarComprobante(
                            cobro = cobro,
                            bytes = bytes,
                            mime = capturaMime,
                            capturaDHash = capturaDHash,
                            numeros = numerosGrupo.sorted()
                        ) { progresoEnvio = it }
                        paso = PasoSubida.ENVIADO
                    } catch (e: SinConexionException) {
                        aviso = "Se perdió la conexión"
                        paso = PasoSubida.POR_VERIFICAR
                    } catch (e: Exception) {
                        val confirmado = if (Caja.conectado.value) Caja.verificarEnvio(cobro, numerosGrupo) else false
                        if (confirmado) {
                            progresoEnvio = 100
                            paso = PasoSubida.ENVIADO
                        } else {
                            aviso = e.message ?: "No se pudo enviar el comprobante"
                            paso = PasoSubida.REVISAR
                        }
                    }
                }
            }
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Etiqueta("SUBIR COMPROBANTE")
        Spacer(Modifier.height(10.dp))

        val colorCobro = if (cobro.tipo == TipoCobro.RAPIDO) Ambar else Verde
        Tarjeta(borde = colorCobro.copy(alpha = .38f)) {
            Etiqueta(if (cobro.tipo == TipoCobro.RAPIDO) "COBRO RÁPIDO" else "COBRO OFICIAL", colorCobro)
            Spacer(Modifier.height(5.dp))
            FilaEntre {
                Text(cobro.titulo, color = Texto, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(soles(cobro.monto), color = colorCobro, fontSize = 17.sp, style = cifra)
            }
        }

        Spacer(Modifier.height(12.dp))
        YapeInfoUsuarioCard(compacta = true)
        Spacer(Modifier.height(12.dp))

        Tarjeta(borde = MoradoYape.copy(alpha = .46f), fondo = PanelAlto) {
            Etiqueta("PAGAR EN CONJUNTO", MoradoYape)
            Spacer(Modifier.height(5.dp))
            Text(
                if (numerosGrupo.size == 1) "Este comprobante paga solo tu número." else "Un solo comprobante para ${numerosGrupo.size} personas.",
                color = Tenue, fontSize = 10.sp
            )
            Spacer(Modifier.height(7.dp))
            Text("Incluye: ${numerosGrupo.sorted().joinToString(", ") { it.toString().padStart(2, '0') }}", color = Texto, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text("Total del grupo: ${soles(cobro.monto * numerosGrupo.size)}", color = MoradoYape, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Boton(if (numerosGrupo.size > 1) "Cambiar personas" else "Agregar personas", Modifier.fillMaxWidth(), relleno = false, color = MoradoYape) { elegirGrupo = true }
        }
        Spacer(Modifier.height(12.dp))

        when (paso) {
            PasoSubida.VACIO -> Tarjeta {
                Titulo("Comprobante Yape")
                Spacer(Modifier.height(14.dp))
                MarcoVacio()
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Boton("Fotos", Modifier.weight(1f), color = Verde) {
                        selectorFotos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    Boton("Archivos", Modifier.weight(1f), color = Cian, relleno = false) {
                        selectorArchivos.launch(arrayOf("image/*"))
                    }
                }
                if (aviso.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(aviso, color = Rojo, fontSize = 11.sp)
                }
                Spacer(Modifier.height(8.dp))
                Boton("Volver", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { alVolver() }
            }

            PasoSubida.CARGANDO -> Tarjeta(fondo = PanelAlto) {
                Titulo("Abriendo imagen…")
            }

            PasoSubida.REVISAR -> {
                val vencido = System.currentTimeMillis() >= cobro.cierra
                Tarjeta {
                    MiniaturaComprobante(capturaBitmap) { verImagen = true }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Boton("Cambiar foto", Modifier.weight(1f), relleno = false, color = Cian) {
                            selectorFotos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                        Boton("Quitar", Modifier.weight(1f), relleno = false, color = Rojo) {
                            capturaUri = null
                            capturaBytes = null
                            capturaBitmap?.takeIf { !it.isRecycled }?.recycle()
                            capturaBitmap = null
                            capturaDHash = 0L
                            aviso = ""
                            paso = PasoSubida.VACIO
                        }
                    }
                    if (!Caja.conectado.value) {
                        Spacer(Modifier.height(10.dp))
                        Pastilla("Sin conexión", Rojo)
                    }
                    if (vencido) {
                        Spacer(Modifier.height(10.dp))
                        Pastilla("Cobro cerrado", Rojo)
                    }
                    if (aviso.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text(aviso, color = Rojo, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(16.dp))
                    Boton("Confirmar y enviar", Modifier.fillMaxWidth(), activo = !vencido) {
                        if (numerosGrupo.size > 1) confirmarEnvioGrupo = true else enviar()
                    }
                }
            }

            PasoSubida.ENVIANDO -> AnimacionEnvioComprobante(progresoEnvio, capturaBitmap)

            PasoSubida.POR_VERIFICAR -> Tarjeta(borde = Ambar.copy(alpha = .5f), fondo = PanelAlto) {
                Box(Modifier.size(54.dp).background(Ambar.copy(alpha = .12f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.CloudOff, null, tint = Ambar, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.height(12.dp))
                Titulo("Envío por verificar")
                Spacer(Modifier.height(12.dp))
                MiniaturaComprobante(capturaBitmap) { verImagen = true }
                Spacer(Modifier.height(12.dp))
                Boton("Verificar", Modifier.fillMaxWidth(), activo = Caja.conectado.value) {
                    scope.launch {
                        if (Caja.verificarEnvio(cobro, numerosGrupo)) paso = PasoSubida.ENVIADO
                        else paso = PasoSubida.REVISAR
                    }
                }
            }

            PasoSubida.ENVIADO -> Tarjeta(borde = Verde.copy(alpha = .48f), fondo = PanelAlto) {
                Box(Modifier.size(58.dp).background(Verde.copy(alpha = .12f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.CloudDone, null, tint = Verde, modifier = Modifier.size(34.dp))
                }
                Spacer(Modifier.height(12.dp))
                Titulo("Comprobante enviado")
                Spacer(Modifier.height(12.dp))
                MiniaturaComprobante(capturaBitmap) { verImagen = true }
                Spacer(Modifier.height(14.dp))
                Boton("Volver al inicio", Modifier.fillMaxWidth()) { alVolver() }
            }
        }
    }

    if (elegirGrupo) Dialog(onDismissRequest = { elegirGrupo = false }) {
        var buscar by remember { mutableStateOf("") }
        val q = buscar.trim()
        val resultados = if (q.isBlank()) emptyList() else Caja.socios.filter { socio ->
            socio.estado == EstadoMiembro.ACTIVO && socio.participaCobros && socio.numero != yo.numero &&
                (socio.numero.toString() == q || socio.nombre.contains(q, ignoreCase = true))
        }.take(8)
        Tarjeta(borde = MoradoYape.copy(alpha = .55f), fondo = PanelAlto) {
            Etiqueta("PERSONAS INCLUIDAS EN EL YAPE", MoradoYape)
            Spacer(Modifier.height(5.dp))
            Text("Tu N.º ${yo.numero} siempre queda incluido. Busca y agrega a quienes estás pagando.", color = Tenue, fontSize = 10.sp)
            Spacer(Modifier.height(9.dp))
            Campo(buscar, { buscar = it }, "Número o nombre")
            if (resultados.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                resultados.forEach { socio ->
                    val estado = Caja.estadoDe(cobro.id, socio.numero)
                    val disponible = estado == EstadoPago.SIN_ENVIAR || estado == EstadoPago.RECHAZADO
                    val incluido = socio.numero in numerosGrupo
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${socio.numero.toString().padStart(2, '0')} · ${socio.nombre}", color = if (disponible || incluido) Texto else Tenue, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            if (!disponible && !incluido) {
                                val txt = when (estado) {
                                    EstadoPago.APROBADO -> "Ya pagó"
                                    EstadoPago.NO_PAGA -> "Declaró que no participa"
                                    else -> "Pago pendiente"
                                }
                                Text(txt, color = if (estado == EstadoPago.APROBADO) Verde else if (estado == EstadoPago.NO_PAGA) Cian else Ambar, fontSize = 9.sp)
                            }
                        }
                        Boton(
                            if (incluido) "Quitar" else "Agregar", Modifier.width(90.dp), relleno = false,
                            color = if (incluido) Rojo else MoradoYape, activo = incluido || disponible
                        ) {
                            numerosGrupo = if (incluido) numerosGrupo - socio.numero else numerosGrupo + socio.numero
                            buscar = ""
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
            if (numerosGrupo.size > 1) {
                Spacer(Modifier.height(9.dp))
                Etiqueta("SELECCIONADOS · ${numerosGrupo.size}", Verde)
                Spacer(Modifier.height(5.dp))
                numerosGrupo.sorted().forEach { n ->
                    Text("${n.toString().padStart(2, '0')} · ${Caja.socio(n)?.nombre.orEmpty()}", color = Texto, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Boton("Listo", Modifier.fillMaxWidth(), color = MoradoYape) { elegirGrupo = false }
        }
    }

    if (confirmarEnvioGrupo) Dialog(onDismissRequest = { confirmarEnvioGrupo = false }) {
        Tarjeta(borde = MoradoYape.copy(alpha = .62f), fondo = PanelAlto) {
            Etiqueta("CONFIRMAR PAGO EN CONJUNTO", MoradoYape)
            Spacer(Modifier.height(8.dp))
            Text(
                "Vas a enviar un comprobante por ${soles(cobro.monto * numerosGrupo.size)}.",
                color = Texto, fontSize = 15.sp, fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Incluye los N.º ${numerosGrupo.sorted().joinToString(", ") { it.toString().padStart(2, '0') }}.",
                color = Tenue, fontSize = 11.sp
            )
            Spacer(Modifier.height(5.dp))
            Text("Revisa bien las personas antes de enviarlo.", color = Tenue, fontSize = 10.sp)
            Spacer(Modifier.height(14.dp))
            Boton("Sí, enviar ${soles(cobro.monto * numerosGrupo.size)}", Modifier.fillMaxWidth(), color = MoradoYape) {
                confirmarEnvioGrupo = false
                enviar()
            }
            Spacer(Modifier.height(8.dp))
            Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) {
                confirmarEnvioGrupo = false
            }
        }
    }

    if (verImagen) capturaBitmap?.let { bitmap -> VisorBitmapDialog(bitmap) { verImagen = false } }
}

@Composable
private fun AnimacionEnvioComprobante(progreso: Int, bitmap: Bitmap?) {
    val p by animateFloatAsState(progreso.coerceIn(0, 100) / 100f, tween(300), label = "envioReal")
    TarjetaPremium {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).background(VerdeBrillante.copy(alpha = .10f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.ReceiptLong, null, tint = VerdeBrillante, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(12.dp))
            Text("Enviando comprobante", color = Texto, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("$progreso%", color = VerdeNeon, fontSize = 16.sp, style = cifra)
        }
        Spacer(Modifier.height(14.dp))
        if (bitmap != null) {
            Box(Modifier.height(135.dp)) { MiniaturaComprobante(bitmap) }
            Spacer(Modifier.height(12.dp))
        }
        Box(Modifier.fillMaxWidth().height(8.dp).background(Borde, RoundedCornerShape(99.dp))) {
            Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(GradientePrincipal, RoundedCornerShape(99.dp)))
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.CheckCircle, null, tint = if (progreso >= 100) Verde else Tenue, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(7.dp))
            Text(if (progreso >= 100) "Listo" else "Guardando…", color = Texto, fontSize = 11.sp)
        }
    }
}

@Composable
private fun MarcoVacio() {
    Column(
        Modifier.fillMaxWidth().height(165.dp).background(FondoProfundo, RoundedCornerShape(16.dp)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Icon(Icons.Rounded.PhotoLibrary, null, tint = VerdeBrillante, modifier = Modifier.size(34.dp))
            Icon(Icons.Rounded.FolderOpen, null, tint = Cian, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text("Selecciona la foto", color = Texto, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}
