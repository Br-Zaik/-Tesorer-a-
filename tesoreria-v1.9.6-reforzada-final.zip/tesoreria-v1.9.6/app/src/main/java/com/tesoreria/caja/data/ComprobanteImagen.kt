package com.tesoreria.caja.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/** Carga local de comprobantes, corrige orientación y genera una huella visual. */
object ComprobanteImagen {
    data class Resultado(
        val bytes: ByteArray,
        val mime: String,
        val bitmap: Bitmap,
        val capturaDHash: Long
    )

    suspend fun leer(context: Context, uri: Uri): Resultado = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val mimeOriginal = resolver.getType(uri)?.lowercase(Locale.ROOT) ?: "image/jpeg"
        if (mimeOriginal !in setOf("image/jpeg", "image/png", "image/webp", "image/heic", "image/heif")) {
            throw IllegalStateException("Selecciona una imagen")
        }
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("No se pudo abrir la imagen")
        if (bytes.isEmpty()) throw IllegalStateException("La imagen está vacía")
        if (bytes.size > 10 * 1024 * 1024) throw IllegalStateException("La imagen supera 10 MB")

        val bitmap = decodificar(bytes) ?: throw IllegalStateException("No se pudo leer la imagen")
        Resultado(
            bytes = bytes,
            mime = normalizarMime(mimeOriginal),
            bitmap = bitmap,
            capturaDHash = calcularDHash(bitmap)
        )
    }

    /**
     * Yape se guarda siempre como JPEG REAL. Esto evita declarar HEIC/HEIF como JPEG
     * sin convertir los bytes y además mantiene la imagen por debajo del límite de 2 MB
     * del bucket para reducir fallos al subir desde celulares.
     */
    suspend fun leerParaYape(context: Context, uri: Uri): Resultado {
        val base = leer(context, uri)
        return withContext(Dispatchers.Default) {
            normalizarAJpeg(base, calidadInicial = 92, maxBytes = 1_850_000)
        }
    }

    /** Para gastos también normalizamos a JPEG para evitar formatos ambiguos y reducir peso. */
    suspend fun leerParaGasto(context: Context, uri: Uri): Resultado {
        val base = leer(context, uri)
        return withContext(Dispatchers.Default) {
            normalizarAJpeg(base, calidadInicial = 88, maxBytes = 9 * 1024 * 1024)
        }
    }

    private fun normalizarAJpeg(base: Resultado, calidadInicial: Int, maxBytes: Int): Resultado {
        var bitmapTrabajo = base.bitmap
        var calidad = calidadInicial.coerceIn(60, 95)
        var ultimo: ByteArray = ByteArray(0)

        repeat(12) { intento ->
            val out = ByteArrayOutputStream()
            if (!bitmapTrabajo.compress(Bitmap.CompressFormat.JPEG, calidad, out)) {
                throw IllegalStateException("No se pudo preparar la imagen")
            }
            ultimo = out.toByteArray()
            if (ultimo.isEmpty()) throw IllegalStateException("La imagen está vacía")
            if (ultimo.size <= maxBytes) {
                return base.copy(bytes = ultimo, mime = "image/jpeg", bitmap = bitmapTrabajo)
            }

            // Primero bajamos calidad; si aún no alcanza, reducimos dimensiones de forma gradual.
            if (calidad > 68) {
                calidad = (calidad - 6).coerceAtLeast(68)
            } else {
                val nuevoAncho = (bitmapTrabajo.width * 0.82f).roundToInt().coerceAtLeast(1)
                val nuevoAlto = (bitmapTrabajo.height * 0.82f).roundToInt().coerceAtLeast(1)
                if (nuevoAncho >= bitmapTrabajo.width && nuevoAlto >= bitmapTrabajo.height) {
                    throw IllegalStateException("La imagen es demasiado pesada")
                }
                val escalado = Bitmap.createScaledBitmap(bitmapTrabajo, nuevoAncho, nuevoAlto, true)
                if (escalado !== bitmapTrabajo && !bitmapTrabajo.isRecycled) bitmapTrabajo.recycle()
                bitmapTrabajo = escalado
                calidad = 82
            }

            if (intento == 11 && ultimo.size > maxBytes) {
                throw IllegalStateException("La imagen es demasiado pesada")
            }
        }
        throw IllegalStateException("No se pudo preparar la imagen")
    }

    private fun normalizarMime(v: String): String = when (v) {
        "image/png" -> "image/png"
        "image/webp" -> "image/webp"
        else -> "image/jpeg"
    }

    private fun decodificar(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > 2800) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null

        val orientation = runCatching {
            ExifInterface(ByteArrayInputStream(bytes)).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
        }
        if (matrix.isIdentity) return decoded

        val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (rotated !== decoded && !decoded.isRecycled) decoded.recycle()
        return rotated
    }

    private fun calcularDHash(bitmap: Bitmap): Long {
        val reducido = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
        return try {
            var hash = 0L
            var bit = 0
            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    val a = reducido.getPixel(x, y)
                    val b = reducido.getPixel(x + 1, y)
                    val ga = ((android.graphics.Color.red(a) * 299) +
                        (android.graphics.Color.green(a) * 587) +
                        (android.graphics.Color.blue(a) * 114)) / 1000
                    val gb = ((android.graphics.Color.red(b) * 299) +
                        (android.graphics.Color.green(b) * 587) +
                        (android.graphics.Color.blue(b) * 114)) / 1000
                    if (ga > gb) hash = hash or (1L shl bit)
                    bit++
                }
            }
            hash
        } finally {
            if (reducido !== bitmap && !reducido.isRecycled) reducido.recycle()
        }
    }
}
