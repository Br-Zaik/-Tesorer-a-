# Validación v1.9.6

Comprobaciones realizadas:

- `app_actualizacion_config`: `SELECT` concedido a `anon` y `authenticated`.
- Índices únicos activos para `gastos.comprobante_path` y `gastos.comprobante_sha256` cuando no son nulos.
- Edge Function `owner-limpiar`: activa en versión 3 y contempla ambos buckets de comprobantes.
- Buckets Yape y gastos permanecen privados.
- Yape usa `leerParaYape`, que produce bytes JPEG reales y limita el tamaño antes de subir.
- Gastos siguen usando `leerParaGasto` y el RPC idempotente `registrar_gasto_v2`.
- VersionCode incrementado a 44 y VersionName a 1.9.6.

La compilación Android final debe pasar por GitHub Actions, ya que el entorno local no incluye el SDK/Gradle completo del proyecto.
