-- Ya aplicado al proyecto Supabase de Tesorería.
-- Fuente de referencia de los cambios principales v1.9.6.

grant select on table public.app_actualizacion_config to anon, authenticated;

create unique index if not exists gastos_comprobante_sha256_uq
on public.gastos (comprobante_sha256)
where comprobante_sha256 is not null;

-- registrar_gasto y registrar_gasto_v2 fueron reemplazadas en el servidor para:
-- 1) tomar pg_advisory_xact_lock(hashtextextended('tesoreria:gastos:saldo',0))
--    antes de validar el saldo;
-- 2) rechazar comprobante_sha256 repetido en registrar_gasto_v2;
-- 3) conservar la idempotencia por request_id.
--
-- La Edge Function owner-limpiar fue desplegada como versión 3 y elimina objetos
-- tanto de comprobantes-yape como de comprobantes-gastos antes de borrar datos.
