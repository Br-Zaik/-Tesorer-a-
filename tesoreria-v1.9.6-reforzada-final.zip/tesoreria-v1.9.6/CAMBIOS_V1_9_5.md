# Tesorería v1.9.5

- En Registrar gasto, el comprobante opcional ahora puede elegirse de dos formas visibles: **Fotos** o **Archivos**.
- **Fotos** usa el selector de imágenes de Android.
- **Archivos** permite buscar imágenes en Descargas/gestores de archivos y conserva permiso de lectura cuando Android lo admite.
- Si ya se eligió un comprobante, también puede cambiarse desde Fotos o Archivos antes de registrar.
- La confirmación de imagen correcta sigue siendo obligatoria antes de usarla.
- El botón **Registrar gasto** cambia de ámbar a rojo para distinguir claramente una salida de dinero.
- No cambia el servidor ni las reglas de comprobantes de gastos de v1.9.4.

VersionCode: 43  
VersionName: 1.9.5
