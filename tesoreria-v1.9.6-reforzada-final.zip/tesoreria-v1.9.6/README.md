# Caja del Grupo · Tesorería v1.9.6

- versionCode: 44
- versionName: 1.9.6
- applicationId: com.tesoreria.caja

Refuerzo de reconexión, gastos concurrentes, comprobantes de gasto duplicados, limpieza completa de Storage y normalización JPEG real para Yape.

Consulta `CAMBIOS_V1_9_6.md`, `SERVER_V1_9_6_APLICADO.md` y `VALIDACION_V1_9_6.md`.

---

# Caja del Grupo · Tesorería v1.8.0

- versionCode: 34
- versionName: 1.8.0
- applicationId: com.tesoreria.caja

Owner/Administrador/Usuario, permisos granulares, hasta 3 cobros oficiales + 2 rápidos, cierre por fecha/hora, usuarios solo visualización, “No quiero pagar” con motivo en acta/PDF, Yape morado/manual verde y limpieza del servidor exclusiva del Owner.

Consulta `CAMBIOS_V1_8_0.md`, `SERVER_V1_8_0_APLICADO.md` y `VALIDACION_V1_8_0.md`.

---

# Caja del Grupo · Tesorería v1.7.1

- versionCode: 28
- versionName: 1.7.1
- applicationId: com.tesoreria.caja

Cobros oficiales y rápidos, actas eliminables con contraseña, plazas liberables y flujo reforzado para activación masiva.

Consulta `CAMBIOS_V1_7_0.md` y `SERVER_V1_7_0_APLICADO.md`.

---

# Caja del Grupo · Tesorería v1.5.0

Versión con firma permanente y actualizador integrado desde GitHub Releases.

- versionCode: 16
- versionName: 1.4.0
- applicationId: com.tesoreria.caja

Consulta `ACTUALIZACIONES_V1_1_0.md` para la configuración única de GitHub Secrets y el flujo de actualización.

---

# Caja del Grupo · Tesorería v1.0.0

Versión 1 enfocada en comprobantes Yape, revisión del tesorero, estabilidad de red y seguridad.

- versionCode: 15
- versionName: 1.0.0
- applicationId: com.tesoreria.caja

Consulta `VALIDACION_V1_0_0.md` para el detalle de cambios.

---

# Tesorería v0.9.0-server

Aplicación Android nativa en Kotlin + Jetpack Compose conectada al proyecto Supabase de Tesorería.

## Cambios principales
- Un solo inicio de sesión por número de lista + contraseña.
- El N.º 22 obtiene permisos de tesorero automáticamente por su rol del servidor.
- Sin pestaña separada "Administrador".
- Estado de pagos usa únicamente el diseño A.
- Solo el tesorero puede aprobar/rechazar Yapes.
- Presidente queda como cargo informativo, sin firma de gastos.
- Datos reales desde Supabase: miembros, cobros, pagos, gastos, actas y bitácora.
- Activación/restablecimiento desde la app mediante código temporal de 6 dígitos.
- Capturas Yape reales a Storage privado, máximo 2 MB.
- Cierre automático de cobros en servidor mediante pg_cron.
- Realtime preparado en servidor; la app sincroniza periódicamente para mantener la UI actualizada.

## Versión
- versionCode: 13
- versionName: 0.9.0-server


## v0.9.1-server-fix
- Corrige compilación Kotlin de Login.kt restaurando FondoAnimado y BarraCarga.
- versionCode 14.
- No se modificaron los workflows de GitHub Actions.


## v1.5.0 · Yape seguro
OCR de apoyo, validación de formato Yape y detección fuerte de comprobantes duplicados.


## v1.5.1 — estabilidad de acceso
El login usa reintentos seguros, evita falsos estados offline y carga el perfil con una sola operación de servidor.


## v1.6.0
Login simplificado, Yape con OCR solo de monto, actas desplegables, QR/número Yape configurable y exportación PDF.

## v1.6.1
- versionCode: 23
- Actualización obligatoria más simple.
- Yape por número, sin QR.
- OCR solo monto + número de operación.
- Actas y Bitácora separadas y fechas más legibles.
- Visor de comprobante a pantalla completa con zoom.

## v1.6.4

- Comprobantes Yape por foto, sin OCR.
- Nuevo permiso delegable Gestionar Yape.
- Menos textos redundantes y flujo de envío más simple.
