# Servidor v1.9.6 aplicado

Proyecto Supabase de Tesorería actualizado.

Cambios aplicados:

- `GRANT SELECT` seguro sobre `app_actualizacion_config` para `anon` y `authenticated`.
- Índice único parcial `gastos_comprobante_sha256_uq` para impedir reutilización exacta de comprobantes de gastos.
- `registrar_gasto` y `registrar_gasto_v2` usan bloqueo transaccional compartido antes de comprobar saldo.
- `registrar_gasto_v2` rechaza una imagen cuyo SHA-256 ya esté asociado a otro gasto.
- Edge Function `owner-limpiar` actualizada a versión 3: limpia `comprobantes-yape` y `comprobantes-gastos`.
- El bucket `comprobantes-gastos` continúa privado y visible solo a usuarios autenticados mediante las políticas RLS existentes.
