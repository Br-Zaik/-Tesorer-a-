# Tesorería v1.9.6

VersionCode: 44  
VersionName: 1.9.6

Refuerzo de estabilidad y seguridad sin cambiar el flujo visual principal:

- La detección de conexión ya no confunde un HTTP 401/403/404 con pérdida de Internet.
- El servidor concede lectura segura de `app_actualizacion_config` a `anon` y `authenticated`, respetando la RLS existente.
- Registro de gastos serializado en servidor: dos administradores no pueden validar el mismo saldo al mismo tiempo y provocar sobregiro.
- El mismo SHA-256 de comprobante de gasto no puede asociarse a dos gastos distintos.
- La limpieza del Owner elimina tanto comprobantes Yape como comprobantes de gastos del Storage privado.
- Los comprobantes Yape se convierten realmente a JPEG antes de subirlos, incluido HEIC/HEIF.
- La conversión Yape reduce calidad/tamaño gradualmente para mantenerse por debajo del límite del bucket y reducir fallos de subida.
- Se mantiene idempotencia: un reintento con el mismo `request_id` no duplica el gasto.

No se modifican cargos, permisos existentes, lógica de cobros, números de lista ni firma de la app.
