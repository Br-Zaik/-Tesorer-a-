package com.tesoreria.caja.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.ComprobanteImagen
import com.tesoreria.caja.data.SinConexionException
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.launch

private enum class PasoSubida { VACIO, CARGANDO, REVISAR, ENVIANDO, POR_VERIFICAR, ENVIADO }

@Composable
fun PantallaSubir(alVolver: () -> Unit) {
    Caja.sesion.value ?: return
    val cobro = Caja.cobroParaSubir()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var paso by remember { mutableStateOf(PasoSubida.VACIO) }
    var aviso by remember { mutableStateOf("") }
    var capturaUri by remember { mutableStateOf<Uri?>(null) }
    var capturaBytes by remember { mutableStateOf<ByteArray?>(null) }
    var capturaMime by remember { mutableStateOf("image/jpeg") }
    var capturaBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var capturaDHash by remember { mutableLongStateOf(0L) }
    var verImagen by remember { mutableStateOf(false) }
    var progresoEnvio by remember { mutableIntStateOf(0) }

    fun seleccionar(uri: Uri?) {
        if (uri == null) return
        capturaUri = uri
        aviso = ""
        paso = PasoSubida.CARGANDO
        scope.launch {
            try {
                val r = ComprobanteImagen.leer(context, uri)
                capturaBitmap?.takeIf { !it.isRecycled }?.recycle()
                capturaBytes = r.bytes
                capturaMime = r.mime
                capturaBitmap = r.bitmap
                capturaDHash = r.capturaDHash
                paso = PasoSubida.REVISAR
            } catch (e: Exception) {
                capturaUri = null
                capturaBytes = null
                capturaBitmap = null
                capturaDHash = 0L
                aviso = e.message ?: "No se pudo abrir la imagen"
                paso = PasoSubida.VACIO
            }
        }
    }

    val selectorFotos = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { seleccionar(it) }
    val selectorArchivos = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        seleccionar(uri)
    }

    if (cobro == null) {
        Tarjeta {
            Titulo("No hay cobro abierto")
            Spacer(Modifier.height(12.dp))
            Boton("Volver", Modifier.fillMaxWidth(), relleno = false) { alVolver() }
        }
        return
    }

    fun enviar() {
        val bytes = capturaBytes
        when {
            !Caja.conectado.value -> aviso = "Sin conexión a Internet"
            bytes == null || capturaUri == null -> aviso = "Selecciona una foto del comprobante"
            System.currentTimeMillis() >= cobro.cierra -> aviso = "El cobro ya cerró"
            else -> {
                aviso = ""
                progresoEnvio = 0
                paso = PasoSubida.ENVIANDO
                scope.launch {
                    try {
                        if (Caja.verificarEnvio(cobro)) {
                            progresoEnvio = 100
                            paso = PasoSubida.ENVIADO
                            return@launch
                        }
                        Caja.enviarComprobante(
                            cobro = cobro,
                            bytes = bytes,
                            mime = capturaMime,
                            capturaDHash = capturaDHash
                        ) { progresoEnvio = it }
                        paso = PasoSubida.ENVIADO
                    } catch (e: SinConexionException) {
                        aviso = "Se perdió la conexión"
                        paso = PasoSubida.POR_VERIFICAR
                    } catch (e: Exception) {
                        val confirmado = if (Caja.conectado.value) Caja.verificarEnvio(cobro) else false
                        if (confirmado) {
                            progresoEnvio = 100
                            paso = PasoSubida.ENVIADO
                        } else {
                            aviso = e.message ?: "No se pudo enviar el comprobante"
                            paso = PasoSubida.REVISAR
                        }
                    }
                }
            }
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Etiqueta("SUBIR COMPROBANTE")
        Spacer(Modifier.height(10.dp))

        Tarjeta(borde = Cian.copy(alpha = .28f)) {
            FilaEntre {
                Text(cobro.titulo, color = Texto, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(soles(cobro.monto), color = Cian, fontSize = 17.sp, style = cifra)
            }
        }

        Spacer(Modifier.height(12.dp))
        YapeInfoUsuarioCard(compacta = true)
        Spacer(Modifier.height(12.dp))

        when (paso) {
            PasoSubida.VACIO -> Tarjeta {
                Titulo("Comprobante Yape")
                Spacer(Modifier.height(14.dp))
                MarcoVacio()
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Boton("Fotos", Modifier.weight(1f), color = Verde) {
                        selectorFotos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    Boton("Archivos", Modifier.weight(1f), color = Cian, relleno = false) {
                        selectorArchivos.launch(arrayOf("image/*"))
                    }
                }
                if (aviso.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(aviso, color = Rojo, fontSize = 11.sp)
                }
                Spacer(Modifier.height(8.dp))
                Boton("Volver", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { alVolver() }
            }

            PasoSubida.CARGANDO -> Tarjeta(fondo = PanelAlto) {
                Titulo("Abriendo imagen…")
            }

            PasoSubida.REVISAR -> {
                val vencido = System.currentTimeMillis() >= cobro.cierra
                Tarjeta {
                    MiniaturaComprobante(capturaBitmap) { verImagen = true }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Boton("Cambiar foto", Modifier.weight(1f), relleno = false, color = Cian) {
                            selectorFotos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                        Boton("Quitar", Modifier.weight(1f), relleno = false, color = Rojo) {
                            capturaUri = null
                            capturaBytes = null
                            capturaBitmap?.takeIf { !it.isRecycled }?.recycle()
                            capturaBitmap = null
                            capturaDHash = 0L
                            aviso = ""
                            paso = PasoSubida.VACIO
                        }
                    }
                    if (!Caja.conectado.value) {
                        Spacer(Modifier.height(10.dp))
                        Pastilla("Sin conexión", Rojo)
                    }
                    if (vencido) {
                        Spacer(Modifier.height(10.dp))
                        Pastilla("Cobro cerrado", Rojo)
                    }
                    if (aviso.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text(aviso, color = Rojo, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(16.dp))
                    Boton("Confirmar y enviar", Modifier.fillMaxWidth(), activo = !vencido) { enviar() }
                }
            }

            PasoSubida.ENVIANDO -> AnimacionEnvioComprobante(progresoEnvio, capturaBitmap)

            PasoSubida.POR_VERIFICAR -> Tarjeta(borde = Ambar.copy(alpha = .5f), fondo = PanelAlto) {
                Box(Modifier.size(54.dp).background(Ambar.copy(alpha = .12f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.CloudOff, null, tint = Ambar, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.height(12.dp))
                Titulo("Envío por verificar")
                Spacer(Modifier.height(12.dp))
                MiniaturaComprobante(capturaBitmap) { verImagen = true }
                Spacer(Modifier.height(12.dp))
                Boton("Verificar", Modifier.fillMaxWidth(), activo = Caja.conectado.value) {
                    scope.launch {
                        if (Caja.verificarEnvio(cobro)) paso = PasoSubida.ENVIADO
                        else paso = PasoSubida.REVISAR
                    }
                }
            }

            PasoSubida.ENVIADO -> Tarjeta(borde = Verde.copy(alpha = .48f), fondo = PanelAlto) {
                Box(Modifier.size(58.dp).background(Verde.copy(alpha = .12f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.CloudDone, null, tint = Verde, modifier = Modifier.size(34.dp))
                }
                Spacer(Modifier.height(12.dp))
                Titulo("Comprobante enviado")
                Spacer(Modifier.height(12.dp))
                MiniaturaComprobante(capturaBitmap) { verImagen = true }
                Spacer(Modifier.height(14.dp))
                Boton("Volver al inicio", Modifier.fillMaxWidth()) { alVolver() }
            }
        }
    }

    if (verImagen) capturaBitmap?.let { bitmap -> VisorBitmapDialog(bitmap) { verImagen = false } }
}

@Composable
private fun AnimacionEnvioComprobante(progreso: Int, bitmap: Bitmap?) {
    val p by animateFloatAsState(progreso.coerceIn(0, 100) / 100f, tween(300), label = "envioReal")
    TarjetaPremium {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).background(VerdeBrillante.copy(alpha = .10f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.ReceiptLong, null, tint = VerdeBrillante, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(12.dp))
            Text("Enviando comprobante", color = Texto, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("$progreso%", color = VerdeNeon, fontSize = 16.sp, style = cifra)
        }
        Spacer(Modifier.height(14.dp))
        if (bitmap != null) {
            Box(Modifier.height(135.dp)) { MiniaturaComprobante(bitmap) }
            Spacer(Modifier.height(12.dp))
        }
        Box(Modifier.fillMaxWidth().height(8.dp).background(Borde, RoundedCornerShape(99.dp))) {
            Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(GradientePrincipal, RoundedCornerShape(99.dp)))
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.CheckCircle, null, tint = if (progreso >= 100) Verde else Tenue, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(7.dp))
            Text(if (progreso >= 100) "Listo" else "Guardando…", color = Texto, fontSize = 11.sp)
        }
    }
}

@Composable
private fun MarcoVacio() {
    Column(
        Modifier.fillMaxWidth().height(165.dp).background(FondoProfundo, RoundedCornerShape(16.dp)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Icon(Icons.Rounded.PhotoLibrary, null, tint = VerdeBrillante, modifier = Modifier.size(34.dp))
            Icon(Icons.Rounded.FolderOpen, null, tint = Cian, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text("Selecciona la foto", color = Texto, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}
