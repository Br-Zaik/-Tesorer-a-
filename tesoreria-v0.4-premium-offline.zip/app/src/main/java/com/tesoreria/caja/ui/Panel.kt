package com.tesoreria.caja.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Pago
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.parseCentavos
import com.tesoreria.caja.data.soles

@Composable
fun PantallaPanel() {
    val yo = Caja.sesion.value ?: return
    var seccion by remember { mutableStateOf(0) }

    Column(Modifier.fillMaxWidth()) {
        if (yo.rol == Rol.PRESIDENTE) {
            Etiqueta("PANEL DEL PRESIDENTE")
            Spacer(Modifier.height(5.dp))
            Titulo("Firmas pendientes")
            Spacer(Modifier.height(4.dp))
            Text("Tu firma es la segunda llave. Sin ella, el gasto no baja el saldo.", color = Tenue, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Firmas(comoPresidente = true)
            return@Column
        }

        Etiqueta("PANEL DEL TESORERO")
        Spacer(Modifier.height(5.dp))
        Titulo("Administración")
        Spacer(Modifier.height(4.dp))
        Text("Las acciones importantes quedan registradas en la bitácora de esta demo.", color = Tenue, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(13.dp))
                .border(BorderStroke(1.dp, Borde), RoundedCornerShape(13.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Pestana("Pagos ${Caja.pendientes().size}", seccion == 0, Cian, Modifier.weight(1f)) { seccion = 0 }
            Pestana("Cobro", seccion == 1, Cian, Modifier.weight(1f)) { seccion = 1 }
            Pestana("Gastos", seccion == 2, Cian, Modifier.weight(1f)) { seccion = 2 }
            Pestana("Socios", seccion == 3, Cian, Modifier.weight(1f)) { seccion = 3 }
        }

        Spacer(Modifier.height(12.dp))

        when (seccion) {
            0 -> Pendientes()
            1 -> CrearCobro()
            2 -> Gastos()
            else -> Socios()
        }
    }
}

@Composable
private fun Pendientes() {
    val lista = Caja.pendientes()
    var rechazar by remember { mutableStateOf<Pago?>(null) }

    Tarjeta(borde = Ambar.copy(alpha = 0.30f), fondo = PanelAlto) {
        FilaEntre {
            Column {
                Etiqueta("PAGOS POR REVISAR", Ambar)
                Spacer(Modifier.height(3.dp))
                Text("${lista.size} pendientes", color = Texto, fontSize = 18.sp, style = cifra)
            }
            Pastilla("REVISIÓN HUMANA", Ambar)
        }
        Spacer(Modifier.height(9.dp))
        Text("Aprueba solo cuando veas el dinero en tu Yape. La captura es respaldo, no prueba.", color = Tenue, fontSize = 11.sp)
    }
    Spacer(Modifier.height(10.dp))

    if (lista.isEmpty()) Vacio("No hay comprobantes esperando revisión.")

    lista.forEach { p ->
        val cobro = Caja.cobros.firstOrNull { it.id == p.cobroId }
        val fueraDePlazo = cobro != null && p.enviado > cobro.cierra
        val montoDistinto = cobro != null && p.monto != cobro.monto
        val repetida = Caja.operacionRepetida(p.operacion, p.id, p.socio)
        val tieneAviso = fueraDePlazo || montoDistinto || repetida

        Tarjeta(borde = if (tieneAviso) Ambar.copy(alpha = 0.58f) else Borde) {
            FilaEntre {
                Column(Modifier.weight(1f)) {
                    Etiqueta("N.º ${p.socio}")
                    Spacer(Modifier.height(3.dp))
                    Text(Caja.socio(p.socio)?.nombre ?: "", color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
                Text(soles(p.monto), color = Cian, fontSize = 17.sp, style = cifra)
            }
            Spacer(Modifier.height(7.dp))
            Text("Operación ${p.operacion} · ${fechaHora(p.enviado)}", color = Tenue, fontSize = 10.sp)
            Spacer(Modifier.height(10.dp))
            MarcoCaptura()

            if (tieneAviso) {
                Spacer(Modifier.height(10.dp))
                Text("AVISOS AUTOMÁTICOS", color = Ambar, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (montoDistinto) Pastilla("⚠ Monto distinto a la cuota", Ambar)
                    if (fueraDePlazo) Pastilla("⚠ Llegó fuera del plazo", Ambar)
                    if (repetida) Pastilla("✕ Operación repetida", Rojo)
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Boton("Aprobar", Modifier.weight(1f), color = Verde) { Caja.aprobarPago(p.id) }
                Boton("Rechazar", Modifier.weight(1f), color = Rojo, relleno = false) { rechazar = p }
            }
        }
        Spacer(Modifier.height(10.dp))
    }

    rechazar?.let { p ->
        Dialog(onDismissRequest = { rechazar = null }) {
            var motivo by remember(p.id) { mutableStateOf("") }
            var error by remember(p.id) { mutableStateOf("") }
            Tarjeta(borde = Rojo.copy(alpha = 0.45f), fondo = PanelAlto) {
                Etiqueta("RECHAZAR COMPROBANTE", Rojo)
                Spacer(Modifier.height(5.dp))
                Text("N.º ${p.socio}", color = Texto, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(5.dp))
                Text("El motivo es obligatorio y lo verá el socio para poder corregir.", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Campo(motivo, { motivo = it; error = "" }, "Ej. El pago no figura en la cuenta")
                if (error.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(error, color = Rojo, fontSize = 11.sp)
                }
                Spacer(Modifier.height(14.dp))
                Boton("Confirmar rechazo", Modifier.fillMaxWidth(), color = Rojo) {
                    if (motivo.trim().length < 4) error = "Escribe un motivo claro"
                    else {
                        Caja.rechazarPago(p.id, motivo)
                        rechazar = null
                    }
                }
                Spacer(Modifier.height(8.dp))
                Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { rechazar = null }
            }
        }
    }
}

@Composable
private fun MarcoCaptura() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(105.dp)
            .background(Violeta.copy(alpha = 0.07f), RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, Violeta.copy(alpha = 0.28f)), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("▣", color = Violeta, fontSize = 23.sp)
            Spacer(Modifier.height(5.dp))
            Text("Captura del comprobante · demo", color = Texto, fontSize = 11.sp)
            Text("Aquí se ampliará la imagen real", color = Tenue, fontSize = 9.sp)
        }
    }
}

@Composable
private fun CrearCobro() {
    var titulo by remember { mutableStateOf("") }
    var monto by remember { mutableStateOf("") }
    var horas by remember { mutableStateOf("9") }
    var aviso by remember { mutableStateOf("") }
    var confirmarNuevo by remember { mutableStateOf(false) }
    var confirmarCierre by remember { mutableStateOf(false) }

    val activo = Caja.cobroActivo()

    if (activo != null) {
        Tarjeta(borde = Ambar.copy(alpha = 0.45f), fondo = PanelAlto) {
            Etiqueta("COBRO ABIERTO", Ambar)
            Spacer(Modifier.height(6.dp))
            FilaEntre {
                Text(activo.titulo, color = Texto, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(soles(activo.monto), color = Cian, fontSize = 16.sp, style = cifra)
            }
            Spacer(Modifier.height(6.dp))
            Text("Cierra ${fechaHora(activo.cierra)}", color = Tenue, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Pastilla("${Caja.aprobados(activo.id)} aprobados", Verde)
                Pastilla("${Caja.porRevisar(activo.id).size} por revisar", Ambar)
            }
            Spacer(Modifier.height(14.dp))
            Boton("Cerrar ahora y congelar acta", Modifier.fillMaxWidth(), color = Ambar) {
                confirmarCierre = true
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Solo puede existir un cobro abierto a la vez.", color = Tenue, fontSize = 11.sp)

        if (confirmarCierre) {
            Dialog(onDismissRequest = { confirmarCierre = false }) {
                Tarjeta(borde = Ambar.copy(alpha = 0.45f), fondo = PanelAlto) {
                    Titulo("¿Cerrar este cobro?")
                    Spacer(Modifier.height(6.dp))
                    Text("Se creará un acta con el estado actual de los registros asignados. En la app final esa acta no se editará.", color = Tenue, fontSize = 12.sp)
                    Spacer(Modifier.height(14.dp))
                    Boton("Sí, cerrar y guardar acta", Modifier.fillMaxWidth(), color = Ambar) {
                        Caja.cerrarCobro(activo.id)
                        confirmarCierre = false
                    }
                    Spacer(Modifier.height(8.dp))
                    Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { confirmarCierre = false }
                }
            }
        }
        return
    }

    val centavos = parseCentavos(monto) ?: 0L
    val h = horas.toIntOrNull() ?: 0

    Tarjeta {
        Titulo("Abrir un cobro")
        Spacer(Modifier.height(5.dp))
        Text("Define la cuota y el plazo. Todos los registros asignados verán el mismo cobro en la versión conectada.", color = Tenue, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        Etiqueta("CONCEPTO")
        Spacer(Modifier.height(6.dp))
        Campo(titulo, { titulo = it; aviso = "" }, "Día del Niño")
        Spacer(Modifier.height(12.dp))
        Etiqueta("MONTO POR PERSONA")
        Spacer(Modifier.height(6.dp))
        Campo(monto, { monto = it; aviso = "" }, "4.00", numerico = true)
        Spacer(Modifier.height(12.dp))
        Etiqueta("PLAZO EN HORAS")
        Spacer(Modifier.height(6.dp))
        Campo(horas, { horas = it.filter { c -> c.isDigit() }.take(3); aviso = "" }, "9", numerico = true)
        Spacer(Modifier.height(16.dp))
        Boton("Revisar y abrir", Modifier.fillMaxWidth()) {
            when {
                titulo.isBlank() -> aviso = "Ponle un nombre al cobro"
                centavos <= 0L -> aviso = "Escribe un monto válido"
                h <= 0 -> aviso = "Escribe un plazo válido"
                else -> confirmarNuevo = true
            }
        }
        if (aviso.isNotEmpty()) {
            Spacer(Modifier.height(9.dp))
            Text(aviso, color = Rojo, fontSize = 12.sp)
        }
    }

    if (confirmarNuevo) {
        Dialog(onDismissRequest = { confirmarNuevo = false }) {
            Tarjeta(borde = Cian.copy(alpha = 0.42f), fondo = PanelAlto) {
                Etiqueta("CONFIRMAR NUEVO COBRO", Cian)
                Spacer(Modifier.height(6.dp))
                Text(titulo.trim(), color = Texto, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                MiniDato("CUOTA", soles(centavos), Cian)
                Spacer(Modifier.height(8.dp))
                MiniDato("PLAZO", "$h horas", Ambar)
                Spacer(Modifier.height(14.dp))
                Boton("Abrir cobro", Modifier.fillMaxWidth()) {
                    Caja.crearCobro(titulo.trim(), centavos, h)
                    titulo = ""; monto = ""; horas = "9"; confirmarNuevo = false
                }
                Spacer(Modifier.height(8.dp))
                Boton("Volver a editar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { confirmarNuevo = false }
            }
        }
    }
}

@Composable
private fun Gastos() {
    var concepto by remember { mutableStateOf("") }
    var monto by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    var confirmar by remember { mutableStateOf(false) }

    val centavos = parseCentavos(monto) ?: 0L

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.weight(1f)) { MiniDato("SALDO", soles(Caja.saldo()), Verde) }
        Box(Modifier.weight(1f)) { MiniDato("DISPONIBLE", soles(Caja.disponibleParaGastos()), Cian) }
    }
    Spacer(Modifier.height(10.dp))

    Tarjeta {
        Titulo("Registrar un gasto")
        Spacer(Modifier.height(5.dp))
        Text("Se registra con tu firma. Solo baja el saldo cuando también firme el presidente.", color = Tenue, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        Etiqueta("CONCEPTO")
        Spacer(Modifier.height(6.dp))
        Campo(concepto, { concepto = it; aviso = "" }, "Bocaditos")
        Spacer(Modifier.height(11.dp))
        Etiqueta("MONTO")
        Spacer(Modifier.height(6.dp))
        Campo(monto, { monto = it; aviso = "" }, "20.00", numerico = true)
        Spacer(Modifier.height(14.dp))
        Boton("Revisar gasto", Modifier.fillMaxWidth()) {
            when {
                concepto.isBlank() -> aviso = "Escribe para qué fue el gasto"
                centavos <= 0L -> aviso = "Escribe un monto válido"
                centavos > Caja.disponibleParaGastos() -> aviso = "No alcanza: disponible ${soles(Caja.disponibleParaGastos())}"
                else -> confirmar = true
            }
        }
        if (aviso.isNotEmpty()) {
            Spacer(Modifier.height(9.dp))
            Text(aviso, color = Rojo, fontSize = 12.sp)
        }
    }

    Spacer(Modifier.height(14.dp))
    Firmas(comoPresidente = false)

    if (confirmar) {
        Dialog(onDismissRequest = { confirmar = false }) {
            Tarjeta(borde = Ambar.copy(alpha = 0.40f), fondo = PanelAlto) {
                Etiqueta("CONFIRMAR GASTO", Ambar)
                Spacer(Modifier.height(5.dp))
                Text(concepto.trim(), color = Texto, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(soles(centavos), color = Rojo, fontSize = 25.sp, style = cifra)
                Spacer(Modifier.height(7.dp))
                Text("Quedará con tu firma y esperando la del presidente. Todavía no bajará el saldo.", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                Boton("Registrar con mi firma", Modifier.fillMaxWidth(), color = Ambar) {
                    Caja.crearGasto(concepto.trim(), centavos)
                    concepto = ""; monto = ""; confirmar = false
                }
                Spacer(Modifier.height(8.dp))
                Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { confirmar = false }
            }
        }
    }
}

@Composable
private fun Firmas(comoPresidente: Boolean) {
    val pendientes = Caja.gastosPorFirmar()
    Etiqueta("GASTOS ESPERANDO FIRMA")
    Spacer(Modifier.height(9.dp))
    if (pendientes.isEmpty()) Vacio("No hay gastos pendientes de firma.")

    pendientes.forEach { g ->
        Tarjeta(borde = Ambar.copy(alpha = 0.40f)) {
            FilaEntre {
                Column(Modifier.weight(1f)) {
                    Text(g.concepto, color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(3.dp))
                    Text(fechaHora(g.fecha), color = Tenue, fontSize = 10.sp)
                }
                Text(soles(g.monto), color = Rojo, fontSize = 15.sp, style = cifra)
            }
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Pastilla(if (g.firmaTesorero) "Tesorero ✓" else "Tesorero pendiente", if (g.firmaTesorero) Verde else Tenue)
                Pastilla(if (g.firmaPresidente) "Presidente ✓" else "Presidente pendiente", if (g.firmaPresidente) Verde else Ambar)
            }
            Spacer(Modifier.height(8.dp))
            Text("Este gasto todavía no baja el saldo hasta completar las dos firmas.", color = Tenue, fontSize = 10.sp)

            val faltaLaMia = if (comoPresidente) !g.firmaPresidente else !g.firmaTesorero
            if (faltaLaMia) {
                Spacer(Modifier.height(13.dp))
                Boton("Firmar gasto", Modifier.fillMaxWidth(), color = Verde) {
                    Caja.firmarGasto(g.id, comoPresidente)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun Socios() {
    var liberar by remember { mutableStateOf<Int?>(null) }

    Tarjeta(fondo = PanelAlto) {
        Etiqueta("CONTRASEÑAS")
        Spacer(Modifier.height(5.dp))
        Text("Liberar no muestra ni cambia la contraseña desde el panel. Abre una ventana de 24 horas para crear una nueva.", color = Tenue, fontSize = 11.sp)
    }
    Spacer(Modifier.height(10.dp))

    Caja.socios.forEach { s ->
        val abierto = Caja.reseteoAbierto(s.numero)
        Tarjeta(borde = if (abierto) Ambar.copy(alpha = 0.50f) else Borde) {
            FilaEntre {
                Column(Modifier.weight(1f)) {
                    Text("${s.numero.toString().padStart(2, '0')} · ${s.nombre}", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        when {
                            abierto -> "Liberada · quedan ~${Caja.horasDeReseteo(s.numero)} h"
                            !Caja.tieneClave(s.numero) -> "Primera entrada pendiente"
                            s.rol == Rol.TESORERO -> "Tesorero · clave creada"
                            s.rol == Rol.PRESIDENTE -> "Presidente · clave creada"
                            else -> "Socio activo · clave creada"
                        },
                        color = if (abierto) Ambar else Tenue,
                        fontSize = 10.sp
                    )
                }
                if (!abierto && Caja.tieneClave(s.numero)) {
                    Boton("Liberar", Modifier.width(88.dp), relleno = false, color = Ambar) { liberar = s.numero }
                }
            }
        }
        Spacer(Modifier.height(7.dp))
    }

    liberar?.let { numero ->
        val s = Caja.socio(numero)
        Dialog(onDismissRequest = { liberar = null }) {
            Tarjeta(borde = Ambar.copy(alpha = 0.45f), fondo = PanelAlto) {
                Etiqueta("LIBERAR CONTRASEÑA", Ambar)
                Spacer(Modifier.height(6.dp))
                Text("N° $numero · ${s?.nombre.orEmpty()}", color = Texto, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(7.dp))
                Text("Tendrá 24 horas para crear una nueva contraseña. Esta acción quedará en la bitácora.", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                Boton("Sí, liberar por 24 h", Modifier.fillMaxWidth(), color = Ambar) {
                    Caja.resetear(numero)
                    liberar = null
                }
                Spacer(Modifier.height(8.dp))
                Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { liberar = null }
            }
        }
    }
}
