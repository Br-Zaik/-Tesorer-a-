package com.tesoreria.caja.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.parseCentavos
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.delay

private enum class PasoSubida { VACIO, LEYENDO, REVISAR, ENVIADO }

@Composable
fun PantallaSubir(alVolver: () -> Unit) {
    val yo = Caja.sesion.value ?: return
    val cobro = Caja.cobroActivo()

    var paso by remember { mutableStateOf(PasoSubida.VACIO) }
    var monto by remember { mutableStateOf("") }
    var operacion by remember { mutableStateOf("") }
    var fechaDetectada by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    var enviando by remember { mutableStateOf(false) }

    if (cobro == null) {
        Tarjeta {
            Titulo("No hay cobro abierto")
            Spacer(Modifier.height(6.dp))
            Text("No puedes subir un comprobante hasta que exista un cobro activo.", color = Tenue, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            Boton("Volver", Modifier.fillMaxWidth(), relleno = false) { alVolver() }
        }
        return
    }

    LaunchedEffect(paso) {
        if (paso == PasoSubida.LEYENDO) {
            delay(1500)
            // Aquí irá ML Kit. En la maqueta simulamos una lectura realista.
            monto = "${cobro.monto / 100}.${(cobro.monto % 100).toString().padStart(2, '0')}"
            operacion = "0091${300 + yo.numero}"
            fechaDetectada = fechaHora(System.currentTimeMillis())
            paso = PasoSubida.REVISAR
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Etiqueta("SUBIR COMPROBANTE")
        Spacer(Modifier.height(8.dp))
        Pasos(paso)
        Spacer(Modifier.height(12.dp))

        Tarjeta(borde = Cian.copy(alpha = 0.28f)) {
            FilaEntre {
                Column(Modifier.weight(1f)) {
                    Etiqueta("COBRO")
                    Spacer(Modifier.height(4.dp))
                    Text(cobro.titulo, color = Texto, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                }
                Text(soles(cobro.monto), color = Cian, fontSize = 17.sp, style = cifra)
            }
            Spacer(Modifier.height(7.dp))
            Text("Tu comprobante quedará pendiente hasta que el tesorero vea el dinero en su Yape.", color = Tenue, fontSize = 11.sp)
        }

        Spacer(Modifier.height(12.dp))

        when (paso) {
            PasoSubida.VACIO -> Tarjeta {
                Titulo("Elige la captura de Yape")
                Spacer(Modifier.height(6.dp))
                Text(
                    "En la versión final podrás elegir galería o cámara. Esta maqueta simula la captura para probar el flujo.",
                    color = Tenue, fontSize = 13.sp
                )
                Spacer(Modifier.height(16.dp))
                MarcoVacio()
                Spacer(Modifier.height(16.dp))
                Boton("Simular captura", Modifier.fillMaxWidth()) { paso = PasoSubida.LEYENDO }
                Spacer(Modifier.height(8.dp))
                Boton("Volver", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { alVolver() }
            }

            PasoSubida.LEYENDO -> Tarjeta(borde = Cian.copy(alpha = 0.35f)) {
                Titulo("Leyendo la captura")
                Spacer(Modifier.height(5.dp))
                Text("OCR local · buscando monto, fecha y número de operación", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                ConstanciaFalsa(escaneando = true, monto = cobro.monto)
                Spacer(Modifier.height(14.dp))
                Pastilla("Procesando en el dispositivo", Cian)
            }

            PasoSubida.REVISAR -> {
                val centavos = parseCentavos(monto) ?: 0L
                val vencido = System.currentTimeMillis() >= cobro.cierra

                Tarjeta {
                    Titulo("Confirma los datos")
                    Spacer(Modifier.height(5.dp))
                    Text("El OCR puede equivocarse. Corrige cualquier dato antes de enviar.", color = Tenue, fontSize = 12.sp)
                    Spacer(Modifier.height(14.dp))
                    ConstanciaFalsa(escaneando = false, monto = centavos.takeIf { it > 0 } ?: cobro.monto)
                    Spacer(Modifier.height(16.dp))

                    Etiqueta("MONTO DETECTADO")
                    Spacer(Modifier.height(6.dp))
                    Campo(monto, { monto = it; aviso = "" }, "4.00", numerico = true)
                    Spacer(Modifier.height(11.dp))

                    Etiqueta("NÚMERO DE OPERACIÓN")
                    Spacer(Modifier.height(6.dp))
                    Campo(
                        operacion,
                        { operacion = it.filter { c -> c.isDigit() }.take(20); aviso = "" },
                        "00000000",
                        numerico = true
                    )
                    Spacer(Modifier.height(11.dp))

                    Etiqueta("FECHA LEÍDA")
                    Spacer(Modifier.height(6.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .background(Fondo, RoundedCornerShape(12.dp))
                            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Text(fechaDetectada, color = Texto, fontSize = 13.sp)
                    }

                    if (centavos > 0 && centavos != cobro.monto) {
                        Spacer(Modifier.height(10.dp))
                        Pastilla("⚠ Monto distinto a ${soles(cobro.monto)}", Ambar)
                    }
                    if (vencido) {
                        Spacer(Modifier.height(10.dp))
                        Pastilla("✕ El plazo ya venció", Rojo)
                    }

                    Spacer(Modifier.height(16.dp))
                    Boton(
                        "Confirmar y enviar",
                        Modifier.fillMaxWidth(),
                        activo = !enviando && !vencido
                    ) {
                        when {
                            centavos <= 0L -> aviso = "Escribe un monto válido"
                            operacion.length < 4 -> aviso = "Falta el número de operación"
                            Caja.operacionRepetida(operacion, socioActual = yo.numero) ->
                                aviso = "Esa operación ya fue registrada por otro pago"
                            System.currentTimeMillis() >= cobro.cierra ->
                                aviso = "El plazo cerró mientras subías. Habla con el tesorero."
                            else -> {
                                enviando = true
                                Caja.registrarPago(cobro.id, yo.numero, centavos, operacion, centavos)
                                enviando = false
                                paso = PasoSubida.ENVIADO
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Boton("Cambiar captura", Modifier.fillMaxWidth(), relleno = false, color = Tenue) {
                        paso = PasoSubida.VACIO
                        aviso = ""
                    }

                    if (aviso.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text(aviso, color = Rojo, fontSize = 12.sp)
                    }
                }
            }

            PasoSubida.ENVIADO -> Tarjeta(borde = Ambar.copy(alpha = 0.50f), fondo = PanelAlto) {
                Box(
                    Modifier
                        .size(48.dp)
                        .background(Ambar.copy(alpha = 0.13f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("•", color = Ambar, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                Titulo("Comprobante recibido")
                Spacer(Modifier.height(6.dp))
                Text(
                    "Tu número ya está en ámbar. Eso significa que ya enviaste; todavía no significa que el pago esté aprobado.",
                    color = Tenue, fontSize = 13.sp
                )
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(Ambar.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                        .border(BorderStroke(1.dp, Ambar.copy(alpha = 0.25f)), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Text("El tesorero debe confirmar que el dinero llegó a su cuenta.", color = Ambar, fontSize = 12.sp)
                }
                Spacer(Modifier.height(16.dp))
                Boton("Volver al inicio", Modifier.fillMaxWidth()) { alVolver() }
            }
        }
    }
}

@Composable
private fun Pasos(paso: PasoSubida) {
    val actual = when (paso) {
        PasoSubida.VACIO -> 1
        PasoSubida.LEYENDO -> 1
        PasoSubida.REVISAR -> 2
        PasoSubida.ENVIADO -> 3
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("1 Captura", "2 Revisar", "3 Enviar").forEachIndexed { i, texto ->
            val activo = i + 1 <= actual
            Box(
                Modifier
                    .weight(1f)
                    .background(if (activo) Cian.copy(alpha = 0.10f) else Panel, RoundedCornerShape(9.dp))
                    .border(BorderStroke(1.dp, if (activo) Cian.copy(alpha = 0.28f) else Borde), RoundedCornerShape(9.dp))
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(texto, color = if (activo) Cian else Tenue, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun MarcoVacio() {
    Column(
        Modifier
            .fillMaxWidth()
            .height(165.dp)
            .background(Fondo, RoundedCornerShape(14.dp))
            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(14.dp)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("▣", color = Cian, fontSize = 28.sp)
        Spacer(Modifier.height(8.dp))
        Text("Sin captura todavía", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(3.dp))
        Text("PNG o JPG en la versión final", color = Tenue, fontSize = 10.sp)
    }
}

/** Constancia visual de demo. Luego se sustituye por la imagen real del usuario. */
@Composable
private fun ConstanciaFalsa(escaneando: Boolean, monto: Long) {
    val t = rememberInfiniteTransition(label = "scan")
    val brillo by t.animateFloat(
        initialValue = 0.28f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(850, easing = LinearEasing), RepeatMode.Reverse),
        label = "brillo"
    )

    Column(
        Modifier
            .fillMaxWidth()
            .background(Violeta.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
            .border(
                BorderStroke(1.dp, if (escaneando) Cian.copy(alpha = brillo) else Violeta.copy(alpha = 0.35f)),
                RoundedCornerShape(14.dp)
            )
            .padding(16.dp)
    ) {
        FilaEntre {
            Text("Constancia Yape · demo", color = Violeta, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Pastilla(if (escaneando) "LEYENDO" else "LISTA", if (escaneando) Cian else Verde)
        }
        Spacer(Modifier.height(12.dp))
        Text(
            soles(monto),
            color = Texto,
            fontSize = 27.sp,
            style = cifra,
            modifier = Modifier.alpha(if (escaneando) brillo else 1f)
        )
        Spacer(Modifier.height(12.dp))
        LineaFalsa(0.78f)
        Spacer(Modifier.height(7.dp))
        LineaFalsa(0.56f)
        Spacer(Modifier.height(7.dp))
        LineaFalsa(0.66f)
    }
}

@Composable
private fun LineaFalsa(ancho: Float) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        Box(
            Modifier
                .fillMaxWidth(ancho)
                .height(8.dp)
                .background(Tenue.copy(alpha = 0.18f), RoundedCornerShape(4.dp))
        )
        Spacer(Modifier.width(1.dp))
    }
}
