package com.tesoreria.caja.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.data.Socio
import kotlinx.coroutines.delay

private enum class Paso { SPLASH, NUMERO, CONFIRMAR, CLAVE, NUEVA_CLAVE }
private enum class Modo { USUARIO, ADMIN }

@Composable
fun PantallaLogin(alEntrar: (Socio) -> Unit) {
    var paso by remember { mutableStateOf(Paso.SPLASH) }
    var modo by remember { mutableStateOf(Modo.USUARIO) }
    var numero by remember { mutableStateOf("") }
    var clave by remember { mutableStateOf("") }
    var clave2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        delay(1250)
        paso = Paso.NUMERO
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Fondo)
    ) {
        FondoAnimado()

        AnimatedContent(
            targetState = paso,
            transitionSpec = {
                (fadeIn(tween(320)) + slideInVertically(tween(420)) { it / 10 }) togetherWith
                    (fadeOut(tween(220)) + slideOutVertically(tween(300)) { -it / 12 })
            },
            label = "loginFlow"
        ) { actual ->
            when (actual) {
                Paso.SPLASH -> SplashPremium()
                else -> LoginContenido(
                    paso = actual,
                    modo = modo,
                    numero = numero,
                    clave = clave,
                    clave2 = clave2,
                    error = error,
                    cambiarModo = { modo = it; error = "" },
                    cambiarNumero = { numero = it.filter(Char::isDigit).take(2); error = "" },
                    cambiarClave = { clave = it; error = "" },
                    cambiarClave2 = { clave2 = it; error = "" },
                    volver = {
                        error = ""
                        clave = ""
                        clave2 = ""
                        paso = when (actual) {
                            Paso.CONFIRMAR -> Paso.NUMERO
                            Paso.CLAVE, Paso.NUEVA_CLAVE -> Paso.CONFIRMAR
                            else -> Paso.NUMERO
                        }
                    },
                    continuarNumero = {
                        val n = numero.toIntOrNull()
                        val socio = n?.let(Caja::socio)
                        when {
                            n == null || n !in 1..35 -> error = "Escribe un número válido del 1 al 35"
                            socio == null && n in 31..35 -> error = "Ese puesto está libre por ahora"
                            socio == null -> error = "Ese número no está registrado"
                            modo == Modo.ADMIN && socio.rol == Rol.SOCIO -> error = "Este acceso es solo para administración"
                            else -> paso = Paso.CONFIRMAR
                        }
                    },
                    confirmarIdentidad = {
                        val socio = numero.toIntOrNull()?.let(Caja::socio)
                        if (socio != null) {
                            paso = if (Caja.necesitaCrearClave(socio.numero)) Paso.NUEVA_CLAVE else Paso.CLAVE
                            error = ""
                        }
                    },
                    iniciar = {
                        val socio = numero.toIntOrNull()?.let(Caja::socio)
                        if (socio == null) error = "No se encontró la cuenta"
                        else if (Caja.validar(socio.numero, clave)) alEntrar(socio)
                        else error = "Contraseña incorrecta"
                    },
                    crear = {
                        val socio = numero.toIntOrNull()?.let(Caja::socio)
                        if (socio == null) error = "No se encontró la cuenta"
                        else {
                            val n = socio.numero
                            val esLiberacion = Caja.tieneClave(n)
                            when {
                                esLiberacion && !Caja.reseteoAbierto(n) -> error = "La autorización de 24 horas ya venció"
                                clave.length < 6 -> error = "Usa al menos 6 caracteres"
                                clave != clave2 -> error = "Las contraseñas no coinciden"
                                clave == n.toString() || clave == n.toString().padStart(2, '0') -> error = "No uses tu número de lista como contraseña"
                                else -> {
                                    Caja.crearClave(n, clave)
                                    alEntrar(socio)
                                }
                            }
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun SplashPremium() {
    val inf = rememberInfiniteTransition(label = "splash")
    val pulso by inf.animateFloat(0.94f, 1.05f, infiniteRepeatable(tween(950), RepeatMode.Reverse), label = "pulse")
    val glow by inf.animateFloat(0.18f, 0.55f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "glow")
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(126.dp).scale(pulso), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                drawCircle(VerdeBrillante.copy(alpha = glow), style = Stroke(width = 2.dp.toPx()))
                drawCircle(VerdeNeon.copy(alpha = 0.08f), radius = size.minDimension * .38f)
            }
            Icon(Icons.Rounded.VerifiedUser, null, tint = VerdeBrillante, modifier = Modifier.size(62.dp))
        }
        Spacer(Modifier.height(28.dp))
        Text("Tesorería", color = Texto, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(7.dp))
        Text("Control · Orden · Transparencia", color = Tenue, fontSize = 13.sp)
        Spacer(Modifier.height(42.dp))
        BarraCarga()
        Spacer(Modifier.height(11.dp))
        Text("Preparando tu espacio…", color = Tenue, fontSize = 11.sp)
    }
}

@Composable
private fun LoginContenido(
    paso: Paso,
    modo: Modo,
    numero: String,
    clave: String,
    clave2: String,
    error: String,
    cambiarModo: (Modo) -> Unit,
    cambiarNumero: (String) -> Unit,
    cambiarClave: (String) -> Unit,
    cambiarClave2: (String) -> Unit,
    volver: () -> Unit,
    continuarNumero: () -> Unit,
    confirmarIdentidad: () -> Unit,
    iniciar: () -> Unit,
    crear: () -> Unit
) {
    val socio = numero.toIntOrNull()?.let(Caja::socio)
    Column(
        Modifier.fillMaxSize().padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (paso != Paso.NUMERO) {
            Row(Modifier.fillMaxWidth()) {
                Box(
                    Modifier.size(42.dp).background(Panel, CircleShape).border(1.dp, Borde, CircleShape).clickable { volver() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.ArrowBack, null, tint = Texto, modifier = Modifier.size(20.dp)) }
            }
            Spacer(Modifier.height(14.dp))
        }

        GlowMark()
        Spacer(Modifier.height(18.dp))

        when (paso) {
            Paso.NUMERO -> {
                Text("Bienvenido", color = Texto, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("Inicia sesión para continuar", color = Tenue, fontSize = 13.sp)
                Spacer(Modifier.height(24.dp))
                SegmentedMode(modo, cambiarModo)
                Spacer(Modifier.height(18.dp))
                TarjetaPremium {
                    Etiqueta(if (modo == Modo.ADMIN) "ACCESO DE ADMINISTRACIÓN" else "ACCESO PERSONAL", VerdeBrillante)
                    Spacer(Modifier.height(10.dp))
                    Campo(numero, cambiarNumero, "Número de lista · Ej. 22", numerico = true)
                    Spacer(Modifier.height(14.dp))
                    Boton(if (modo == Modo.ADMIN) "Continuar como administrador  →" else "Continuar  →", Modifier.fillMaxWidth()) { continuarNumero() }
                }
                Spacer(Modifier.height(18.dp))
                Text("Acceso local seguro para probar la aplicación", color = Tenue.copy(alpha = .74f), fontSize = 10.sp)
            }
            Paso.CONFIRMAR -> {
                Text("Confirma tu acceso", color = Texto, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(5.dp))
                Text("Verifica los datos antes de continuar", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(22.dp))
                TarjetaPremium {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(50.dp).background(VerdeNeon.copy(alpha = .10f), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                            Icon(if (modo == Modo.ADMIN) Icons.Rounded.AdminPanelSettings else Icons.Rounded.Shield, null, tint = VerdeBrillante)
                        }
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text(socio?.nombre.orEmpty(), color = Texto, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(3.dp))
                            Text("N.º ${socio?.numero ?: ""} · ${rolBonito(socio?.rol)}", color = Tenue, fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Boton("Sí, continuar  →", Modifier.fillMaxWidth()) { confirmarIdentidad() }
                    Spacer(Modifier.height(9.dp))
                    Boton("No, volver", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { volver() }
                }
            }
            Paso.CLAVE -> {
                Text("Ingresa tu contraseña", color = Texto, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(5.dp))
                Text("N.º ${socio?.numero} · ${socio?.nombre?.substringBefore(" ")}", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(22.dp))
                TarjetaPremium {
                    Campo(clave, cambiarClave, "Contraseña", clave = true)
                    Spacer(Modifier.height(14.dp))
                    Boton("Iniciar sesión  →", Modifier.fillMaxWidth()) { iniciar() }
                    Spacer(Modifier.height(12.dp))
                    Text("¿Olvidaste tu contraseña? Solicita una liberación al tesorero.", color = VerdeBrillante, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
            Paso.NUEVA_CLAVE -> {
                Text("Crea tu contraseña", color = Texto, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(5.dp))
                Text("Será tu acceso personal", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(22.dp))
                TarjetaPremium {
                    Campo(clave, cambiarClave, "Nueva contraseña", clave = true)
                    Spacer(Modifier.height(10.dp))
                    Campo(clave2, cambiarClave2, "Confirmar contraseña", clave = true)
                    Spacer(Modifier.height(15.dp))
                    ReglaClave(clave.length >= 6, "Al menos 6 caracteres")
                    ReglaClave(clave != numero && clave != numero.padStart(2, '0'), "No uses tu número de lista")
                    ReglaClave(clave.isNotEmpty() && clave == clave2, "Ambas contraseñas coinciden")
                    Spacer(Modifier.height(15.dp))
                    Boton("Crear contraseña  →", Modifier.fillMaxWidth()) { crear() }
                }
            }
            else -> Unit
        }

        AnimatedVisibility(visible = error.isNotBlank()) {
            Box(
                Modifier.fillMaxWidth().padding(top = 13.dp).background(Rojo.copy(alpha = .10f), RoundedCornerShape(13.dp)).border(1.dp, Rojo.copy(alpha = .35f), RoundedCornerShape(13.dp)).padding(11.dp)
            ) { Text(error, color = Rojo, fontSize = 11.sp) }
        }

        if (paso == Paso.CLAVE) {
            Spacer(Modifier.height(16.dp))
            Text("Demo offline · contraseña inicial 123456", color = Tenue.copy(alpha = .65f), fontSize = 9.sp)
        }
    }
}

@Composable
private fun SegmentedMode(modo: Modo, cambiar: (Modo) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).border(1.dp, Borde, RoundedCornerShape(16.dp)).padding(4.dp)) {
        ModoItem("Usuario", modo == Modo.USUARIO, Modifier.weight(1f)) { cambiar(Modo.USUARIO) }
        ModoItem("Administrador", modo == Modo.ADMIN, Modifier.weight(1f)) { cambiar(Modo.ADMIN) }
    }
}

@Composable
private fun ModoItem(texto: String, activo: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.height(44.dp).background(if (activo) GradientePrincipal else androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)), RoundedCornerShape(13.dp)).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(texto, color = if (activo) FondoProfundo else Tenue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ReglaClave(ok: Boolean, texto: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
        Icon(Icons.Rounded.CheckCircle, null, tint = if (ok) Verde else Tenue.copy(alpha = .45f), modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(8.dp))
        Text(texto, color = if (ok) Texto else Tenue, fontSize = 11.sp)
    }
}

@Composable
private fun GlowMark() {
    val inf = rememberInfiniteTransition(label = "mark")
    val giro by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(6500, easing = LinearEasing)), label = "spin")
    val pulso by inf.animateFloat(.3f, .75f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "pulse")
    Box(Modifier.size(86.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().rotate(giro)) {
            drawArc(VerdeBrillante.copy(alpha = pulso), -40f, 210f, false, style = Stroke(width = 2.dp.toPx()))
            drawArc(VerdeNeon.copy(alpha = .25f), 190f, 110f, false, style = Stroke(width = 4.dp.toPx()))
        }
        Box(Modifier.size(61.dp).background(VerdeBrillante.copy(alpha = .08f), CircleShape).border(1.dp, VerdeBrillante.copy(alpha = .38f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Lock, null, tint = VerdeBrillante, modifier = Modifier.size(29.dp))
        }
    }
}

@Composable
private fun FondoAnimado() {
    val inf = rememberInfiniteTransition(label = "bg")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Reverse), label = "t")
    Canvas(Modifier.fillMaxSize()) {
        val r = size.minDimension * .55f
        drawCircle(VerdeBrillante.copy(alpha = .035f), r, Offset(size.width * (.8f - .1f * t), size.height * .12f))
        drawCircle(VerdeNeon.copy(alpha = .025f), r * .75f, Offset(size.width * .08f, size.height * (.82f + .05f * t)))
    }
}

@Composable
private fun BarraCarga() {
    val inf = rememberInfiniteTransition(label = "load")
    val p by inf.animateFloat(.15f, .82f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "progress")
    Box(Modifier.width(180.dp).height(5.dp).background(Borde.copy(alpha = .55f), RoundedCornerShape(9.dp))) {
        Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(GradientePrincipal, RoundedCornerShape(9.dp)))
    }
}

private fun rolBonito(rol: Rol?): String = when (rol) {
    Rol.TESORERO -> "Tesorero"
    Rol.PRESIDENTE -> "Presidente"
    else -> "Usuario"
}
