package com.tesoreria.caja.data

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil

/*
 * MAQUETA LOCAL: todo vive solo en memoria y se reinicia al cerrar la app.
 * Esta capa imita las reglas del producto final para poder probar bien las interfaces.
 */

val PE: Locale = Locale("es", "PE")

fun soles(centavos: Long): String =
    String.format(PE, "S/ %,.2f", centavos / 100.0)

fun fechaHora(t: Long): String =
    SimpleDateFormat("dd/MM/yyyy HH:mm", PE).format(Date(t))

fun fechaCorta(t: Long): String =
    SimpleDateFormat("dd/MM/yyyy", PE).format(Date(t))

/** Convierte texto de dinero a céntimos SIN usar Double. */
fun parseCentavos(texto: String): Long? {
    var s = texto.trim().replace("S/", "", ignoreCase = true).replace(" ", "")
    if (s.isBlank()) return null

    s = when {
        s.contains(',') && s.contains('.') -> s.replace(",", "") // 1,250.50
        s.contains(',') -> s.replace(',', '.') // 4,50
        else -> s
    }

    if (!s.matches(Regex("\\d+(\\.\\d{0,2})?"))) return null
    val partes = s.split('.')
    val entero = partes[0].toLongOrNull() ?: return null
    val dec = when {
        partes.size == 1 -> 0L
        partes[1].isEmpty() -> 0L
        partes[1].length == 1 -> partes[1].toLong() * 10L
        else -> partes[1].take(2).toLong()
    }
    return entero * 100L + dec
}

enum class EstadoPago { SIN_ENVIAR, PENDIENTE, APROBADO, RECHAZADO }
enum class Rol { SOCIO, PRESIDENTE, TESORERO }

data class Socio(
    val numero: Int,
    val nombre: String,
    val rol: Rol = Rol.SOCIO
)

data class Cobro(
    val id: Int,
    val titulo: String,
    val monto: Long,
    val creado: Long,
    val cierra: Long,
    val cerrado: Boolean = false
)

data class Pago(
    val id: Int,
    val cobroId: Int,
    val socio: Int,
    val monto: Long,
    val estado: EstadoPago,
    val enviado: Long,
    val operacion: String,
    val ocrMonto: Long,
    val nota: String = ""
)

data class Gasto(
    val id: Int,
    val concepto: String,
    val monto: Long,
    val fecha: Long,
    val firmaTesorero: Boolean = false,
    val firmadoTesoreroEn: Long? = null,
    val firmaPresidente: Boolean = false,
    val firmadoPresidenteEn: Long? = null,
    val anulado: Boolean = false,
    val motivoAnulacion: String = ""
) {
    val aprobado: Boolean get() = firmaTesorero && firmaPresidente && !anulado
}

data class Acta(
    val cobroId: Int,
    val titulo: String,
    val monto: Long,
    val cierre: Long,
    val recaudado: Long,
    val pagaron: List<Int>,
    val faltaron: List<Int>,
    val estados: Map<Int, EstadoPago> = emptyMap()
)

object Caja {

    val socios = mutableStateListOf<Socio>()
    val cobros = mutableStateListOf<Cobro>()
    val pagos = mutableStateListOf<Pago>()
    val gastos = mutableStateListOf<Gasto>()
    val actas = mutableStateListOf<Acta>()
    val bitacora = mutableStateListOf<String>()

    private val claves = mutableMapOf<Int, String>()
    private val reseteos = mutableMapOf<Int, Long>()

    val sesion = mutableStateOf<Socio?>(null)

    private var seqCobro = 1
    private var seqPago = 1
    private var seqGasto = 1

    val esAdmin: Boolean get() = sesion.value?.rol == Rol.TESORERO
    val esPresidente: Boolean get() = sesion.value?.rol == Rol.PRESIDENTE

    // ---------- saldo ----------

    fun ingresos(): Long = pagos.filter { it.estado == EstadoPago.APROBADO }.sumOf { it.monto }
    fun egresos(): Long = gastos.filter { it.aprobado }.sumOf { it.monto }
    fun saldo(): Long = ingresos() - egresos()

    /** Reserva visual para no registrar más gastos pendientes de los que el saldo soporta. */
    fun comprometidoPendiente(): Long = gastos
        .filter { !it.aprobado && !it.anulado && it.firmaTesorero }
        .sumOf { it.monto }

    fun disponibleParaGastos(): Long = (saldo() - comprometidoPendiente()).coerceAtLeast(0L)

    // ---------- cobros ----------

    fun cobroActivo(): Cobro? = cobros.firstOrNull { !it.cerrado }

    private fun ultimoPago(cobroId: Int, numero: Int): Pago? =
        pagos.filter { it.cobroId == cobroId && it.socio == numero }.maxByOrNull { it.id }

    fun estadoDe(cobroId: Int, numero: Int): EstadoPago =
        ultimoPago(cobroId, numero)?.estado ?: EstadoPago.SIN_ENVIAR

    fun pagoDe(cobroId: Int, numero: Int): Pago? = ultimoPago(cobroId, numero)

    fun faltantes(cobroId: Int): List<Int> = socios.map { it.numero }
        .filter { estadoDe(cobroId, it) != EstadoPago.APROBADO }
        .sorted()

    fun noEnviaron(cobroId: Int): List<Int> = socios.map { it.numero }
        .filter { estadoDe(cobroId, it) == EstadoPago.SIN_ENVIAR }
        .sorted()

    fun porRevisar(cobroId: Int): List<Int> = socios.map { it.numero }
        .filter { estadoDe(cobroId, it) == EstadoPago.PENDIENTE }
        .sorted()

    fun rechazados(cobroId: Int): List<Int> = socios.map { it.numero }
        .filter { estadoDe(cobroId, it) == EstadoPago.RECHAZADO }
        .sorted()

    fun aprobados(cobroId: Int): Int = socios.count { estadoDe(cobroId, it.numero) == EstadoPago.APROBADO }

    fun recaudado(cobroId: Int): Long = pagos
        .filter { it.cobroId == cobroId && it.estado == EstadoPago.APROBADO }
        .sumOf { it.monto }

    fun crearCobro(titulo: String, monto: Long, horas: Int) {
        if (cobroActivo() != null) return
        val ahora = System.currentTimeMillis()
        cobros.add(
            Cobro(
                id = seqCobro++,
                titulo = titulo,
                monto = monto,
                creado = ahora,
                cierra = ahora + horas * 3_600_000L
            )
        )
        anotar("abrió el cobro \"$titulo\" por ${soles(monto)}, plazo $horas h")
    }

    fun cerrarCobro(id: Int) {
        val i = cobros.indexOfFirst { it.id == id }
        if (i < 0 || cobros[i].cerrado) return
        val c = cobros[i]
        cobros[i] = c.copy(cerrado = true)

        val estados = socios.associate { it.numero to estadoDe(id, it.numero) }
        val pagaron = estados.filterValues { it == EstadoPago.APROBADO }.keys.sorted()
        val faltaron = estados.filterValues { it != EstadoPago.APROBADO }.keys.sorted()

        actas.add(
            Acta(
                cobroId = id,
                titulo = c.titulo,
                monto = c.monto,
                cierre = System.currentTimeMillis(),
                recaudado = recaudado(id),
                pagaron = pagaron,
                faltaron = faltaron,
                estados = estados
            )
        )
        anotar("cerró el cobro \"${c.titulo}\" y guardó el acta")
    }

    /** Respaldo local de la maqueta: cierra lo vencido mientras la app está abierta. */
    fun revisarVencidos() {
        val ahora = System.currentTimeMillis()
        cobros.filter { !it.cerrado && it.cierra <= ahora }.forEach { cerrarCobro(it.id) }
    }

    // ---------- pagos ----------

    fun registrarPago(cobroId: Int, numero: Int, monto: Long, operacion: String, ocr: Long) {
        val cobro = cobros.firstOrNull { it.id == cobroId } ?: return
        if (cobro.cerrado || System.currentTimeMillis() >= cobro.cierra) return

        // Nunca se elimina el pago rechazado anterior: el nuevo intento queda como otro registro.
        pagos.add(
            Pago(
                id = seqPago++,
                cobroId = cobroId,
                socio = numero,
                monto = monto,
                estado = EstadoPago.PENDIENTE,
                enviado = System.currentTimeMillis(),
                operacion = operacion.trim(),
                ocrMonto = ocr
            )
        )
        anotar("envió comprobante del socio $numero por ${soles(monto)}")
    }

    fun aprobarPago(id: Int) {
        val i = pagos.indexOfFirst { it.id == id }
        if (i < 0 || pagos[i].estado != EstadoPago.PENDIENTE) return
        pagos[i] = pagos[i].copy(estado = EstadoPago.APROBADO)
        anotar("aprobó el pago del socio ${pagos[i].socio} por ${soles(pagos[i].monto)}")
    }

    fun rechazarPago(id: Int, motivo: String) {
        val i = pagos.indexOfFirst { it.id == id }
        if (i < 0 || pagos[i].estado != EstadoPago.PENDIENTE) return
        pagos[i] = pagos[i].copy(estado = EstadoPago.RECHAZADO, nota = motivo.trim())
        anotar("rechazó el pago del socio ${pagos[i].socio}: ${motivo.trim()}")
    }

    fun pendientes(): List<Pago> = pagos
        .filter { it.estado == EstadoPago.PENDIENTE }
        .sortedByDescending { it.enviado }

    /** En la demo, permite reusar la misma operación solo si era un rechazo del mismo socio. */
    fun operacionRepetida(operacion: String, exceptoPago: Int = -1, socioActual: Int? = null): Boolean =
        pagos.any {
            it.operacion == operacion.trim() &&
                it.id != exceptoPago &&
                !(socioActual != null && it.socio == socioActual && it.estado == EstadoPago.RECHAZADO)
        }

    // ---------- gastos ----------

    fun crearGasto(concepto: String, monto: Long) {
        if (monto <= 0L || monto > disponibleParaGastos()) return
        val ahora = System.currentTimeMillis()
        gastos.add(
            Gasto(
                id = seqGasto++,
                concepto = concepto,
                monto = monto,
                fecha = ahora,
                firmaTesorero = true,
                firmadoTesoreroEn = ahora
            )
        )
        anotar("registró el gasto \"$concepto\" por ${soles(monto)}; falta firma del presidente")
    }

    fun firmarGasto(id: Int, comoPresidente: Boolean) {
        val i = gastos.indexOfFirst { it.id == id }
        if (i < 0 || gastos[i].anulado) return
        val ahora = System.currentTimeMillis()
        gastos[i] = if (comoPresidente) {
            if (gastos[i].firmaPresidente) return
            gastos[i].copy(firmaPresidente = true, firmadoPresidenteEn = ahora)
        } else {
            if (gastos[i].firmaTesorero) return
            gastos[i].copy(firmaTesorero = true, firmadoTesoreroEn = ahora)
        }
        anotar(
            if (comoPresidente) "firmó como presidente el gasto \"${gastos[i].concepto}\""
            else "firmó como tesorero el gasto \"${gastos[i].concepto}\""
        )
    }

    fun gastosPorFirmar(): List<Gasto> = gastos.filter { !it.aprobado && !it.anulado }

    // ---------- claves ----------

    fun tieneClave(numero: Int): Boolean = claves.containsKey(numero)

    fun reseteoAbierto(numero: Int): Boolean {
        val hasta = reseteos[numero] ?: return false
        if (hasta <= System.currentTimeMillis()) {
            reseteos.remove(numero)
            return false
        }
        return true
    }

    fun horasDeReseteo(numero: Int): Long {
        val hasta = reseteos[numero] ?: return 0
        val ms = (hasta - System.currentTimeMillis()).coerceAtLeast(0L)
        return ceil(ms / 3_600_000.0).toLong()
    }

    fun necesitaCrearClave(numero: Int): Boolean = !tieneClave(numero) || reseteoAbierto(numero)

    fun crearClave(numero: Int, clave: String) {
        claves[numero] = clave
        reseteos.remove(numero)
        anotar("creó una nueva contraseña para el socio $numero")
    }

    fun validar(numero: Int, clave: String): Boolean = claves[numero] == clave

    fun resetear(numero: Int) {
        if (!tieneClave(numero)) return
        // La clave anterior se conserva en esta maqueta. Si la ventana vence, vuelve a pedirse esa clave.
        reseteos[numero] = System.currentTimeMillis() + 24 * 3_600_000L
        anotar("liberó la contraseña del socio $numero por 24 h")
    }

    fun socio(numero: Int): Socio? = socios.firstOrNull { it.numero == numero }

    private fun anotar(accion: String) {
        val actor = sesion.value
        val quien = if (actor == null) "Sistema" else "N° ${actor.numero} ${actor.nombre.substringBefore(" ")}"
        bitacora.add(0, "${fechaHora(System.currentTimeMillis())}  ·  $quien  ·  $accion")
    }

    // ---------- demo ----------

    fun cargarDemo() {
        if (socios.isNotEmpty()) return

        val nombres = listOf(
            "Ronny Edilberto Afata Gonzales",
            "Yesber Alferez Ancalle",
            "Luz Clarita Alvarez Huancara",
            "Rosales Arphi Pauccara",
            "Cinthya Luz Berna Laura",
            "Ruben Carlos Pucho",
            "Alahor Castro Quispe",
            "Jamil Elar Ccorahua Ccama",
            "Ronaldiño Ccorimanya Yauri",
            "Jhon Tony Champi Tarifa",
            "Fausto Checca Huaylla",
            "Karen Massiel Chuchullo Pari",
            "Lisbeth Katerine Condori Saico",
            "Luz Eliana Cuti Cusihuaman",
            "Franklin Roberto Florez Condori",
            "Nayely Merly Huamanchoque Puma",
            "Delia Yuli Huamani Condorcahuana",
            "Brayan Jhonatan Huarca Anccasi",
            "Fabian Alexis Kana Chaco",
            "Jessica Gladys Leandro Ramirez",
            "Reiner Mendigure Katata",
            "Brian Pacco Huayhua",
            "Jhon Jhojan Pacco Quispe",
            "Katy Rosalia Phacsi Callahuasi",
            "Bhunden Fhan Alex Quispe Puma",
            "Williams Manuel Suclle Hancco",
            "Oscar Rene Suico Cuti",
            "Ronal Alex Suico Cuti",
            "Rodrigo Diego Umasi Hualla",
            "Zulma Nayely Velazco Florez"
        )
        nombres.forEachIndexed { i, nombre ->
            val numero = i + 1
            val rol = if (numero == 22) Rol.TESORERO else Rol.SOCIO
            socios.add(Socio(numero, nombre, rol))
        }

        // Maqueta offline: clave general de prueba. 12 y 27 conservan el flujo de primera entrada.
        // El N° 22 (Brian Pacco Huayhua) entra como tesorero con 123456.
        socios.forEach { if (it.numero != 12 && it.numero != 27) claves[it.numero] = "123456" }

        val ahora = System.currentTimeMillis()

        // Cobro ya cerrado, con acta congelada.
        cobros.add(
            Cobro(
                id = seqCobro++, titulo = "Cuota agosto", monto = 2500,
                creado = ahora - 40 * 24 * 3_600_000L,
                cierra = ahora - 38 * 24 * 3_600_000L, cerrado = true
            )
        )
        val pagaronAgosto = (1..30).filterNot { it in listOf(9, 21) }
        pagaronAgosto.forEach {
            pagos.add(
                Pago(
                    seqPago++, 1, it, 2500, EstadoPago.APROBADO,
                    ahora - 39 * 24 * 3_600_000L, "0086${400 + it}", 2500
                )
            )
        }
        val estadosAgosto = (1..30).associateWith {
            if (it in pagaronAgosto) EstadoPago.APROBADO else EstadoPago.SIN_ENVIAR
        }
        actas.add(
            Acta(
                cobroId = 1, titulo = "Cuota agosto", monto = 2500,
                cierre = ahora - 38 * 24 * 3_600_000L,
                recaudado = pagaronAgosto.size * 2500L,
                pagaron = pagaronAgosto,
                faltaron = listOf(9, 21),
                estados = estadosAgosto
            )
        )

        // Cobro activo para probar los cuatro estados visuales.
        cobros.add(
            Cobro(
                id = seqCobro++, titulo = "Día del Niño", monto = 400,
                creado = ahora - 5 * 3_600_000L,
                cierra = ahora + 9 * 3_600_000L
            )
        )
        val aprobados = listOf(1, 2, 3, 5, 7, 8, 10, 11, 13, 14, 16, 17, 18, 20, 22, 23, 24, 25, 27, 28, 29)
        aprobados.forEach {
            pagos.add(
                Pago(
                    seqPago++, 2, it, 400, EstadoPago.APROBADO,
                    ahora - 3 * 3_600_000L, "0091${200 + it}", 400
                )
            )
        }
        listOf(4, 12, 19).forEach {
            pagos.add(
                Pago(
                    seqPago++, 2, it, 400, EstadoPago.PENDIENTE,
                    ahora - 40 * 60_000L, "0091${200 + it}", 400
                )
            )
        }
        pagos.add(
            Pago(
                seqPago++, 2, 30, 400, EstadoPago.RECHAZADO,
                ahora - 70 * 60_000L, "0091${230}", 400,
                nota = "No figura en la cuenta del tesorero"
            )
        )

        gastos.add(
            Gasto(
                seqGasto++, "Bocaditos reunión de agosto", 6000,
                ahora - 30 * 24 * 3_600_000L,
                firmaTesorero = true, firmadoTesoreroEn = ahora - 30 * 24 * 3_600_000L,
                firmaPresidente = true, firmadoPresidenteEn = ahora - 29 * 24 * 3_600_000L
            )
        )
        gastos.add(
            Gasto(
                seqGasto++, "Globos y sorpresas", 4500,
                ahora - 2 * 3_600_000L,
                firmaTesorero = true, firmadoTesoreroEn = ahora - 2 * 3_600_000L,
                firmaPresidente = false
            )
        )

        anotar("cargó los datos de demostración")
    }
}
