package com.tesoreria.caja

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Caja.cargarDemo()
        setContent { CajaTheme { App() } }
    }
}

private enum class Vista { INICIO, SUBIR, MOVIMIENTOS, ARCHIVO, PANEL }

@Composable
fun App() {
    val yo = Caja.sesion.value
    var vista by remember { mutableStateOf(Vista.INICIO) }

    if (yo == null) {
        PantallaLogin { s ->
            Caja.sesion.value = s
            Caja.revisarVencidos()
            vista = Vista.INICIO
        }
        return
    }

    val conPanel = yo.rol == Rol.TESORERO || yo.rol == Rol.PRESIDENTE
    val rolTexto = when (yo.rol) {
        Rol.TESORERO -> "Tesorero"
        Rol.PRESIDENTE -> "Presidente"
        Rol.SOCIO -> "Usuario"
    }

    Column(Modifier.fillMaxSize().background(Fondo)) {
        // Cabecera limpia tipo app publicada: saludo, identidad y salida discreta.
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 14.dp, top = 18.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Hola, ${yo.nombre.substringBefore(" ")}", color = Texto, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(3.dp))
                Text("N.º ${yo.numero} · $rolTexto", color = Tenue, fontSize = 11.sp)
            }
            Box(
                Modifier.size(43.dp).background(Panel, CircleShape).clickable {
                    Caja.sesion.value = null
                    vista = Vista.INICIO
                },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Logout, "Cerrar sesión", tint = Tenue, modifier = Modifier.size(20.dp))
            }
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp).padding(bottom = 22.dp)
        ) {
            when (vista) {
                Vista.INICIO -> PantallaInicio { vista = Vista.SUBIR }
                Vista.SUBIR -> PantallaSubir { vista = Vista.INICIO }
                Vista.MOVIMIENTOS -> PantallaMovimientos()
                Vista.ARCHIVO -> PantallaArchivo()
                Vista.PANEL -> PantallaPanel()
            }
        }

        BarraInferior(
            vista = vista,
            conPanel = conPanel,
            onInicio = { vista = Vista.INICIO },
            onMovimientos = { vista = Vista.MOVIMIENTOS },
            onArchivo = { vista = Vista.ARCHIVO },
            onPanel = { vista = Vista.PANEL }
        )
    }
}

@Composable
private fun BarraInferior(
    vista: Vista,
    conPanel: Boolean,
    onInicio: () -> Unit,
    onMovimientos: () -> Unit,
    onArchivo: () -> Unit,
    onPanel: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().background(FondoProfundo).padding(horizontal = 9.dp, vertical = 8.dp).navigationBarsPadding(),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        NavItem("Inicio", Icons.Rounded.Home, vista == Vista.INICIO || vista == Vista.SUBIR, Modifier.weight(1f), onInicio)
        NavItem("Movimientos", Icons.Rounded.ReceiptLong, vista == Vista.MOVIMIENTOS, Modifier.weight(1f), onMovimientos)
        NavItem("Actas", Icons.Rounded.FolderOpen, vista == Vista.ARCHIVO, Modifier.weight(1f), onArchivo)
        if (conPanel) {
            NavItem("Panel", Icons.Rounded.Tune, vista == Vista.PANEL, Modifier.weight(1f), onPanel)
        }
    }
}

@Composable
private fun NavItem(texto: String, icono: ImageVector, activa: Boolean, modifier: Modifier, alTocar: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val escala by animateFloatAsState(if (pressed) .94f else 1f, spring(stiffness = 700f), label = "navScale")
    val color by animateColorAsState(if (activa) VerdeNeon else Tenue, label = "navColor")
    Column(
        modifier.scale(escala).height(56.dp).background(if (activa) VerdeNeon.copy(alpha = .08f) else Color.Transparent, RoundedCornerShape(15.dp))
            .clickable(interactionSource = interaction, indication = null) { alTocar() },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icono, texto, tint = color, modifier = Modifier.size(21.dp))
        Spacer(Modifier.height(3.dp))
        Text(texto, color = color, fontSize = 9.sp, fontWeight = if (activa) FontWeight.Bold else FontWeight.Medium)
    }
}
