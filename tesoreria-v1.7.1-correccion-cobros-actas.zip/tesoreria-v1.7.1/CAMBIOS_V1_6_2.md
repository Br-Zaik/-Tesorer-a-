# Tesorería v1.6.2

versionCode 24

## Cambios

- Eliminado por completo el OCR del APK y retirada la dependencia ML Kit Text Recognition.
- El envío Yape usa únicamente la foto del comprobante como evidencia.
- El monto del pago Yape se toma directamente del cobro activo en el servidor.
- Se mantiene la huella SHA-256 de la imagen para impedir reutilizar exactamente la misma captura en otro pago.
- Nuevo permiso delegable `Gestionar Yape`.
- Un miembro con `Gestionar Yape` puede cambiar el número Yape, revisar capturas Yape y aprobar/rechazar esos pagos cuando el tesorero no esté.
- El acceso a las capturas privadas en Supabase Storage también respeta `Gestionar Yape`.
- Quitados textos pequeños y explicaciones redundantes en la carga de comprobantes y configuración Yape.
- Eliminados campos y textos de monto/operación detectados por OCR.
- Se conserva la vista completa de la captura con zoom.
