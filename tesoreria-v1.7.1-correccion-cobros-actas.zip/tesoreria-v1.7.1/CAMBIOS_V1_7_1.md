# Tesorería v1.7.1

- versionName: 1.7.1
- versionCode: 28
- Liberar plaza corregido y limitado a N.º 31–35.
- Cobro rápido usa el mismo flujo real de pagos que el oficial: Yape o pago manual.
- Cada cobro activo tiene su propia cuadrícula 1–35.
- Pago manual permite elegir el cobro oficial o rápido antes de registrar.
- Actas separadas en Oficiales, Rápidas y Bitácora, con pestañas fijas.
- Vista admin distingue medio de pago: Yape morado y manual verde oscuro, manteniendo el estado del pago.
- PDFs se guardan en Descargas/Tesoreria y luego ofrecen Abrir o Cerrar, sin compartir automáticamente.
- Subir comprobante muestra claramente si corresponde a cobro oficial o rápido.
