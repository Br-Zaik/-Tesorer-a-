package com.tesoreria.caja.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Pago
import com.tesoreria.caja.data.soles

@Composable
fun MiniaturaComprobante(
    bitmap: Bitmap?,
    modifier: Modifier = Modifier,
    alTocar: (() -> Unit)? = null
) {
    val base = modifier
        .fillMaxWidth()
        .height(184.dp)
        .background(FondoProfundo, RoundedCornerShape(16.dp))
        .border(1.dp, Borde, RoundedCornerShape(16.dp))
    Box(
        if (alTocar != null) base.clickable { alTocar() } else base,
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null && !bitmap.isRecycled) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Comprobante",
                modifier = Modifier.fillMaxSize().padding(8.dp),
                contentScale = ContentScale.Fit
            )
            if (alTocar != null) {
                Box(
                    Modifier.align(Alignment.BottomEnd).padding(10.dp)
                        .background(PanelAlto.copy(alpha = .94f), RoundedCornerShape(99.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) { Text("Ver completa", color = VerdeBrillante, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            }
        } else {
            Icon(Icons.Rounded.ReceiptLong, null, tint = Tenue, modifier = Modifier.size(42.dp))
        }
    }
}

@Composable
fun VisorBitmapDialog(bitmap: Bitmap, cerrar: () -> Unit) {
    var escala by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    Dialog(
        onDismissRequest = cerrar,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(Modifier.fillMaxSize().background(FondoProfundo.copy(alpha = .96f))) {
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            escala = (escala * zoom).coerceIn(1f, 5f)
                            if (escala > 1f) {
                                offsetX += pan.x
                                offsetY += pan.y
                            } else {
                                offsetX = 0f; offsetY = 0f
                            }
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Comprobante completo",
                    modifier = Modifier.fillMaxWidth().fillMaxHeight()
                        .padding(horizontal = 8.dp, vertical = 56.dp)
                        .graphicsLayer {
                            scaleX = escala; scaleY = escala
                            translationX = offsetX; translationY = offsetY
                        },
                    contentScale = ContentScale.Fit
                )
            }
            Row(
                Modifier.fillMaxWidth().align(Alignment.TopCenter)
                    .background(PanelAlto.copy(alpha = .92f)).padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Comprobante completo", color = Texto, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(10.dp))
                BotonCerrar(cerrar)
            }
        }
    }
}

@Composable
fun VisorPagoDialog(pago: Pago, cerrar: () -> Unit) {
    var bitmap by remember(pago.serverId) { mutableStateOf<Bitmap?>(null) }
    var pantallaCompleta by remember(pago.serverId) { mutableStateOf(false) }
    var error by remember(pago.serverId) { mutableStateOf("") }
    var cargando by remember(pago.serverId) { mutableStateOf(true) }

    LaunchedEffect(pago.serverId) {
        cargando = true
        error = ""
        try {
            val bytes = Caja.comprobanteBytes(pago)
            bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: throw IllegalStateException("No se pudo abrir la captura")
        } catch (e: Exception) {
            error = e.message ?: "No se pudo abrir el comprobante"
        } finally {
            cargando = false
        }
    }

    Dialog(
        onDismissRequest = cerrar,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            Modifier.fillMaxSize().background(FondoProfundo.copy(alpha = .78f)).padding(horizontal = 12.dp, vertical = 18.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier.fillMaxWidth().fillMaxHeight(.94f)
                    .background(PanelAlto, RoundedCornerShape(24.dp))
                    .border(1.dp, Borde, RoundedCornerShape(24.dp))
                    .padding(14.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Etiqueta("COMPROBANTE YAPE", VerdeBrillante)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "N.º ${pago.socio} · ${Caja.socio(pago.socio)?.nombre.orEmpty()}",
                            color = Texto,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    BotonCerrar(cerrar)
                }
                Spacer(Modifier.height(10.dp))

                // Solo esta zona se desplaza. El encabezado y el botón Cerrar siempre quedan visibles.
                Column(
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
                        .padding(end = 2.dp)
                ) {
                    when {
                        cargando -> Box(
                            Modifier.fillMaxWidth().height(150.dp).background(FondoProfundo, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Abriendo comprobante…", color = Tenue, fontSize = 12.sp)
                        }
                        bitmap != null -> Box(
                            Modifier.fillMaxWidth().background(FondoProfundo, RoundedCornerShape(14.dp)).padding(7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                bitmap = bitmap!!.asImageBitmap(),
                                contentDescription = "Captura enviada",
                                modifier = Modifier.fillMaxWidth().heightIn(min = 230.dp, max = 410.dp),
                                contentScale = ContentScale.Fit
                            )
                        }
                        else -> Box(
                            Modifier.fillMaxWidth().height(150.dp).background(FondoProfundo, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Rounded.BrokenImage, null, tint = Rojo, modifier = Modifier.size(34.dp))
                                Spacer(Modifier.height(7.dp))
                                Text(error.ifBlank { "No hay imagen disponible" }, color = Rojo, fontSize = 11.sp)
                            }
                        }
                    }

                    if (bitmap != null) {
                        Spacer(Modifier.height(10.dp))
                        Boton("Ver imagen completa", Modifier.fillMaxWidth(), relleno = false, color = Cian) { pantallaCompleta = true }
                    }
                    Spacer(Modifier.height(12.dp))
                    MiniDato("MONTO DEL COBRO", soles(pago.monto), Verde)
                    Spacer(Modifier.height(4.dp))
                }

                Spacer(Modifier.height(10.dp))
                Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
            }
        }
    }
    if (pantallaCompleta && bitmap != null) {
        VisorBitmapDialog(bitmap!!) { pantallaCompleta = false }
    }
}

@Composable
private fun BotonCerrar(cerrar: () -> Unit) {
    Box(
        Modifier.size(38.dp).background(FondoProfundo, CircleShape)
            .border(1.dp, Borde, CircleShape).clickable { cerrar() },
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.Close, "Cerrar", tint = Texto, modifier = Modifier.size(20.dp))
    }
}
