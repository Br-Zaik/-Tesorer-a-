package com.tesoreria.caja.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.util.Locale
import kotlin.math.max

/** Carga local de la captura y calcula una huella para detectar reutilizaciones exactas. */
object ComprobanteImagen {
    data class Resultado(
        val bytes: ByteArray,
        val mime: String,
        val bitmap: Bitmap,
        val capturaDHash: Long
    )

    suspend fun leer(context: Context, uri: Uri): Resultado = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val mimeOriginal = resolver.getType(uri)?.lowercase(Locale.ROOT) ?: "image/jpeg"
        if (mimeOriginal !in setOf("image/jpeg", "image/png", "image/webp", "image/heic", "image/heif")) {
            throw IllegalStateException("Selecciona una imagen")
        }
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("No se pudo abrir la imagen")
        if (bytes.isEmpty()) throw IllegalStateException("La imagen está vacía")
        if (bytes.size > 10 * 1024 * 1024) throw IllegalStateException("La imagen supera 10 MB")

        val bitmap = decodificar(bytes) ?: throw IllegalStateException("No se pudo leer la imagen")
        Resultado(
            bytes = bytes,
            mime = normalizarMime(mimeOriginal),
            bitmap = bitmap,
            capturaDHash = calcularDHash(bitmap)
        )
    }

    private fun normalizarMime(v: String): String = when (v) {
        "image/png" -> "image/png"
        "image/webp" -> "image/webp"
        else -> "image/jpeg"
    }

    private fun decodificar(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > 2800) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null

        val orientation = runCatching {
            ExifInterface(ByteArrayInputStream(bytes)).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
        }
        if (matrix.isIdentity) return decoded

        val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (rotated !== decoded && !decoded.isRecycled) decoded.recycle()
        return rotated
    }

    private fun calcularDHash(bitmap: Bitmap): Long {
        val reducido = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
        return try {
            var hash = 0L
            var bit = 0
            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    val a = reducido.getPixel(x, y)
                    val b = reducido.getPixel(x + 1, y)
                    val ga = ((android.graphics.Color.red(a) * 299) +
                        (android.graphics.Color.green(a) * 587) +
                        (android.graphics.Color.blue(a) * 114)) / 1000
                    val gb = ((android.graphics.Color.red(b) * 299) +
                        (android.graphics.Color.green(b) * 587) +
                        (android.graphics.Color.blue(b) * 114)) / 1000
                    if (ga > gb) hash = hash or (1L shl bit)
                    bit++
                }
            }
            hash
        } finally {
            if (reducido !== bitmap && !reducido.isRecycled) reducido.recycle()
        }
    }
}
