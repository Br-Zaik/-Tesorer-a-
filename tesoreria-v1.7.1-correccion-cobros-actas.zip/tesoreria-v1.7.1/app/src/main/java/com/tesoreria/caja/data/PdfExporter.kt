package com.tesoreria.caja.data

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat

object PdfExporter {
    data class PdfGuardado(val uri: Uri, val nombre: String)

    fun guardarActa(context: Context, acta: Acta, admin: Boolean): PdfGuardado {
        val lineas = mutableListOf<String>()
        val cobro = Caja.cobros.firstOrNull { it.id == acta.cobroId }
        lineas += if (acta.tipo == TipoCobro.RAPIDO) "RESUMEN DE COBRO RÁPIDO" else "ACTA DE COBRO OFICIAL"
        lineas += "Cobro: ${acta.titulo}"
        lineas += "Cuota: ${soles(acta.monto)}"
        lineas += "Recaudado: ${soles(acta.recaudado)}"
        cobro?.let {
            lineas += "Apertura: ${fechaLarga(it.creado)} · ${horaCorta(it.creado)}"
            lineas += "Cierre programado: ${fechaLarga(it.cierra)} · ${horaCorta(it.cierra)}"
        }
        lineas += "Cierre real: ${fechaLarga(acta.cierre)} · ${horaCorta(acta.cierre)}"
        cobro?.let { lineas += "Duración: ${duracion(it.cierra - it.creado)}" }
        lineas += ""

        fun grupo(titulo: String, estado: EstadoPago) {
            val numeros = acta.estados.filterValues { it == estado }.keys.sorted()
            lineas += "$titulo (${numeros.size})"
            if (admin) {
                if (numeros.isEmpty()) lineas += "  - Ninguno"
                numeros.forEach { n ->
                    val d = acta.detalles[n]
                    val nombre = d?.nombreSnapshot?.ifBlank { Caja.socio(n)?.nombre.orEmpty() } ?: Caja.socio(n)?.nombre.orEmpty()
                    val pago = Caja.pagos.filter { it.cobroId == acta.cobroId && it.socio == n }.maxByOrNull { it.enviado }
                    val info = buildList {
                        add("N° $n")
                        if (nombre.isNotBlank()) add(nombre)
                        if (pago != null) {
                            add(soles(pago.monto))
                            add(if (pago.medio == MedioPago.MANUAL) "Manual" else "Yape")
                            add("${fechaLarga(pago.enviado)} ${horaCorta(pago.enviado)}")
                        } else {
                            d?.monto?.let { add(soles(it)) }
                            d?.medio?.let { add(if (it == MedioPago.MANUAL) "Manual" else "Yape") }
                        }
                    }.joinToString(" · ")
                    lineas += "  - $info"
                }
            } else {
                lineas += if (numeros.isEmpty()) "  - Ninguno" else "  - " + numeros.joinToString(", ") { "N° $it" }
            }
            lineas += ""
        }

        grupo("Pagaron", EstadoPago.APROBADO)
        grupo("Pendientes", EstadoPago.PENDIENTE)
        grupo("Rechazados", EstadoPago.RECHAZADO)
        grupo("No enviaron", EstadoPago.SIN_ENVIAR)
        return guardarPdf(context, "acta-${limpio(acta.titulo)}.pdf", lineas)
    }

    fun guardarBitacora(context: Context, admin: Boolean): PdfGuardado {
        val eventos = if (admin) Caja.bitacora else Caja.bitacoraPublica()
        val lineas = mutableListOf<String>()
        lineas += "BITÁCORA DE TESORERÍA"
        lineas += "Generado: ${fechaLarga(System.currentTimeMillis())} · ${horaCorta(System.currentTimeMillis())}"
        lineas += "Eventos: ${eventos.size}"
        lineas += ""
        if (eventos.isEmpty()) lineas += "No hay eventos registrados."
        var fechaAnterior = ""
        eventos.forEach { e ->
            val m = Regex("^(\\d{2}/\\d{2}/\\d{4}) (\\d{2}:\\d{2})\\s+·\\s+(.*)$").find(e)
            if (m == null) {
                lineas += e
                return@forEach
            }
            val fecha = m.groupValues[1]
            val hora = m.groupValues[2]
            val resto = m.groupValues[3]
            if (fecha != fechaAnterior) {
                val ms = runCatching { SimpleDateFormat("dd/MM/yyyy", PE).parse(fecha)?.time }.getOrNull()
                lineas += if (ms != null) fechaLarga(ms) else fecha
                fechaAnterior = fecha
            }
            lineas += "  $hora · $resto"
        }
        return guardarPdf(context, "bitacora-tesoreria.pdf", lineas)
    }

    fun abrir(context: Context, pdf: PdfGuardado) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(pdf.uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Abrir PDF"))
    }

    private fun guardarPdf(context: Context, nombre: String, lineas: List<String>): PdfGuardado {
        val doc = crearDocumento(lineas)
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, nombre)
                    put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Tesoreria")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("No se pudo crear el PDF")
                resolver.openOutputStream(uri)?.use { doc.writeTo(it) }
                    ?: throw IllegalStateException("No se pudo guardar el PDF")
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                PdfGuardado(uri, nombre)
            } else {
                val dir = File(context.cacheDir, "exports").apply { mkdirs() }
                val file = File(dir, nombre)
                file.outputStream().use { doc.writeTo(it) }
                val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
                PdfGuardado(uri, nombre)
            }
        } finally {
            doc.close()
        }
    }

    private fun crearDocumento(lineas: List<String>): PdfDocument {
        val doc = PdfDocument()
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(0, 55, 35)
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(25, 25, 25); textSize = 10.5f }
        val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(90, 90, 90); textSize = 8.5f }
        val pageW = 595
        val pageH = 842
        val left = 42f
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
        var y = 48f

        fun footer() {
            page.canvas.drawText("Tesorería · Respaldo PDF · Página $pageNo", left, pageH - 28f, small)
        }

        fun newPage() {
            footer()
            doc.finishPage(page)
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
            y = 48f
        }

        lineas.forEachIndexed { idx, raw ->
            val paint = if (idx == 0) title else body
            val wrapped = wrap(raw, if (idx == 0) 54 else 92)
            wrapped.forEach { linea ->
                if (y > pageH - 58f) newPage()
                page.canvas.drawText(linea, left, y, paint)
                y += if (idx == 0) 24f else 16f
            }
            if (raw.isBlank()) y += 4f
        }
        footer()
        doc.finishPage(page)
        return doc
    }

    private fun wrap(text: String, max: Int): List<String> {
        if (text.isBlank()) return listOf("")
        val out = mutableListOf<String>()
        var line = ""
        text.split(" ").forEach { word ->
            if ((line.length + word.length + 1) > max && line.isNotBlank()) {
                out += line
                line = word
            } else line = if (line.isBlank()) word else "$line $word"
        }
        if (line.isNotBlank()) out += line
        return out
    }

    private fun limpio(v: String): String = v.lowercase(PE).replace(Regex("[^a-z0-9]+"), "-").trim('-').ifBlank { "cobro" }

    private fun duracion(ms: Long): String {
        val min = (ms / 60000L).coerceAtLeast(0)
        val h = min / 60
        val m = min % 60
        return if (h > 0) "$h h $m min" else "$m min"
    }
}
