-- Tesorería v1.6.4: idempotencia para acciones críticas.
-- Aplicado en Supabase el 13/09/2026.

create table if not exists public.operaciones_idempotentes (
  actor_uid uuid not null,
  request_id uuid not null,
  operacion text not null,
  resultado jsonb not null default '{"ok":true}'::jsonb,
  creado_at timestamptz not null default now(),
  primary key (actor_uid, request_id)
);

alter table public.operaciones_idempotentes enable row level security;
revoke all on public.operaciones_idempotentes from anon, authenticated;

-- La función ejecutar_operacion_idempotente está instalada en el servidor.
-- La app envía un request_id único y puede reintentar la misma acción sin duplicarla.
