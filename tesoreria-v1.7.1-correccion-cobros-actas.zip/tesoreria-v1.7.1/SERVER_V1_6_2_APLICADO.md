# Servidor aplicado para Tesorería v1.6.2

Aplicado directamente al proyecto Supabase de Tesorería.

- Añadido `gestionar_yape` al enum `permiso_tipo`.
- Añadida función `puede_gestionar_yape()`.
- `guardar_yape_config()` permite tesorero o miembro con `gestionar_yape`.
- `revisar_pago_yape()` permite tesorero o miembro con `gestionar_yape`.
- RLS de `pagos_privados` actualizado para el permiso Yape.
- Política de Storage de comprobantes actualizada para el permiso Yape.
- Añadidos RPC `validar_comprobante_yape_foto()` y `enviar_pago_yape_foto()` sin OCR.
- Los nuevos pagos Yape toman el monto del cobro del servidor y guardan solo la captura como evidencia privada.
