# Tesorería v1.6.3 — carga inmediata y sincronización optimizada

- versionCode 25 / versionName 1.6.3.
- Inicio ya no aparece con saldo/cobro vacíos mientras llegan los datos.
- Login y restauración esperan un snapshot completo antes de mostrar la app.
- Se reemplazaron más de 12 consultas HTTP de carga por un solo RPC de Supabase: `cargar_app_snapshot_v1`.
- Se eliminó la recarga duplicada que ocurría inmediatamente después de entrar.
- La sincronización periódica continúa cada 30 segundos y las operaciones siguen refrescando al terminar.
- Mantiene RLS: el snapshot es SECURITY INVOKER y respeta los permisos del usuario autenticado.
