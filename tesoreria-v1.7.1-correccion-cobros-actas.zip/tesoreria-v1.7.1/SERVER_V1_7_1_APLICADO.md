# Servidor Tesorería v1.7.1 aplicado

- `liberar_plaza_db` corregido para cumplir `miembro_libre_valido`.
- Al liberar, `nombre` y `auth_user_id` quedan NULL, rol socio y estado libre.
- Liberación restringida exclusivamente a plazas 31–35.
- Edge Function `liberar-plaza` actualizada con la misma restricción.
- El historial anterior se conserva.
- RPC nuevos de v1.7 restringidos para que `anon` no pueda ejecutarlos; requieren sesión autenticada.
