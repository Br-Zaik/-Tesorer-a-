# Tesorería 1.6.4

- Las acciones críticas usan request_id idempotente en Supabase: un reintento por microcorte no duplica cobros, pagos, gastos ni aprobaciones.
- Una sincronización lenta posterior a una acción ya guardada no se muestra como error de la acción.
- Se elimina el aviso "La conexión tardó demasiado" de la interfaz.
- Si realmente no hay acceso, aparece una pantalla de reconexión automática estilo app financiera.
- Al recuperar Internet se sincroniza inmediatamente.
- El código temporal de 24 h incorpora botón Copiar.
