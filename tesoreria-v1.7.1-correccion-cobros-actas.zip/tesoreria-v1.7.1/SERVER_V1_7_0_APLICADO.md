# Servidor Tesorería v1.7.0 aplicado

Cambios aplicados directamente al proyecto Supabase de Tesorería:

- `cobros.tipo`: `oficial` / `rapido`.
- `actas.tipo`: `oficial` / `rapido`.
- Máximo un cobro oficial activo; hasta tres cobros activos en total mediante validación de RPC.
- RPC `crear_cobro_v2` con duración en minutos.
- RPC `marcar_pago_rapido`.
- Los pagos rápidos no forman parte del saldo oficial y se eliminan cuando el cobro rápido cierra, después de generar su resumen.
- RPC `eliminar_acta` solo para tesorero.
- Edge Function `liberar-plaza` para liberar plaza y eliminar la cuenta Auth asociada.
- Generación de códigos 24 h atómica: un solo código activo por miembro.
- Código recuperable de forma segura por el tesorero para códigos generados desde v1.7.0.
- `activar-cuenta` v3 con `request_id` idempotente y reintentos seguros.
- Snapshot de app actualizado con tipo de cobro, tipo de acta y datos administrativos de revisión.
