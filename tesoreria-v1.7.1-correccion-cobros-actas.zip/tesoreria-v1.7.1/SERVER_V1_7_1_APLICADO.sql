-- Aplicado en Supabase para Tesorería v1.7.1
-- Corrige Liberar plaza y la limita a N.º 31–35.

create or replace function public.liberar_plaza_db(p_numero smallint, p_actor smallint)
returns uuid
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_uid uuid;
begin
  if not exists(
    select 1 from public.miembros
    where numero = p_actor and rol = 'tesorero' and estado = 'activo'
  ) then
    raise exception 'Tesorero no válido';
  end if;

  if p_numero < 31 or p_numero > 35 then
    raise exception 'Solo las plazas 31 al 35 pueden volver a quedar libres';
  end if;

  select auth_user_id into v_uid
  from public.miembros
  where numero = p_numero and estado <> 'libre'
  for update;

  if not found then raise exception 'La plaza ya está libre'; end if;

  delete from public.permisos_miembro where socio_numero = p_numero;
  update public.reseteos_contrasena
     set cancelado_at = coalesce(cancelado_at, now())
   where socio_numero = p_numero and usado_at is null and cancelado_at is null;

  update public.miembros
     set nombre = null,
         rol = 'socio',
         estado = 'libre',
         auth_user_id = null,
         actualizado_at = now()
   where numero = p_numero;

  insert into public.bitacora(actor_numero,nivel,publico,evento,entidad,entidad_id,detalle)
  values(p_actor,'critico',false,'Plaza liberada','miembro',p_numero::text,
         'N.º '||p_actor||' liberó la plaza N.º '||p_numero||'. El historial anterior se conserva.');

  return v_uid;
end;
$function$;

-- Seguridad adicional aplicada: los RPC nuevos no son ejecutables por anon.
revoke all on function public.crear_cobro_v2(text,bigint,integer,text) from public, anon;
grant execute on function public.crear_cobro_v2(text,bigint,integer,text) to authenticated;
revoke all on function public.eliminar_acta(uuid) from public, anon;
grant execute on function public.eliminar_acta(uuid) to authenticated;
revoke all on function public.marcar_pago_rapido(uuid,boolean) from public, anon;
grant execute on function public.marcar_pago_rapido(uuid,boolean) to authenticated;
