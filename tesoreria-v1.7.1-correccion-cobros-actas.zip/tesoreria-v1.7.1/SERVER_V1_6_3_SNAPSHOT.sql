-- Tesorería v1.6.3
-- Aplicado en Supabase: carga inicial compacta en una sola llamada.
create or replace function public.cargar_app_snapshot_v1()
returns jsonb
language sql
security invoker
set search_path = public, pg_temp
as $$
select jsonb_build_object(
  'mi_numero', public.mi_numero(),
  'miembros', coalesce((select jsonb_agg(to_jsonb(x) order by x.numero) from (
      select numero,nombre,rol,estado from public.miembros where estado <> 'libre' order by numero
  ) x), '[]'::jsonb),
  'permisos', coalesce((select jsonb_agg(to_jsonb(x) order by x.socio_numero, x.permiso) from (
      select socio_numero,permiso from public.permisos_miembro order by socio_numero,permiso
  ) x), '[]'::jsonb),
  'cobros', coalesce((select jsonb_agg(to_jsonb(x) order by x.creado_at desc) from (
      select * from public.cobros order by creado_at desc
  ) x), '[]'::jsonb),
  'pagos', coalesce((select jsonb_agg(to_jsonb(x) order by x.enviado_at desc) from (
      select id,cobro_id,socio_numero,medio,estado,monto_centavos,enviado_at
      from public.pagos where vigente = true order by enviado_at desc
  ) x), '[]'::jsonb),
  'privados', coalesce((select jsonb_agg(to_jsonb(x)) from (
      select pago_id,motivo_rechazo,captura_path,captura_sha256 from public.pagos_privados
  ) x), '[]'::jsonb),
  'gastos', coalesce((select jsonb_agg(to_jsonb(x) order by x.registrado_at desc) from (
      select * from public.gastos order by registrado_at desc
  ) x), '[]'::jsonb),
  'actas', coalesce((select jsonb_agg(to_jsonb(x) order by x.cerrado_at desc) from (
      select * from public.actas order by cerrado_at desc
  ) x), '[]'::jsonb),
  'detalle_publico', coalesce((select jsonb_agg(to_jsonb(x)) from (
      select acta_id,socio_numero,estado from public.acta_detalle_publico
  ) x), '[]'::jsonb),
  'detalle_privado', coalesce((select jsonb_agg(to_jsonb(x)) from (
      select acta_id,socio_numero,nombre_snapshot,estado,medio,monto_centavos from public.acta_detalle
  ) x), '[]'::jsonb),
  'bitacora', coalesce((select jsonb_agg(to_jsonb(x) order by x.creado_at desc) from (
      select * from public.bitacora order by creado_at desc limit 100
  ) x), '[]'::jsonb),
  'yape_config', coalesce((select jsonb_agg(to_jsonb(x)) from (
      select numero_yape,actualizado_at from public.yape_config where id='principal' limit 1
  ) x), '[]'::jsonb),
  'reseteos', coalesce((select jsonb_agg(to_jsonb(x) order by x.vence_at desc) from (
      select socio_numero,vence_at,usado_at,cancelado_at from public.reseteos_contrasena order by vence_at desc
  ) x), '[]'::jsonb),
  'servidor_at', now()
);
$$;

revoke all on function public.cargar_app_snapshot_v1() from public;
revoke all on function public.cargar_app_snapshot_v1() from anon;
grant execute on function public.cargar_app_snapshot_v1() to authenticated;
