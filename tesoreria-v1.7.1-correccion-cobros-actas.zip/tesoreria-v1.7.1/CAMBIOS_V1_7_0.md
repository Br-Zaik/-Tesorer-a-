# Tesorería v1.7.0

- versionCode: 27
- versionName: 1.7.0

## Cobros
- Cobro oficial (verde): queda en historial y genera acta oficial.
- Cobro rápido (naranja): visible para todos, hasta 3 cobros activos en total, no suma al saldo oficial.
- Cobros rápidos permiten marcar/desmarcar pago propio sin comprobante.
- Duración configurable en minutos u horas.
- Al cerrar un cobro rápido se genera un resumen descargable en PDF; los pagos temporales se eliminan del servidor y queda solo el resumen hasta que el tesorero lo elimine.

## Actas
- Actas oficiales y resúmenes rápidos diferenciados visualmente.
- El tesorero puede descargar PDF y eliminar un acta/resumen después de confirmar su contraseña.
- Al eliminar un resumen rápido también se elimina su cobro temporal cerrado.

## Miembros
- Nueva opción Liberar plaza, conservando el historial financiero/bitácora previo.
- La cuenta de Auth asociada se elimina para que la plaza pueda volver a invitarse y activarse correctamente.

## Códigos y altas masivas
- Un solo código activo de 6 dígitos por miembro durante 24 horas.
- Los nuevos códigos son recuperables de forma segura por el tesorero sin almacenarlos en texto plano.
- Copiar código desde la app.
- Activación idempotente para soportar reintentos y altas simultáneas de los miembros sin duplicar cuentas.

## UI y pagos
- Los cuadros administrativos distinguen Yape y Manual.
- Detalle del pago muestra tipo, monto, fecha, revisor y comprobante cuando existe.
- Guardado del número Yape muestra Guardando… / ✓ Guardado.
- Se mantiene envío de comprobante con progreso y protección contra duplicados.
