package com.tesoreria.caja

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Permiso
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Caja.cargarDemo()
        setContent { CajaTheme { App() } }
    }
}

private enum class Vista { INICIO, SUBIR, MOVIMIENTOS, ARCHIVO, PANEL }

@Composable
fun App() {
    val yo = Caja.sesion.value
    var vista by remember { mutableStateOf(Vista.INICIO) }

    if (yo == null) {
        PantallaLogin { s ->
            Caja.sesion.value = s
            Caja.revisarVencidos()
            vista = Vista.INICIO
        }
        return
    }

    val conPanel = yo.rol == Rol.TESORERO || Caja.tienePermiso(yo, Permiso.GESTIONAR_MIEMBROS)
    val rolTexto = when (yo.rol) {
        Rol.TESORERO -> "Tesorero"
        Rol.PRESIDENTE -> "Presidente"
        Rol.SOCIO -> "Usuario"
        Rol.PERSONALIZADO -> "Personalizado"
    }

    Column(Modifier.fillMaxSize().background(Fondo)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 14.dp, top = 18.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Hola, ${yo.nombre.substringBefore(" ")}", color = Texto, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(3.dp))
                Text("N.º ${yo.numero} · $rolTexto", color = Tenue, fontSize = 11.sp)
            }
            Box(
                Modifier.size(43.dp).background(Panel, CircleShape).clickable {
                    Caja.sesion.value = null
                    vista = Vista.INICIO
                },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Logout, "Cerrar sesión", tint = Tenue, modifier = Modifier.size(20.dp))
            }
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp).padding(bottom = 22.dp)
        ) {
            when (vista) {
                Vista.INICIO -> PantallaInicio { vista = Vista.SUBIR }
                Vista.SUBIR -> PantallaSubir { vista = Vista.INICIO }
                Vista.MOVIMIENTOS -> PantallaMovimientos()
                Vista.ARCHIVO -> PantallaArchivo()
                Vista.PANEL -> PantallaPanel()
            }
        }

        BarraInferior(
            vista = vista,
            conPanel = conPanel,
            onInicio = { vista = Vista.INICIO },
            onMovimientos = { vista = Vista.MOVIMIENTOS },
            onArchivo = { vista = Vista.ARCHIVO },
            onPanel = { vista = Vista.PANEL }
        )
    }
}

@Composable
private fun BarraInferior(
    vista: Vista,
    conPanel: Boolean,
    onInicio: () -> Unit,
    onMovimientos: () -> Unit,
    onArchivo: () -> Unit,
    onPanel: () -> Unit
) {
    val indice = when (vista) {
        Vista.INICIO, Vista.SUBIR -> 0
        Vista.MOVIMIENTOS -> 1
        Vista.ARCHIVO -> 2
        Vista.PANEL -> if (conPanel) 3 else 2
    }
    val total = if (conPanel) 4 else 3

    BoxWithConstraints(
        Modifier.fillMaxWidth().background(FondoProfundo).navigationBarsPadding().height(72.dp)
    ) {
        val anchoItem = maxWidth / total.toFloat()
        val desplazamiento by animateDpAsState(
            targetValue = anchoItem * indice.toFloat(),
            animationSpec = tween(320, easing = FastOutSlowInEasing),
            label = "navIndicator"
        )

        Box(
            Modifier.offset(x = desplazamiento).width(anchoItem).fillMaxHeight().padding(horizontal = 7.dp, vertical = 7.dp)
                .background(VerdeNeon.copy(alpha = .075f), RoundedCornerShape(18.dp))
        )
        Box(
            Modifier.offset(x = desplazamiento + anchoItem * .28f).width(anchoItem * .44f).height(3.dp)
                .background(GradientePrincipal, RoundedCornerShape(99.dp))
        )

        Row(Modifier.fillMaxSize().padding(horizontal = 5.dp)) {
            NavItem("Inicio", Icons.Rounded.Home, indice == 0, Modifier.weight(1f), onInicio)
            NavItem("Movimientos", Icons.Rounded.ReceiptLong, indice == 1, Modifier.weight(1f), onMovimientos)
            NavItem("Actas", Icons.Rounded.FolderOpen, indice == 2, Modifier.weight(1f), onArchivo)
            if (conPanel) NavItem("Panel", Icons.Rounded.Tune, indice == 3, Modifier.weight(1f), onPanel)
        }
    }
}

@Composable
private fun NavItem(texto: String, icono: ImageVector, activa: Boolean, modifier: Modifier, alTocar: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val escala by animateFloatAsState(
        targetValue = when { pressed -> .92f; activa -> 1.07f; else -> 1f },
        animationSpec = spring(stiffness = 650f),
        label = "navScale"
    )
    val color by animateColorAsState(if (activa) VerdeNeon else Tenue, tween(220), label = "navColor")
    val elevacion by animateDpAsState(if (activa) (-2).dp else 0.dp, tween(250), label = "navLift")

    Column(
        modifier.offset(y = elevacion).scale(escala).fillMaxHeight()
            .clickable(interactionSource = interaction, indication = null) { alTocar() },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icono, texto, tint = color, modifier = Modifier.size(21.dp))
        Spacer(Modifier.height(3.dp))
        Text(texto, color = color, fontSize = 9.sp, fontWeight = if (activa) FontWeight.Bold else FontWeight.Medium)
    }
}
