package com.tesoreria.caja

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.runtime.mutableStateListOf
import com.tesoreria.caja.data.fechaHora

object YapeInbox {
    data class Registro(val cuando: Long, val titulo: String, val texto: String, val paquete: String)
    val registros = mutableStateListOf<Registro>()

    fun agregar(registro: Registro) {
        registros.add(0, registro)
        while (registros.size > 20) registros.removeLast()
    }
}

class YapeNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn ?: return
        val extras = n.notification.extras
        val titulo = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val texto = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val paquete = n.packageName.orEmpty()
        val combinado = "$titulo $texto $paquete".lowercase()

        if (!combinado.contains("yape")) return
        YapeInbox.agregar(YapeInbox.Registro(System.currentTimeMillis(), titulo, texto, paquete))
    }
}
