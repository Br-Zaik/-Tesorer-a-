# Tesorería v2.0.1

VersionCode: 49 · VersionName: 2.0.1

- En la lista de Inicio, tocar un número solo abre la foto del comprobante si esa persona lo mandó. Si no mandó nada, no se abre nada.
