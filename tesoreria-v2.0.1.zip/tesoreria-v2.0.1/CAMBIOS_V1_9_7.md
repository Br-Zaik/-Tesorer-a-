# Tesorería v1.9.7

VersionCode: 45
VersionName: 1.9.7

Rediseño visual y pago manual con captura:

- Un color por sección: Inicio verde, Movimientos azul, Actas dorado, Panel lima.
- Panel con cuadros grandes de íconos (Pagos verde, Cobro celeste, Gastos rojo, Yape morado, Miembros azul, Owner dorado) y encabezado de sección con su color.
- Botón morado "Pagar con Yape" arriba en Inicio para quien debe pagar.
- Lista de números rediseñada: verde = pagó (rebote), naranja = en revisión (borde que late), rojo = falta, celeste = invitado, punto morado = pagó por Yape.
- Cualquiera puede tocar un número y ver la captura de un pago aprobado.
- Registrar pago manual ahora permite adjuntar la captura del Yape (foto o archivo).
- Animación de envío (avión de papel y check) al subir Yape o la captura manual.
- Barra de avance animada del cobro, campana en vez de interruptor de notificaciones.
- Letra más grande en todas las pantallas y menos texto.
