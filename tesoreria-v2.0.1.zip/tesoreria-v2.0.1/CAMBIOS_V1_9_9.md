# Tesorería v1.9.9

VersionCode: 47 · VersionName: 1.9.9

- Comprobantes en HD: la vista previa y la galería usan la imagen original del servidor. Mientras llega, se ve la miniatura y luego la HD aparece con un fundido suave (sin cuadros grises ni "reconstrucción").
- Caché HD en memoria y en disco: la segunda vez abre al instante y sin gastar datos. Miniaturas más nítidas (420 px).
- En la lista de Inicio, tocar un cuadro verde con foto abre directo la galería en pantalla completa.
- Arranque nuevo: anillo de luz que gira alrededor del logo, halo, puntos de "Conectando".
- Transición suave entre arranque, login y la app (fundido con zoom).
- Entrada en cascada en Inicio: saludo, botón Yape, saldo, cobro, estado, alertas y lista; barra inferior que sube.
- Destello de luz que cruza la tarjeta del saldo al entrar; contador de pagos que cambia deslizándose.
- Encabezados de Movimientos y Actas entran suave.
