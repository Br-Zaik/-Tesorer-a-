# Servidor v1.9.7 aplicado

- Limpieza total de datos operativos (cobros, pagos, gastos, actas, bitácora, códigos). Saldo en S/ 0.
- Lista nueva: N.º 1 al 22 pagan (orden de la lista del evento), N.º 23 owner/tesorero sin cobro, N.º 24 al 28 libres para invitados, 29 al 35 libres.
- Cuentas: Kana Chaco pasó del 19 al 11 y Umasi del 29 al 12, con su misma contraseña. El owner pasó del 22 al 23 con su misma contraseña. Se borraron las cuentas de los N.º 1 y 11 anteriores y la cuenta de prueba 31.
- Las funciones que protegían al owner ya no usan el número 22 fijo: protegen a quien tenga nivel owner.
- Liberar plaza: ahora del 24 al 35 (base de datos y función liberar-plaza).
- Nueva función `registrar_pago_manual_foto` y políticas para que cualquier miembro vea capturas de pagos aprobados.
- Quedan 5 fotos viejas en Storage (no se pueden borrar por SQL); se eliminan con Panel › Owner › Limpiar datos.
