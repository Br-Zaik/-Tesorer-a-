package com.tesoreria.caja.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Miniaturas de comprobantes con caché en memoria y en disco.
 * Cada captura se baja una sola vez; luego se lee del celular sin gastar datos.
 */
object Miniaturas {
    private const val LADO = 420
    private val memoria = LruCache<String, Bitmap>(64)
    private val completas = object : LruCache<String, ByteArray>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ByteArray): Int = value.size
    }
    // Imágenes HD ya decodificadas para abrir al instante la segunda vez.
    private val hd = object : LruCache<String, Bitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val candado = Mutex()
    private val enCurso = mutableMapOf<String, Deferred<Bitmap?>>()
    private var carpeta: File? = null

    fun inicializar(context: Context) {
        carpeta = File(context.cacheDir, "miniaturas").apply { mkdirs() }
    }

    fun enMemoria(path: String): Bitmap? = if (path.isBlank()) null else memoria.get(path)

    private fun nombreSeguro(path: String) = path.replace(Regex("[^A-Za-z0-9._-]"), "_")

    private fun archivo(path: String): File? =
        carpeta?.let { File(it, nombreSeguro(path) + "_m2.jpg") }

    private fun archivoCompleto(path: String): File? =
        carpeta?.let { File(File(it, "hd").apply { mkdirs() }, nombreSeguro(path) + ".bin") }

    fun hdEnMemoria(path: String): Bitmap? = if (path.isBlank()) null else hd.get(path)

    /** Bytes completos de la captura: memoria → disco → servidor. */
    suspend fun bytesCompletos(path: String, descargar: suspend () -> ByteArray): ByteArray {
        completas.get(path)?.let { return it }
        val f = archivoCompleto(path)
        val enDisco = kotlinx.coroutines.withContext(Dispatchers.IO) {
            f?.takeIf { it.exists() && it.length() > 0 }?.readBytes()
        }
        val bytes = enDisco ?: descargar().also { b ->
            kotlinx.coroutines.withContext(Dispatchers.IO) { runCatching { f?.writeBytes(b) } }
        }
        completas.put(path, bytes)
        return bytes
    }

    /** Imagen en alta calidad, tal como la mandó el servidor. */
    suspend fun completa(path: String, descargar: suspend () -> ByteArray): Bitmap? {
        if (path.isBlank()) return null
        hd.get(path)?.let { return it }
        val bytes = bytesCompletos(path, descargar)
        val bmp = kotlinx.coroutines.withContext(Dispatchers.Default) {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } ?: return null
        hd.put(path, bmp)
        return bmp
    }

    suspend fun cargar(path: String, descargar: suspend () -> ByteArray): Bitmap? {
        if (path.isBlank()) return null
        memoria.get(path)?.let { return it }
        val tarea = candado.withLock {
            enCurso[path] ?: alcance.async {
                try {
                    val disco = archivo(path)
                    val desdeDisco = disco?.takeIf { it.exists() && it.length() > 0 }?.let { BitmapFactory.decodeFile(it.absolutePath) }
                    val bmp = desdeDisco ?: run {
                        val bytes = bytesCompletos(path, descargar)
                        val reducido = reducir(bytes) ?: return@run null
                        disco?.let { f ->
                            runCatching {
                                val out = ByteArrayOutputStream()
                                reducido.compress(Bitmap.CompressFormat.JPEG, 82, out)
                                f.writeBytes(out.toByteArray())
                            }
                        }
                        reducido
                    }
                    if (bmp != null) memoria.put(path, bmp)
                    bmp
                } catch (_: Exception) {
                    null
                } finally {
                    candado.withLock { enCurso.remove(path) }
                }
            }.also { enCurso[path] = it }
        }
        return tarea.await()
    }

    private fun reducir(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var muestra = 1
        while (bounds.outWidth / (muestra * 2) >= LADO && bounds.outHeight / (muestra * 2) >= LADO) muestra *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = muestra }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }
}
