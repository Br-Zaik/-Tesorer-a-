# Tesorería v1.9.8

VersionCode: 46 · VersionName: 1.9.8

Rediseño visual y animaciones, sin cambiar el funcionamiento:

- Base gris casi negro; cada sección pone su color (Inicio verde, Movimientos azul, Actas dorado, Panel por herramienta).
- Arranque: logo que respira con brillo de carga.
- Login: logo y formulario entran suave; cambio deslizado entre Entrar / Crear cuenta / Contraseña; temblor y vibración si hay error; check dibujado y "¡Bienvenido!" al entrar.
- Cambio de pantallas con deslizamiento y desvanecido.
- Inicio: saldo que sube contando, cuadros de la lista en cascada, giro al pasar a "pagó", miniatura de la captura en el cuadro verde, leyenda ordenada, pasos del pago con línea de avance.
- Ficha de pago (hoja que sube): miniatura grande, monto, Yape/Manual, fecha, revisor.
- Galería de comprobantes: pantalla completa negra, zoom con dos dedos, doble toque, deslizar abajo para cerrar, datos abajo.
- Movimientos: cada ingreso con miniatura, nombre, fecha y medio; total azul que cuenta; filas en cascada; vacíos con ícono.
- Ventanas como hojas que suben desde abajo y se acomodan al teclado.
- Gestionar miembro por bloques (Datos, Color, Cobros, Acceso), colores en círculos, interruptores limpios, zona sensible aparte.
- Código de acceso: 6 dígitos que aparecen uno por uno, anillo de 24 h, copiar con vibración.
- Avisos con íconos reales en vez de ✓ escritos.
- Optimización: miniaturas reducidas con caché en memoria y disco; capturas completas con caché corta.
