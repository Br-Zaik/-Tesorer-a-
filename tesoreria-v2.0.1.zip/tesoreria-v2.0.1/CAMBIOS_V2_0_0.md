# Tesorería v2.0.0

VersionCode: 48 · VersionName: 2.0.0

- Se quitó el círculo de "¡Bienvenido!" al iniciar sesión: ahora pasa directo a la app con la transición suave.
- Arranque: en vez de un anillo que gira (parecía carga), ondas suaves que salen del logo.
- Actas rediseñadas: encabezado simple, total grande, resumen con íconos (Pagaron / Faltaron / No pagan).
- En cada acta, fila de tarjetas con la foto del comprobante, nombre y monto de quienes pagaron. Visible para todos; al tocar se abre la galería.
- "Ver quiénes faltaron" se abre con animación y muestra número y nombre.
- Bitácora: una tarjeta por día con línea de tiempo, ícono por tipo de evento y un solo color.
