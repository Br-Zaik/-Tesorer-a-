package com.tesoreria.caja.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateOf

object NetworkMonitor {
    val conectado = mutableStateOf(false)
    private var initialized = false

    @Synchronized
    fun initialize(context: Context) {
        if (initialized) return
        initialized = true
        val app = context.applicationContext
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val main = Handler(Looper.getMainLooper())

        fun actualizar() {
            val activo = cm.activeNetwork
            val caps = activo?.let { cm.getNetworkCapabilities(it) }
            val ok = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            main.post { conectado.value = ok }
        }

        actualizar()
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = actualizar()
            override fun onLost(network: Network) = actualizar()
            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) = actualizar()
        }
        runCatching { cm.registerDefaultNetworkCallback(callback) }
            .recoverCatching {
                cm.registerNetworkCallback(
                    NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(),
                    callback
                )
            }
    }
}
