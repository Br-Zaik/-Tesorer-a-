package com.tesoreria.caja.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Pago
import com.tesoreria.caja.data.soles

@Composable
fun MiniaturaComprobante(
    bitmap: Bitmap?,
    modifier: Modifier = Modifier,
    alTocar: (() -> Unit)? = null
) {
    val base = modifier
        .fillMaxWidth()
        .height(190.dp)
        .background(FondoProfundo, RoundedCornerShape(16.dp))
        .border(1.dp, Borde, RoundedCornerShape(16.dp))
    Box(
        if (alTocar != null) base.clickable { alTocar() } else base,
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null && !bitmap.isRecycled) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Comprobante",
                modifier = Modifier.fillMaxSize().padding(8.dp),
                contentScale = ContentScale.Fit
            )
            if (alTocar != null) {
                Box(
                    Modifier.align(Alignment.BottomEnd).padding(12.dp)
                        .background(PanelAlto.copy(alpha = .92f), RoundedCornerShape(99.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) { Text("Ver completa", color = VerdeBrillante, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            }
        } else {
            Icon(Icons.Rounded.ReceiptLong, null, tint = Tenue, modifier = Modifier.size(42.dp))
        }
    }
}

@Composable
fun VisorBitmapDialog(bitmap: Bitmap, cerrar: () -> Unit) {
    Dialog(onDismissRequest = cerrar) {
        Column(
            Modifier.fillMaxWidth().background(FondoProfundo, RoundedCornerShape(20.dp))
                .border(1.dp, Borde, RoundedCornerShape(20.dp)).padding(12.dp)
        ) {
            Text("Comprobante", color = Texto, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Comprobante completo",
                modifier = Modifier.fillMaxWidth().heightIn(min = 260.dp, max = 610.dp),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(10.dp))
            Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
        }
    }
}

@Composable
fun VisorPagoDialog(pago: Pago, cerrar: () -> Unit) {
    var bitmap by remember(pago.serverId) { mutableStateOf<Bitmap?>(null) }
    var error by remember(pago.serverId) { mutableStateOf("") }
    var cargando by remember(pago.serverId) { mutableStateOf(true) }

    LaunchedEffect(pago.serverId) {
        cargando = true
        error = ""
        try {
            val bytes = Caja.comprobanteBytes(pago)
            bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: throw IllegalStateException("No se pudo abrir la captura")
        } catch (e: Exception) {
            error = e.message ?: "No se pudo abrir el comprobante"
        } finally {
            cargando = false
        }
    }

    Dialog(onDismissRequest = cerrar) {
        Column(
            Modifier.fillMaxWidth().background(PanelAlto, RoundedCornerShape(22.dp))
                .border(1.dp, Borde, RoundedCornerShape(22.dp)).padding(16.dp)
        ) {
            Etiqueta("COMPROBANTE YAPE", VerdeBrillante)
            Spacer(Modifier.height(5.dp))
            Text("N.º ${pago.socio} · ${Caja.socio(pago.socio)?.nombre.orEmpty()}", color = Texto, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))

            when {
                cargando -> Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) {
                    Text("Abriendo comprobante…", color = Tenue, fontSize = 12.sp)
                }
                bitmap != null -> Image(
                    bitmap = bitmap!!.asImageBitmap(),
                    contentDescription = "Captura enviada",
                    modifier = Modifier.fillMaxWidth().heightIn(min = 260.dp, max = 480.dp)
                        .background(FondoProfundo, RoundedCornerShape(14.dp)).padding(6.dp),
                    contentScale = ContentScale.Fit
                )
                else -> Box(
                    Modifier.fillMaxWidth().height(180.dp).background(FondoProfundo, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.BrokenImage, null, tint = Rojo, modifier = Modifier.size(36.dp))
                        Spacer(Modifier.height(7.dp))
                        Text(error.ifBlank { "No hay imagen disponible" }, color = Rojo, fontSize = 11.sp)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            MiniDato("MONTO", soles(pago.monto), Verde)
            Spacer(Modifier.height(7.dp))
            MiniDato("N.º DE OPERACIÓN", pago.operacion.ifBlank { "No detectado" }, Cian)
            Spacer(Modifier.height(7.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Box(Modifier.weight(1f)) { MiniDato("FECHA", pago.fechaOcr.ifBlank { "No detectada" }, Ambar) }
                Box(Modifier.weight(1f)) { MiniDato("HORA", pago.horaOcr.ifBlank { "No detectada" }, Ambar) }
            }
            if (pago.codigoSeguridad.isNotBlank()) {
                Spacer(Modifier.height(7.dp))
                MiniDato("CÓDIGO DE SEGURIDAD", pago.codigoSeguridad, Violeta)
            }
            Spacer(Modifier.height(12.dp))
            Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
        }
    }
}
