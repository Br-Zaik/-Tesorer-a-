package com.tesoreria.caja.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.absoluteValue

val PE: Locale = Locale("es", "PE")

fun soles(centavos: Long): String = String.format(PE, "S/ %,.2f", centavos / 100.0)
fun fechaHora(t: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", PE).format(Date(t))
fun fechaCorta(t: Long): String = SimpleDateFormat("dd/MM/yyyy", PE).format(Date(t))

fun parseCentavos(texto: String): Long? {
    var s = texto.trim().replace("S/", "", ignoreCase = true).replace(" ", "")
    if (s.isBlank()) return null
    s = when {
        s.contains(',') && s.contains('.') -> s.replace(",", "")
        s.contains(',') -> s.replace(',', '.')
        else -> s
    }
    if (!s.matches(Regex("\\d+(\\.\\d{0,2})?"))) return null
    val partes = s.split('.')
    val entero = partes[0].toLongOrNull() ?: return null
    val dec = when {
        partes.size == 1 || partes[1].isEmpty() -> 0L
        partes[1].length == 1 -> partes[1].toLong() * 10L
        else -> partes[1].take(2).toLong()
    }
    return entero * 100L + dec
}

enum class EstadoPago { SIN_ENVIAR, PENDIENTE, APROBADO, RECHAZADO }
enum class MedioPago { YAPE, MANUAL }
enum class Rol { SOCIO, PRESIDENTE, TESORERO, PERSONALIZADO }
enum class EstadoMiembro { ACTIVO, BLOQUEADO, RETIRADO }
enum class Permiso { REGISTRAR_PAGO_MANUAL, GESTIONAR_COBROS, REGISTRAR_GASTOS }

data class Socio(
    val numero: Int,
    val nombre: String,
    val rol: Rol = Rol.SOCIO,
    val estado: EstadoMiembro = EstadoMiembro.ACTIVO,
    val permisosExtra: Set<Permiso> = emptySet()
)

data class Cobro(
    val id: Int,
    val serverId: String,
    val titulo: String,
    val monto: Long,
    val creado: Long,
    val cierra: Long,
    val cerrado: Boolean = false,
    val extensionTexto: String = ""
)

data class Pago(
    val id: Int,
    val serverId: String,
    val cobroId: Int,
    val socio: Int,
    val monto: Long,
    val estado: EstadoPago,
    val enviado: Long,
    val operacion: String = "",
    val ocrMonto: Long = 0,
    val nota: String = "",
    val medio: MedioPago = MedioPago.YAPE,
    val fechaOcr: String = "",
    val horaOcr: String = "",
    val codigoSeguridad: String = "",
    val capturaPath: String = "",
    val capturaSha256: String = ""
)

data class Gasto(
    val id: Int,
    val serverId: String,
    val concepto: String,
    val monto: Long,
    val fecha: Long,
    val anulado: Boolean = false,
    val motivoAnulacion: String = ""
) {
    val aprobado: Boolean get() = !anulado
    val firmaTesorero: Boolean get() = !anulado
    val firmaPresidente: Boolean get() = true
}

data class Acta(
    val serverId: String,
    val cobroId: Int,
    val titulo: String,
    val monto: Long,
    val cierre: Long,
    val recaudado: Long,
    val pagaron: List<Int>,
    val faltaron: List<Int>,
    val estados: Map<Int, EstadoPago> = emptyMap()
)

data class EstadoCuenta(
    val numero: Int,
    val nombre: String,
    val rol: Rol,
    val estado: EstadoMiembro,
    val activada: Boolean,
    val reseteoActivo: Boolean
)

object Caja {
    val socios = mutableStateListOf<Socio>()
    val cobros = mutableStateListOf<Cobro>()
    val pagos = mutableStateListOf<Pago>()
    val gastos = mutableStateListOf<Gasto>()
    val actas = mutableStateListOf<Acta>()
    val bitacora = mutableStateListOf<String>()
    val sesion = mutableStateOf<Socio?>(null)
    val cargando = mutableStateOf(false)
    val ultimoError = mutableStateOf<String?>(null)
    val ultimoCodigoTemporal = mutableStateOf<String?>(null)
    val codigoTemporalPara = mutableStateOf<Int?>(null)
    val conectado = NetworkMonitor.conectado

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val esAdmin: Boolean get() = sesion.value?.rol == Rol.TESORERO
    val esPresidente: Boolean get() = sesion.value?.rol == Rol.PRESIDENTE

    fun initialize(context: Context) = SupabaseApi.initialize(context)

    suspend fun restaurarSesion(): Boolean = try {
        if (!SupabaseApi.restaurarSesion()) false else { cargarTodo(); sesion.value != null }
    } catch (_: Exception) { false }

    suspend fun consultarCuenta(numero: Int): EstadoCuenta {
        val j = SupabaseApi.estadoCuenta(numero)
        return EstadoCuenta(
            numero = j.getInt("numero"),
            nombre = j.getString("nombre"),
            rol = rolDe(j.optString("rol")),
            estado = estadoMiembroDe(j.optString("estado")),
            activada = j.optBoolean("activada"),
            reseteoActivo = j.optBoolean("reseteo_activo")
        )
    }

    suspend fun iniciarSesion(numero: Int, clave: String): Socio {
        SupabaseApi.iniciarSesion(numero, clave)
        cargarTodo()
        return sesion.value ?: throw IllegalStateException("No se pudo cargar tu perfil")
    }

    suspend fun activarCuenta(numero: Int, codigo: String, clave: String): Socio {
        SupabaseApi.activarCuenta(numero, codigo, clave)
        SupabaseApi.iniciarSesion(numero, clave)
        cargarTodo()
        return sesion.value ?: throw IllegalStateException("La cuenta se activó, pero no se pudo iniciar sesión")
    }

    fun cerrarSesion() {
        scope.launch { SupabaseApi.cerrarSesion() }
        sesion.value = null
        limpiarDatos()
    }

    private fun limpiarDatos() {
        socios.clear(); cobros.clear(); pagos.clear(); gastos.clear(); actas.clear(); bitacora.clear()
    }

    suspend fun cargarTodo() = withContext(Dispatchers.IO) {
        val miembrosD = async { SupabaseApi.getArray("miembros?select=numero,nombre,rol,estado&estado=neq.libre&order=numero") }
        val permisosD = async { SupabaseApi.getArray("permisos_miembro?select=socio_numero,permiso") }
        val cobrosD = async { SupabaseApi.getArray("cobros?select=*&order=creado_at.desc") }
        val pagosD = async { SupabaseApi.getArray("pagos?select=id,cobro_id,socio_numero,medio,estado,monto_centavos,enviado_at&vigente=eq.true&order=enviado_at.desc") }
        val privadosD = async { SupabaseApi.getArray("pagos_privados?select=*") }
        val gastosD = async { SupabaseApi.getArray("gastos?select=*&order=registrado_at.desc") }
        val actasD = async { SupabaseApi.getArray("actas?select=*&order=cerrado_at.desc") }
        val detalleD = async { SupabaseApi.getArray("acta_detalle?select=*") }
        val bitacoraD = async { SupabaseApi.getArray("bitacora?select=*&order=creado_at.desc&limit=100") }

        val miembros = miembrosD.await(); val permisos = permisosD.await(); val cobrosJ = cobrosD.await()
        val pagosJ = pagosD.await(); val privados = privadosD.await(); val gastosJ = gastosD.await()
        val actasJ = actasD.await(); val detalleJ = detalleD.await(); val bitJ = bitacoraD.await()

        val permisosPor = mutableMapOf<Int, MutableSet<Permiso>>()
        for (i in 0 until permisos.length()) {
            val p = permisos.getJSONObject(i)
            val n = p.getInt("socio_numero")
            permisoDe(p.getString("permiso"))?.let { permisosPor.getOrPut(n) { mutableSetOf() }.add(it) }
        }

        val nuevosSocios = mutableListOf<Socio>()
        for (i in 0 until miembros.length()) {
            val m = miembros.getJSONObject(i)
            nuevosSocios += Socio(
                m.getInt("numero"), m.optString("nombre"), rolDe(m.optString("rol")),
                estadoMiembroDe(m.optString("estado")), permisosPor[m.getInt("numero")] ?: emptySet()
            )
        }

        val nuevosCobros = mutableListOf<Cobro>()
        val cobroMap = mutableMapOf<String, Int>()
        for (i in 0 until cobrosJ.length()) {
            val c = cobrosJ.getJSONObject(i); val sid = c.getString("id"); val lid = localId(sid); cobroMap[sid] = lid
            nuevosCobros += Cobro(lid, sid, c.getString("titulo"), c.getLong("monto_centavos"), iso(c.getString("creado_at")), iso(c.getString("cierra_at")), !c.isNull("cerrado_at"), c.optString("extension_texto"))
        }

        val privadosMap = mutableMapOf<String, JSONObject>()
        for (i in 0 until privados.length()) privadosMap[privados.getJSONObject(i).getString("pago_id")] = privados.getJSONObject(i)
        val nuevosPagos = mutableListOf<Pago>()
        for (i in 0 until pagosJ.length()) {
            val p = pagosJ.getJSONObject(i); val sid = p.getString("id"); val priv = privadosMap[sid]
            val fechaPriv = priv?.optString("fecha_operacion").orEmpty().takeUnless { it == "null" }.orEmpty()
            val fechaMillis = isoOrNull(fechaPriv)
            nuevosPagos += Pago(
                id = localId(sid), serverId = sid, cobroId = cobroMap[p.getString("cobro_id")] ?: localId(p.getString("cobro_id")),
                socio = p.getInt("socio_numero"), monto = p.getLong("monto_centavos"), estado = estadoPagoDe(p.getString("estado")),
                enviado = iso(p.getString("enviado_at")), operacion = priv?.optString("operacion").orEmpty(),
                ocrMonto = priv?.optLong("ocr_monto_centavos", 0L) ?: 0L, nota = priv?.optString("motivo_rechazo").orEmpty(),
                medio = if (p.optString("medio") == "manual") MedioPago.MANUAL else MedioPago.YAPE,
                fechaOcr = fechaMillis?.let(::fechaCorta).orEmpty(),
                horaOcr = fechaMillis?.let { SimpleDateFormat("HH:mm", PE).format(Date(it)) }.orEmpty(),
                codigoSeguridad = priv?.optString("ocr_codigo_seguridad").orEmpty(),
                capturaPath = priv?.optString("captura_path").orEmpty(),
                capturaSha256 = priv?.optString("captura_sha256").orEmpty()
            )
        }

        val nuevosGastos = mutableListOf<Gasto>()
        for (i in 0 until gastosJ.length()) {
            val g = gastosJ.getJSONObject(i); val sid = g.getString("id")
            nuevosGastos += Gasto(localId(sid), sid, g.getString("concepto"), g.getLong("monto_centavos"), iso(g.getString("registrado_at")), !g.isNull("anulado_at"), g.optString("motivo_anulacion"))
        }

        val detallesPorActa = mutableMapOf<String, MutableList<JSONObject>>()
        for (i in 0 until detalleJ.length()) {
            val d = detalleJ.getJSONObject(i); detallesPorActa.getOrPut(d.getString("acta_id")) { mutableListOf() }.add(d)
        }
        val nuevasActas = mutableListOf<Acta>()
        for (i in 0 until actasJ.length()) {
            val a = actasJ.getJSONObject(i); val sid = a.getString("id"); val det = detallesPorActa[sid].orEmpty()
            val estados = det.associate { it.getInt("socio_numero") to estadoActaDe(it.getString("estado")) }
            nuevasActas += Acta(sid, cobroMap[a.getString("cobro_id")] ?: localId(a.getString("cobro_id")), a.getString("titulo"), a.getLong("cuota_centavos"), iso(a.getString("cerrado_at")), a.getLong("recaudado_centavos"), estados.filterValues { it == EstadoPago.APROBADO }.keys.sorted(), estados.filterValues { it != EstadoPago.APROBADO }.keys.sorted(), estados)
        }

        val nuevosEventos = mutableListOf<String>()
        for (i in 0 until bitJ.length()) {
            val b = bitJ.getJSONObject(i)
            val actor = if (b.isNull("actor_numero")) "Sistema" else "N° ${b.getInt("actor_numero")}" 
            nuevosEventos += "${fechaHora(iso(b.getString("creado_at")))}  ·  $actor  ·  ${b.optString("detalle", b.optString("evento"))}"
        }

        withContext(Dispatchers.Main) {
            socios.clear(); socios.addAll(nuevosSocios)
            cobros.clear(); cobros.addAll(nuevosCobros)
            pagos.clear(); pagos.addAll(nuevosPagos)
            gastos.clear(); gastos.addAll(nuevosGastos)
            actas.clear(); actas.addAll(nuevasActas)
            bitacora.clear(); bitacora.addAll(nuevosEventos)
            val miNumero = try { SupabaseApi.rpc("mi_numero").trim().trim('"').toIntOrNull() } catch (_: Exception) { null }
            sesion.value = miNumero?.let { n -> socios.firstOrNull { it.numero == n } }
        }
    }

    fun refrescar() {
        if (!conectado.value || sesion.value == null) return
        scope.launch {
            try {
                cargarTodo()
                ultimoError.value = null
            } catch (e: SesionInvalidaException) {
                ultimoError.value = e.message
                sesion.value = null
                limpiarDatos()
            } catch (e: Exception) {
                ultimoError.value = e.message ?: "No se pudo actualizar"
            }
        }
    }

    fun permisosDelegables(): Set<Permiso> = setOf(Permiso.REGISTRAR_PAGO_MANUAL, Permiso.GESTIONAR_COBROS, Permiso.REGISTRAR_GASTOS)
    fun puedeAbrirPanel(socio: Socio?): Boolean = socio != null && socio.estado == EstadoMiembro.ACTIVO && (socio.rol == Rol.TESORERO || socio.permisosExtra.any { it in permisosDelegables() })
    fun permisosBase(rol: Rol): Set<Permiso> = if (rol == Rol.TESORERO) permisosDelegables() else emptySet()
    fun tienePermiso(socio: Socio?, permiso: Permiso): Boolean = socio != null && socio.estado == EstadoMiembro.ACTIVO && (permiso in permisosBase(socio.rol) || permiso in socio.permisosExtra)

    fun ingresos(): Long = pagos.filter { it.estado == EstadoPago.APROBADO }.sumOf { it.monto }
    fun egresos(): Long = gastos.filter { it.aprobado }.sumOf { it.monto }
    fun saldo(): Long = ingresos() - egresos()
    fun comprometidoPendiente(): Long = 0L
    fun disponibleParaGastos(): Long = saldo().coerceAtLeast(0L)
    fun cobroActivo(): Cobro? = cobros.firstOrNull { !it.cerrado && it.cierra > System.currentTimeMillis() }
    private fun ultimoPago(cobroId: Int, numero: Int): Pago? = pagos.filter { it.cobroId == cobroId && it.socio == numero }.maxByOrNull { it.enviado }
    fun estadoDe(cobroId: Int, numero: Int): EstadoPago = ultimoPago(cobroId, numero)?.estado ?: EstadoPago.SIN_ENVIAR
    fun pagoDe(cobroId: Int, numero: Int): Pago? = ultimoPago(cobroId, numero)
    fun miembrosActivos(): List<Socio> = socios.filter { it.estado != EstadoMiembro.RETIRADO }
    fun faltantes(cobroId: Int): List<Int> = miembrosActivos().map { it.numero }.filter { estadoDe(cobroId, it) != EstadoPago.APROBADO }.sorted()
    fun noEnviaron(cobroId: Int): List<Int> = miembrosActivos().map { it.numero }.filter { estadoDe(cobroId, it) == EstadoPago.SIN_ENVIAR }.sorted()
    fun porRevisar(cobroId: Int): List<Int> = miembrosActivos().map { it.numero }.filter { estadoDe(cobroId, it) == EstadoPago.PENDIENTE }.sorted()
    fun rechazados(cobroId: Int): List<Int> = miembrosActivos().map { it.numero }.filter { estadoDe(cobroId, it) == EstadoPago.RECHAZADO }.sorted()
    fun aprobados(cobroId: Int): Int = miembrosActivos().count { estadoDe(cobroId, it.numero) == EstadoPago.APROBADO }
    fun recaudado(cobroId: Int): Long = pagos.filter { it.cobroId == cobroId && it.estado == EstadoPago.APROBADO }.sumOf { it.monto }
    fun socio(numero: Int): Socio? = socios.firstOrNull { it.numero == numero }
    fun pendientes(): List<Pago> = pagos.filter { it.estado == EstadoPago.PENDIENTE }.sortedByDescending { it.enviado }
    fun operacionRepetida(operacion: String, exceptoPago: Int = -1, socioActual: Int? = null): Boolean = pagos.any { it.operacion.isNotBlank() && it.operacion == operacion.trim() && it.id != exceptoPago && !(socioActual != null && it.socio == socioActual && it.estado == EstadoPago.RECHAZADO) }

    fun crearCobro(titulo: String, monto: Long, horas: Int) = operar("crear_cobro", JSONObject().put("p_titulo", titulo).put("p_monto_centavos", monto).put("p_horas", horas))
    fun ajustarCobro(id: Int, minutosDelta: Int) { cobros.firstOrNull { it.id == id }?.let { operar("ajustar_cobro", JSONObject().put("p_cobro_id", it.serverId).put("p_minutos_delta", minutosDelta)) } }
    fun cerrarCobro(id: Int) { cobros.firstOrNull { it.id == id }?.let { operar("cerrar_cobro", JSONObject().put("p_cobro_id", it.serverId)) } }
    fun registrarPagoManual(cobroId: Int, numero: Int, monto: Long) { cobros.firstOrNull { it.id == cobroId }?.let { operar("registrar_pago_manual", JSONObject().put("p_cobro_id", it.serverId).put("p_socio_numero", numero).put("p_monto_centavos", monto)) } }
    fun corregirAsignacionPago(id: Int, nuevoNumero: Int) { pagos.firstOrNull { it.id == id }?.let { operar("corregir_asignacion_pago", JSONObject().put("p_pago_id", it.serverId).put("p_nuevo_socio", nuevoNumero)) } }
    fun aprobarPago(id: Int) { pagos.firstOrNull { it.id == id }?.let { operar("revisar_pago_yape", JSONObject().put("p_pago_id", it.serverId).put("p_aprobar", true).put("p_motivo_rechazo", JSONObject.NULL)) } }
    fun rechazarPago(id: Int, motivo: String) { pagos.firstOrNull { it.id == id }?.let { operar("revisar_pago_yape", JSONObject().put("p_pago_id", it.serverId).put("p_aprobar", false).put("p_motivo_rechazo", motivo)) } }
    fun crearGasto(concepto: String, monto: Long) = operar("registrar_gasto", JSONObject().put("p_concepto", concepto).put("p_monto_centavos", monto))
    fun gastosPorFirmar(): List<Gasto> = emptyList()
    fun firmarGasto(id: Int, comoPresidente: Boolean) = Unit

    suspend fun enviarComprobante(
        cobro: Cobro,
        monto: Long,
        operacion: String,
        bytes: ByteArray,
        mime: String,
        codigoSeguridad: String = "",
        fecha: String = "",
        hora: String = "",
        onProgress: (Int) -> Unit = {}
    ) {
        val yo = sesion.value ?: throw IllegalStateException("Sesión no válida")
        if (!conectado.value) throw SinConexionException()
        val hash = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        val ext = when (mime) { "image/png" -> "png"; "image/webp" -> "webp"; else -> "jpg" }
        val path = "${yo.numero}/${cobro.serverId}/${System.currentTimeMillis()}-$hash.$ext"
        onProgress(12)
        SupabaseApi.uploadComprobante(path, bytes, mime)
        onProgress(62)
        val fechaIso = ReceiptOcr.fechaHoraIso(fecha, hora)
        val metadata = JSONObject()
            .put("motor", "mlkit_local_v1")
            .put("monto_detectado", monto > 0)
            .put("operacion_detectada", operacion.isNotBlank())
            .put("fecha_detectada", fecha.isNotBlank())
            .put("hora_detectada", hora.isNotBlank())
            .put("codigo_detectado", codigoSeguridad.isNotBlank())
        SupabaseApi.rpc("enviar_pago_yape", JSONObject()
            .put("p_cobro_id", cobro.serverId).put("p_monto_centavos", monto).put("p_operacion", operacion.trim())
            .put("p_captura_path", path).put("p_captura_sha256", hash)
            .put("p_fecha_operacion", fechaIso ?: JSONObject.NULL)
            .put("p_ocr_monto_centavos", monto).put("p_ocr_operacion", operacion.trim())
            .put("p_ocr_fecha_operacion", fechaIso ?: JSONObject.NULL)
            .put("p_ocr_codigo_seguridad", if (codigoSeguridad.isBlank()) JSONObject.NULL else codigoSeguridad)
            .put("p_metadata_ocr", metadata))
        onProgress(94)
        try { cargarTodo() } catch (_: Exception) { /* El RPC ya confirmó el envío. */ }
        onProgress(100)
    }

    suspend fun verificarEnvio(cobro: Cobro, operacion: String): Boolean {
        if (!conectado.value) return false
        return try {
            cargarTodo()
            pagoDe(cobro.id, sesion.value?.numero ?: return false)?.let {
                it.estado == EstadoPago.PENDIENTE && it.operacion.trim() == operacion.trim()
            } == true
        } catch (_: Exception) { false }
    }

    suspend fun comprobanteBytes(pago: Pago): ByteArray = SupabaseApi.descargarComprobante(pago.capturaPath)

    fun actualizarNombre(numero: Int, nombre: String) {
        operar("actualizar_nombre_miembro", JSONObject().put("p_numero", numero).put("p_nombre", nombre.trim()))
    }

    fun resetear(numero: Int) {
        ultimoCodigoTemporal.value = null; codigoTemporalPara.value = numero
        scope.launch {
            try {
                val j = SupabaseApi.generarCodigo(numero)
                ultimoCodigoTemporal.value = j.getString("codigo")
                ultimoError.value = null
            } catch (e: Exception) { ultimoError.value = e.message }
        }
    }
    fun tieneClave(numero: Int): Boolean = true
    fun reseteoAbierto(numero: Int): Boolean = false
    fun horasDeReseteo(numero: Int): Long = 0
    fun necesitaCrearClave(numero: Int): Boolean = false
    fun crearClave(numero: Int, clave: String) = Unit
    fun validar(numero: Int, clave: String): Boolean = false
    fun cerrarSesiones(numero: Int) = Unit

    fun invitarMiembro(numero: Int, nombre: String, rol: Rol, permisos: Set<Permiso>) {
        if (!conectado.value) { ultimoError.value = "Sin conexión a Internet"; return }
        scope.launch {
            try {
                SupabaseApi.rpc("invitar_miembro", JSONObject().put("p_numero", numero).put("p_nombre", nombre.trim()).put("p_rol", rolSql(rol)))
                if (rol == Rol.PERSONALIZADO) {
                    val arr = JSONArray(); permisos.forEach { arr.put(permisoSql(it)) }
                    SupabaseApi.rpc("guardar_rol_permisos", JSONObject().put("p_numero", numero).put("p_rol", rolSql(rol)).put("p_permisos", arr))
                }
                cargarTodo(); ultimoError.value = null
            } catch (e: Exception) { ultimoError.value = e.message ?: "No se pudo crear la invitación" }
        }
    }
    fun cambiarRol(numero: Int, rol: Rol, permisos: Set<Permiso>) {
        val arr = JSONArray(); permisos.forEach { arr.put(permisoSql(it)) }
        operar("guardar_rol_permisos", JSONObject().put("p_numero", numero).put("p_rol", rolSql(rol)).put("p_permisos", arr))
    }

    fun guardarMiembro(numero: Int, nombre: String, rol: Rol, permisos: Set<Permiso>) {
        if (!conectado.value) { ultimoError.value = "Sin conexión a Internet"; return }
        scope.launch {
            try {
                val actual = socio(numero)
                if (actual != null && actual.nombre.trim() != nombre.trim()) {
                    SupabaseApi.rpc("actualizar_nombre_miembro", JSONObject().put("p_numero", numero).put("p_nombre", nombre.trim()))
                }
                val arr = JSONArray(); permisos.forEach { arr.put(permisoSql(it)) }
                SupabaseApi.rpc("guardar_rol_permisos", JSONObject().put("p_numero", numero).put("p_rol", rolSql(rol)).put("p_permisos", arr))
                cargarTodo(); ultimoError.value = null
            } catch (e: SesionInvalidaException) {
                ultimoError.value = e.message; sesion.value = null; limpiarDatos()
            } catch (e: Exception) {
                ultimoError.value = e.message ?: "No se pudieron guardar los cambios"
            }
        }
    }
    fun cambiarEstadoMiembro(numero: Int, estado: EstadoMiembro) = operar("cambiar_estado_miembro", JSONObject().put("p_numero", numero).put("p_estado", estadoSql(estado)))
    fun revisarVencidos() = refrescar()
    fun bitacoraPublica(): List<String> = bitacora

    private fun operar(nombre: String, params: JSONObject) {
        if (!conectado.value) {
            ultimoError.value = "Sin conexión a Internet"
            return
        }
        scope.launch {
            try {
                SupabaseApi.rpc(nombre, params)
                cargarTodo()
                ultimoError.value = null
            } catch (e: SesionInvalidaException) {
                ultimoError.value = e.message
                sesion.value = null
                limpiarDatos()
            } catch (e: Exception) {
                ultimoError.value = e.message ?: "No se pudo completar la operación"
            }
        }
    }

    private fun localId(uuid: String): Int = uuid.hashCode().absoluteValue
    private fun rolDe(v: String) = when (v) { "tesorero" -> Rol.TESORERO; "presidente" -> Rol.PRESIDENTE; "personalizado" -> Rol.PERSONALIZADO; else -> Rol.SOCIO }
    private fun rolSql(v: Rol) = when (v) { Rol.TESORERO -> "tesorero"; Rol.PRESIDENTE -> "presidente"; Rol.PERSONALIZADO -> "personalizado"; Rol.SOCIO -> "socio" }
    private fun estadoMiembroDe(v: String) = when (v) { "bloqueado" -> EstadoMiembro.BLOQUEADO; "retirado" -> EstadoMiembro.RETIRADO; else -> EstadoMiembro.ACTIVO }
    private fun estadoSql(v: EstadoMiembro) = when (v) { EstadoMiembro.BLOQUEADO -> "bloqueado"; EstadoMiembro.RETIRADO -> "retirado"; EstadoMiembro.ACTIVO -> "activo" }
    private fun permisoDe(v: String): Permiso? = when (v) { "registrar_pago_manual" -> Permiso.REGISTRAR_PAGO_MANUAL; "gestionar_cobros" -> Permiso.GESTIONAR_COBROS; "registrar_gastos" -> Permiso.REGISTRAR_GASTOS; else -> null }
    private fun permisoSql(v: Permiso) = when (v) { Permiso.REGISTRAR_PAGO_MANUAL -> "registrar_pago_manual"; Permiso.GESTIONAR_COBROS -> "gestionar_cobros"; Permiso.REGISTRAR_GASTOS -> "registrar_gastos" }
    private fun estadoPagoDe(v: String) = when (v) { "aprobado" -> EstadoPago.APROBADO; "rechazado" -> EstadoPago.RECHAZADO; else -> EstadoPago.PENDIENTE }
    private fun estadoActaDe(v: String) = when (v) { "aprobado" -> EstadoPago.APROBADO; "pendiente" -> EstadoPago.PENDIENTE; "rechazado" -> EstadoPago.RECHAZADO; else -> EstadoPago.SIN_ENVIAR }
    private fun isoOrNull(v: String): Long? = try {
        if (v.isBlank() || v == "null") null else {
            val fixed = v.replace(Regex("\\.(\\d{3})\\d+([+-]\\d{2}:?\\d{2}|Z)$"), ".$1$2")
            val patterns = listOf("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX")
            patterns.firstNotNullOfOrNull { p -> try { SimpleDateFormat(p, Locale.US).parse(fixed)?.time } catch (_: Exception) { null } }
        }
    } catch (_: Exception) { null }

    private fun iso(v: String): Long = try {
        val fixed = v.replace(Regex("\\.(\\d{3})\\d+([+-]\\d{2}:?\\d{2}|Z)$"), ".$1$2")
        val patterns = listOf("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX")
        patterns.firstNotNullOfOrNull { p -> try { SimpleDateFormat(p, Locale.US).parse(fixed)?.time } catch (_: Exception) { null } } ?: System.currentTimeMillis()
    } catch (_: Exception) { System.currentTimeMillis() }
}
