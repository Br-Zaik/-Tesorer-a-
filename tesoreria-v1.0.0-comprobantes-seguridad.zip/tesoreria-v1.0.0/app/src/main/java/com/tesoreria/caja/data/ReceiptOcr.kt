package com.tesoreria.caja.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.max

/** OCR local y conservador para comprobantes Yape. Nunca inventa datos faltantes. */
object ReceiptOcr {
    data class Resultado(
        val bytes: ByteArray,
        val mime: String,
        val bitmap: Bitmap,
        val monto: String,
        val operacion: String,
        val fecha: String,
        val hora: String,
        val codigoSeguridad: String,
        val textoDetectado: String
    )

    suspend fun leer(context: Context, uri: Uri): Resultado = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val mime = resolver.getType(uri)?.lowercase(Locale.ROOT) ?: "image/jpeg"
        if (mime !in setOf("image/jpeg", "image/png", "image/webp", "image/heic", "image/heif")) {
            throw IllegalStateException("Selecciona una imagen de Yape")
        }
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("No se pudo abrir la imagen")
        if (bytes.isEmpty()) throw IllegalStateException("La imagen está vacía")
        if (bytes.size > 8 * 1024 * 1024) throw IllegalStateException("La imagen supera 8 MB")

        val bitmap = decodificar(bytes) ?: throw IllegalStateException("No se pudo leer la captura")
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val texto = try {
            val task = recognizer.process(InputImage.fromBitmap(bitmap, 0))
            Tasks.await(task, 14, TimeUnit.SECONDS).text.orEmpty()
        } catch (e: Exception) {
            ""
        } finally {
            recognizer.close()
        }
        val limpio = texto.replace('\r', '\n').replace(Regex("\\n{2,}"), "\n").trim()
        val lineas = limpio.lines().map { it.trim() }.filter { it.isNotBlank() }
        Resultado(
            bytes = bytes,
            mime = normalizarMime(mime),
            bitmap = bitmap,
            monto = extraerMonto(limpio),
            operacion = extraerOperacion(lineas, limpio),
            fecha = extraerFecha(limpio),
            hora = extraerHora(limpio),
            codigoSeguridad = extraerCodigo(lineas, limpio),
            textoDetectado = limpio
        )
    }

    private fun normalizarMime(v: String): String = when (v) {
        "image/png" -> "image/png"
        "image/webp" -> "image/webp"
        else -> "image/jpeg"
    }

    private fun decodificar(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > 2400) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null
        val orientation = runCatching {
            ExifInterface(ByteArrayInputStream(bytes)).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
        }
        if (matrix.isIdentity) return decoded
        val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (rotated !== decoded && !decoded.isRecycled) decoded.recycle()
        return rotated
    }

    private fun extraerMonto(texto: String): String {
        val regex = Regex("(?i)S\\s*/\\s*([0-9]{1,7}(?:[.,][0-9]{1,2})?)")
        val encontrados = regex.findAll(texto).mapNotNull { m ->
            val raw = m.groupValues[1].replace(',', '.')
            raw.toDoubleOrNull()?.takeIf { it > 0.0 && it < 1_000_000.0 }?.let { raw }
        }.toList()
        return encontrados.firstOrNull().orEmpty()
    }

    private fun extraerOperacion(lineas: List<String>, texto: String): String {
        Regex("(?is)(?:nro\\.?|n[uú]mero)?\\s*(?:de\\s*)?operaci[oó]n\\s*[:#-]?\\s*([0-9]{6,20})")
            .find(texto)?.groupValues?.getOrNull(1)?.let { return it }
        val idx = lineas.indexOfFirst { it.contains("operaci", ignoreCase = true) }
        if (idx >= 0) {
            for (i in idx..minOf(idx + 3, lineas.lastIndex)) {
                val d = lineas[i].filter(Char::isDigit)
                if (d.length in 6..20) return d
            }
        }
        return ""
    }

    private fun extraerCodigo(lineas: List<String>, texto: String): String {
        Regex("(?is)c[oó]digo\\s+de\\s+seguridad[^0-9]{0,30}([0-9](?:\\s*[0-9]){2})")
            .find(texto)?.groupValues?.getOrNull(1)?.filter(Char::isDigit)?.takeIf { it.length == 3 }?.let { return it }
        val idx = lineas.indexOfFirst { it.contains("seguridad", ignoreCase = true) }
        if (idx >= 0) {
            for (i in idx..minOf(idx + 3, lineas.lastIndex)) {
                val d = lineas[i].filter(Char::isDigit)
                if (d.length == 3) return d
            }
        }
        return ""
    }

    private fun extraerFecha(texto: String): String {
        Regex("\\b(\\d{1,2})[/-](\\d{1,2})[/-](\\d{4})\\b").find(texto)?.let { m ->
            val d = m.groupValues[1].toIntOrNull() ?: return@let
            val mo = m.groupValues[2].toIntOrNull() ?: return@let
            val y = m.groupValues[3].toIntOrNull() ?: return@let
            if (d in 1..31 && mo in 1..12 && y in 2020..2100) return "%02d/%02d/%04d".format(d, mo, y)
        }
        val meses = mapOf(
            "ene" to 1, "feb" to 2, "mar" to 3, "abr" to 4, "may" to 5, "jun" to 6,
            "jul" to 7, "ago" to 8, "sep" to 9, "sept" to 9, "oct" to 10, "nov" to 11, "dic" to 12
        )
        Regex("(?i)\\b(\\d{1,2})\\s+(ene|feb|mar|abr|may|jun|jul|ago|sep|sept|oct|nov|dic)\\.?\\s+(\\d{4})\\b")
            .find(texto)?.let { m ->
                val d = m.groupValues[1].toIntOrNull() ?: return@let
                val mo = meses[m.groupValues[2].lowercase(Locale.ROOT)] ?: return@let
                val y = m.groupValues[3].toIntOrNull() ?: return@let
                if (d in 1..31 && y in 2020..2100) return "%02d/%02d/%04d".format(d, mo, y)
            }
        return ""
    }

    private fun extraerHora(texto: String): String {
        Regex("(?i)\\b(\\d{1,2}):(\\d{2})\\s*([ap])\\s*\\.?\\s*m\\.?").find(texto)?.let { m ->
            var h = m.groupValues[1].toIntOrNull() ?: return@let
            val min = m.groupValues[2].toIntOrNull() ?: return@let
            val ap = m.groupValues[3].lowercase(Locale.ROOT)
            if (h !in 1..12 || min !in 0..59) return@let
            if (ap == "p" && h != 12) h += 12
            if (ap == "a" && h == 12) h = 0
            return "%02d:%02d".format(h, min)
        }
        Regex("\\b([01]?\\d|2[0-3]):([0-5]\\d)\\b").find(texto)?.let { m ->
            return "%02d:%02d".format(m.groupValues[1].toInt(), m.groupValues[2].toInt())
        }
        return ""
    }

    fun fechaHoraIso(fecha: String, hora: String): String? {
        if (fecha.isBlank() || hora.isBlank()) return null
        return runCatching {
            val f = SimpleDateFormat("dd/MM/yyyy HH:mm", PE).apply { isLenient = false }
            val date = f.parse("${fecha.trim()} ${hora.trim()}") ?: return@runCatching null
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(date)
        }.getOrNull()
    }
}
