package com.tesoreria.caja.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.EstadoCuenta
import com.tesoreria.caja.data.EstadoMiembro
import com.tesoreria.caja.data.Socio
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class Paso { SPLASH, NUMERO, CLAVE, ACTIVAR }

@Composable
fun PantallaLogin(alEntrar: (Socio) -> Unit) {
    var paso by remember { mutableStateOf(Paso.SPLASH) }
    var numero by remember { mutableStateOf("") }
    var clave by remember { mutableStateOf("") }
    var clave2 by remember { mutableStateOf("") }
    var codigo by remember { mutableStateOf("") }
    var cuenta by remember { mutableStateOf<EstadoCuenta?>(null) }
    var error by remember { mutableStateOf("") }
    var cargando by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        delay(900)
        paso = Paso.NUMERO
    }

    Box(Modifier.fillMaxSize().background(Fondo)) {
        FondoAnimado()
        AnimatedContent(
            targetState = paso,
            transitionSpec = {
                (fadeIn(tween(260)) + slideInVertically(tween(330)) { it / 14 }) togetherWith
                    (fadeOut(tween(190)) + slideOutVertically(tween(260)) { -it / 16 })
            }, label = "login"
        ) { actual ->
            if (actual == Paso.SPLASH) {
                SplashPremium()
            } else {
                Column(
                    Modifier.fillMaxSize().padding(horizontal = 22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (actual != Paso.NUMERO) {
                        Row(Modifier.fillMaxWidth()) {
                            Box(
                                Modifier.size(42.dp).background(Panel, CircleShape).border(1.dp, Borde, CircleShape)
                                    .clickable(enabled = !cargando) {
                                        error = ""; clave = ""; clave2 = ""; codigo = ""; paso = Paso.NUMERO
                                    },
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Rounded.ArrowBack, "Volver", tint = Tenue) }
                        }
                        Spacer(Modifier.height(14.dp))
                    }

                    Box(Modifier.size(86.dp).background(VerdeBrillante.copy(alpha = .08f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Shield, null, tint = VerdeBrillante, modifier = Modifier.size(44.dp))
                    }
                    Spacer(Modifier.height(18.dp))
                    Text(if (actual == Paso.NUMERO) "Bienvenido" else cuenta?.nombre ?: "Tesorería", color = Texto, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(5.dp))
                    Text(
                        when (actual) {
                            Paso.NUMERO -> "Inicia sesión para continuar"
                            Paso.CLAVE -> "N.º ${cuenta?.numero} · Escribe tu contraseña"
                            Paso.ACTIVAR -> "N.º ${cuenta?.numero} · Crea tu contraseña"
                            else -> ""
                        },
                        color = Tenue, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(16.dp))
                    if (!Caja.conectado.value) {
                        Box(
                            Modifier.fillMaxWidth().background(Rojo.copy(alpha = .09f), RoundedCornerShape(14.dp))
                                .border(1.dp, Rojo.copy(alpha = .30f), RoundedCornerShape(14.dp)).padding(12.dp)
                        ) {
                            Column {
                                Text("Sin conexión a Internet", color = Rojo, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(2.dp))
                                Text("Revisa tu red e inténtalo nuevamente.", color = Tenue, fontSize = 10.sp)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                    }

                    Tarjeta(borde = VerdeBrillante.copy(alpha = .28f), fondo = PanelAlto) {
                        when (actual) {
                            Paso.NUMERO -> {
                                Etiqueta("ACCESO PERSONAL", VerdeBrillante)
                                Spacer(Modifier.height(12.dp))
                                Campo(numero, { numero = it.filter(Char::isDigit).take(2); error = "" }, "Número de lista · Ej. 22", numerico = true)
                                Spacer(Modifier.height(14.dp))
                                Boton("Continuar →", Modifier.fillMaxWidth(), activo = !cargando && Caja.conectado.value) {
                                    val n = numero.toIntOrNull()
                                    if (n == null || n !in 1..35) { error = "Escribe un número válido del 1 al 35"; return@Boton }
                                    cargando = true; error = ""
                                    scope.launch {
                                        try {
                                            val e = Caja.consultarCuenta(n)
                                            if (e.estado == EstadoMiembro.BLOQUEADO) throw IllegalStateException("Esta cuenta está bloqueada")
                                            if (e.estado == EstadoMiembro.RETIRADO) throw IllegalStateException("Esta cuenta ya no está activa")
                                            cuenta = e
                                            paso = if (!e.activada || e.reseteoActivo) Paso.ACTIVAR else Paso.CLAVE
                                        } catch (ex: Exception) { error = ex.message ?: "No se pudo consultar la cuenta" }
                                        cargando = false
                                    }
                                }
                            }
                            Paso.CLAVE -> {
                                Etiqueta("CONTRASEÑA")
                                Spacer(Modifier.height(10.dp))
                                Campo(clave, { clave = it; error = "" }, "Tu contraseña", clave = true)
                                Spacer(Modifier.height(14.dp))
                                Boton(if (cargando) "Entrando…" else "Entrar", Modifier.fillMaxWidth(), activo = !cargando && Caja.conectado.value) {
                                    val n = cuenta?.numero ?: return@Boton
                                    if (clave.length < 6) { error = "Escribe tu contraseña"; return@Boton }
                                    cargando = true; error = ""
                                    scope.launch {
                                        try { alEntrar(Caja.iniciarSesion(n, clave)) }
                                        catch (ex: Exception) { error = ex.message ?: "No se pudo iniciar sesión"; cargando = false }
                                    }
                                }
                            }
                            Paso.ACTIVAR -> {
                                Etiqueta(if (cuenta?.activada == true) "RESTABLECER CONTRASEÑA" else "ACTIVAR CUENTA", VerdeBrillante)
                                Spacer(Modifier.height(6.dp))
                                Text("Usa el código temporal de 6 dígitos que te dio el tesorero.", color = Tenue, fontSize = 11.sp)
                                Spacer(Modifier.height(12.dp))
                                Campo(codigo, { codigo = it.filter(Char::isDigit).take(6); error = "" }, "Código temporal", numerico = true)
                                Spacer(Modifier.height(9.dp))
                                Campo(clave, { clave = it; error = "" }, "Nueva contraseña", clave = true)
                                Spacer(Modifier.height(9.dp))
                                Campo(clave2, { clave2 = it; error = "" }, "Repite la contraseña", clave = true)
                                Spacer(Modifier.height(14.dp))
                                Boton(if (cargando) "Guardando…" else "Guardar y entrar", Modifier.fillMaxWidth(), activo = !cargando && Caja.conectado.value) {
                                    val n = cuenta?.numero ?: return@Boton
                                    when {
                                        codigo.length != 6 -> error = "Escribe el código temporal de 6 dígitos"
                                        clave.length < 6 -> error = "La contraseña debe tener al menos 6 caracteres"
                                        clave != clave2 -> error = "Las contraseñas no coinciden"
                                        clave == n.toString() || clave == n.toString().padStart(2, '0') -> error = "No uses tu número de lista como contraseña"
                                        else -> {
                                            cargando = true; error = ""
                                            scope.launch {
                                                try { alEntrar(Caja.activarCuenta(n, codigo, clave)) }
                                                catch (ex: Exception) { error = ex.message ?: "No se pudo activar la cuenta"; cargando = false }
                                            }
                                        }
                                    }
                                }
                            }
                            else -> Unit
                        }

                        if (error.isNotBlank()) {
                            Spacer(Modifier.height(10.dp))
                            Text(error, color = Rojo, fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("Conectado de forma segura al servidor de Tesorería", color = Tenue.copy(alpha = .75f), fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun SplashPremium() {
    val inf = rememberInfiniteTransition(label = "splash")
    val pulso by inf.animateFloat(.95f, 1.045f, infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "pulse")
    val giro by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(5000, easing = LinearEasing)), label = "spin")
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(136.dp).scale(pulso), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().rotate(giro)) {
                drawArc(VerdeBrillante.copy(alpha = .55f), -20f, 185f, false, style = Stroke(width = 2.dp.toPx()))
                drawArc(VerdeNeon.copy(alpha = .28f), 190f, 110f, false, style = Stroke(width = 5.dp.toPx()))
            }
            Box(Modifier.size(88.dp).background(VerdeBrillante.copy(alpha = .08f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Shield, null, tint = VerdeBrillante, modifier = Modifier.size(52.dp))
            }
        }
        Spacer(Modifier.height(28.dp))
        Text("Tesorería", color = Texto, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(7.dp))
        Text("Control · Orden · Transparencia", color = Tenue, fontSize = 13.sp)
        Spacer(Modifier.height(42.dp))
        BarraCarga()
        Spacer(Modifier.height(11.dp))
        Text("Conectando con el servidor…", color = Tenue, fontSize = 11.sp)
    }
}


@Composable
private fun FondoAnimado() {
    val inf = rememberInfiniteTransition(label = "bg")
    val t by inf.animateFloat(
        0f,
        1f,
        infiniteRepeatable(tween(8000, easing = LinearEasing), RepeatMode.Reverse),
        label = "t"
    )
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawCircle(
            VerdeBrillante.copy(alpha = .035f),
            size.minDimension * .60f,
            center = androidx.compose.ui.geometry.Offset(w * (.82f - .08f * t), h * .13f)
        )
        drawCircle(
            VerdeNeon.copy(alpha = .025f),
            size.minDimension * .46f,
            center = androidx.compose.ui.geometry.Offset(w * .06f, h * (.84f + .04f * t))
        )
        val paso = w / 7f
        for (i in 1..6) {
            drawLine(
                VerdeBrillante.copy(alpha = .018f),
                androidx.compose.ui.geometry.Offset(i * paso, 0f),
                androidx.compose.ui.geometry.Offset(i * paso, h),
                1f
            )
        }
        for (i in 1..10) {
            val x = ((i * 83f) % w)
            val y = ((i * 137f + t * 90f) % h)
            drawCircle(
                VerdeBrillante.copy(alpha = .10f),
                1.6.dp.toPx(),
                androidx.compose.ui.geometry.Offset(x, y)
            )
        }
    }
}

@Composable
private fun BarraCarga() {
    val inf = rememberInfiniteTransition(label = "load")
    val p by inf.animateFloat(
        .15f,
        .82f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "progress"
    )
    Box(
        Modifier
            .width(180.dp)
            .height(5.dp)
            .background(Borde.copy(alpha = .55f), RoundedCornerShape(9.dp))
    ) {
        Box(
            Modifier
                .fillMaxWidth(p)
                .fillMaxHeight()
                .background(GradientePrincipal, RoundedCornerShape(9.dp))
        )
    }
}
