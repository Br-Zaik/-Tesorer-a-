-- Tesorería v1.9.4 · comprobantes opcionales de gastos
-- La imagen solo se asocia en el momento de registrar el gasto.

alter table public.gastos
  add column if not exists comprobante_path text,
  add column if not exists comprobante_sha256 text,
  add column if not exists comprobante_mime text;

do $$ begin
  if not exists (
    select 1 from pg_constraint where conname='gastos_comprobante_consistente'
  ) then
    alter table public.gastos add constraint gastos_comprobante_consistente check (
      (comprobante_path is null and comprobante_sha256 is null and comprobante_mime is null)
      or
      (comprobante_path is not null
       and comprobante_sha256 ~ '^[a-f0-9]{64}$'
       and comprobante_mime in ('image/jpeg','image/png','image/webp'))
    );
  end if;
end $$;
create unique index if not exists gastos_comprobante_path_uq
  on public.gastos(comprobante_path) where comprobante_path is not null;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values (
  'comprobantes-gastos','comprobantes-gastos',false,10485760,
  array['image/jpeg','image/png','image/webp']::text[]
)
on conflict (id) do update set
  public=false,
  file_size_limit=excluded.file_size_limit,
  allowed_mime_types=excluded.allowed_mime_types;

-- Subida: solo owner o administrador con permiso registrar_gastos, y solo en su carpeta.
drop policy if exists "subir comprobante gasto autorizado" on storage.objects;
create policy "subir comprobante gasto autorizado"
on storage.objects for insert to authenticated
with check (
  bucket_id='comprobantes-gastos'
  and public.mi_numero() is not null
  and (storage.foldername(name))[1] = public.mi_numero()::text
  and public.tiene_permiso('registrar_gastos'::public.permiso_tipo)
);

-- Lectura: cualquier usuario activo puede ver comprobantes que ya estén ligados a un gasto.
drop policy if exists "ver comprobante gasto autenticado" on storage.objects;
create policy "ver comprobante gasto autenticado"
on storage.objects for select to authenticated
using (
  bucket_id='comprobantes-gastos'
  and public.mi_numero() is not null
  and exists (
    select 1 from public.gastos g
    where g.comprobante_path = storage.objects.name
  )
);

-- Limpieza segura: solo el autor puede borrar una subida que todavía NO esté ligada a un gasto.
drop policy if exists "borrar comprobante gasto huerfano" on storage.objects;
create policy "borrar comprobante gasto huerfano"
on storage.objects for delete to authenticated
using (
  bucket_id='comprobantes-gastos'
  and public.mi_numero() is not null
  and (storage.foldername(name))[1] = public.mi_numero()::text
  and public.tiene_permiso('registrar_gastos'::public.permiso_tipo)
  and not exists (
    select 1 from public.gastos g
    where g.comprobante_path = storage.objects.name
  )
);

create or replace function public.registrar_gasto_v2(
  p_request_id uuid,
  p_concepto text,
  p_monto_centavos bigint,
  p_comprobante_path text default null,
  p_comprobante_sha256 text default null,
  p_comprobante_mime text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, storage, pg_temp
as $$
declare
  v_uid uuid := auth.uid();
  v_actor smallint := public.mi_numero();
  v_id uuid;
  v_saldo bigint;
  v_path text := nullif(trim(coalesce(p_comprobante_path,'')), '');
  v_hash text := nullif(lower(trim(coalesce(p_comprobante_sha256,''))), '');
  v_mime text := nullif(lower(trim(coalesce(p_comprobante_mime,''))), '');
  v_prev_operacion text;
  v_prev_resultado jsonb;
  v_resultado jsonb;
begin
  if v_uid is null or v_actor is null then raise exception 'Debes iniciar sesión'; end if;
  if p_request_id is null then raise exception 'Solicitud inválida'; end if;
  if not public.tiene_permiso('registrar_gastos'::public.permiso_tipo) then
    raise exception 'No tienes permiso para registrar gastos';
  end if;

  perform pg_advisory_xact_lock(hashtextextended(v_uid::text||':'||p_request_id::text,0));
  select operacion, resultado into v_prev_operacion, v_prev_resultado
  from public.operaciones_idempotentes
  where actor_uid=v_uid and request_id=p_request_id;
  if found then
    if v_prev_operacion <> 'registrar_gasto_v2' then raise exception 'Solicitud reutilizada para otra operación'; end if;
    return v_prev_resultado;
  end if;

  if char_length(trim(coalesce(p_concepto,''))) < 2 then raise exception 'Concepto inválido'; end if;
  if p_monto_centavos is null or p_monto_centavos <= 0 then raise exception 'Monto inválido'; end if;
  v_saldo := public.saldo_actual_centavos();
  if p_monto_centavos > v_saldo then raise exception 'Saldo insuficiente para registrar este gasto'; end if;

  if v_path is not null then
    if split_part(v_path,'/',1) <> v_actor::text then raise exception 'Ruta de comprobante inválida'; end if;
    if v_hash is null or v_hash !~ '^[a-f0-9]{64}$' then raise exception 'Huella del comprobante inválida'; end if;
    if v_mime not in ('image/jpeg','image/png','image/webp') then raise exception 'Formato de comprobante inválido'; end if;
    if not exists (
      select 1 from storage.objects o
      where o.bucket_id='comprobantes-gastos' and o.name=v_path
    ) then raise exception 'El comprobante no existe en el almacenamiento'; end if;
    if exists (select 1 from public.gastos g where g.comprobante_path=v_path) then
      raise exception 'Este comprobante ya está asociado a un gasto';
    end if;
  else
    v_hash := null;
    v_mime := null;
  end if;

  insert into public.gastos(
    concepto,monto_centavos,registrado_por,
    comprobante_path,comprobante_sha256,comprobante_mime
  ) values (
    trim(p_concepto),p_monto_centavos,v_actor,
    v_path,v_hash,v_mime
  ) returning id into v_id;

  insert into public.bitacora(actor_numero,nivel,publico,evento,entidad,entidad_id,detalle)
  values(
    v_actor,'importante',true,'Gasto registrado','gasto',v_id::text,
    'Se registró el gasto "'||trim(p_concepto)||'" por '||p_monto_centavos||' centavos'||
    case when v_path is not null then ' con comprobante adjunto.' else ' sin comprobante.' end
  );

  v_resultado := jsonb_build_object('ok',true,'id',v_id,'con_comprobante',v_path is not null);
  insert into public.operaciones_idempotentes(actor_uid,request_id,operacion,resultado)
  values(v_uid,p_request_id,'registrar_gasto_v2',v_resultado);
  delete from public.operaciones_idempotentes where creado_at < now()-interval '30 days';
  return v_resultado;
end;
$$;

revoke all on function public.registrar_gasto_v2(uuid,text,bigint,text,text,text) from public, anon;
grant execute on function public.registrar_gasto_v2(uuid,text,bigint,text,text,text) to authenticated, service_role;
