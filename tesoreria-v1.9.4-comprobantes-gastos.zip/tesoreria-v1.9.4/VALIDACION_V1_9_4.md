# Validación v1.9.4

- versionCode 42 / versionName 1.9.4.
- Migración de Supabase aplicada y verificada: bucket privado `comprobantes-gastos` y RPC `registrar_gasto_v2` (anon sin EXECUTE, authenticated con EXECUTE).
- El snapshot existente usa `select *` de gastos, por lo que las nuevas columnas llegan a todos los clientes sin romper versiones anteriores.
- La app normaliza la imagen de gasto a JPEG antes de subirla y limita la selección a imágenes.
- La imagen queda en memoria local hasta confirmar y pulsar Registrar gasto; no se sube al seleccionarla.
- Movimientos solo expone lectura del comprobante, nunca agregar/reemplazar/borrar.
- Se ejecutó revisión sintáctica con el compilador Kotlin disponible; no aparecieron errores de parseo. La compilación Android final corresponde al workflow de GitHub Actions porque este entorno no incluye Android SDK/Gradle completo.
