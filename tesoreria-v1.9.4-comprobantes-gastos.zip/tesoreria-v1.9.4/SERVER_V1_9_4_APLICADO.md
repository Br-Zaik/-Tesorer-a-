# Servidor v1.9.4 aplicado

Migración aplicada en Supabase: `v1_9_4_comprobantes_gastos`.

Incluye columnas de comprobante en `gastos`, bucket privado `comprobantes-gastos`, políticas RLS y RPC idempotente `registrar_gasto_v2`. La función no es ejecutable por `anon` y sí por `authenticated`.
