# Tesorería v1.9.3

## Corrección visual del inicio de sesión

- Corregido el pequeño salto/parpadeo aparente del logo y del formulario al pulsar **Entrar**.
- La causa era el reajuste de altura del teclado (IME) combinado con el centrado vertical del formulario.
- El login ahora queda anclado en una posición estable mientras el teclado se abre o se cierra.
- Se mantiene el desplazamiento vertical para pantallas pequeñas y el `imePadding` para que el teclado no tape los controles.
- No se modificó la lógica de autenticación, Supabase, permisos, cobros ni notificaciones.

VersionCode: 41  
VersionName: 1.9.3
