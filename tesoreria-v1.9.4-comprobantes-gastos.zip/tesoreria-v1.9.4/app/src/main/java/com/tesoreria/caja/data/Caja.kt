package com.tesoreria.caja.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.absoluteValue

val PE: Locale = Locale("es", "PE")

fun soles(centavos: Long): String = String.format(PE, "S/ %,.2f", centavos / 100.0)
fun fechaHora(t: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", PE).format(Date(t))
fun fechaCorta(t: Long): String = SimpleDateFormat("dd/MM/yyyy", PE).format(Date(t))
fun fechaLarga(t: Long): String {
    val raw = SimpleDateFormat("d 'de' MMMM 'de' yyyy", PE).format(Date(t))
    return raw.replaceFirstChar { if (it.isLowerCase()) it.titlecase(PE) else it.toString() }
}
fun horaCorta(t: Long): String = SimpleDateFormat("HH:mm", PE).format(Date(t))
fun fechaHoraLarga(t: Long): String = "${fechaLarga(t)} · ${horaCorta(t)}"

fun parseCentavos(texto: String): Long? {
    var s = texto.trim().replace("S/", "", ignoreCase = true).replace(" ", "")
    if (s.isBlank()) return null
    s = when {
        s.contains(',') && s.contains('.') -> s.replace(",", "")
        s.contains(',') -> s.replace(',', '.')
        else -> s
    }
    if (!s.matches(Regex("\\d+(\\.\\d{0,2})?"))) return null
    val partes = s.split('.')
    val entero = partes[0].toLongOrNull() ?: return null
    val dec = when {
        partes.size == 1 || partes[1].isEmpty() -> 0L
        partes[1].length == 1 -> partes[1].toLong() * 10L
        else -> partes[1].take(2).toLong()
    }
    return entero * 100L + dec
}

enum class EstadoPago { SIN_ENVIAR, PENDIENTE, APROBADO, RECHAZADO, NO_PAGA }
enum class MedioPago { YAPE, MANUAL }
enum class TipoCobro { OFICIAL, RAPIDO }
enum class Rol { SOCIO, PRESIDENTE, TESORERO, PERSONALIZADO }
enum class NivelAcceso { OWNER, ADMINISTRADOR, USUARIO }
enum class EstadoMiembro { ACTIVO, BLOQUEADO, RETIRADO }
enum class Permiso {
    REGISTRAR_PAGO_MANUAL, GESTIONAR_COBROS, REGISTRAR_GASTOS,
    VER_COMPROBANTES_YAPE, REVISAR_COMPROBANTES_YAPE, GESTIONAR_NUMERO_YAPE,
    GESTIONAR_MIEMBROS, EXPORTAR_ACTAS, GESTIONAR_YAPE
}

data class Socio(
    val numero: Int,
    val nombre: String,
    val rol: Rol = Rol.SOCIO,
    val estado: EstadoMiembro = EstadoMiembro.ACTIVO,
    val permisosExtra: Set<Permiso> = emptySet(),
    val nivelAcceso: NivelAcceso = NivelAcceso.USUARIO,
    val cargoNombre: String = "",
    val cargoColor: String = "#22C55E",
    val participaCobros: Boolean = true
)

data class Cobro(
    val id: Int,
    val serverId: String,
    val titulo: String,
    val monto: Long,
    val creado: Long,
    val cierra: Long,
    val cerrado: Boolean = false,
    val extensionTexto: String = "",
    val tipo: TipoCobro = TipoCobro.OFICIAL
)

data class Pago(
    val id: Int,
    val serverId: String,
    val cobroId: Int,
    val socio: Int,
    val monto: Long,
    val estado: EstadoPago,
    val enviado: Long,
    val nota: String = "",
    val medio: MedioPago = MedioPago.YAPE,
    val capturaPath: String = "",
    val capturaSha256: String = "",
    val revisadoPor: Int? = null,
    val recibidoPor: Int? = null,
    val grupoId: String = "",
    val pagadorNumero: Int? = null,
    val grupoNumeros: List<Int> = emptyList()
)

enum class EstadoCodigoMasivo { DISPONIBLE, USADO, VENCIDO, CANCELADO }

data class CodigoMasivo(
    val codigo: String,
    val vence: Long,
    val creado: Long = 0L,
    val estado: EstadoCodigoMasivo = EstadoCodigoMasivo.DISPONIBLE,
    val usadoPor: Int? = null,
    val usadoAt: Long? = null
)

data class Gasto(
    val id: Int,
    val serverId: String,
    val concepto: String,
    val monto: Long,
    val fecha: Long,
    val anulado: Boolean = false,
    val motivoAnulacion: String = "",
    val comprobantePath: String = "",
    val comprobanteSha256: String = "",
    val comprobanteMime: String = ""
) {
    val aprobado: Boolean get() = !anulado
    val firmaTesorero: Boolean get() = !anulado
    val firmaPresidente: Boolean get() = true
}

data class DetalleActa(
    val socioNumero: Int,
    val nombreSnapshot: String = "",
    val estado: EstadoPago,
    val medio: MedioPago? = null,
    val monto: Long? = null,
    val motivoNoPago: String = ""
)

data class Acta(
    val serverId: String,
    val cobroId: Int,
    val titulo: String,
    val monto: Long,
    val cierre: Long,
    val recaudado: Long,
    val pagaron: List<Int>,
    val faltaron: List<Int>,
    val estados: Map<Int, EstadoPago> = emptyMap(),
    val detalles: Map<Int, DetalleActa> = emptyMap(),
    val tipo: TipoCobro = TipoCobro.OFICIAL
)

data class EstadoCuenta(
    val numero: Int,
    val nombre: String,
    val rol: Rol,
    val estado: EstadoMiembro,
    val activada: Boolean,
    val reseteoActivo: Boolean
)

data class YapeConfig(
    val numeroYape: String = "",
    val qrPath: String = "",
    val actualizado: Long = 0L
)

enum class EstadoConexionMiembro { CONECTADO, DESCONECTADO, SIN_ACTIVAR, BLOQUEADO, LIBRE }

data class PresenciaMiembro(
    val numero: Int,
    val estado: EstadoConexionMiembro,
    val ultimaActividad: Long? = null,
    val appVersion: String = ""
)

object Caja {
    val socios = mutableStateListOf<Socio>()
    val cobros = mutableStateListOf<Cobro>()
    val pagos = mutableStateListOf<Pago>()
    val gastos = mutableStateListOf<Gasto>()
    val actas = mutableStateListOf<Acta>()
    val bitacora = mutableStateListOf<String>()
    val yapeConfig = mutableStateOf(YapeConfig())
    val sesion = mutableStateOf<Socio?>(null)
    val cargando = mutableStateOf(false)
    val ultimoError = mutableStateOf<String?>(null)
    val ultimoCodigoTemporal = mutableStateOf<String?>(null)
    val codigoTemporalPara = mutableStateOf<Int?>(null)
    val cobroSubidaId = mutableStateOf<Int?>(null)
    val codigosActivos = mutableStateMapOf<Int, Long>()
    val codigosMasivos = mutableStateListOf<CodigoMasivo>()
    val decisionesNoPago = mutableStateMapOf<String, Set<Int>>()
    val motivosNoPago = mutableStateMapOf<String, String>()
    val cargandoCodigosMasivos = mutableStateOf(false)
    val presencias = mutableStateMapOf<Int, PresenciaMiembro>()
    val presenciasCargadas = mutableStateOf(false)
    val appEnPrimerPlano = mutableStateOf(false)
    val conectado = NetworkMonitor.conectado

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var appContext: Context? = null
    private var refrescoEnCurso = false
    private val operacionesEnCurso = mutableSetOf<String>()

    val esOwner: Boolean get() = sesion.value?.nivelAcceso == NivelAcceso.OWNER
    val esAdministrador: Boolean get() = sesion.value?.nivelAcceso == NivelAcceso.ADMINISTRADOR
    // Compatibilidad con pantallas antiguas: “admin” significa el owner principal.
    val esAdmin: Boolean get() = esOwner
    val esPresidente: Boolean get() = sesion.value?.rol == Rol.PRESIDENTE

    fun initialize(context: Context) {
        appContext = context.applicationContext
        SupabaseApi.initialize(context)
        cargarCodigosLocales()
    }

    suspend fun restaurarSesion(): Boolean = try {
        if (!SupabaseApi.restaurarSesion()) {
            false
        } else {
            // No mostramos Inicio hasta tener el snapshot completo del servidor.
            // Así nunca aparece durante unos segundos saldo/cobros en cero.
            cargarTodo()
            sesion.value != null
        }
    } catch (_: Exception) { false }

    suspend fun consultarCuenta(numero: Int): EstadoCuenta {
        val j = SupabaseApi.estadoCuenta(numero)
        return EstadoCuenta(
            numero = j.getInt("numero"),
            nombre = j.getString("nombre"),
            rol = rolDe(j.optString("rol")),
            estado = estadoMiembroDe(j.optString("estado")),
            activada = j.optBoolean("activada"),
            reseteoActivo = j.optBoolean("reseteo_activo")
        )
    }

    suspend fun iniciarSesion(numero: Int, clave: String): Socio {
        SupabaseApi.iniciarSesion(numero, clave)
        // Una sola carga compacta del servidor antes de abrir Inicio.
        // El usuario entra cuando saldo, cobro, pagos y permisos ya están listos.
        cargarTodo()
        return sesion.value ?: throw IllegalStateException("No se pudo cargar tu cuenta")
    }

    suspend fun activarCuenta(numero: Int, codigo: String, clave: String): Socio {
        SupabaseApi.activarCuenta(numero, codigo, clave)
        SupabaseApi.iniciarSesion(numero, clave)
        cargarTodo()
        return sesion.value ?: throw IllegalStateException("La cuenta se activó, pero no se pudo cargar")
    }


    fun cerrarSesion() {
        scope.launch {
            try { SupabaseApi.marcarDesconectado() } catch (_: Exception) { }
            SupabaseApi.cerrarSesion()
        }
        sesion.value = null
        limpiarDatos()
    }

    private fun limpiarDatos() {
        socios.clear(); cobros.clear(); pagos.clear(); gastos.clear(); actas.clear(); bitacora.clear(); codigosActivos.clear(); codigosMasivos.clear(); decisionesNoPago.clear(); motivosNoPago.clear(); presencias.clear(); presenciasCargadas.value = false
    }

    suspend fun cargarTodo() = withContext(Dispatchers.IO) {
        // Antes se abrían 12+ peticiones HTTP independientes. En red móvil eso
        // hacía que Inicio apareciera vacío y se rellenara varios segundos después.
        // Ahora Supabase entrega un snapshot coherente en una sola petición.
        val snapshot = SupabaseApi.snapshotApp()
        val contextoNotificaciones = appContext
        if (contextoNotificaciones != null) {
            try { Notificaciones.procesarSnapshot(contextoNotificaciones, snapshot) } catch (_: Exception) { }
        }
        fun array(nombre: String): JSONArray = snapshot.optJSONArray(nombre) ?: JSONArray()

        val miembros = array("miembros")
        val permisos = array("permisos")
        val cobrosJ = array("cobros")
        val pagosJ = array("pagos")
        val privados = array("privados")
        val decisionesJ = array("decisiones")
        val decisionesPrivadasJ = array("decisiones_privadas")
        val gastosJ = array("gastos")
        val actasJ = array("actas")
        val detallePublicoJ = array("detalle_publico")
        val detallePrivadoJ = array("detalle_privado")
        val bitJ = array("bitacora")
        val yapeJ = array("yape_config")
        val reseteosJ = array("reseteos")
        val miNumero = if (snapshot.has("mi_numero") && !snapshot.isNull("mi_numero")) snapshot.optInt("mi_numero") else null

        val permisosPor = mutableMapOf<Int, MutableSet<Permiso>>()
        for (i in 0 until permisos.length()) {
            val p = permisos.getJSONObject(i)
            val n = p.getInt("socio_numero")
            permisoDe(p.getString("permiso"))?.let { permisosPor.getOrPut(n) { mutableSetOf() }.add(it) }
        }

        val nuevosSocios = mutableListOf<Socio>()
        for (i in 0 until miembros.length()) {
            val m = miembros.getJSONObject(i)
            nuevosSocios += Socio(
                numero = m.getInt("numero"),
                nombre = m.optString("nombre"),
                rol = rolDe(m.optString("rol")),
                estado = estadoMiembroDe(m.optString("estado")),
                permisosExtra = permisosPor[m.getInt("numero")] ?: emptySet(),
                nivelAcceso = nivelAccesoDe(m.optString("nivel_acceso", "usuario")),
                cargoNombre = m.optString("cargo_nombre"),
                cargoColor = m.optString("cargo_color", "#22C55E"),
                participaCobros = m.optBoolean("participa_cobros", true)
            )
        }

        val nuevosCobros = mutableListOf<Cobro>()
        val cobroMap = mutableMapOf<String, Int>()
        for (i in 0 until cobrosJ.length()) {
            val c = cobrosJ.getJSONObject(i); val sid = c.getString("id"); val lid = localId(sid); cobroMap[sid] = lid
            nuevosCobros += Cobro(lid, sid, c.getString("titulo"), c.getLong("monto_centavos"), iso(c.getString("creado_at")), iso(c.getString("cierra_at")), !c.isNull("cerrado_at"), c.optString("extension_texto"), tipoCobroDe(c.optString("tipo", "oficial")))
        }

        val privadosMap = mutableMapOf<String, JSONObject>()
        for (i in 0 until privados.length()) privadosMap[privados.getJSONObject(i).getString("pago_id")] = privados.getJSONObject(i)
        val nuevosPagos = mutableListOf<Pago>()
        for (i in 0 until pagosJ.length()) {
            val p = pagosJ.getJSONObject(i); val sid = p.getString("id"); val priv = privadosMap[sid]
            val meta = priv?.optJSONObject("metadata_ocr")
            val grupoNumeros = mutableListOf<Int>()
            meta?.optJSONArray("numeros")?.let { a ->
                for (k in 0 until a.length()) a.optInt(k, 0).takeIf { it in 1..35 }?.let(grupoNumeros::add)
            }
            nuevosPagos += Pago(
                id = localId(sid), serverId = sid, cobroId = cobroMap[p.getString("cobro_id")] ?: localId(p.getString("cobro_id")),
                socio = p.getInt("socio_numero"), monto = p.getLong("monto_centavos"), estado = estadoPagoDe(p.getString("estado")),
                enviado = iso(p.getString("enviado_at")), nota = priv?.optString("motivo_rechazo").orEmpty(),
                medio = if (p.optString("medio") == "manual") MedioPago.MANUAL else MedioPago.YAPE,
                capturaPath = priv?.optString("captura_path").orEmpty(),
                capturaSha256 = priv?.optString("captura_sha256").orEmpty(),
                revisadoPor = if (p.isNull("revisado_por")) null else p.optInt("revisado_por"),
                recibidoPor = if (p.isNull("recibido_por")) null else p.optInt("recibido_por"),
                grupoId = meta?.optString("grupo_id").orEmpty(),
                pagadorNumero = meta?.optInt("pagador_numero", 0)?.takeIf { it in 1..35 },
                grupoNumeros = grupoNumeros.distinct().sorted()
            )
        }

        val nuevasDecisiones = mutableMapOf<String, MutableSet<Int>>()
        for (i in 0 until decisionesJ.length()) {
            val d = decisionesJ.optJSONObject(i) ?: continue
            val cobroSid = d.optString("cobro_id")
            val cobroLocal = cobroMap[cobroSid] ?: localId(cobroSid)
            nuevasDecisiones.getOrPut(cobroLocal.toString()) { mutableSetOf() }.add(d.optInt("socio_numero"))
        }
        val nuevosMotivos = mutableMapOf<String, String>()
        for (i in 0 until decisionesPrivadasJ.length()) {
            val d = decisionesPrivadasJ.optJSONObject(i) ?: continue
            val cobroSid = d.optString("cobro_id")
            val cobroLocal = cobroMap[cobroSid] ?: localId(cobroSid)
            val n = d.optInt("socio_numero")
            nuevosMotivos["$cobroLocal:$n"] = d.optString("motivo")
        }

        val nuevosGastos = mutableListOf<Gasto>()
        for (i in 0 until gastosJ.length()) {
            val g = gastosJ.getJSONObject(i); val sid = g.getString("id")
            nuevosGastos += Gasto(
                id = localId(sid),
                serverId = sid,
                concepto = g.getString("concepto"),
                monto = g.getLong("monto_centavos"),
                fecha = iso(g.getString("registrado_at")),
                anulado = !g.isNull("anulado_at"),
                motivoAnulacion = g.optString("motivo_anulacion"),
                comprobantePath = if (g.isNull("comprobante_path")) "" else g.optString("comprobante_path"),
                comprobanteSha256 = if (g.isNull("comprobante_sha256")) "" else g.optString("comprobante_sha256"),
                comprobanteMime = if (g.isNull("comprobante_mime")) "" else g.optString("comprobante_mime")
            )
        }

        val resumenPorActa = mutableMapOf<String, MutableList<JSONObject>>()
        for (i in 0 until detallePublicoJ.length()) {
            val d = detallePublicoJ.getJSONObject(i)
            resumenPorActa.getOrPut(d.getString("acta_id")) { mutableListOf() }.add(d)
        }
        val privadoPorClave = mutableMapOf<Pair<String, Int>, JSONObject>()
        for (i in 0 until detallePrivadoJ.length()) {
            val d = detallePrivadoJ.getJSONObject(i)
            privadoPorClave[d.getString("acta_id") to d.getInt("socio_numero")] = d
        }

        val nuevasActas = mutableListOf<Acta>()
        for (i in 0 until actasJ.length()) {
            val a = actasJ.getJSONObject(i)
            val sid = a.getString("id")
            val resumen = resumenPorActa[sid].orEmpty()
            val detalles = resumen.associate { r ->
                val numero = r.getInt("socio_numero")
                val privado = privadoPorClave[sid to numero]
                val medio = if (privado == null || privado.isNull("medio")) null else when (privado.optString("medio")) {
                    "manual" -> MedioPago.MANUAL
                    "yape" -> MedioPago.YAPE
                    else -> null
                }
                numero to DetalleActa(
                    socioNumero = numero,
                    nombreSnapshot = if (privado == null || privado.isNull("nombre_snapshot")) "" else privado.optString("nombre_snapshot"),
                    estado = estadoActaDe(r.getString("estado")),
                    medio = medio,
                    monto = if (privado == null || privado.isNull("monto_centavos")) null else privado.optLong("monto_centavos"),
                    motivoNoPago = if (privado != null && !privado.isNull("motivo_no_pago")) privado.optString("motivo_no_pago") else r.optString("motivo_no_pago")
                )
            }
            val estados = detalles.mapValues { it.value.estado }
            nuevasActas += Acta(
                serverId = sid,
                cobroId = cobroMap[a.getString("cobro_id")] ?: localId(a.getString("cobro_id")),
                titulo = a.getString("titulo"),
                monto = a.getLong("cuota_centavos"),
                cierre = iso(a.getString("cerrado_at")),
                recaudado = a.getLong("recaudado_centavos"),
                pagaron = estados.filterValues { it == EstadoPago.APROBADO }.keys.sorted(),
                faltaron = estados.filterValues { it != EstadoPago.APROBADO && it != EstadoPago.NO_PAGA }.keys.sorted(),
                estados = estados,
                detalles = detalles,
                tipo = tipoCobroDe(a.optString("tipo", "oficial"))
            )
        }

        val nuevosEventos = mutableListOf<String>()
        for (i in 0 until bitJ.length()) {
            val b = bitJ.getJSONObject(i)
            val actorNumero = if (b.isNull("actor_numero")) null else b.getInt("actor_numero")
            val actor = actorNumero?.let { "N.º $it" } ?: "Sistema"
            val detalleOriginal = b.optString("detalle", b.optString("evento")).trim()
            // Varias entradas antiguas ya incluyen el actor al inicio del detalle.
            // Como la UI agrega el actor en una columna propia, quitamos solo ese prefijo
            // para evitar textos como "N.º 22 · N.º 22 aprobó...".
            val detalle = if (actorNumero != null) {
                detalleOriginal.replaceFirst(
                    Regex("^N[.º°\\s]*\\.?\\s*${actorNumero}\\s*[·:–—-]?\\s*", RegexOption.IGNORE_CASE),
                    ""
                ).trim()
            } else {
                detalleOriginal.replaceFirst(Regex("^Sistema\\s*[·:–—-]?\\s*", RegexOption.IGNORE_CASE), "").trim()
            }
            nuevosEventos += "${fechaHora(iso(b.getString("creado_at")))}  ·  $actor  ·  $detalle"
        }

        val nuevoYape = if (yapeJ.length() > 0) {
            val y = yapeJ.getJSONObject(0)
            YapeConfig(
                numeroYape = y.optString("numero_yape"),
                qrPath = "",
                actualizado = isoOrNull(y.optString("actualizado_at")) ?: 0L
            )
        } else YapeConfig()

        val ahoraServidor = System.currentTimeMillis()
        val resetsActivos = mutableMapOf<Int, Long>()
        for (i in 0 until reseteosJ.length()) {
            val r = reseteosJ.getJSONObject(i)
            if (!r.isNull("usado_at") || !r.isNull("cancelado_at")) continue
            val vence = isoOrNull(r.optString("vence_at")) ?: continue
            if (vence > ahoraServidor) {
                val n = r.getInt("socio_numero")
                if ((resetsActivos[n] ?: 0L) < vence) resetsActivos[n] = vence
            }
        }

        withContext(Dispatchers.Main) {
            socios.clear(); socios.addAll(nuevosSocios)
            cobros.clear(); cobros.addAll(nuevosCobros)
            pagos.clear(); pagos.addAll(nuevosPagos)
            gastos.clear(); gastos.addAll(nuevosGastos)
            actas.clear(); actas.addAll(nuevasActas)
            bitacora.clear(); bitacora.addAll(nuevosEventos)
            yapeConfig.value = nuevoYape
            codigosActivos.clear(); codigosActivos.putAll(resetsActivos)
            decisionesNoPago.clear(); nuevasDecisiones.forEach { (k, v) -> decisionesNoPago[k] = v.toSet() }
            motivosNoPago.clear(); motivosNoPago.putAll(nuevosMotivos)
            limpiarCodigosLocalesVencidos()
            if (miNumero != null) {
                val yo = socios.firstOrNull { it.numero == miNumero }
                    ?: throw IllegalStateException("No se pudo cargar tu cuenta")
                if (yo.estado == EstadoMiembro.BLOQUEADO) throw IllegalStateException("Esta cuenta está bloqueada")
                if (yo.estado == EstadoMiembro.RETIRADO) throw IllegalStateException("Esta cuenta ya no está activa")
                sesion.value = yo
            } else {
                throw SesionInvalidaException()
            }
        }
    }

    fun refrescar() {
        if (!conectado.value || sesion.value == null || refrescoEnCurso) return
        refrescoEnCurso = true
        scope.launch {
            try {
                cargarTodo()
                ultimoError.value = null
            } catch (e: SesionInvalidaException) {
                ultimoError.value = e.message
                sesion.value = null
                limpiarDatos()
            } catch (e: Exception) {
                val mensaje = mensajeAmigable(e)
                if (e !is SinConexionException && e !is ServidorTemporalException) {
                    ultimoError.value = mensaje
                }
            } finally {
                refrescoEnCurso = false
            }
        }
    }

    fun permisosDelegables(): Set<Permiso> = setOf(
        Permiso.REGISTRAR_PAGO_MANUAL, Permiso.GESTIONAR_COBROS, Permiso.REGISTRAR_GASTOS,
        Permiso.VER_COMPROBANTES_YAPE, Permiso.REVISAR_COMPROBANTES_YAPE, Permiso.GESTIONAR_NUMERO_YAPE,
        Permiso.GESTIONAR_MIEMBROS, Permiso.EXPORTAR_ACTAS
    )
    fun puedeAbrirPanel(socio: Socio?): Boolean = socio != null && socio.estado == EstadoMiembro.ACTIVO &&
        (socio.nivelAcceso == NivelAcceso.OWNER || (socio.nivelAcceso == NivelAcceso.ADMINISTRADOR && socio.permisosExtra.isNotEmpty()))
    fun permisosBase(socio: Socio?): Set<Permiso> = if (socio?.nivelAcceso == NivelAcceso.OWNER) permisosDelegables() else emptySet()
    fun tienePermiso(socio: Socio?, permiso: Permiso): Boolean = socio != null && socio.estado == EstadoMiembro.ACTIVO &&
        (permiso in permisosBase(socio) || (socio.nivelAcceso == NivelAcceso.ADMINISTRADOR && permiso in socio.permisosExtra))
    fun puedeVerYape(socio: Socio?): Boolean = esOwner || tienePermiso(socio, Permiso.VER_COMPROBANTES_YAPE) || tienePermiso(socio, Permiso.REVISAR_COMPROBANTES_YAPE) || tienePermiso(socio, Permiso.GESTIONAR_YAPE)
    fun puedeRevisarYape(socio: Socio?): Boolean = esOwner || tienePermiso(socio, Permiso.REVISAR_COMPROBANTES_YAPE) || tienePermiso(socio, Permiso.GESTIONAR_YAPE)

    fun ingresos(): Long = pagos.filter { p -> p.estado == EstadoPago.APROBADO && cobros.firstOrNull { it.id == p.cobroId }?.tipo != TipoCobro.RAPIDO }.sumOf { it.monto }
    fun egresos(): Long = gastos.filter { it.aprobado }.sumOf { it.monto }
    fun saldo(): Long = ingresos() - egresos()
    fun comprometidoPendiente(): Long = 0L
    fun disponibleParaGastos(): Long = saldo().coerceAtLeast(0L)
    fun cobrosActivos(): List<Cobro> = cobros.filter { !it.cerrado && it.cierra > System.currentTimeMillis() }.sortedWith(compareBy<Cobro> { it.tipo == TipoCobro.RAPIDO }.thenByDescending { it.creado })
    fun cobroActivo(): Cobro? = cobrosActivos().firstOrNull { it.tipo == TipoCobro.OFICIAL }
    fun cobroParaSubir(): Cobro? = cobroSubidaId.value?.let { id -> cobrosActivos().firstOrNull { it.id == id } } ?: cobrosActivos().firstOrNull()
    fun cobrosRapidosActivos(): List<Cobro> = cobrosActivos().filter { it.tipo == TipoCobro.RAPIDO }
    private fun ultimoPago(cobroId: Int, numero: Int): Pago? = pagos.filter { it.cobroId == cobroId && it.socio == numero }.maxByOrNull { it.enviado }
    fun estadoDe(cobroId: Int, numero: Int): EstadoPago {
        val pago = ultimoPago(cobroId, numero)
        if (pago != null) return pago.estado
        if (decisionesNoPago[cobroId.toString()]?.contains(numero) == true) return EstadoPago.NO_PAGA
        return EstadoPago.SIN_ENVIAR
    }
    fun motivoNoPago(cobroId: Int, numero: Int): String = motivosNoPago["$cobroId:$numero"].orEmpty()
    fun pagoDe(cobroId: Int, numero: Int): Pago? = ultimoPago(cobroId, numero)
    fun miembrosActivos(): List<Socio> = socios.filter { it.estado != EstadoMiembro.RETIRADO }
    fun miembrosParticipantes(): List<Socio> = socios.filter { it.estado == EstadoMiembro.ACTIVO && it.participaCobros }
    fun faltantes(cobroId: Int): List<Int> = miembrosParticipantes().map { it.numero }.filter { estadoDe(cobroId, it) !in setOf(EstadoPago.APROBADO, EstadoPago.NO_PAGA) }.sorted()
    fun noEnviaron(cobroId: Int): List<Int> = miembrosParticipantes().map { it.numero }.filter { estadoDe(cobroId, it) == EstadoPago.SIN_ENVIAR }.sorted()
    fun noParticipan(cobroId: Int): List<Int> = miembrosParticipantes().map { it.numero }.filter { estadoDe(cobroId, it) == EstadoPago.NO_PAGA }.sorted()
    fun porRevisar(cobroId: Int): List<Int> = miembrosParticipantes().map { it.numero }.filter { estadoDe(cobroId, it) == EstadoPago.PENDIENTE }.sorted()
    fun rechazados(cobroId: Int): List<Int> = miembrosParticipantes().map { it.numero }.filter { estadoDe(cobroId, it) == EstadoPago.RECHAZADO }.sorted()
    fun aprobados(cobroId: Int): Int = miembrosParticipantes().count { estadoDe(cobroId, it.numero) == EstadoPago.APROBADO }
    fun recaudado(cobroId: Int): Long = pagos.filter { it.cobroId == cobroId && it.estado == EstadoPago.APROBADO }.sumOf { it.monto }
    fun socio(numero: Int): Socio? = socios.firstOrNull { it.numero == numero }
    fun pendientes(): List<Pago> = pagos.filter { it.estado == EstadoPago.PENDIENTE }.sortedByDescending { it.enviado }

    fun crearCobro(titulo: String, monto: Long, duracionMinutos: Int, tipo: TipoCobro = TipoCobro.OFICIAL) = operar("crear_cobro_v2", JSONObject().put("p_titulo", titulo).put("p_monto_centavos", monto).put("p_duracion_minutos", duracionMinutos).put("p_tipo", if (tipo == TipoCobro.RAPIDO) "rapido" else "oficial"))
    fun crearCobroFecha(titulo: String, monto: Long, cierraAt: Long, tipo: TipoCobro = TipoCobro.OFICIAL) = operar("crear_cobro_v3", JSONObject().put("p_titulo", titulo).put("p_monto_centavos", monto).put("p_cierra_at", isoDesdeMillis(cierraAt)).put("p_tipo", if (tipo == TipoCobro.RAPIDO) "rapido" else "oficial"))
    fun ajustarCobroFecha(id: Int, cierraAt: Long) { cobros.firstOrNull { it.id == id }?.let { operar("ajustar_cobro_fecha", JSONObject().put("p_cobro_id", it.serverId).put("p_cierra_at", isoDesdeMillis(cierraAt))) } }
    fun declararNoPago(cobroId: Int, motivo: String, onFin: (Boolean, String) -> Unit = { _, _ -> }) {
        cobros.firstOrNull { it.id == cobroId }?.let { operar("declarar_no_pago", JSONObject().put("p_cobro_id", it.serverId).put("p_motivo", motivo.trim()), onFin) } ?: onFin(false, "Cobro no encontrado")
    }
    fun cancelarNoPago(cobroId: Int, onFin: (Boolean, String) -> Unit = { _, _ -> }) {
        cobros.firstOrNull { it.id == cobroId }?.let { operar("cancelar_no_pago", JSONObject().put("p_cobro_id", it.serverId), onFin) } ?: onFin(false, "Cobro no encontrado")
    }
    fun marcarPagoRapido(cobroId: Int, pagado: Boolean) { cobros.firstOrNull { it.id == cobroId && it.tipo == TipoCobro.RAPIDO }?.let { operar("marcar_pago_rapido", JSONObject().put("p_cobro_id", it.serverId).put("p_pagado", pagado)) } }
    fun ajustarCobro(id: Int, minutosDelta: Int) { cobros.firstOrNull { it.id == id }?.let { operar("ajustar_cobro", JSONObject().put("p_cobro_id", it.serverId).put("p_minutos_delta", minutosDelta)) } }
    fun cerrarCobro(id: Int) { cobros.firstOrNull { it.id == id }?.let { operar("cerrar_cobro", JSONObject().put("p_cobro_id", it.serverId)) } }
    fun registrarPagoManual(
        cobroId: Int,
        numero: Int,
        monto: Long,
        onFin: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        val cobro = cobros.firstOrNull { it.id == cobroId }
        if (cobro == null) {
            onFin(false, "Cobro no encontrado")
            return
        }
        operar(
            "registrar_pago_manual",
            JSONObject()
                .put("p_cobro_id", cobro.serverId)
                .put("p_socio_numero", numero)
                .put("p_monto_centavos", monto),
            onFin
        )
    }
    fun registrarPagoManualGrupo(
        cobroId: Int,
        numeros: Collection<Int>,
        onFin: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        val cobro = cobros.firstOrNull { it.id == cobroId }
        val lista = numeros.filter { it in 1..35 }.distinct().sorted()
        if (cobro == null) { onFin(false, "Cobro no encontrado"); return }
        if (lista.isEmpty()) { onFin(false, "Selecciona al menos una persona"); return }
        scope.launch {
            try {
                SupabaseApi.rpc(
                    "registrar_pago_manual_grupo",
                    JSONObject().put("p_cobro_id", cobro.serverId).put("p_socios", JSONArray(lista))
                )
                try { cargarTodo() } catch (_: Exception) { }
                onFin(true, "Pago conjunto registrado")
            } catch (e: Exception) {
                onFin(false, mensajeAmigable(e))
            }
        }
    }

    fun corregirAsignacionPago(id: Int, nuevoNumero: Int) { pagos.firstOrNull { it.id == id }?.let { operar("corregir_asignacion_pago", JSONObject().put("p_pago_id", it.serverId).put("p_nuevo_socio", nuevoNumero)) } }
    fun aprobarPago(id: Int) { pagos.firstOrNull { it.id == id }?.let { operar("revisar_pago_yape", JSONObject().put("p_pago_id", it.serverId).put("p_aprobar", true).put("p_motivo_rechazo", JSONObject.NULL)) } }
    fun rechazarPago(id: Int, motivo: String) { pagos.firstOrNull { it.id == id }?.let { operar("revisar_pago_yape", JSONObject().put("p_pago_id", it.serverId).put("p_aprobar", false).put("p_motivo_rechazo", motivo)) } }
    fun aprobarGrupoYape(grupoId: String) = revisarGrupoYape(grupoId, true, null)
    fun rechazarGrupoYape(grupoId: String, motivo: String) = revisarGrupoYape(grupoId, false, motivo)

    private fun revisarGrupoYape(grupoId: String, aprobar: Boolean, motivo: String?) {
        if (grupoId.isBlank()) return
        scope.launch {
            try {
                SupabaseApi.rpc(
                    "revisar_pago_yape_grupo",
                    JSONObject().put("p_grupo_id", grupoId).put("p_aprobar", aprobar)
                        .put("p_motivo_rechazo", motivo ?: JSONObject.NULL)
                )
                try { cargarTodo() } catch (_: Exception) { }
            } catch (e: Exception) {
                ultimoError.value = mensajeAmigable(e)
            }
        }
    }
    fun crearGasto(concepto: String, monto: Long) = operar("registrar_gasto", JSONObject().put("p_concepto", concepto).put("p_monto_centavos", monto))

    suspend fun registrarGastoNuevo(
        concepto: String,
        monto: Long,
        comprobante: ComprobanteImagen.Resultado? = null,
        requestId: String = UUID.randomUUID().toString()
    ) {
        val yo = sesion.value ?: throw IllegalStateException("Sesión no válida")
        if (!(esOwner || tienePermiso(yo, Permiso.REGISTRAR_GASTOS))) throw IllegalStateException("No tienes permiso para registrar gastos")
        if (!conectado.value) throw SinConexionException()
        if (concepto.trim().length < 2) throw IllegalStateException("Concepto inválido")
        if (monto <= 0L) throw IllegalStateException("Monto inválido")

        var path: String? = null
        var hash: String? = null
        var mime: String? = null
        if (comprobante != null) {
            hash = MessageDigest.getInstance("SHA-256").digest(comprobante.bytes).joinToString("") { "%02x".format(it) }
            mime = comprobante.mime
            val ext = when (mime) { "image/png" -> "png"; "image/webp" -> "webp"; else -> "jpg" }
            path = "${yo.numero}/gasto-$requestId-$hash.$ext"
            try {
                SupabaseApi.uploadComprobanteGasto(path, comprobante.bytes, mime)
            } catch (e: Exception) {
                // Si una respuesta se perdió y el usuario reintenta con el mismo requestId,
                // el archivo puede existir ya. En ese caso continuamos hacia el RPC
                // idempotente, que devolverá el gasto ya creado o terminará de crearlo.
                val n = e.message.orEmpty().lowercase(Locale.ROOT)
                if ("already exists" !in n && "resource already exists" !in n && "duplicate" !in n && "ya existe" !in n) throw e
            }
        }

        try {
            SupabaseApi.registrarGastoV2(
                requestId = requestId,
                concepto = concepto.trim(),
                montoCentavos = monto,
                comprobantePath = path,
                comprobanteSha256 = hash,
                comprobanteMime = mime
            )
        } catch (e: Exception) {
            if (path != null && e !is SinConexionException && e !is ServidorTemporalException) {
                runCatching { SupabaseApi.eliminarComprobanteGastoHuerfano(path) }
            }
            throw e
        }
        try { cargarTodo() } catch (_: Exception) { }
    }

    suspend fun comprobanteGastoBytes(gasto: Gasto): ByteArray =
        SupabaseApi.descargarComprobanteGasto(gasto.comprobantePath)

    fun gastosPorFirmar(): List<Gasto> = emptyList()
    fun firmarGasto(id: Int, comoPresidente: Boolean) = Unit

    suspend fun enviarComprobante(
        cobro: Cobro,
        bytes: ByteArray,
        mime: String,
        capturaDHash: Long,
        numeros: List<Int> = listOf(sesion.value?.numero ?: 0),
        onProgress: (Int) -> Unit = {}
    ) {
        val yo = sesion.value ?: throw IllegalStateException("Sesión no válida")
        val grupo = (numeros + yo.numero).filter { it in 1..35 }.distinct().sorted()
        if (!conectado.value) throw SinConexionException()
        val hash = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        val ext = when (mime) { "image/png" -> "png"; "image/webp" -> "webp"; else -> "jpg" }
        val path = "${yo.numero}/${cobro.serverId}/${System.currentTimeMillis()}-$hash.$ext"

        val validacionRaw = SupabaseApi.rpc("validar_comprobante_yape_foto", JSONObject()
            .put("p_cobro_id", cobro.serverId)
            .put("p_captura_sha256", hash)
            .put("p_captura_dhash", capturaDHash))
        val validacion = runCatching { JSONObject(validacionRaw) }.getOrNull()
        if (validacion != null && !validacion.optBoolean("ok", false)) {
            throw IllegalStateException(validacion.optString("mensaje", "Esta captura ya fue utilizada"))
        }

        onProgress(12)
        SupabaseApi.uploadComprobante(path, bytes, mime)
        onProgress(62)
        try {
            if (grupo.size > 1) {
                SupabaseApi.rpc("enviar_pago_yape_foto_grupo", JSONObject()
                    .put("p_cobro_id", cobro.serverId)
                    .put("p_socios", JSONArray(grupo))
                    .put("p_captura_path", path)
                    .put("p_captura_sha256", hash)
                    .put("p_captura_dhash", capturaDHash))
            } else {
                SupabaseApi.rpc("enviar_pago_yape_foto", JSONObject()
                    .put("p_cobro_id", cobro.serverId)
                    .put("p_captura_path", path)
                    .put("p_captura_sha256", hash)
                    .put("p_captura_dhash", capturaDHash))
            }
        } catch (e: Exception) {
            // Si el servidor respondió con un rechazo definitivo, la foto ya subida
            // no debe quedar ocupando Storage. En errores de red/timeout NO se borra:
            // la operación podría haberse confirmado en el servidor y la UI la verifica.
            if (e !is SinConexionException && e !is ServidorTemporalException) {
                runCatching { SupabaseApi.eliminarComprobanteHuerfano(path) }
            }
            throw e
        }
        onProgress(94)
        try { cargarTodo() } catch (_: Exception) { }
        onProgress(100)
    }

    suspend fun verificarEnvio(cobro: Cobro, numeros: Collection<Int> = listOf(sesion.value?.numero ?: 0)): Boolean {
        if (!conectado.value) return false
        return try {
            cargarTodo()
            val yo = sesion.value?.numero ?: return false
            val lista = (numeros + yo).filter { it in 1..35 }.distinct()
            lista.isNotEmpty() && lista.all { pagoDe(cobro.id, it)?.estado == EstadoPago.PENDIENTE }
        } catch (_: Exception) { false }
    }

    suspend fun comprobanteBytes(pago: Pago): ByteArray = SupabaseApi.descargarComprobante(pago.capturaPath)

    fun guardarConfigYape(numeroYape: String, onFin: (Boolean, String) -> Unit = { _, _ -> }) {
        if (!(esOwner || tienePermiso(sesion.value, Permiso.GESTIONAR_NUMERO_YAPE) || tienePermiso(sesion.value, Permiso.GESTIONAR_YAPE))) { ultimoError.value = "No tienes permiso"; onFin(false, "No tienes permiso"); return }
        if (!conectado.value) { ultimoError.value = "Sin conexión a Internet"; onFin(false, "Sin conexión a Internet"); return }
        scope.launch {
            try {
                val numero = numeroYape.filter(Char::isDigit).take(9)
                if (numero.length != 9) throw IllegalStateException("Escribe un número Yape válido de 9 dígitos")
                SupabaseApi.rpcIdempotente("guardar_yape_config", JSONObject().put("p_numero_yape", numero).put("p_qr_path", JSONObject.NULL))
                ultimoError.value = null
                yapeConfig.value = yapeConfig.value.copy(numeroYape = numero, actualizado = System.currentTimeMillis())
                try { cargarTodo() } catch (_: Exception) { }
                onFin(true, "Guardado")
            } catch (e: Exception) {
                val m = mensajeAmigable(e).ifBlank { "No se pudo guardar" }
                if (e !is SinConexionException && e !is ServidorTemporalException) ultimoError.value = m
                onFin(false, m)
            }
        }
    }

    fun actualizarNombre(numero: Int, nombre: String) {
        operar("actualizar_nombre_miembro", JSONObject().put("p_numero", numero).put("p_nombre", nombre.trim()))
    }

    fun resetear(numero: Int) {
        val local = codigoLocal(numero)
        if (reseteoAbierto(numero) && !local.isNullOrBlank()) {
            ultimoCodigoTemporal.value = local
            codigoTemporalPara.value = numero
            return
        }
        ultimoCodigoTemporal.value = null; codigoTemporalPara.value = numero
        scope.launch {
            try {
                val j = SupabaseApi.generarCodigo(numero)
                val codigo = j.getString("codigo")
                val vence = isoOrNull(j.optString("vence_at")) ?: (System.currentTimeMillis() + 24L * 60L * 60L * 1000L)
                ultimoCodigoTemporal.value = codigo
                codigoTemporalPara.value = numero
                codigosActivos[numero] = vence
                guardarCodigoLocal(numero, codigo, vence)
                ultimoError.value = null
            } catch (e: Exception) { ultimoError.value = mensajeAmigable(e) }
        }
    }

    fun tieneClave(numero: Int): Boolean = true
    fun reseteoAbierto(numero: Int): Boolean = (codigosActivos[numero] ?: 0L) > System.currentTimeMillis()
    fun horasDeReseteo(numero: Int): Long = ((codigosActivos[numero] ?: 0L) - System.currentTimeMillis()).coerceAtLeast(0L)
    fun codigoLocal(numero: Int): String? {
        val ctx = appContext ?: return null
        val p = ctx.getSharedPreferences("tesoreria_codigos", Context.MODE_PRIVATE)
        val vence = p.getLong("vence_$numero", 0L)
        if (vence <= System.currentTimeMillis()) {
            p.edit().remove("codigo_$numero").remove("vence_$numero").apply()
            return null
        }
        return p.getString("codigo_$numero", null)
    }
    private fun guardarCodigoLocal(numero: Int, codigo: String, vence: Long) {
        appContext?.getSharedPreferences("tesoreria_codigos", Context.MODE_PRIVATE)?.edit()
            ?.putString("codigo_$numero", codigo)?.putLong("vence_$numero", vence)?.apply()
    }
    private fun cargarCodigosLocales() {
        limpiarCodigosLocalesVencidos()
    }
    private fun limpiarCodigosLocalesVencidos() {
        val ctx = appContext ?: return
        val p = ctx.getSharedPreferences("tesoreria_codigos", Context.MODE_PRIVATE)
        val e = p.edit()
        for (n in 1..35) {
            val vence = p.getLong("vence_$n", 0L)
            if (vence > 0L && vence <= System.currentTimeMillis()) { e.remove("codigo_$n").remove("vence_$n") }
        }
        e.apply()
    }
    fun necesitaCrearClave(numero: Int): Boolean = false
    fun crearClave(numero: Int, clave: String) = Unit
    fun validar(numero: Int, clave: String): Boolean = false
    fun cerrarSesiones(numero: Int) = Unit

    fun invitarMiembro(numero: Int, nombre: String, cargo: String = "", color: String = "#22C55E", participa: Boolean = false, onFin: (Boolean, String) -> Unit = { _, _ -> }) {
        if (!conectado.value) { onFin(false, "Sin conexión a Internet"); return }
        scope.launch {
            try {
                SupabaseApi.rpc("invitar_miembro_v2", JSONObject().put("p_numero", numero).put("p_nombre", nombre.trim()).put("p_cargo", cargo.trim()).put("p_color", color).put("p_participa", participa))
                try { cargarTodo() } catch (_: Exception) { }
                onFin(true, "Miembro creado")
            } catch (e: Exception) { onFin(false, mensajeAmigable(e)) }
        }
    }

    fun guardarColorPropio(color: String, onFin: (Boolean, String) -> Unit = { _, _ -> }) {
        val actual = sesion.value
        if (actual == null) { onFin(false, "Debes iniciar sesión"); return }
        if (!esOwner) { onFin(false, "Solo el owner puede cambiar su color desde esta opción"); return }
        if (!conectado.value) { onFin(false, "Sin conexión a Internet"); return }
        scope.launch {
            try {
                SupabaseApi.rpc(
                    "actualizar_miembro_basico",
                    JSONObject()
                        .put("p_numero", actual.numero)
                        .put("p_nombre", actual.nombre)
                        .put("p_cargo", actual.cargoNombre)
                        .put("p_color", color)
                        .put("p_participa", actual.participaCobros)
                )
                try { cargarTodo() } catch (_: Exception) { }
                onFin(true, "Color actualizado")
            } catch (e: Exception) {
                onFin(false, mensajeAmigable(e))
            }
        }
    }

    fun guardarMiembroOwner(numero: Int, nombre: String, nivel: NivelAcceso, cargo: String, color: String, participa: Boolean, permisos: Set<Permiso>, onFin: (Boolean, String) -> Unit = { _, _ -> }) {
        if (!esOwner) { onFin(false, "Solo el owner puede cambiar accesos"); return }
        val arr = JSONArray(); permisos.forEach { arr.put(permisoSql(it)) }
        scope.launch {
            try {
                SupabaseApi.rpc("guardar_miembro_owner", JSONObject().put("p_numero", numero).put("p_nombre", nombre.trim()).put("p_nivel", nivelSql(nivel)).put("p_cargo", cargo.trim()).put("p_color", color).put("p_participa", participa).put("p_permisos", arr))
                try { cargarTodo() } catch (_: Exception) { }
                onFin(true, "Perfil guardado")
            } catch (e: Exception) { onFin(false, mensajeAmigable(e)) }
        }
    }

    fun guardarMiembroBasico(numero: Int, nombre: String, cargo: String, color: String, participa: Boolean, onFin: (Boolean, String) -> Unit = { _, _ -> }) {
        scope.launch {
            try {
                SupabaseApi.rpc("actualizar_miembro_basico", JSONObject().put("p_numero", numero).put("p_nombre", nombre.trim()).put("p_cargo", cargo.trim()).put("p_color", color).put("p_participa", participa))
                try { cargarTodo() } catch (_: Exception) { }
                onFin(true, "Guardado")
            } catch (e: Exception) { onFin(false, mensajeAmigable(e)) }
        }
    }

    fun cambiarEstadoMiembro(numero: Int, estado: EstadoMiembro) = operar("cambiar_estado_miembro", JSONObject().put("p_numero", numero).put("p_estado", estadoSql(estado)))
    fun liberarPlaza(numero: Int, onFin: (Boolean, String) -> Unit = { _, _ -> }) {
        if (!esOwner) { onFin(false, "Solo el owner puede liberar plazas"); return }
        scope.launch {
            try {
                SupabaseApi.liberarPlaza(numero)
                ultimoError.value = null
                try { cargarTodo() } catch (_: Exception) { }
                onFin(true, "Plaza liberada")
            } catch (e: Exception) {
                val m = mensajeAmigable(e).ifBlank { "No se pudo liberar la plaza" }
                ultimoError.value = m
                onFin(false, m)
            }
        }
    }

    suspend fun cargarCodigosMasivos() {
        if (!esOwner || !conectado.value) return
        if (cargandoCodigosMasivos.value) return
        cargandoCodigosMasivos.value = true
        try {
            aplicarCodigosMasivos(SupabaseApi.codigosMasivos("listar", 30))
        } finally { cargandoCodigosMasivos.value = false }
    }

    fun generarCodigosMasivos(cantidad: Int, onFin: (Boolean, String) -> Unit = { _, _ -> }) {
        if (!esOwner) { onFin(false, "Solo el owner puede generar códigos"); return }
        scope.launch {
            cargandoCodigosMasivos.value = true
            try {
                val j = SupabaseApi.codigosMasivos("generar", cantidad.coerceIn(1, 30))
                aplicarCodigosMasivos(j)
                val mensajeServidor = j.optString("mensaje").trim()
                val disponibles = codigosMasivos.count { it.estado == EstadoCodigoMasivo.DISPONIBLE }
                onFin(true, mensajeServidor.ifBlank { "Disponibles ahora: $disponibles" })
            } catch (e: Exception) {
                onFin(false, mensajeAmigable(e))
            } finally { cargandoCodigosMasivos.value = false }
        }
    }

    private fun aplicarCodigosMasivos(j: JSONObject) {
        val nuevos = mutableListOf<CodigoMasivo>()
        val arr = j.optJSONArray("historial") ?: j.optJSONArray("codigos") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val c = arr.optJSONObject(i) ?: continue
            val codigo = c.optString("codigo")
            if (!codigo.matches(Regex("\\d{6}"))) continue
            val vence = isoOrNull(c.optString("vence_at")) ?: 0L
            val creado = isoOrNull(c.optString("creado_at")) ?: 0L
            val usadoAt = isoOrNull(c.optString("usado_at"))
            val usadoPor = c.optInt("usado_por", 0).takeIf { it in 1..35 }
            val estado = when (c.optString("estado")) {
                "usado" -> EstadoCodigoMasivo.USADO
                "vencido" -> EstadoCodigoMasivo.VENCIDO
                "cancelado" -> EstadoCodigoMasivo.CANCELADO
                else -> EstadoCodigoMasivo.DISPONIBLE
            }
            nuevos += CodigoMasivo(codigo, vence, creado, estado, usadoPor, usadoAt)
        }
        codigosMasivos.clear()
        codigosMasivos.addAll(nuevos.sortedByDescending { it.creado })
    }

    suspend fun registrarPresenciaAhora() {
        if (sesion.value == null || !conectado.value || !appEnPrimerPlano.value) return
        try { SupabaseApi.registrarPresencia() } catch (_: Exception) { }
    }

    fun marcarDesconectadoAsync() {
        if (sesion.value == null) return
        scope.launch {
            try { SupabaseApi.marcarDesconectado() } catch (_: Exception) { }
        }
    }

    suspend fun refrescarPresenciasAdmin() {
        if (!esOwner || !conectado.value) return
        try {
            val arr = SupabaseApi.presenciaAdmin()
            val nuevos = mutableMapOf<Int, PresenciaMiembro>()
            for (i in 0 until arr.length()) {
                val j = arr.optJSONObject(i) ?: continue
                val numero = j.optInt("numero", 0)
                if (numero !in 1..35) continue
                val estado = when (j.optString("estado")) {
                    "conectado" -> EstadoConexionMiembro.CONECTADO
                    "sin_activar" -> EstadoConexionMiembro.SIN_ACTIVAR
                    "bloqueado" -> EstadoConexionMiembro.BLOQUEADO
                    "libre" -> EstadoConexionMiembro.LIBRE
                    else -> EstadoConexionMiembro.DESCONECTADO
                }
                nuevos[numero] = PresenciaMiembro(
                    numero = numero,
                    estado = estado,
                    ultimaActividad = isoOrNull(j.optString("ultima_actividad")),
                    appVersion = j.optString("app_version")
                )
            }
            withContext(Dispatchers.Main) {
                presencias.clear()
                presencias.putAll(nuevos)
                presenciasCargadas.value = true
            }
        } catch (_: Exception) {
            // La presencia es informativa; nunca bloquea el panel administrativo.
        }
    }

    suspend fun eliminarActaConClave(acta: Acta, clave: String) {
        val yo = sesion.value ?: throw IllegalStateException("Sesión no válida")
        if (yo.nivelAcceso != NivelAcceso.OWNER) throw IllegalStateException("Solo el owner puede eliminar actas")
        SupabaseApi.iniciarSesion(yo.numero, clave)
        SupabaseApi.rpcIdempotente("eliminar_acta", JSONObject().put("p_acta_id", acta.serverId))
        cargarTodo()
    }
    fun eliminarCodigosFinalizados(onFin: (Boolean, String) -> Unit = { _, _ -> }) {
        if (!esOwner) { onFin(false, "Solo el owner puede eliminar códigos"); return }
        scope.launch {
            try {
                val raw = SupabaseApi.rpc("owner_eliminar_codigos_finalizados")
                cargarCodigosMasivos()
                onFin(true, "Historial limpiado")
            } catch (e: Exception) { onFin(false, mensajeAmigable(e)) }
        }
    }

    suspend fun resumenLimpieza(desde: Long?, hasta: Long?, todo: Boolean): JSONObject =
        SupabaseApi.ownerLimpiar("vista", desde, hasta, todo)

    suspend fun limpiarServidorConClave(clave: String, desde: Long?, hasta: Long?, todo: Boolean): JSONObject {
        val yo = sesion.value ?: throw IllegalStateException("Sesión no válida")
        if (!esOwner) throw IllegalStateException("Solo el owner puede limpiar el servidor")
        if (clave.length < 6) throw IllegalStateException("Escribe tu contraseña")
        // Reautenticación obligatoria antes de una operación destructiva.
        SupabaseApi.iniciarSesion(yo.numero, clave)
        val r = SupabaseApi.ownerLimpiar("limpiar", desde, hasta, todo)
        cargarTodo()
        return r
    }

    fun revisarVencidos() = refrescar()
    fun bitacoraPublica(): List<String> = bitacora

    private fun operar(
        nombre: String,
        params: JSONObject,
        onFin: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        if (!conectado.value) {
            onFin(false, "Sin conexión a Internet")
            return
        }
        val clave = "$nombre:${params}"
        synchronized(operacionesEnCurso) {
            if (!operacionesEnCurso.add(clave)) {
                onFin(false, "Esta operación ya se está procesando")
                return
            }
        }
        val requestId = UUID.randomUUID().toString()
        scope.launch {
            try {
                // Es seguro reintentar: el servidor reconoce requestId y jamás duplica la acción.
                SupabaseApi.rpcIdempotente(nombre, params, requestId)
                ultimoError.value = null
                // Una falla de sincronización posterior NO convierte una acción ya guardada
                // en error para el usuario. Se recuperará automáticamente al reconectar.
                try { cargarTodo() } catch (_: Exception) { }
                onFin(true, "Guardado")
            } catch (e: SesionInvalidaException) {
                ultimoError.value = e.message
                sesion.value = null
                limpiarDatos()
                onFin(false, e.message ?: "Sesión vencida")
            } catch (e: Exception) {
                val mensaje = mensajeAmigable(e)
                if (e !is SinConexionException && e !is ServidorTemporalException) {
                    ultimoError.value = mensaje
                }
                onFin(false, mensaje.ifBlank { "No se pudo completar la operación" })
            } finally {
                synchronized(operacionesEnCurso) { operacionesEnCurso.remove(clave) }
            }
        }
    }

    private fun mensajeAmigable(e: Exception): String {
        val raw = e.message.orEmpty()
        val n = raw.lowercase(Locale.ROOT)
        return when {
            "permission denied" in n || "row-level security" in n || "not authorized" in n -> "No tienes permiso"
            e is SinConexionException || e is ServidorTemporalException || "timeout" in n || "tardó demasiado" in n -> ""
            raw.isBlank() -> "No se pudo actualizar"
            else -> raw
        }
    }

    private fun localId(uuid: String): Int = uuid.hashCode().absoluteValue
    private fun rolDe(v: String) = when (v) { "tesorero" -> Rol.TESORERO; "presidente" -> Rol.PRESIDENTE; "personalizado" -> Rol.PERSONALIZADO; else -> Rol.SOCIO }
    private fun rolSql(v: Rol) = when (v) { Rol.TESORERO -> "tesorero"; Rol.PRESIDENTE -> "presidente"; Rol.PERSONALIZADO -> "personalizado"; Rol.SOCIO -> "socio" }
    private fun estadoMiembroDe(v: String) = when (v) { "bloqueado" -> EstadoMiembro.BLOQUEADO; "retirado" -> EstadoMiembro.RETIRADO; else -> EstadoMiembro.ACTIVO }
    private fun estadoSql(v: EstadoMiembro) = when (v) { EstadoMiembro.BLOQUEADO -> "bloqueado"; EstadoMiembro.RETIRADO -> "retirado"; EstadoMiembro.ACTIVO -> "activo" }
    private fun tipoCobroDe(v: String): TipoCobro = if (v.lowercase(Locale.ROOT) == "rapido") TipoCobro.RAPIDO else TipoCobro.OFICIAL
    private fun permisoDe(v: String): Permiso? = when (v) {
        "registrar_pago_manual" -> Permiso.REGISTRAR_PAGO_MANUAL
        "gestionar_cobros" -> Permiso.GESTIONAR_COBROS
        "registrar_gastos" -> Permiso.REGISTRAR_GASTOS
        "ver_comprobantes_yape" -> Permiso.VER_COMPROBANTES_YAPE
        "revisar_comprobantes_yape" -> Permiso.REVISAR_COMPROBANTES_YAPE
        "gestionar_numero_yape" -> Permiso.GESTIONAR_NUMERO_YAPE
        "gestionar_miembros" -> Permiso.GESTIONAR_MIEMBROS
        "exportar_actas" -> Permiso.EXPORTAR_ACTAS
        "gestionar_yape" -> Permiso.GESTIONAR_YAPE
        else -> null
    }
    private fun permisoSql(v: Permiso) = when (v) {
        Permiso.REGISTRAR_PAGO_MANUAL -> "registrar_pago_manual"
        Permiso.GESTIONAR_COBROS -> "gestionar_cobros"
        Permiso.REGISTRAR_GASTOS -> "registrar_gastos"
        Permiso.VER_COMPROBANTES_YAPE -> "ver_comprobantes_yape"
        Permiso.REVISAR_COMPROBANTES_YAPE -> "revisar_comprobantes_yape"
        Permiso.GESTIONAR_NUMERO_YAPE -> "gestionar_numero_yape"
        Permiso.GESTIONAR_MIEMBROS -> "gestionar_miembros"
        Permiso.EXPORTAR_ACTAS -> "exportar_actas"
        Permiso.GESTIONAR_YAPE -> "revisar_comprobantes_yape"
    }
    private fun nivelAccesoDe(v: String) = when (v.lowercase(Locale.ROOT)) { "owner" -> NivelAcceso.OWNER; "administrador" -> NivelAcceso.ADMINISTRADOR; else -> NivelAcceso.USUARIO }
    private fun nivelSql(v: NivelAcceso) = when (v) { NivelAcceso.OWNER -> "owner"; NivelAcceso.ADMINISTRADOR -> "administrador"; NivelAcceso.USUARIO -> "usuario" }
    private fun estadoPagoDe(v: String) = when (v) { "aprobado" -> EstadoPago.APROBADO; "rechazado" -> EstadoPago.RECHAZADO; else -> EstadoPago.PENDIENTE }
    private fun estadoActaDe(v: String) = when (v) { "aprobado" -> EstadoPago.APROBADO; "pendiente" -> EstadoPago.PENDIENTE; "rechazado" -> EstadoPago.RECHAZADO; "no_paga" -> EstadoPago.NO_PAGA; else -> EstadoPago.SIN_ENVIAR }
    private fun isoDesdeMillis(ms: Long): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(Date(ms))
    private fun isoOrNull(v: String): Long? = try {
        if (v.isBlank() || v == "null") null else {
            val fixed = v.replace(Regex("\\.(\\d{3})\\d+([+-]\\d{2}:?\\d{2}|Z)$"), ".$1$2")
            val patterns = listOf("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX")
            patterns.firstNotNullOfOrNull { p -> try { SimpleDateFormat(p, Locale.US).parse(fixed)?.time } catch (_: Exception) { null } }
        }
    } catch (_: Exception) { null }

    private fun iso(v: String): Long = try {
        val fixed = v.replace(Regex("\\.(\\d{3})\\d+([+-]\\d{2}:?\\d{2}|Z)$"), ".$1$2")
        val patterns = listOf("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX")
        patterns.firstNotNullOfOrNull { p -> try { SimpleDateFormat(p, Locale.US).parse(fixed)?.time } catch (_: Exception) { null } } ?: System.currentTimeMillis()
    } catch (_: Exception) { System.currentTimeMillis() }
}
