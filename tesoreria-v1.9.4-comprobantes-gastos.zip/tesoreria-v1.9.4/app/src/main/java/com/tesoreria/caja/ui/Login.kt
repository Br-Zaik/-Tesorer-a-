package com.tesoreria.caja.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LockReset
import androidx.compose.material.icons.rounded.Login
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.R
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Socio
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun PantallaLogin(avisoInicial: String? = null, alEntrar: (Socio) -> Unit) {
    var numero by remember { mutableStateOf("") }
    var clave by remember { mutableStateOf("") }
    var codigo by remember { mutableStateOf("") }
    var clave2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var cargando by remember { mutableStateOf(false) }
    // 0 = entrar, 1 = crear cuenta, 2 = cambiar contraseña
    var modo by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current

    fun limpiarFormulario(modoNuevo: Int) {
        modo = modoNuevo
        error = ""
        clave = ""
        clave2 = ""
        codigo = ""
    }

    val tituloModo = when (modo) {
        1 -> "CREAR CUENTA"
        2 -> "CAMBIAR CONTRASEÑA"
        else -> "ACCESO PERSONAL"
    }
    val ayudaModo = when (modo) {
        1 -> "Usa uno de los códigos de activación compartidos por Tesorería."
        2 -> "Usa el código temporal generado para tu número de lista."
        else -> "Ingresa con tu número de lista y contraseña."
    }

    Box(Modifier.fillMaxSize().background(Fondo)) {
        FondoEstaticoLogin()
        // Mantener el contenido anclado arriba evita el “salto” visual al cerrar
        // el teclado durante el inicio de sesión. Antes se centraba con Arrangement.Center;
        // al desaparecer el IME cambiaba la altura disponible y toda la pantalla (incluido
        // el logo) se recolocaba durante unos fotogramas.
        Column(
            Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(top = 22.dp, bottom = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Image(painter = painterResource(R.drawable.tesoreria_logo_hd), contentDescription = "Tesorería", modifier = Modifier.size(86.dp))
            Spacer(Modifier.height(10.dp))
            Text("Tesorería", color = Texto, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(3.dp))
            Text("Acceso rápido y seguro", color = Tenue, fontSize = 12.sp)
            Spacer(Modifier.height(18.dp))

            if (!avisoInicial.isNullOrBlank()) {
                Box(
                    Modifier.fillMaxWidth().background(Ambar.copy(alpha = .09f), RoundedCornerShape(14.dp))
                        .border(1.dp, Ambar.copy(alpha = .30f), RoundedCornerShape(14.dp)).padding(12.dp)
                ) { Text(avisoInicial, color = Texto, fontSize = 11.sp, fontWeight = FontWeight.Medium) }
                Spacer(Modifier.height(10.dp))
            }

            Tarjeta(borde = VerdeBrillante.copy(alpha = .30f), fondo = PanelAlto) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(VerdeBrillante.copy(alpha = .10f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(if (modo == 0) Icons.Rounded.Login else Icons.Rounded.LockReset, null, tint = VerdeBrillante, modifier = Modifier.size(23.dp))
                    }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Etiqueta(tituloModo, VerdeBrillante)
                        Spacer(Modifier.height(3.dp))
                        Text(ayudaModo, color = Tenue, fontSize = 10.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))

                Etiqueta("NÚMERO DE LISTA")
                Spacer(Modifier.height(6.dp))
                Campo(numero, { numero = it.filter(Char::isDigit).take(2); error = "" }, "Ej. 22", numerico = true)
                Spacer(Modifier.height(11.dp))

                if (modo != 0) {
                    Etiqueta(if (modo == 1) "CÓDIGO DE ACTIVACIÓN" else "CÓDIGO TEMPORAL")
                    Spacer(Modifier.height(6.dp))
                    Campo(codigo, { codigo = it.filter(Char::isDigit).take(6); error = "" }, "6 dígitos", numerico = true)
                    Spacer(Modifier.height(11.dp))
                    Etiqueta("NUEVA CONTRASEÑA")
                    Spacer(Modifier.height(6.dp))
                    Campo(clave, { clave = it; error = "" }, "Nueva contraseña", clave = true)
                    Spacer(Modifier.height(11.dp))
                    Etiqueta("REPETIR CONTRASEÑA")
                    Spacer(Modifier.height(6.dp))
                    Campo(clave2, { clave2 = it; error = "" }, "Repite la contraseña", clave = true)
                } else {
                    Etiqueta("CONTRASEÑA")
                    Spacer(Modifier.height(6.dp))
                    Campo(clave, { clave = it; error = "" }, "Tu contraseña", clave = true)
                }

                if (error.isNotBlank()) { Spacer(Modifier.height(10.dp)); Text(error, color = Rojo, fontSize = 11.sp) }
                Spacer(Modifier.height(15.dp))
                Boton(
                    if (cargando) "Verificando…" else when (modo) { 1 -> "Crear cuenta y entrar"; 2 -> "Guardar nueva contraseña"; else -> "Entrar" },
                    Modifier.fillMaxWidth(), activo = !cargando
                ) {
                    val n = numero.toIntOrNull()
                    when {
                        n == null || n !in 1..35 -> error = "Escribe un número válido del 1 al 35"
                        clave.length < 6 -> error = "La contraseña debe tener al menos 6 caracteres"
                        modo != 0 && codigo.length != 6 -> error = "Escribe el código de 6 dígitos"
                        modo != 0 && clave != clave2 -> error = "Las contraseñas no coinciden"
                        modo != 0 && (clave == n.toString() || clave == n.toString().padStart(2, '0')) -> error = "No uses tu número de lista como contraseña"
                        else -> {
                            keyboard?.hide(); focus.clearFocus(); cargando = true; error = ""
                            scope.launch {
                                try {
                                    val socio = if (modo == 0) Caja.iniciarSesion(n, clave) else Caja.activarCuenta(n, codigo, clave)
                                    alEntrar(socio)
                                } catch (ex: Exception) {
                                    error = mensajeLogin(ex, when (modo) { 1 -> "No se pudo crear la cuenta"; 2 -> "No se pudo cambiar la contraseña"; else -> "No se pudo iniciar sesión" })
                                    cargando = false
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                if (modo == 0) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Boton("Crear cuenta", Modifier.weight(1f), relleno = false, color = VerdeBrillante, activo = !cargando) { limpiarFormulario(1) }
                        Boton("Cambiar contraseña", Modifier.weight(1f), relleno = false, color = Ambar, activo = !cargando) { limpiarFormulario(2) }
                    }
                } else {
                    Boton("Volver al inicio de sesión", Modifier.fillMaxWidth(), relleno = false, color = Tenue, activo = !cargando) { limpiarFormulario(0) }
                }
            }

            Spacer(Modifier.height(13.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Shield, null, tint = VerdeBrillante.copy(alpha = .75f), modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(6.dp))
                Text("Conexión segura con Tesorería", color = Tenue.copy(alpha = .78f), fontSize = 10.sp)
            }
        }
    }
}

private fun mensajeLogin(ex: Exception, fallback: String): String {
    val raw = ex.message.orEmpty()
    val n = raw.lowercase(Locale.ROOT)
    return when {
        "permission denied" in n || "row-level security" in n || "not authorized" in n -> "No tienes permiso"
        "sin conexión" in n -> "Sin conexión a Internet"
        "tardó" in n || "timeout" in n || "temporalmente" in n || "servidor" in n -> "El servidor tardó en responder. Inténtalo nuevamente"
        "contraseña incorrecta" in n || "invalid login" in n || "invalid credentials" in n -> "Número o contraseña incorrectos"
        raw.isBlank() -> fallback
        else -> raw
    }
}

@Composable
private fun FondoEstaticoLogin() {
    androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawCircle(VerdeBrillante.copy(alpha = .030f), size.minDimension * .60f, center = androidx.compose.ui.geometry.Offset(w * .80f, h * .13f))
        drawCircle(VerdeNeon.copy(alpha = .020f), size.minDimension * .46f, center = androidx.compose.ui.geometry.Offset(w * .07f, h * .86f))
        val paso = w / 7f
        for (i in 1..6) {
            drawLine(VerdeBrillante.copy(alpha = .014f), androidx.compose.ui.geometry.Offset(i * paso, 0f), androidx.compose.ui.geometry.Offset(i * paso, h), 1f)
        }
    }
}
