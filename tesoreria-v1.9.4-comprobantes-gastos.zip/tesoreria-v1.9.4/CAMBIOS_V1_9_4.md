# Tesorería v1.9.4

- Comprobante opcional al registrar un gasto: Yape, boleta o recibo.
- La imagen se elige y se previsualiza localmente; antes de usarla aparece una confirmación explícita.
- Nada se sube al servidor hasta pulsar **Registrar gasto**.
- No existe opción para agregar, reemplazar o borrar el comprobante desde Movimientos.
- En Movimientos > Gastos, todos los usuarios autenticados pueden abrir **Ver comprobante** cuando el gasto tiene imagen.
- Solo owner o administradores con permiso **Registrar gastos** pueden subir comprobantes.
- Storage privado independiente `comprobantes-gastos`, con RLS para lectura del grupo y escritura solo autorizada.
- Registro idempotente de gasto + referencia de comprobante. Los reintentos con el mismo requestId no duplican el gasto.
- Limpieza permitida únicamente para imágenes propias que todavía no estén asociadas a un gasto.
- Bitácora registra si el gasto fue creado con o sin comprobante.
