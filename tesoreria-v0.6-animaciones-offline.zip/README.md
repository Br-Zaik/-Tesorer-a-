# Tesorería — maqueta premium offline v0.6

Versión offline para probar diseño, flujos y animaciones antes de conectar Supabase.

## Novedades v0.6 — animaciones nativas
- Login reactivo completamente propio, sin mascota ni WebView.
- Núcleo de seguridad animado: aro en movimiento, escudo/candado, error reactivo y apertura del candado al validar correctamente.
- Contraseña correcta: candado abierto → check → “Acceso concedido” antes de entrar.
- Contraseña incorrecta: vibración lateral y estado rojo sin cambiar de pantalla.
- Selector Usuario / Administrador con indicador deslizante propio.
- Campos de contraseña con animación de foco y botón mostrar/ocultar.
- Fondo del login con movimiento muy suave, puntos y líneas de baja intensidad para evitar espacios muertos.
- Envío de comprobante inspirado en la referencia del “lanzamiento”: la tarjeta del comprobante sube con estela verde y progreso; termina en “Comprobante enviado · Pendiente de revisión”. Nunca muestra aprobado automáticamente.
- Botón de envío queda funcionalmente bloqueado al entrar en la fase de envío, evitando doble registro.
- Switches animados para permisos administrativos.
- Selector deslizante en el panel: Pagos / Cobro / Gastos / Miembros.
- Barra inferior con indicador verde deslizante, elevación corta del icono activo y transición de color.
- Sin tema claro/oscuro, OTP ni efectos tipo circuito en esta versión.
- Todas las animaciones están hechas con Jetpack Compose nativo; no se añadió ninguna librería externa.

## Funciones conservadas de v0.5
- Pago manual desde administración.
- Solo dos medios: Yape y Manual.
- Corregir un pago asignado al número equivocado dejando registro en bitácora.
- Extender plazo de cobros.
- Plazas 31–35 bloqueadas hasta invitación del tesorero.
- Roles y permisos configurables.
- Bloqueo/desbloqueo, liberación de contraseña por 24 h y cierre de sesiones simulado.
- OCR simulado: monto, operación, fecha, hora y código de seguridad.
- Verificación Yape opcional mediante NotificationListenerService.

## Demo
- N.º 22: Brian Pacco Huayhua — Tesorero.
- Clave demo: `123456` para cuentas creadas.
- N.º 12 y 27: flujo de primera entrada.
- 31–35: plazas libres y bloqueadas hasta invitación.

## Versión
- versionCode: 7
- versionName: `0.6-animaciones-offline`

## Estado técnico
Todo sigue en memoria y se reinicia al cerrar la app. No hay Supabase todavía. El OCR/cámara reales se conectarán más adelante.
