Tesorería v0.8 – rediseño visual

Cambios principales:
- Inicio renovado con 3 estilos de resumen (Vista A / B / C) para elegir.
- Alerta de pago rechazado subida arriba con motivo claro y botón de reenvío.
- Resumen de estados mejorado: No enviaron / Esperando revisión / Deben reenviar.
- Movimientos con selector Ingresos / Gastos fijo arriba y lista interna desplazable.
- Bitácora rediseñada en tarjetas visuales por tipo de evento.
- Limpieza de microtextos en panel y miembros.
- Logo nuevo estilo balanza para launcher/adaptive icon.
- MainActivity ajustada para que el panel aparezca según permisos reales.
- build.gradle.kts actualizado a versionCode 11 y versionName 0.8-rediseno.

Base usada: tesoreria-v0.7-permisos-logo.zip
