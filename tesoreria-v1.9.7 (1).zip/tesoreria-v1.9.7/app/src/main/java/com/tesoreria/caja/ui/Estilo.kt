package com.tesoreria.caja.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Identidad visual verde oscuro inspirada en la referencia Gana Geo.
val Fondo = Color(0xFF00170E)
val FondoProfundo = Color(0xFF001109)
val Panel = Color(0xFF06281A)
val PanelAlto = Color(0xFF0A3322)
val Borde = Color(0xFF185B3B)
val Cian = Color(0xFFB7FF00) // nombre histórico para no romper otras pantallas
val VerdeNeon = Color(0xFFB7FF00)
val VerdeBrillante = Color(0xFF55F56A)
val Verde = Color(0xFF4CF58A)
val Ambar = Color(0xFFFFC940)
val Rojo = Color(0xFFFF5C68)
val Violeta = Color(0xFF7B2CBF)
val MoradoYape = Color(0xFFC084FC)
val Texto = Color(0xFFF3FFF7)
val Tenue = Color(0xFFA3B8AA)
val Suave = Color(0xFF0B3624)
val Celeste = Color(0xFF22D3EE)
val Azul = Color(0xFF60A5FA)
val Naranja = Color(0xFFFF9F1C)

// Un color por sección para saber siempre dónde estás.
val ColorInicio = Verde
val ColorMovimientos = Azul
val ColorActas = Ambar
val ColorPanel = VerdeNeon


fun colorCargo(hex: String?, fallback: Color = Cian): Color = runCatching {
    val limpio = hex.orEmpty().trim().removePrefix("#")
    require(limpio.length == 6)
    Color(android.graphics.Color.parseColor("#$limpio"))
}.getOrDefault(fallback)

val GradientePrincipal = Brush.horizontalGradient(listOf(Color(0xFF24EE75), Color(0xFFB7FF00)))
val GradienteTarjeta = Brush.linearGradient(listOf(Color(0xFF0A3926), Color(0xFF052719)))

private val esquema = darkColorScheme(
    primary = VerdeNeon,
    onPrimary = FondoProfundo,
    primaryContainer = PanelAlto,
    onPrimaryContainer = Texto,
    secondary = VerdeBrillante,
    background = Fondo,
    onBackground = Texto,
    surface = Panel,
    onSurface = Texto,
    surfaceVariant = PanelAlto,
    onSurfaceVariant = Tenue,
    error = Rojo,
    onError = Texto
)

@Composable
fun CajaTheme(contenido: @Composable () -> Unit) {
    MaterialTheme(colorScheme = esquema, content = contenido)
}

val cifra = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.SemiBold,
    letterSpacing = 0.sp
)

@Composable
fun Tarjeta(
    modifier: Modifier = Modifier,
    borde: Color = Borde.copy(alpha = 0.78f),
    fondo: Color = Panel,
    contenido: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(fondo, RoundedCornerShape(22.dp))
            .border(BorderStroke(1.dp, borde), RoundedCornerShape(22.dp))
            .padding(17.dp),
        content = contenido
    )
}

@Composable
fun TarjetaPremium(
    modifier: Modifier = Modifier,
    contenido: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(GradienteTarjeta, RoundedCornerShape(24.dp))
            .border(BorderStroke(1.dp, VerdeBrillante.copy(alpha = 0.35f)), RoundedCornerShape(24.dp))
            .padding(18.dp),
        content = contenido
    )
}

@Composable
fun Etiqueta(texto: String, color: Color = Tenue) {
    Text(texto, color = color, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
}

@Composable
fun Titulo(texto: String) {
    Text(texto, color = Texto, fontSize = 23.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun Subtitulo(texto: String) {
    Text(texto, color = Tenue, fontSize = 13.5.sp)
}

@Composable
fun Boton(
    texto: String,
    modifier: Modifier = Modifier,
    color: Color = VerdeNeon,
    relleno: Boolean = true,
    activo: Boolean = true,
    icono: ImageVector? = null,
    alTocar: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val escala by animateFloatAsState(if (pressed) 0.965f else 1f, spring(stiffness = 650f), label = "buttonScale")
    val brillo by animateFloatAsState(if (pressed) 0.72f else 1f, label = "buttonGlow")
    val fondoModifier = when {
        !activo -> Modifier.background(Color.Transparent, RoundedCornerShape(16.dp))
        relleno && color == VerdeNeon -> Modifier.background(GradientePrincipal, RoundedCornerShape(16.dp))
        relleno -> Modifier.background(color.copy(alpha = brillo), RoundedCornerShape(16.dp))
        else -> Modifier.background(Color.Transparent, RoundedCornerShape(16.dp))
    }
    val base = Modifier
        .scale(escala)
        .height(54.dp)
        .then(fondoModifier)
        .border(BorderStroke(1.dp, if (activo) color.copy(alpha = if (relleno) 0.85f else 0.55f) else Borde), RoundedCornerShape(16.dp))
        .clickable(interactionSource = interaction, indication = null, enabled = activo) { alTocar() }

    val colorTexto = if (!activo) Tenue else if (relleno) FondoProfundo else color
    Box(modifier.then(base), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icono != null) {
                Icon(icono, null, tint = colorTexto, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text(
                texto,
                color = colorTexto,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun Campo(
    valor: String,
    alCambiar: (String) -> Unit,
    pista: String,
    modifier: Modifier = Modifier,
    numerico: Boolean = false,
    clave: Boolean = false,
    focusRequester: FocusRequester? = null
) {
    var enfocado by remember { mutableStateOf(false) }
    var mostrarClave by remember { mutableStateOf(false) }
    val colorBorde by animateColorAsState(
        targetValue = if (enfocado) VerdeBrillante else Borde,
        label = "campoBorde"
    )
    val escala by animateFloatAsState(if (enfocado) 1.01f else 1f, label = "campoEscala")

    Row(
        modifier = modifier
            .fillMaxWidth()
            .scale(escala)
            .height(58.dp)
            .background(FondoProfundo.copy(alpha = 0.76f), RoundedCornerShape(16.dp))
            .border(BorderStroke(1.dp, colorBorde), RoundedCornerShape(16.dp))
            .padding(start = 15.dp, end = if (clave) 8.dp else 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .weight(1f)
                .onFocusChanged { enfocado = it.hasFocus },
            contentAlignment = Alignment.CenterStart
        ) {
            if (valor.isEmpty()) Text(pista, color = Tenue.copy(alpha = 0.70f), fontSize = 15.sp)
            BasicTextField(
                value = valor,
                onValueChange = alCambiar,
                singleLine = true,
                textStyle = TextStyle(color = Texto, fontSize = 16.sp, fontWeight = FontWeight.Medium),
                cursorBrush = SolidColor(VerdeNeon),
                visualTransformation = if (clave && !mostrarClave) PasswordVisualTransformation() else VisualTransformation.None,
                keyboardOptions = KeyboardOptions(
                    keyboardType = when {
                        clave -> KeyboardType.Password
                        numerico -> KeyboardType.Decimal
                        else -> KeyboardType.Text
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            )
        }
        if (clave) {
            val interaction = remember { MutableInteractionSource() }
            Box(
                Modifier
                    .size(42.dp)
                    .clickable(interactionSource = interaction, indication = null) { mostrarClave = !mostrarClave },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (mostrarClave) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                    contentDescription = if (mostrarClave) "Ocultar contraseña" else "Mostrar contraseña",
                    tint = if (enfocado) VerdeBrillante else Tenue,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun Pastilla(texto: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.11f), RoundedCornerShape(999.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.36f)), RoundedCornerShape(999.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(texto, color = color, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MiniDato(etiqueta: String, valor: String, color: Color) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.07f), RoundedCornerShape(15.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.20f)), RoundedCornerShape(15.dp))
            .padding(horizontal = 13.dp, vertical = 11.dp)
    ) {
        Text(etiqueta, color = Tenue, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(3.dp))
        Text(valor, color = color, fontSize = 16.sp, style = cifra)
    }
}

@Composable
fun FilaEntre(contenido: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        content = contenido
    )
}


/** Encabezado corto con ícono y color de la sección. */
@Composable
fun CabeceraSeccion(icono: ImageVector, titulo: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(40.dp).background(color.copy(alpha = .16f), RoundedCornerShape(13.dp))
                .border(BorderStroke(1.dp, color.copy(alpha = .45f)), RoundedCornerShape(13.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icono, null, tint = color, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(11.dp))
        Text(titulo, color = Texto, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    }
}

/**
 * Animación de envío: el avión de papel vuela mientras se sube y, al terminar,
 * aparece un check con rebote. Ligera: solo íconos y transformaciones.
 */
@Composable
fun AnimacionEnvio(progreso: Int, listo: Boolean, color: Color = VerdeBrillante, texto: String = "Enviando…") {
    val infinita = rememberInfiniteTransition(label = "envio")
    val vuelo by infinita.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "vuelo"
    )
    val halo by infinita.animateFloat(
        initialValue = .35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800, easing = LinearEasing), RepeatMode.Reverse),
        label = "halo"
    )
    val escalaCheck by animateFloatAsState(
        if (listo) 1f else 0f,
        spring(dampingRatio = 0.42f, stiffness = 380f),
        label = "check"
    )
    val p by animateFloatAsState(progreso.coerceIn(0, 100) / 100f, tween(350), label = "progresoEnvio")
    val colorFinal = if (listo) Verde else color

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(96.dp).alpha(if (listo) 1f else halo)
                    .background(colorFinal.copy(alpha = .12f), CircleShape)
                    .border(BorderStroke(2.dp, colorFinal.copy(alpha = .45f)), CircleShape)
            )
            if (listo) {
                Icon(
                    Icons.Rounded.CheckCircle, null, tint = Verde,
                    modifier = Modifier.size(58.dp).scale(escalaCheck)
                )
            } else {
                Icon(
                    Icons.Rounded.Send, null, tint = color,
                    modifier = Modifier
                        .size(40.dp)
                        .offset(x = (-16 + 34 * vuelo).dp, y = (14 - 30 * vuelo).dp)
                        .rotate(-28f)
                        .alpha(if (vuelo > .85f) (1f - vuelo) * 6.6f else 1f)
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(if (listo) "¡Listo!" else texto, color = colorFinal, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).background(Borde, RoundedCornerShape(99.dp))) {
            Box(
                Modifier.fillMaxWidth(if (listo) 1f else p).fillMaxHeight()
                    .background(colorFinal, RoundedCornerShape(99.dp))
            )
        }
    }
}
