package com.tesoreria.caja.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.EventAvailable
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PriorityHigh
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.EstadoPago
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.data.TipoCobro
import com.tesoreria.caja.data.MedioPago
import com.tesoreria.caja.data.NivelAcceso
import com.tesoreria.caja.data.Permiso
import com.tesoreria.caja.data.Cobro
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.delay

@Composable
fun PantallaInicio(irASubir: () -> Unit) {
    val yo = Caja.sesion.value ?: return
    val activos = Caja.cobrosActivos()
    var detalle by remember { mutableStateOf<Pair<Cobro, Int>?>(null) }
    var mostrarPendientes by remember { mutableStateOf<Cobro?>(null) }
    var verPago by remember { mutableStateOf<com.tesoreria.caja.data.Pago?>(null) }
    var noPagar by remember { mutableStateOf<Cobro?>(null) }
    var ahora by remember { mutableStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) { delay(1000); ahora = System.currentTimeMillis() }
    }

    Column(Modifier.fillMaxWidth()) {
        // Botón morado de Yape arriba: lo primero que ve quien debe pagar.
        if (yo.participaCobros) {
            activos.firstOrNull { c ->
                val e = Caja.estadoDe(c.id, yo.numero)
                e == EstadoPago.SIN_ENVIAR || e == EstadoPago.RECHAZADO
            }?.let { c ->
                TarjetaPagarYape(c, Caja.estadoDe(c.id, yo.numero) == EstadoPago.RECHAZADO) {
                    Caja.cobroSubidaId.value = c.id
                    irASubir()
                }
                Spacer(Modifier.height(12.dp))
            }
        }
        ResumenInicioA()
        Spacer(Modifier.height(10.dp))

        if (activos.isEmpty()) {
            Tarjeta {
                Etiqueta("COBROS")
                Spacer(Modifier.height(7.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.EventAvailable, null, tint = Tenue, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(10.dp))
                    Titulo("Sin cobros abiertos")
                }
                if (Caja.tienePermiso(yo, Permiso.GESTIONAR_COBROS)) { Spacer(Modifier.height(6.dp)); Text("Ábrelo en Panel › Cobro.", color = Tenue, fontSize = 13.sp) }
            }
            return@Column
        }

        activos.forEach { cobro ->
            val rapido = cobro.tipo == TipoCobro.RAPIDO
            val color = if (rapido) Ambar else Verde
            val noEnviaron = Caja.noEnviaron(cobro.id)
            val porRevisar = Caja.porRevisar(cobro.id)
            val rechazados = Caja.rechazados(cobro.id)
            val noParticipan = Caja.noParticipan(cobro.id)
            val pagaron = Caja.aprobados(cobro.id)
            val totalActivos = Caja.miembrosParticipantes().size
            val restante = cobro.cierra - ahora
            val miEstado = Caja.estadoDe(cobro.id, yo.numero)
            val miPago = Caja.pagoDe(cobro.id, yo.numero)

            if (miEstado == EstadoPago.RECHAZADO) {
                AlertaImportanteRechazo(miPago?.nota?.ifBlank { "Debes reenviar el comprobante." } ?: "Debes reenviar el comprobante.") {
                    Caja.cobroSubidaId.value = cobro.id
                    irASubir()
                }
                Spacer(Modifier.height(10.dp))
            }

            Tarjeta(borde = color.copy(alpha = .50f), fondo = if (rapido) Ambar.copy(alpha=.035f) else PanelAlto) {
                FilaEntre {
                    Column(Modifier.weight(1f)) {
                        Etiqueta(if (rapido) "COBRO RÁPIDO" else "COBRO OFICIAL", color)
                        Spacer(Modifier.height(4.dp))
                        Text(cobro.titulo, color = Texto, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(soles(cobro.monto), color = color, fontSize = 18.sp, style = cifra)
                }
                Spacer(Modifier.height(7.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Timer, null, tint = if (restante > 0) color else Rojo, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (restante > 0) cuenta(restante) else "Plazo vencido", color = if (restante > 0) color else Rojo, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(11.dp))
                BarraProgreso(if (totalActivos > 0) pagaron.toFloat() / totalActivos else 0f, color)
                Spacer(Modifier.height(8.dp))
                FilaEntre {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Groups, null, tint = color, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("$pagaron / $totalActivos", color = Texto, fontSize = 15.sp, style = cifra)
                    }
                    Text(soles(Caja.recaudado(cobro.id)), color = color, fontSize = 15.sp, style = cifra)
                }
                if (cobro.extensionTexto.isNotBlank()) { Spacer(Modifier.height(7.dp)); Pastilla(cobro.extensionTexto, Ambar) }
            }

            Spacer(Modifier.height(8.dp))

            if (yo.participaCobros) EstadoPropio(miEstado, cobro.id, yo.numero) else {
                Box(Modifier.fillMaxWidth().background(Celeste.copy(alpha=.08f), RoundedCornerShape(12.dp)).border(BorderStroke(1.dp, Celeste.copy(alpha=.24f)), RoundedCornerShape(12.dp)).padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Visibility, null, tint = Celeste, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Solo miras · no pagas este cobro", color = Celeste, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                if (porRevisar.isNotEmpty()) AlertaEstado("En revisión", "${porRevisar.size}", porRevisar.joinToString(", "), Ambar, alTocar = if (Caja.puedeVerYape(yo)) ({ mostrarPendientes = cobro }) else null)
                if (rechazados.isNotEmpty()) AlertaEstado("Deben reenviar", "${rechazados.size}", rechazados.joinToString(", "), Rojo)
                if (noParticipan.isNotEmpty()) AlertaEstado("No participan", "${noParticipan.size}", noParticipan.joinToString(", "), Celeste)
            }
            Spacer(Modifier.height(10.dp))
            Tarjeta(borde = if (rapido) Ambar.copy(alpha = .34f) else Borde) {
                FilaEntre {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.GridView, null, tint = color, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Lista", color = Texto, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("$pagaron/$totalActivos", color = color, fontSize = 16.sp, style = cifra)
                }
                Spacer(Modifier.height(12.dp))
                Cuadro(cobro.id, 0) { numero -> detalle = cobro to numero }
                Spacer(Modifier.height(10.dp))
                LeyendaCompleta()
                if (!yo.participaCobros) {
                    Spacer(Modifier.height(11.dp))
                    Pastilla("Solo miras", Tenue)
                } else if (miEstado == EstadoPago.SIN_ENVIAR || miEstado == EstadoPago.RECHAZADO) {
                    Spacer(Modifier.height(11.dp))
                    Boton("No pagaré", Modifier.fillMaxWidth(), relleno = false, color = Tenue, icono = Icons.Rounded.Block) { noPagar = cobro }
                } else if (miEstado == EstadoPago.NO_PAGA) {
                    Spacer(Modifier.height(11.dp))
                    Boton("Mejor sí pago", Modifier.fillMaxWidth(), relleno = false, color = MoradoYape, icono = Icons.Rounded.QrCode2) {
                        Caja.cancelarNoPago(cobro.id) { ok, _ -> if (ok) { Caja.cobroSubidaId.value = cobro.id; irASubir() } }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }
    }

    mostrarPendientes?.let { cobro ->
        Dialog(onDismissRequest = { mostrarPendientes = null }) {
            Tarjeta(borde = Ambar.copy(alpha=.45f), fondo = PanelAlto) {
                Etiqueta("COMPROBANTES PENDIENTES", Ambar)
                Spacer(Modifier.height(9.dp))
                val lista = Caja.pendientes().filter { it.cobroId == cobro.id }
                lista.forEach { p ->
                    Row(Modifier.fillMaxWidth().background(Fondo, RoundedCornerShape(12.dp)).border(BorderStroke(1.dp, Ambar.copy(alpha=.25f)), RoundedCornerShape(12.dp)).clickable { verPago = p }.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("N.º ${p.socio} · ${Caja.socio(p.socio)?.nombre.orEmpty()}", color = Texto, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(3.dp)); Text(soles(p.monto), color = Tenue, fontSize = 12.sp)
                        }
                        Pastilla("Ver", Cian)
                    }
                    Spacer(Modifier.height(7.dp))
                }
                if (lista.isEmpty()) Text("Ya no hay comprobantes pendientes.", color = Tenue, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp)); Boton("Cerrar", Modifier.fillMaxWidth(), relleno=false, color=Tenue) { mostrarPendientes=null }
            }
        }
    }

    detalle?.let { (cobro,n) ->
        Dialog(onDismissRequest = { detalle = null }) {
            Tarjeta(borde=Borde, fondo=PanelAlto) {
                val socio = Caja.socio(n); val p = Caja.pagoDe(cobro.id,n); val estado = if (socio?.participaCobros == false) EstadoPago.NO_PAGA else Caja.estadoDe(cobro.id,n)
                FilaEntre {
                    Column(Modifier.weight(1f)) { Etiqueta("N.º $n"); Spacer(Modifier.height(4.dp)); Text(socio?.nombre ?: "", color=Texto, fontSize=18.sp, fontWeight=FontWeight.SemiBold) }
                    Pastilla(textoEstado(estado), colorDe(estado))
                }
                Spacer(Modifier.height(12.dp))
                if (estado == EstadoPago.NO_PAGA) {
                    Text(if (socio?.participaCobros == false) "Invitado · no paga cobros." else "Dijo que no participará.", color=Celeste, fontSize=14.sp)
                    val motivo = if (socio?.participaCobros == false) "" else Caja.motivoNoPago(cobro.id, n)
                    if (motivo.isNotBlank()) { Spacer(Modifier.height(7.dp)); Text("Motivo: $motivo", color=Texto, fontSize=13.5.sp) }
                } else if (p == null) Text("Aún no paga.", color=Rojo, fontSize=14.sp, fontWeight = FontWeight.SemiBold) else {
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Pastilla(if (p.medio == MedioPago.YAPE) "Yape" else "Manual", if (p.medio == MedioPago.YAPE) Violeta else Verde)
                        Text(soles(p.monto), color=Texto, fontSize=14.sp, style=cifra)
                    }
                    Spacer(Modifier.height(5.dp)); Text("${fechaHora(p.enviado)}", color=Tenue, fontSize=13.5.sp)
                    p.revisadoPor?.let { Spacer(Modifier.height(4.dp)); Text("Revisó N.º $it", color=Tenue, fontSize=12.sp) }
                    if (p.capturaPath.isNotBlank() && (p.estado == EstadoPago.APROBADO || Caja.puedeVerYape(yo) || yo.numero == n)) {
                        Spacer(Modifier.height(10.dp)); Boton("Ver captura", Modifier.fillMaxWidth(), color = Celeste, icono = Icons.Rounded.Image) { verPago=p }
                    }
                    if (estado == EstadoPago.RECHAZADO && p.nota.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text("Motivo: ${p.nota}", color=Rojo, fontSize=13.5.sp) }
                }
                Spacer(Modifier.height(14.dp)); Boton("Cerrar", Modifier.fillMaxWidth(), relleno=false) { detalle=null }
            }
        }
    }
    noPagar?.let { cobro ->
        Dialog(onDismissRequest = { noPagar = null }) {
            var motivo by remember(cobro.id) { mutableStateOf("") }
            var aviso by remember(cobro.id) { mutableStateOf("") }
            var guardando by remember(cobro.id) { mutableStateOf(false) }
            Tarjeta(borde = Cian.copy(alpha = .45f), fondo = PanelAlto) {
                Etiqueta("NO PARTICIPAR EN ESTE COBRO", Cian)
                Spacer(Modifier.height(7.dp))
                Text(cobro.titulo, color = Texto, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Tu decisión y el motivo quedarán guardados en el acta y en el PDF cuando cierre el cobro.", color = Tenue, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Campo(motivo, { motivo = it.take(300); aviso = "" }, "Motivo · mínimo 4 caracteres")
                if (aviso.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text(aviso, color = Rojo, fontSize = 13.sp) }
                Spacer(Modifier.height(11.dp))
                Boton(if (guardando) "Guardando…" else "Confirmar que no pagaré", Modifier.fillMaxWidth(), color = Cian, activo = !guardando) {
                    if (motivo.trim().length < 4) aviso = "Escribe un motivo claro" else {
                        guardando = true
                        Caja.declararNoPago(cobro.id, motivo) { ok, msg ->
                            guardando = false
                            if (ok) noPagar = null else aviso = msg
                        }
                    }
                }
                Spacer(Modifier.height(7.dp))
                Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue, activo = !guardando) { noPagar = null }
            }
        }
    }
    verPago?.let { p -> VisorPagoDialog(p) { verPago=null } }
}

@Composable
private fun ResumenInicioA() {
    TarjetaPremium {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Etiqueta("SALDO EN CAJA", VerdeBrillante)
                Spacer(Modifier.height(5.dp))
                Text(soles(Caja.saldo()), color = Texto, fontSize = 34.sp, style = cifra)
            }
            Icon(Icons.Rounded.AccountBalanceWallet, null, tint = VerdeBrillante, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) { MiniDato("INGRESOS", soles(Caja.ingresos()), Verde) }
            Box(Modifier.weight(1f)) { MiniDato("GASTOS", soles(Caja.egresos()), Rojo) }
        }
    }
}

@Composable
private fun ResumenInicioB() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TarjetaPremium {
            Etiqueta("SALDO ACTUAL", Verde)
            Spacer(Modifier.height(6.dp))
            Text(soles(Caja.saldo()), color = Texto, fontSize = 32.sp, style = cifra)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tarjeta(Modifier.weight(1f), borde = Verde.copy(alpha = .3f)) {
                Etiqueta("INGRESOS", Verde)
                Spacer(Modifier.height(6.dp))
                Text(soles(Caja.ingresos()), color = Verde, fontSize = 20.sp, style = cifra)
            }
            Tarjeta(Modifier.weight(1f), borde = Rojo.copy(alpha = .3f)) {
                Etiqueta("GASTOS", Rojo)
                Spacer(Modifier.height(6.dp))
                Text(soles(Caja.egresos()), color = Rojo, fontSize = 20.sp, style = cifra)
            }
        }
    }
}

@Composable
private fun ResumenInicioC() {
    TarjetaPremium {
        FilaEntre {
            Column(Modifier.weight(1f)) {
                Etiqueta("TABLERO", Ambar)
                Spacer(Modifier.height(4.dp))
                Text(soles(Caja.saldo()), color = Texto, fontSize = 28.sp, style = cifra)
            }
            Column(horizontalAlignment = Alignment.End) {
                Pastilla("Ingreso ${soles(Caja.ingresos())}", Verde)
                Spacer(Modifier.height(6.dp))
                Pastilla("Gasto ${soles(Caja.egresos())}", Rojo)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ResumenChip("Cobros", Caja.cobros.count { !it.cerrado }.toString(), Cian, Modifier.weight(1f))
            ResumenChip("Pagos", Caja.pagos.count { it.estado == EstadoPago.APROBADO }.toString(), Verde, Modifier.weight(1f))
            ResumenChip("Actas", Caja.actas.size.toString(), Ambar, Modifier.weight(1f))
        }
    }
}

@Composable
private fun ResumenChip(titulo: String, valor: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier
            .background(color.copy(alpha = .1f), RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = .3f)), RoundedCornerShape(12.dp))
            .padding(vertical = 10.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(valor, color = color, fontSize = 16.sp, style = cifra, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(2.dp))
            Text(titulo, color = Tenue, fontSize = 12.sp)
        }
    }
}

@Composable
private fun AlertaEstado(titulo: String, contador: String, detalle: String, color: Color, alTocar: (() -> Unit)? = null) {
    val base = Modifier
        .fillMaxWidth()
        .background(color.copy(alpha = 0.085f), RoundedCornerShape(14.dp))
        .border(BorderStroke(1.dp, color.copy(alpha = 0.28f)), RoundedCornerShape(14.dp))
    Row(
        (if (alTocar != null) base.clickable { alTocar() } else base)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            Modifier.size(34.dp).background(color.copy(alpha = 0.14f), RoundedCornerShape(11.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(if (color == Ambar) Icons.Rounded.HourglassTop else if (color == Celeste) Icons.Rounded.Block else Icons.Rounded.PriorityHigh, null, tint = color, modifier = Modifier.size(19.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(titulo, color = color, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(detalle, color = Texto, fontSize = 13.sp)
        }
        Pastilla(contador, color)
    }
}

@Composable
private fun AlertaImportanteRechazo(motivo: String, reenviar: () -> Unit) {
    Tarjeta(borde = Rojo.copy(alpha = .45f), fondo = PanelAlto) {
        Etiqueta("AVISO IMPORTANTE", Rojo)
        Spacer(Modifier.height(8.dp))
        Text("Tu comprobante fue rechazado", color = Texto, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("Motivo", color = Rojo, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .background(Rojo.copy(alpha = 0.10f), RoundedCornerShape(12.dp))
                .border(BorderStroke(1.dp, Rojo.copy(alpha = 0.28f)), RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text(motivo, color = Texto, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(14.dp))
        Boton("Reenviar ahora", Modifier.fillMaxWidth(), color = Rojo) { reenviar() }
    }
}

@Composable
private fun BarraProgreso(valor: Float, color: Color = Verde) {
    val animado by animateFloatAsState(valor.coerceIn(0f, 1f), tween(900, easing = FastOutSlowInEasing), label = "barraCobro")
    Box(
        Modifier
            .fillMaxWidth()
            .height(10.dp)
            .background(Borde.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
    ) {
        Box(
            Modifier
                .fillMaxWidth(animado)
                .height(10.dp)
                .background(color, RoundedCornerShape(8.dp))
        )
    }
}

@Composable
private fun TarjetaPagarYape(cobro: Cobro, rechazado: Boolean, alTocar: () -> Unit) {
    val infinita = rememberInfiniteTransition(label = "yapeBrillo")
    val brillo by infinita.animateFloat(
        initialValue = .35f, targetValue = .85f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Reverse),
        label = "brilloYape"
    )
    Row(
        Modifier
            .fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(Color(0xFF5B21B6), Color(0xFF7C3AED))), RoundedCornerShape(22.dp))
            .border(BorderStroke(1.5.dp, MoradoYape.copy(alpha = brillo)), RoundedCornerShape(22.dp))
            .clickable { alTocar() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(52.dp).background(Color.White.copy(alpha = .16f), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.QrCode2, null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(if (rechazado) "Reenviar Yape" else "Pagar con Yape", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(2.dp))
            Text("${cobro.titulo} · ${soles(cobro.monto)}", color = Color.White.copy(alpha = .85f), fontSize = 13.sp, maxLines = 1)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = Color.White, modifier = Modifier.size(28.dp))
    }
}

@Composable
fun Cuadro(cobroId: Int, estilo: Int, alTocar: (Int) -> Unit) {
    // Una sola animación compartida para todas las celdas "en proceso" (ligero).
    val infinita = rememberInfiniteTransition(label = "cuadro")
    val pulso by infinita.animateFloat(
        initialValue = .35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulsoProceso"
    )
    // 1-22 pagan, 23 tesorero, 24-28 invitados. Más plazas solo si están ocupadas.
    val ultimo = maxOf(28, Caja.socios.maxOfOrNull { it.numero } ?: 0).coerceAtMost(35)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        (1..ultimo).toList().chunked(5).forEach { fila ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                fila.forEach { numero ->
                    val socio = Caja.socio(numero)
                    val asignado = socio != null
                    val participa = socio?.participaCobros == true
                    val estado = if (asignado && participa) Caja.estadoDe(cobroId, numero) else null
                    val pago = if (asignado && participa) Caja.pagoDe(cobroId, numero) else null
                    CeldaLista(
                        Modifier.weight(1f).height(58.dp),
                        numero, asignado, participa, estado,
                        owner = socio?.nivelAcceso == NivelAcceso.OWNER,
                        yape = estado == EstadoPago.APROBADO && pago?.medio == MedioPago.YAPE,
                        pulso = pulso,
                        alTocar = alTocar
                    )
                }
                repeat(5 - fila.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun CeldaLista(
    modifier: Modifier,
    numero: Int,
    asignado: Boolean,
    participa: Boolean,
    estado: EstadoPago?,
    owner: Boolean,
    yape: Boolean,
    pulso: Float,
    alTocar: (Int) -> Unit
) {
    if (!asignado) {
        Box(
            modifier.background(Tenue.copy(alpha = 0.03f), RoundedCornerShape(14.dp))
                .border(BorderStroke(1.dp, Borde.copy(alpha = 0.30f)), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("$numero", color = Tenue.copy(alpha = .35f), fontSize = 13.5.sp, style = cifra)
        }
        return
    }
    val color = when {
        owner && !participa -> Ambar
        !participa -> Celeste
        estado == EstadoPago.APROBADO -> Verde
        estado == EstadoPago.PENDIENTE -> Naranja
        estado == EstadoPago.NO_PAGA -> Tenue
        else -> Rojo
    }
    val icono = when {
        owner && !participa -> Icons.Rounded.Star
        !participa -> Icons.Rounded.Person
        estado == EstadoPago.APROBADO -> Icons.Rounded.Check
        estado == EstadoPago.PENDIENTE -> Icons.Rounded.HourglassTop
        estado == EstadoPago.RECHAZADO -> Icons.Rounded.PriorityHigh
        estado == EstadoPago.NO_PAGA -> Icons.Rounded.Block
        else -> Icons.Rounded.Close
    }
    val enProceso = estado == EstadoPago.PENDIENTE
    // Rebote suave cuando alguien pasa a verde.
    val escala by animateFloatAsState(
        if (estado == EstadoPago.APROBADO) 1f else 0.94f,
        spring(dampingRatio = 0.38f, stiffness = 420f),
        label = "celda$numero"
    )
    val fondo by animateColorAsState(color.copy(alpha = if (estado == EstadoPago.APROBADO) .22f else .12f), tween(400), label = "fondoCelda$numero")
    Box(
        modifier
            .scale(escala)
            .background(fondo, RoundedCornerShape(14.dp))
            .border(
                BorderStroke(
                    if (estado == EstadoPago.RECHAZADO || enProceso) 2.dp else 1.dp,
                    color.copy(alpha = if (enProceso) pulso else .60f)
                ),
                RoundedCornerShape(14.dp)
            )
            .clickable { alTocar(numero) }
    ) {
        Text(
            "$numero", color = Texto, fontSize = 13.sp, style = cifra, fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.TopStart).padding(start = 7.dp, top = 4.dp)
        )
        if (yape) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(top = 6.dp, end = 6.dp).size(8.dp)
                    .background(MoradoYape, RoundedCornerShape(99.dp))
            )
        }
        Icon(
            icono, null, tint = color,
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 6.dp, bottom = 5.dp).size(21.dp)
        )
    }
}

@Composable
private fun LeyendaCompleta() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Leyenda(Verde, Icons.Rounded.Check, "Pagó", Modifier.weight(1f))
            Leyenda(Naranja, Icons.Rounded.HourglassTop, "En revisión", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth()) {
            Leyenda(Rojo, Icons.Rounded.Close, "Falta", Modifier.weight(1f))
            Leyenda(Celeste, Icons.Rounded.Person, "Invitado", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth()) {
            Leyenda(Ambar, Icons.Rounded.Star, "Tesorero", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth()) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(MoradoYape, RoundedCornerShape(99.dp)))
                Spacer(Modifier.width(8.dp))
                Text("Por Yape", color = Tenue, fontSize = 13.sp)
            }
            Leyenda(Tenue, Icons.Rounded.Block, "No paga", Modifier.weight(1f))
        }
    }
}

@Composable
private fun Leyenda(color: Color, icono: ImageVector, texto: String, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Icon(icono, null, tint = color, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(6.dp))
        Text(texto, color = Tenue, fontSize = 13.sp)
    }
}

@Composable
private fun EstadoPropio(estado: EstadoPago, cobroId: Int, numero: Int) {
    val p = Caja.pagoDe(cobroId, numero)
    val color = colorDe(estado)
    Box(
        Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.24f)), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Column {
            Text("Tú · ${textoEstado(estado)}", color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                when (estado) {
                    EstadoPago.APROBADO -> "Pago confirmado ✓"
                    EstadoPago.PENDIENTE -> "Enviado, falta revisar."
                    EstadoPago.RECHAZADO -> "Reenvía. ${p?.nota.orEmpty()}"
                    EstadoPago.SIN_ENVIAR -> "Aún no pagas."
                    EstadoPago.NO_PAGA -> "No participas."
                },
                color = Tenue,
                fontSize = 13.sp
            )
            Spacer(Modifier.height(9.dp))
            EstadoLinea(estado)
        }
    }
}

@Composable
private fun EstadoLinea(estado: EstadoPago) {
    if (estado == EstadoPago.NO_PAGA) {
        Text("Decisión guardada", color = Celeste, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
        return
    }
    val enviado = estado != EstadoPago.SIN_ENVIAR
    val revisado = estado == EstadoPago.APROBADO || estado == EstadoPago.RECHAZADO
    val aprobado = estado == EstadoPago.APROBADO
    val rechazado = estado == EstadoPago.RECHAZADO
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        PasoEstado("Enviado", enviado, if (enviado) Verde else Tenue, Modifier.weight(1f))
        Text("›", color = Tenue, fontSize = 13.5.sp)
        PasoEstado(
            if (estado == EstadoPago.PENDIENTE) "Revisión" else "Revisado",
            estado == EstadoPago.PENDIENTE || revisado,
            if (estado == EstadoPago.PENDIENTE) Ambar else if (revisado) Verde else Tenue,
            Modifier.weight(1f)
        )
        Text("›", color = Tenue, fontSize = 13.5.sp)
        PasoEstado(
            when { rechazado -> "Rechazado"; aprobado -> "Aprobado"; else -> "Resultado" },
            aprobado || rechazado,
            if (rechazado) Rojo else if (aprobado) Verde else Tenue,
            Modifier.weight(1f)
        )
    }
}

@Composable
private fun PasoEstado(texto: String, activo: Boolean, color: Color, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).background(if (activo) color else Tenue.copy(alpha = .28f), RoundedCornerShape(50)))
        Spacer(Modifier.width(4.dp))
        Text(texto, color = if (activo) color else Tenue.copy(alpha = .65f), fontSize = 13.sp, fontWeight = if (activo) FontWeight.SemiBold else FontWeight.Normal)
    }
}

fun colorDe(estado: EstadoPago): Color = when (estado) {
    EstadoPago.APROBADO -> Verde
    EstadoPago.PENDIENTE -> Naranja
    EstadoPago.RECHAZADO -> Rojo
    EstadoPago.SIN_ENVIAR -> Rojo
    EstadoPago.NO_PAGA -> Celeste
}

fun marcaDe(estado: EstadoPago): String = when (estado) {
    EstadoPago.APROBADO -> "✓"
    EstadoPago.PENDIENTE -> "•"
    EstadoPago.RECHAZADO -> "!"
    EstadoPago.SIN_ENVIAR -> "✕"
    EstadoPago.NO_PAGA -> "N"
}

fun textoEstado(estado: EstadoPago): String = when (estado) {
    EstadoPago.APROBADO -> "Pagó"
    EstadoPago.PENDIENTE -> "En revisión"
    EstadoPago.RECHAZADO -> "Rechazado"
    EstadoPago.SIN_ENVIAR -> "Falta"
    EstadoPago.NO_PAGA -> "No participa"
}

fun cuenta(ms: Long): String {
    val s = ms.coerceAtLeast(0L) / 1000
    val d = s / 86400
    val h = (s % 86400) / 3600
    val m = (s % 3600) / 60
    val seg = s % 60
    return if (d > 0) "$d d $h h $m min" else "$h h $m min $seg s"
}
