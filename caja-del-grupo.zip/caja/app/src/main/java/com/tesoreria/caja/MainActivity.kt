package com.tesoreria.caja

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.ui.Borde
import com.tesoreria.caja.ui.Boton
import com.tesoreria.caja.ui.CajaTheme
import com.tesoreria.caja.ui.Cian
import com.tesoreria.caja.ui.Fondo
import com.tesoreria.caja.ui.Panel
import com.tesoreria.caja.ui.PantallaArchivo
import com.tesoreria.caja.ui.PantallaInicio
import com.tesoreria.caja.ui.PantallaLogin
import com.tesoreria.caja.ui.PantallaMovimientos
import com.tesoreria.caja.ui.PantallaPanel
import com.tesoreria.caja.ui.PantallaSubir
import com.tesoreria.caja.ui.Tenue
import com.tesoreria.caja.ui.Texto

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Caja.cargarDemo()
        setContent { CajaTheme { App() } }
    }
}

private enum class Vista { INICIO, SUBIR, MOVIMIENTOS, ARCHIVO, PANEL }

@Composable
fun App() {

    val yo = Caja.sesion.value
    var vista by remember { mutableStateOf(Vista.INICIO) }

    if (yo == null) {
        PantallaLogin { s ->
            Caja.sesion.value = s
            Caja.revisarVencidos()
            vista = Vista.INICIO
        }
        return
    }

    val conPanel = yo.rol == Rol.TESORERO || yo.rol == Rol.PRESIDENTE

    Column(
        Modifier
            .fillMaxSize()
            .background(Fondo)
    ) {

        // ---- barra superior ----
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Caja del grupo", color = Texto, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                Text(
                    "N° ${yo.numero}  ·  ${yo.nombre.substringBefore(" ")}" +
                        when (yo.rol) {
                            Rol.TESORERO -> "  ·  tesorero"
                            Rol.PRESIDENTE -> "  ·  presidente"
                            else -> ""
                        },
                    color = Tenue, fontSize = 11.sp
                )
            }
            Boton("Salir", Modifier.width(78.dp), relleno = false, color = Tenue) {
                Caja.sesion.value = null
            }
        }

        // ---- contenido ----
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
                .padding(bottom = 18.dp)
        ) {
            when (vista) {
                Vista.INICIO -> PantallaInicio { vista = Vista.SUBIR }
                Vista.SUBIR -> PantallaSubir { vista = Vista.INICIO }
                Vista.MOVIMIENTOS -> PantallaMovimientos()
                Vista.ARCHIVO -> PantallaArchivo()
                Vista.PANEL -> PantallaPanel()
            }
        }

        // ---- barra inferior ----
        Row(
            Modifier
                .fillMaxWidth()
                .background(Panel)
                .border(BorderStroke(1.dp, Borde), RoundedCornerShape(0.dp))
                .padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Tab("Inicio", vista == Vista.INICIO || vista == Vista.SUBIR, Modifier.weight(1f)) {
                vista = Vista.INICIO
            }
            Tab("Movimientos", vista == Vista.MOVIMIENTOS, Modifier.weight(1f)) {
                vista = Vista.MOVIMIENTOS
            }
            Tab("Archivo", vista == Vista.ARCHIVO, Modifier.weight(1f)) {
                vista = Vista.ARCHIVO
            }
            if (conPanel) {
                Tab("Panel", vista == Vista.PANEL, Modifier.weight(1f)) { vista = Vista.PANEL }
            }
        }
    }
}

@Composable
private fun Tab(texto: String, activa: Boolean, modifier: Modifier = Modifier, alTocar: () -> Unit) {
    Box(
        modifier
            .height(44.dp)
            .background(
                if (activa) Cian.copy(alpha = 0.13f) else androidx.compose.ui.graphics.Color.Transparent,
                RoundedCornerShape(10.dp)
            )
            .clickable { alTocar() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            texto,
            color = if (activa) Cian else Tenue,
            fontSize = 12.sp,
            fontWeight = if (activa) FontWeight.Medium else FontWeight.Normal
        )
    }
}
