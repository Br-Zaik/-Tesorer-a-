package com.tesoreria.caja.data

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/*
 * Todo esto vive solo en memoria. Al cerrar la app se reinicia.
 * Cuando conectemos Supabase, este archivo es lo unico que cambia:
 * las pantallas no se tocan.
 */

val PE: Locale = Locale("es", "PE")

fun soles(centavos: Long): String =
    String.format(PE, "S/ %,.2f", centavos / 100.0)

fun fechaHora(t: Long): String =
    SimpleDateFormat("dd/MM/yyyy HH:mm", PE).format(Date(t))

fun fechaCorta(t: Long): String =
    SimpleDateFormat("dd/MM/yyyy", PE).format(Date(t))

enum class EstadoPago { SIN_ENVIAR, PENDIENTE, APROBADO, RECHAZADO }

enum class Rol { SOCIO, PRESIDENTE, TESORERO }

data class Socio(
    val numero: Int,
    val nombre: String,
    val rol: Rol = Rol.SOCIO
)

data class Cobro(
    val id: Int,
    val titulo: String,
    val monto: Long,
    val creado: Long,
    val cierra: Long,
    val cerrado: Boolean = false
)

data class Pago(
    val id: Int,
    val cobroId: Int,
    val socio: Int,
    val monto: Long,
    val estado: EstadoPago,
    val enviado: Long,
    val operacion: String,
    val ocrMonto: Long,
    val nota: String = ""
)

data class Gasto(
    val id: Int,
    val concepto: String,
    val monto: Long,
    val fecha: Long,
    val firmaTesorero: Boolean = false,
    val firmaPresidente: Boolean = false
) {
    val aprobado: Boolean get() = firmaTesorero && firmaPresidente
}

data class Acta(
    val cobroId: Int,
    val titulo: String,
    val monto: Long,
    val cierre: Long,
    val recaudado: Long,
    val pagaron: List<Int>,
    val faltaron: List<Int>
)

object Caja {

    val socios = mutableStateListOf<Socio>()
    val cobros = mutableStateListOf<Cobro>()
    val pagos = mutableStateListOf<Pago>()
    val gastos = mutableStateListOf<Gasto>()
    val actas = mutableStateListOf<Acta>()
    val bitacora = mutableStateListOf<String>()

    private val claves = mutableMapOf<Int, String>()
    private val reseteos = mutableMapOf<Int, Long>()

    val sesion = mutableStateOf<Socio?>(null)

    private var seqCobro = 1
    private var seqPago = 1
    private var seqGasto = 1

    val esAdmin: Boolean
        get() = sesion.value?.rol == Rol.TESORERO
    val esPresidente: Boolean
        get() = sesion.value?.rol == Rol.PRESIDENTE

    // ---------- saldo ----------

    fun ingresos(): Long = pagos.filter { it.estado == EstadoPago.APROBADO }.sumOf { it.monto }

    fun egresos(): Long = gastos.filter { it.aprobado }.sumOf { it.monto }

    fun saldo(): Long = ingresos() - egresos()

    // ---------- cobros ----------

    fun cobroActivo(): Cobro? = cobros.firstOrNull { !it.cerrado }

    fun estadoDe(cobroId: Int, numero: Int): EstadoPago =
        pagos.firstOrNull { it.cobroId == cobroId && it.socio == numero }?.estado
            ?: EstadoPago.SIN_ENVIAR

    fun pagoDe(cobroId: Int, numero: Int): Pago? =
        pagos.firstOrNull { it.cobroId == cobroId && it.socio == numero }

    fun faltantes(cobroId: Int): List<Int> =
        socios.map { it.numero }.filter { estadoDe(cobroId, it) != EstadoPago.APROBADO }.sorted()

    fun recaudado(cobroId: Int): Long =
        pagos.filter { it.cobroId == cobroId && it.estado == EstadoPago.APROBADO }.sumOf { it.monto }

    fun crearCobro(titulo: String, monto: Long, horas: Int) {
        val ahora = System.currentTimeMillis()
        cobros.add(
            Cobro(
                id = seqCobro++,
                titulo = titulo,
                monto = monto,
                creado = ahora,
                cierra = ahora + horas * 3_600_000L
            )
        )
        anotar("Se creo el cobro \"$titulo\" por ${soles(monto)}, plazo $horas h")
    }

    fun cerrarCobro(id: Int) {
        val i = cobros.indexOfFirst { it.id == id }
        if (i < 0 || cobros[i].cerrado) return
        val c = cobros[i]
        cobros[i] = c.copy(cerrado = true)
        val pagaron = socios.map { it.numero }
            .filter { estadoDe(id, it) == EstadoPago.APROBADO }
        actas.add(
            Acta(
                cobroId = id,
                titulo = c.titulo,
                monto = c.monto,
                cierre = System.currentTimeMillis(),
                recaudado = recaudado(id),
                pagaron = pagaron,
                faltaron = socios.map { it.numero }.filterNot { pagaron.contains(it) }
            )
        )
        anotar("Se cerro el cobro \"${c.titulo}\" y se guardo el acta")
    }

    /** Se llama cada vez que alguien abre la app. Cierra lo vencido. */
    fun revisarVencidos() {
        val ahora = System.currentTimeMillis()
        cobros.filter { !it.cerrado && it.cierra <= ahora }.forEach { cerrarCobro(it.id) }
    }

    // ---------- pagos ----------

    fun registrarPago(cobroId: Int, numero: Int, monto: Long, operacion: String, ocr: Long) {
        pagos.removeAll { it.cobroId == cobroId && it.socio == numero && it.estado == EstadoPago.RECHAZADO }
        pagos.add(
            Pago(
                id = seqPago++,
                cobroId = cobroId,
                socio = numero,
                monto = monto,
                estado = EstadoPago.PENDIENTE,
                enviado = System.currentTimeMillis(),
                operacion = operacion,
                ocrMonto = ocr
            )
        )
        anotar("El socio $numero envio su comprobante por ${soles(monto)}")
    }

    fun aprobarPago(id: Int) {
        val i = pagos.indexOfFirst { it.id == id }
        if (i < 0) return
        pagos[i] = pagos[i].copy(estado = EstadoPago.APROBADO)
        anotar("Se aprobo el pago del socio ${pagos[i].socio}")
    }

    fun rechazarPago(id: Int, motivo: String) {
        val i = pagos.indexOfFirst { it.id == id }
        if (i < 0) return
        pagos[i] = pagos[i].copy(estado = EstadoPago.RECHAZADO, nota = motivo)
        anotar("Se rechazo el pago del socio ${pagos[i].socio}: $motivo")
    }

    fun pendientes(): List<Pago> = pagos.filter { it.estado == EstadoPago.PENDIENTE }

    /** Detecta si un numero de operacion ya fue usado por otro socio. */
    fun operacionRepetida(operacion: String, exceptoPago: Int): Boolean =
        pagos.any { it.operacion == operacion && it.id != exceptoPago }

    // ---------- gastos ----------

    fun crearGasto(concepto: String, monto: Long) {
        gastos.add(
            Gasto(
                id = seqGasto++,
                concepto = concepto,
                monto = monto,
                fecha = System.currentTimeMillis(),
                firmaTesorero = true
            )
        )
        anotar("Se registro el gasto \"$concepto\" por ${soles(monto)}, falta la firma del presidente")
    }

    fun firmarGasto(id: Int, comoPresidente: Boolean) {
        val i = gastos.indexOfFirst { it.id == id }
        if (i < 0) return
        gastos[i] = if (comoPresidente) gastos[i].copy(firmaPresidente = true)
        else gastos[i].copy(firmaTesorero = true)
        if (gastos[i].aprobado) anotar("El gasto \"${gastos[i].concepto}\" quedo con las dos firmas")
    }

    fun gastosPorFirmar(): List<Gasto> = gastos.filter { !it.aprobado }

    // ---------- claves ----------

    fun tieneClave(numero: Int): Boolean = claves.containsKey(numero)

    fun reseteoAbierto(numero: Int): Boolean {
        val hasta = reseteos[numero] ?: return false
        return hasta > System.currentTimeMillis()
    }

    fun horasDeReseteo(numero: Int): Long {
        val hasta = reseteos[numero] ?: return 0
        return ((hasta - System.currentTimeMillis()) / 3_600_000L).coerceAtLeast(0)
    }

    fun necesitaCrearClave(numero: Int): Boolean =
        !tieneClave(numero) || reseteoAbierto(numero)

    fun crearClave(numero: Int, clave: String) {
        claves[numero] = clave
        reseteos.remove(numero)
        anotar("El socio $numero creo su contrasena")
    }

    fun validar(numero: Int, clave: String): Boolean = claves[numero] == clave

    fun resetear(numero: Int) {
        claves.remove(numero)
        reseteos[numero] = System.currentTimeMillis() + 24 * 3_600_000L
        anotar("Se abrio el reseteo de contrasena del socio $numero por 24 h")
    }

    fun socio(numero: Int): Socio? = socios.firstOrNull { it.numero == numero }

    private fun anotar(texto: String) {
        bitacora.add(0, "${fechaHora(System.currentTimeMillis())}  ·  $texto")
    }

    // ---------- demo ----------

    fun cargarDemo() {
        if (socios.isNotEmpty()) return

        val nombres = listOf(
            "Brian Quispe Ramos", "Elena Vargas Huaman", "Carlos Mendoza Ríos",
            "Rosa Ccahuana Puma", "Luis Paredes Soto", "Marta Flores Chávez",
            "Diego Salazar León", "Ana Torres Gutiérrez", "Jorge Ríos Cárdenas",
            "Silvia Ramos Espinoza", "Pedro Aguilar Núñez", "Julia Condori Mamani",
            "Raúl Medina Castro", "Nora Peralta Vega", "Iván Cabrera Rojas",
            "Delia Sánchez Ortiz", "Óscar Huamán Loayza", "Teresa Bravo Silva",
            "Manuel Ibáñez Cruz", "Gloria Rivas Pacheco", "Félix Guzmán Arce",
            "Beatriz Campos Núñez", "Alberto Zegarra Lima", "Carmen Alvarado Roca",
            "Hugo Delgado Ponce", "Sara Molina Tapia", "Walter Cáceres Yupanqui",
            "Lucía Maldonado Pinto", "Ernesto Fuentes Bautista", "Irma Palacios Vera",
            "Gustavo Neyra Cordero", "Pilar Segura Escobar", "Andrés Villena Ocampo",
            "Rocío Bermúdez Lazo", "Tomás Reyna Alfaro"
        )
        nombres.forEachIndexed { i, nombre ->
            val rol = when (i) {
                0 -> Rol.TESORERO
                1 -> Rol.PRESIDENTE
                else -> Rol.SOCIO
            }
            socios.add(Socio(i + 1, nombre, rol))
        }

        // Todos tienen clave 123456, menos el 12 y el 27 para ver el primer ingreso.
        socios.forEach { if (it.numero != 12 && it.numero != 27) claves[it.numero] = "123456" }

        val ahora = System.currentTimeMillis()

        // Cobro ya cerrado, con su acta.
        cobros.add(
            Cobro(
                id = seqCobro++, titulo = "Cuota agosto", monto = 2500,
                creado = ahora - 40 * 24 * 3_600_000L,
                cierra = ahora - 38 * 24 * 3_600_000L, cerrado = true
            )
        )
        val pagaronAgosto = (1..35).filterNot { it in listOf(9, 21, 33) }
        pagaronAgosto.forEach {
            pagos.add(
                Pago(
                    seqPago++, 1, it, 2500, EstadoPago.APROBADO,
                    ahora - 39 * 24 * 3_600_000L, "0086${400 + it}", 2500
                )
            )
        }
        actas.add(
            Acta(
                cobroId = 1, titulo = "Cuota agosto", monto = 2500,
                cierre = ahora - 38 * 24 * 3_600_000L,
                recaudado = pagaronAgosto.size * 2500L,
                pagaron = pagaronAgosto,
                faltaron = listOf(9, 21, 33)
            )
        )

        // Cobro activo.
        cobros.add(
            Cobro(
                id = seqCobro++, titulo = "Día del Niño", monto = 400,
                creado = ahora - 5 * 3_600_000L,
                cierra = ahora + 9 * 3_600_000L
            )
        )
        val aprobados = listOf(1, 2, 3, 5, 7, 8, 10, 11, 13, 14, 16, 17, 18, 20, 22, 23, 24, 25, 27, 28, 29, 31, 32, 34, 35)
        aprobados.forEach {
            pagos.add(
                Pago(
                    seqPago++, 2, it, 400, EstadoPago.APROBADO,
                    ahora - 3 * 3_600_000L, "0091${200 + it}", 400
                )
            )
        }
        listOf(4, 12, 19, 30).forEach {
            pagos.add(
                Pago(
                    seqPago++, 2, it, 400, EstadoPago.PENDIENTE,
                    ahora - 40 * 60_000L, "0091${200 + it}", 400
                )
            )
        }

        gastos.add(
            Gasto(
                seqGasto++, "Bocaditos reunión de agosto", 6000,
                ahora - 30 * 24 * 3_600_000L,
                firmaTesorero = true, firmaPresidente = true
            )
        )
        gastos.add(
            Gasto(
                seqGasto++, "Globos y sorpresas", 4500,
                ahora - 2 * 3_600_000L,
                firmaTesorero = true, firmaPresidente = false
            )
        )

        anotar("Datos de prueba cargados")
    }
}
