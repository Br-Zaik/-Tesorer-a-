package com.tesoreria.caja.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Paleta: azul de medianoche con un solo acento de cian de datos.
val Fondo = Color(0xFF070A12)
val Panel = Color(0xFF0F1523)
val PanelAlto = Color(0xFF18203A)
val Borde = Color(0xFF22304D)
val Cian = Color(0xFF2DE2E6)
val Violeta = Color(0xFF7C6BF5)
val Verde = Color(0xFF3DD68C)
val Ambar = Color(0xFFF5A524)
val Rojo = Color(0xFFF0525B)
val Texto = Color(0xFFDCE5F5)
val Tenue = Color(0xFF7E8DAA)

private val esquema = darkColorScheme(
    primary = Cian,
    onPrimary = Color(0xFF04141A),
    background = Fondo,
    onBackground = Texto,
    surface = Panel,
    onSurface = Texto,
    error = Rojo
)

@Composable
fun CajaTheme(contenido: @Composable () -> Unit) {
    MaterialTheme(colorScheme = esquema, content = contenido)
}

/** Cifras de dinero: monoespaciado, como un libro de caja. */
val cifra = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.Medium,
    letterSpacing = 0.sp
)

@Composable
fun Tarjeta(
    modifier: Modifier = Modifier,
    borde: Color = Borde,
    contenido: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(14.dp))
            .border(BorderStroke(1.dp, borde), RoundedCornerShape(14.dp))
            .padding(16.dp),
        content = contenido
    )
}

@Composable
fun Etiqueta(texto: String, color: Color = Tenue) {
    Text(texto, color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium)
}

@Composable
fun Titulo(texto: String) {
    Text(texto, color = Texto, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
fun Boton(
    texto: String,
    modifier: Modifier = Modifier,
    color: Color = Cian,
    relleno: Boolean = true,
    activo: Boolean = true,
    alTocar: () -> Unit
) {
    val fondo = if (relleno && activo) color else Color.Transparent
    val letra = when {
        !activo -> Tenue
        relleno -> Color(0xFF04141A)
        else -> color
    }
    Box(
        modifier = modifier
            .height(46.dp)
            .background(fondo, RoundedCornerShape(10.dp))
            .border(BorderStroke(1.dp, if (activo) color else Borde), RoundedCornerShape(10.dp))
            .clickable(enabled = activo) { alTocar() },
        contentAlignment = Alignment.Center
    ) {
        Text(texto, color = letra, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Campo(
    valor: String,
    alCambiar: (String) -> Unit,
    pista: String,
    modifier: Modifier = Modifier,
    numerico: Boolean = false,
    clave: Boolean = false
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .background(Fondo, RoundedCornerShape(10.dp))
            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(10.dp))
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        if (valor.isEmpty()) Text(pista, color = Tenue, fontSize = 15.sp)
        BasicTextField(
            value = valor,
            onValueChange = alCambiar,
            singleLine = true,
            textStyle = TextStyle(color = Texto, fontSize = 15.sp),
            cursorBrush = SolidColor(Cian),
            visualTransformation =
                if (clave) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(
                keyboardType = if (numerico) KeyboardType.Number else KeyboardType.Text
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun Pastilla(texto: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.14f), RoundedCornerShape(6.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.45f)), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(texto, color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun FilaEntre(contenido: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        content = contenido
    )
}
