package com.tesoreria.caja.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Socio

private enum class Paso { NUMERO, CONFIRMAR, CLAVE, NUEVA_CLAVE }

@Composable
fun PantallaLogin(alEntrar: (Socio) -> Unit) {

    var paso by remember { mutableStateOf(Paso.NUMERO) }
    var numero by remember { mutableStateOf("") }
    var clave by remember { mutableStateOf("") }
    var clave2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var listo by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { listo = true }

    val entrada by animateFloatAsState(
        targetValue = if (listo) 1f else 0f,
        animationSpec = tween(900),
        label = "entrada"
    )

    val socio = numero.toIntOrNull()?.let { Caja.socio(it) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Fondo)
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        AnilloVivo()

        Spacer(Modifier.height(22.dp))

        Text(
            "Caja del grupo",
            color = Texto,
            fontSize = 26.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.alpha(entrada)
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Todo lo que entra y sale, a la vista de todos",
            color = Tenue,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.alpha(entrada)
        )

        Spacer(Modifier.height(34.dp))

        Box(Modifier.alpha(entrada)) {
            Tarjeta {
                when (paso) {

                    Paso.NUMERO -> {
                        Etiqueta("Tu número de lista")
                        Spacer(Modifier.height(8.dp))
                        Campo(numero, { numero = it.filter { c -> c.isDigit() }.take(2); error = "" },
                            "Ejemplo: 12", numerico = true)
                        Spacer(Modifier.height(14.dp))
                        Boton("Continuar", Modifier.fillMaxWidth()) {
                            if (socio == null) error = "Ese número no está en la lista"
                            else paso = Paso.CONFIRMAR
                        }
                    }

                    Paso.CONFIRMAR -> {
                        Etiqueta("Número ${socio?.numero}")
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "¿Eres ${socio?.nombre}?",
                            color = Texto,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(Modifier.height(16.dp))
                        Boton("Sí, soy yo", Modifier.fillMaxWidth()) {
                            paso = if (Caja.necesitaCrearClave(socio!!.numero))
                                Paso.NUEVA_CLAVE else Paso.CLAVE
                        }
                        Spacer(Modifier.height(8.dp))
                        Boton("No, volver", Modifier.fillMaxWidth(), relleno = false, color = Tenue) {
                            numero = ""; paso = Paso.NUMERO
                        }
                    }

                    Paso.CLAVE -> {
                        Etiqueta("Hola, ${socio?.nombre?.substringBefore(" ")}")
                        Spacer(Modifier.height(8.dp))
                        Campo(clave, { clave = it; error = "" }, "Tu contraseña", clave = true)
                        Spacer(Modifier.height(14.dp))
                        Boton("Entrar", Modifier.fillMaxWidth()) {
                            if (Caja.validar(socio!!.numero, clave)) alEntrar(socio!!)
                            else error = "Contraseña incorrecta"
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "¿La olvidaste? Pídele al tesorero que la libere.",
                            color = Tenue,
                            fontSize = 12.sp
                        )
                    }

                    Paso.NUEVA_CLAVE -> {
                        Etiqueta("Primera vez, ${socio?.nombre?.substringBefore(" ")}")
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Crea tu contraseña. Nadie más la verá, ni el tesorero.",
                            color = Tenue, fontSize = 13.sp
                        )
                        Spacer(Modifier.height(12.dp))
                        Campo(clave, { clave = it; error = "" }, "Nueva contraseña", clave = true)
                        Spacer(Modifier.height(8.dp))
                        Campo(clave2, { clave2 = it; error = "" }, "Repítela", clave = true)
                        Spacer(Modifier.height(14.dp))
                        Boton("Crear y entrar", Modifier.fillMaxWidth()) {
                            val n = socio!!.numero
                            when {
                                clave.length < 6 -> error = "Debe tener al menos 6 caracteres"
                                clave != clave2 -> error = "Las dos no coinciden"
                                clave == n.toString() -> error = "No uses tu número de lista"
                                else -> {
                                    Caja.crearClave(n, clave)
                                    alEntrar(socio!!)
                                }
                            }
                        }
                    }
                }

                if (error.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(error, color = Rojo, fontSize = 13.sp)
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            "Demo sin internet · clave 123456 · el 1 es tesorero, el 2 presidente, el 12 aún no tiene clave",
            color = Tenue.copy(alpha = 0.65f),
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.alpha(entrada)
        )
    }
}

/** Dos arcos girando en sentido contrario: la marca de la app. */
@Composable
private fun AnilloVivo() {
    val giro = rememberInfiniteTransition(label = "giro")
    val a by giro.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(5200, easing = LinearEasing), RepeatMode.Restart),
        label = "a"
    )
    val b by giro.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(7400, easing = LinearEasing), RepeatMode.Restart),
        label = "b"
    )
    val pulso by giro.animateFloat(
        initialValue = 0.35f, targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulso"
    )

    Box(Modifier.size(118.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().rotate(a)) {
            drawArc(
                color = Cian, startAngle = 0f, sweepAngle = 110f, useCenter = false,
                style = Stroke(width = 3f),
                topLeft = Offset(6f, 6f),
                size = Size(size.width - 12f, size.height - 12f)
            )
            drawArc(
                color = Cian.copy(alpha = 0.45f), startAngle = 180f, sweepAngle = 70f,
                useCenter = false, style = Stroke(width = 3f),
                topLeft = Offset(6f, 6f),
                size = Size(size.width - 12f, size.height - 12f)
            )
        }
        Canvas(Modifier.fillMaxSize().padding(16.dp).rotate(b)) {
            drawArc(
                color = Violeta, startAngle = 40f, sweepAngle = 140f, useCenter = false,
                style = Stroke(width = 2.5f),
                topLeft = Offset.Zero,
                size = Size(size.width, size.height)
            )
        }
        Box(
            Modifier
                .size(52.dp)
                .alpha(pulso)
                .background(Cian.copy(alpha = 0.10f), androidx.compose.foundation.shape.CircleShape)
        )
        Text("S/", color = Cian, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}
