package com.tesoreria.caja.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.EstadoPago
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.delay

@Composable
fun PantallaInicio(irASubir: () -> Unit) {

    val yo = Caja.sesion.value ?: return
    val cobro = Caja.cobroActivo()
    var detalle by remember { mutableStateOf<Int?>(null) }

    var ahora by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            ahora = System.currentTimeMillis()
            Caja.revisarVencidos()
        }
    }

    Column(Modifier.fillMaxWidth()) {

        // ---- saldo ----
        Tarjeta(borde = Cian.copy(alpha = 0.35f)) {
            Etiqueta("Saldo del grupo")
            Spacer(Modifier.height(4.dp))
            Text(soles(Caja.saldo()), color = Texto, fontSize = 32.sp, style = cifra)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Column {
                    Etiqueta("Ingresos", Verde)
                    Text(soles(Caja.ingresos()), color = Texto, fontSize = 14.sp, style = cifra)
                }
                Column {
                    Etiqueta("Gastos", Rojo)
                    Text(soles(Caja.egresos()), color = Texto, fontSize = 14.sp, style = cifra)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "Este saldo no se escribe a mano: sale de sumar los pagos aprobados y restar los gastos firmados.",
                color = Tenue, fontSize = 11.sp
            )
        }

        Spacer(Modifier.height(12.dp))

        if (cobro == null) {
            Tarjeta {
                Titulo("No hay cobro abierto")
                Spacer(Modifier.height(6.dp))
                Text(
                    if (Caja.esAdmin) "Abre uno desde el panel de tesorería."
                    else "Cuando el tesorero abra uno, aparecerá aquí.",
                    color = Tenue, fontSize = 13.sp
                )
            }
            return@Column
        }

        val faltan = Caja.faltantes(cobro.id)
        val pagaron = Caja.socios.size - faltan.size

        // ---- franja de faltantes ----
        val colorFranja = if (faltan.isEmpty()) Verde else Rojo
        Box(
            Modifier
                .fillMaxWidth()
                .background(colorFranja.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                .border(BorderStroke(1.dp, colorFranja.copy(alpha = 0.4f)), RoundedCornerShape(12.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                if (faltan.isEmpty()) "Todos al día"
                else "Faltan pagar: " + faltan.joinToString(", "),
                color = colorFranja, fontSize = 13.sp, fontWeight = FontWeight.Medium
            )
        }

        Spacer(Modifier.height(12.dp))

        // ---- cobro activo ----
        Tarjeta {
            FilaEntre {
                Text(cobro.titulo, color = Texto, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(soles(cobro.monto), color = Cian, fontSize = 16.sp, style = cifra)
            }
            Spacer(Modifier.height(6.dp))
            val restante = cobro.cierra - ahora
            Text(
                if (restante > 0) "Cierra en ${cuenta(restante)}" else "Plazo vencido",
                color = if (restante > 0) Ambar else Rojo, fontSize = 13.sp
            )

            Spacer(Modifier.height(14.dp))
            Cuadro(cobro.id) { detalle = it }
            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Leyenda(Verde, "Aprobado")
                Leyenda(Ambar, "Por revisar")
                Leyenda(Rojo, "No envió")
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "$pagaron de ${Caja.socios.size}  ·  ${soles(Caja.recaudado(cobro.id))} recaudado",
                color = Texto, fontSize = 13.sp, style = cifra
            )

            val mio = Caja.estadoDe(cobro.id, yo.numero)
            if (mio == EstadoPago.SIN_ENVIAR || mio == EstadoPago.RECHAZADO) {
                Spacer(Modifier.height(14.dp))
                Boton("Subir mi comprobante", Modifier.fillMaxWidth()) { irASubir() }
            }
        }
    }

    detalle?.let { n ->
        Dialog(onDismissRequest = { detalle = null }) {
            Tarjeta {
                val s = Caja.socio(n)
                Etiqueta("Número $n")
                Spacer(Modifier.height(4.dp))
                Text(s?.nombre ?: "", color = Texto, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(12.dp))
                val p = cobro?.let { Caja.pagoDe(it.id, n) }
                if (p == null) {
                    Text("Todavía no envía su comprobante.", color = Tenue, fontSize = 13.sp)
                } else {
                    Text("Monto: ${soles(p.monto)}", color = Texto, fontSize = 14.sp, style = cifra)
                    Spacer(Modifier.height(4.dp))
                    Text("Operación ${p.operacion}", color = Tenue, fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Enviado ${fechaHora(p.enviado)}", color = Tenue, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Pastilla(
                        when (p.estado) {
                            EstadoPago.APROBADO -> "Aprobado"
                            EstadoPago.PENDIENTE -> "Por revisar"
                            EstadoPago.RECHAZADO -> "Rechazado"
                            else -> "Sin enviar"
                        },
                        colorDe(p.estado)
                    )
                }
                Spacer(Modifier.height(16.dp))
                Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false) { detalle = null }
            }
        }
    }
}

@Composable
fun Cuadro(cobroId: Int, alTocar: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Caja.socios.chunked(6).forEach { fila ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                fila.forEach { s ->
                    val estado = Caja.estadoDe(cobroId, s.numero)
                    val c = colorDe(estado)
                    Box(
                        Modifier
                            .weight(1f)
                            .height(46.dp)
                            .background(c.copy(alpha = 0.13f), RoundedCornerShape(9.dp))
                            .border(BorderStroke(1.dp, c.copy(alpha = 0.45f)), RoundedCornerShape(9.dp))
                            .clickable { alTocar(s.numero) },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${s.numero}", color = c, fontSize = 12.sp, style = cifra)
                            Text(marcaDe(estado), color = c, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                repeat(6 - fila.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun Leyenda(color: Color, texto: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).background(color, RoundedCornerShape(3.dp)))
        Spacer(Modifier.width(6.dp))
        Text(texto, color = Tenue, fontSize = 11.sp)
    }
}

fun colorDe(estado: EstadoPago): Color = when (estado) {
    EstadoPago.APROBADO -> Verde
    EstadoPago.PENDIENTE -> Ambar
    EstadoPago.RECHAZADO -> Rojo
    EstadoPago.SIN_ENVIAR -> Rojo
}

fun marcaDe(estado: EstadoPago): String = when (estado) {
    EstadoPago.APROBADO -> "✓"
    EstadoPago.PENDIENTE -> "•"
    else -> "✕"
}

fun cuenta(ms: Long): String {
    val s = ms / 1000
    val d = s / 86400
    val h = (s % 86400) / 3600
    val m = (s % 3600) / 60
    val seg = s % 60
    return if (d > 0) "$d d $h h $m min" else "$h h $m min $seg s"
}
