package com.tesoreria.caja.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.delay

private enum class PasoSubida { VACIO, LEYENDO, REVISAR, ENVIADO }

@Composable
fun PantallaSubir(alVolver: () -> Unit) {

    val yo = Caja.sesion.value ?: return
    val cobro = Caja.cobroActivo()

    var paso by remember { mutableStateOf(PasoSubida.VACIO) }
    var monto by remember { mutableStateOf("") }
    var operacion by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }

    if (cobro == null) {
        Tarjeta {
            Titulo("No hay cobro abierto")
            Spacer(Modifier.height(12.dp))
            Boton("Volver", Modifier.fillMaxWidth(), relleno = false) { alVolver() }
        }
        return
    }

    LaunchedEffect(paso) {
        if (paso == PasoSubida.LEYENDO) {
            delay(1700)
            // Aca ira ML Kit. Por ahora simulamos lo que leeria de la captura.
            monto = String.format(java.util.Locale.US, "%.2f", cobro.monto / 100.0)
            operacion = "0091" + (300 + yo.numero)
            paso = PasoSubida.REVISAR
        }
    }

    Column(Modifier.fillMaxWidth()) {

        Tarjeta {
            Etiqueta("Cobro")
            Spacer(Modifier.height(4.dp))
            FilaEntre {
                Text(cobro.titulo, color = Texto, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(soles(cobro.monto), color = Cian, fontSize = 16.sp, style = cifra)
            }
        }

        Spacer(Modifier.height(12.dp))

        when (paso) {

            PasoSubida.VACIO -> Tarjeta {
                Titulo("Sube tu captura del Yape")
                Spacer(Modifier.height(6.dp))
                Text(
                    "Yapea ${soles(cobro.monto)} y sube la constancia. La app lee el monto sola; tú solo confirmas.",
                    color = Tenue, fontSize = 13.sp
                )
                Spacer(Modifier.height(16.dp))
                MarcoVacio()
                Spacer(Modifier.height(16.dp))
                Boton("Elegir captura", Modifier.fillMaxWidth()) { paso = PasoSubida.LEYENDO }
                Spacer(Modifier.height(8.dp))
                Boton("Volver", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { alVolver() }
            }

            PasoSubida.LEYENDO -> Tarjeta {
                Titulo("Leyendo la captura")
                Spacer(Modifier.height(16.dp))
                ConstanciaFalsa(escaneando = true, monto = cobro.monto)
                Spacer(Modifier.height(16.dp))
                Text("Buscando monto, fecha y número de operación…", color = Tenue, fontSize = 13.sp)
            }

            PasoSubida.REVISAR -> Tarjeta {
                Titulo("Revisa lo que leímos")
                Spacer(Modifier.height(14.dp))
                ConstanciaFalsa(escaneando = false, monto = cobro.monto)
                Spacer(Modifier.height(16.dp))

                Etiqueta("Monto detectado")
                Spacer(Modifier.height(6.dp))
                Campo(monto, { monto = it; aviso = "" }, "0.00", numerico = true)
                Spacer(Modifier.height(10.dp))
                Etiqueta("Número de operación")
                Spacer(Modifier.height(6.dp))
                Campo(operacion, { operacion = it; aviso = "" }, "00000000", numerico = true)

                Spacer(Modifier.height(14.dp))
                val centavos = (monto.replace(",", ".").toDoubleOrNull() ?: 0.0).times(100).toLong()
                if (centavos != cobro.monto && centavos > 0) {
                    Pastilla("No coincide con ${soles(cobro.monto)}", Ambar)
                    Spacer(Modifier.height(10.dp))
                }

                Boton("Enviar comprobante", Modifier.fillMaxWidth()) {
                    when {
                        centavos <= 0 -> aviso = "Escribe el monto"
                        operacion.length < 4 -> aviso = "Falta el número de operación"
                        Caja.operacionRepetida(operacion, -1) ->
                            aviso = "Esa operación ya fue registrada por otro socio"
                        else -> {
                            Caja.registrarPago(cobro.id, yo.numero, centavos, operacion, centavos)
                            paso = PasoSubida.ENVIADO
                        }
                    }
                }
                if (aviso.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(aviso, color = Rojo, fontSize = 13.sp)
                }
            }

            PasoSubida.ENVIADO -> Tarjeta(borde = Ambar.copy(alpha = 0.45f)) {
                Box(
                    Modifier
                        .size(46.dp)
                        .background(Ambar.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("•", color = Ambar, fontSize = 28.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(12.dp))
                Titulo("Enviado, falta la aprobación")
                Spacer(Modifier.height(6.dp))
                Text(
                    "Tu número ya aparece en ámbar en el cuadro. Cuando el tesorero confirme que el dinero llegó, se pondrá en verde.",
                    color = Tenue, fontSize = 13.sp
                )
                Spacer(Modifier.height(16.dp))
                Boton("Volver al inicio", Modifier.fillMaxWidth()) { alVolver() }
            }
        }
    }
}

@Composable
private fun MarcoVacio() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(160.dp)
            .background(Fondo, RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text("Sin captura todavía", color = Tenue, fontSize = 13.sp)
    }
}

/** Simula la constancia de Yape. Cuando conectemos la camara, aqui va la imagen real. */
@Composable
private fun ConstanciaFalsa(escaneando: Boolean, monto: Long) {
    val t = rememberInfiniteTransition(label = "scan")
    val brillo by t.animateFloat(
        initialValue = 0.25f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse),
        label = "brillo"
    )
    Column(
        Modifier
            .fillMaxWidth()
            .background(Violeta.copy(alpha = 0.10f), RoundedCornerShape(12.dp))
            .border(
                BorderStroke(1.dp, if (escaneando) Cian.copy(alpha = brillo) else Violeta.copy(alpha = 0.4f)),
                RoundedCornerShape(12.dp)
            )
            .padding(16.dp)
    ) {
        Text("Constancia de pago", color = Violeta, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        Text(
            soles(monto),
            color = Texto,
            fontSize = 26.sp,
            style = cifra,
            modifier = Modifier.alpha(if (escaneando) brillo else 1f)
        )
        Spacer(Modifier.height(10.dp))
        LineaFalsa(0.75f)
        Spacer(Modifier.height(6.dp))
        LineaFalsa(0.5f)
        Spacer(Modifier.height(6.dp))
        LineaFalsa(0.62f)
    }
}

@Composable
private fun LineaFalsa(ancho: Float) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        Box(
            Modifier
                .fillMaxWidth(ancho)
                .height(8.dp)
                .background(Tenue.copy(alpha = 0.22f), RoundedCornerShape(4.dp))
        )
        Spacer(Modifier.width(1.dp))
    }
}
