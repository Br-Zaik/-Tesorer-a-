package com.tesoreria.caja.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.soles

@Composable
fun PantallaPanel() {

    val yo = Caja.sesion.value ?: return
    var seccion by remember { mutableStateOf(0) }

    Column(Modifier.fillMaxWidth()) {

        if (yo.rol == Rol.PRESIDENTE) {
            Titulo("Firmas del presidente")
            Spacer(Modifier.height(4.dp))
            Text(
                "Tu firma es la segunda llave. Sin ella, ningún gasto baja el saldo.",
                color = Tenue, fontSize = 12.sp
            )
            Spacer(Modifier.height(12.dp))
            Firmas(comoPresidente = true)
            return@Column
        }

        Row(
            Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(12.dp))
                .border(BorderStroke(1.dp, Borde), RoundedCornerShape(12.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Pestana("Pagos", seccion == 0, Cian, Modifier.weight(1f)) { seccion = 0 }
            Pestana("Cobro", seccion == 1, Cian, Modifier.weight(1f)) { seccion = 1 }
            Pestana("Gastos", seccion == 2, Cian, Modifier.weight(1f)) { seccion = 2 }
            Pestana("Socios", seccion == 3, Cian, Modifier.weight(1f)) { seccion = 3 }
        }

        Spacer(Modifier.height(12.dp))

        when (seccion) {
            0 -> Pendientes()
            1 -> CrearCobro()
            2 -> Gastos()
            else -> Socios()
        }
    }
}

@Composable
private fun Pendientes() {
    val lista = Caja.pendientes()
    Titulo("Por revisar")
    Spacer(Modifier.height(4.dp))
    Text(
        "Aprueba solo cuando veas el dinero en tu Yape. La captura es respaldo, no prueba.",
        color = Tenue, fontSize = 12.sp
    )
    Spacer(Modifier.height(12.dp))

    if (lista.isEmpty()) Vacio("Nada pendiente. Todo al día.")

    lista.forEach { p ->
        val cobro = Caja.cobros.firstOrNull { it.id == p.cobroId }
        val fueraDePlazo = cobro != null && p.enviado > cobro.cierra
        val montoDistinto = cobro != null && p.monto != cobro.monto
        val repetida = Caja.operacionRepetida(p.operacion, p.id)

        Tarjeta(
            borde = if (fueraDePlazo || montoDistinto || repetida) Ambar.copy(alpha = 0.6f) else Borde
        ) {
            FilaEntre {
                Column {
                    Text(
                        "N° ${p.socio}  ${Caja.socio(p.socio)?.nombre ?: ""}",
                        color = Texto, fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(3.dp))
                    Text("Operación ${p.operacion}", color = Tenue, fontSize = 11.sp)
                }
                Text(soles(p.monto), color = Cian, fontSize = 16.sp, style = cifra)
            }
            Spacer(Modifier.height(6.dp))
            Text("Enviado ${fechaHora(p.enviado)}", color = Tenue, fontSize = 11.sp)

            Spacer(Modifier.height(10.dp))
            MarcoCaptura()

            if (fueraDePlazo || montoDistinto || repetida) {
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (montoDistinto) Pastilla("El monto no coincide con la cuota", Ambar)
                    if (fueraDePlazo) Pastilla("Llegó fuera del plazo", Ambar)
                    if (repetida) Pastilla("Operación repetida", Rojo)
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Boton("Aprobar", Modifier.weight(1f), color = Verde) { Caja.aprobarPago(p.id) }
                Boton("Rechazar", Modifier.weight(1f), color = Rojo, relleno = false) {
                    Caja.rechazarPago(p.id, "El pago no figura en la cuenta")
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun MarcoCaptura() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(96.dp)
            .background(Violeta.copy(alpha = 0.08f), RoundedCornerShape(10.dp))
            .border(BorderStroke(1.dp, Violeta.copy(alpha = 0.3f)), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text("Captura guardada  ·  tocar para ampliar", color = Tenue, fontSize = 12.sp)
    }
}

@Composable
private fun CrearCobro() {
    var titulo by remember { mutableStateOf("") }
    var monto by remember { mutableStateOf("") }
    var horas by remember { mutableStateOf("9") }
    var aviso by remember { mutableStateOf("") }

    val activo = Caja.cobroActivo()

    if (activo != null) {
        Tarjeta(borde = Ambar.copy(alpha = 0.5f)) {
            Etiqueta("Cobro abierto", Ambar)
            Spacer(Modifier.height(6.dp))
            Text(activo.titulo, color = Texto, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "${soles(activo.monto)}  ·  cierra ${fechaHora(activo.cierra)}",
                color = Tenue, fontSize = 12.sp
            )
            Spacer(Modifier.height(14.dp))
            Boton("Cerrar ahora y guardar el acta", Modifier.fillMaxWidth(), color = Ambar) {
                Caja.cerrarCobro(activo.id)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "Solo puede haber un cobro abierto a la vez. Ciérralo para abrir otro.",
            color = Tenue, fontSize = 12.sp
        )
        return
    }

    Tarjeta {
        Titulo("Abrir un cobro")
        Spacer(Modifier.height(14.dp))
        Etiqueta("Para qué es")
        Spacer(Modifier.height(6.dp))
        Campo(titulo, { titulo = it; aviso = "" }, "Día del Niño")
        Spacer(Modifier.height(12.dp))
        Etiqueta("Cuánto pone cada uno")
        Spacer(Modifier.height(6.dp))
        Campo(monto, { monto = it; aviso = "" }, "4.00", numerico = true)
        Spacer(Modifier.height(12.dp))
        Etiqueta("Plazo en horas")
        Spacer(Modifier.height(6.dp))
        Campo(horas, { horas = it.filter { c -> c.isDigit() }.take(3); aviso = "" }, "9", numerico = true)
        Spacer(Modifier.height(16.dp))
        Boton("Abrir cobro", Modifier.fillMaxWidth()) {
            val c = (monto.replace(",", ".").toDoubleOrNull() ?: 0.0).times(100).toLong()
            val h = horas.toIntOrNull() ?: 0
            when {
                titulo.isBlank() -> aviso = "Ponle un nombre"
                c <= 0 -> aviso = "Escribe el monto"
                h <= 0 -> aviso = "Escribe el plazo"
                else -> {
                    Caja.crearCobro(titulo.trim(), c, h)
                    titulo = ""; monto = ""; horas = "9"
                }
            }
        }
        if (aviso.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text(aviso, color = Rojo, fontSize = 13.sp)
        }
    }
}

@Composable
private fun Gastos() {
    var concepto by remember { mutableStateOf("") }
    var monto by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }

    Tarjeta {
        Titulo("Registrar un gasto")
        Spacer(Modifier.height(6.dp))
        Text(
            "Queda con tu firma. Baja el saldo recién cuando el presidente firme también.",
            color = Tenue, fontSize = 12.sp
        )
        Spacer(Modifier.height(14.dp))
        Campo(concepto, { concepto = it; aviso = "" }, "Bocaditos")
        Spacer(Modifier.height(10.dp))
        Campo(monto, { monto = it; aviso = "" }, "20.00", numerico = true)
        Spacer(Modifier.height(14.dp))
        Boton("Registrar gasto", Modifier.fillMaxWidth()) {
            val c = (monto.replace(",", ".").toDoubleOrNull() ?: 0.0).times(100).toLong()
            when {
                concepto.isBlank() -> aviso = "Escribe para qué fue"
                c <= 0 -> aviso = "Escribe el monto"
                c > Caja.saldo() -> aviso = "No alcanza: el saldo es ${soles(Caja.saldo())}"
                else -> { Caja.crearGasto(concepto.trim(), c); concepto = ""; monto = "" }
            }
        }
        if (aviso.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text(aviso, color = Rojo, fontSize = 13.sp)
        }
    }
    Spacer(Modifier.height(14.dp))
    Firmas(comoPresidente = false)
}

@Composable
private fun Firmas(comoPresidente: Boolean) {
    val pendientes = Caja.gastosPorFirmar()
    Etiqueta("Gastos esperando firma")
    Spacer(Modifier.height(10.dp))
    if (pendientes.isEmpty()) Vacio("No hay gastos pendientes de firma.")
    pendientes.forEach { g ->
        Tarjeta(borde = Ambar.copy(alpha = 0.5f)) {
            FilaEntre {
                Text(g.concepto, color = Texto, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text(soles(g.monto), color = Rojo, fontSize = 15.sp, style = cifra)
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pastilla(if (g.firmaTesorero) "Tesorero ✓" else "Tesorero pendiente",
                    if (g.firmaTesorero) Verde else Tenue)
                Pastilla(if (g.firmaPresidente) "Presidente ✓" else "Presidente pendiente",
                    if (g.firmaPresidente) Verde else Tenue)
            }
            val faltaLaMia = if (comoPresidente) !g.firmaPresidente else !g.firmaTesorero
            if (faltaLaMia) {
                Spacer(Modifier.height(14.dp))
                Boton("Firmar", Modifier.fillMaxWidth(), color = Verde) {
                    Caja.firmarGasto(g.id, comoPresidente)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun Socios() {
    Titulo("Socios")
    Spacer(Modifier.height(4.dp))
    Text(
        "Si alguien olvida su contraseña, libérala. Tiene 24 horas para crear una nueva.",
        color = Tenue, fontSize = 12.sp
    )
    Spacer(Modifier.height(12.dp))

    Caja.socios.forEach { s ->
        val abierto = Caja.reseteoAbierto(s.numero)
        Tarjeta(borde = if (abierto) Ambar.copy(alpha = 0.55f) else Borde) {
            FilaEntre {
                Column(Modifier.weight(1f)) {
                    Text("${s.numero}  ${s.nombre}", color = Texto, fontSize = 14.sp)
                    Spacer(Modifier.height(3.dp))
                    Text(
                        when {
                            abierto -> "Puede crear su clave (le quedan ${Caja.horasDeReseteo(s.numero)} h)"
                            !Caja.tieneClave(s.numero) -> "Aún no ha entrado nunca"
                            s.rol == Rol.TESORERO -> "Tesorero"
                            s.rol == Rol.PRESIDENTE -> "Presidente"
                            else -> "Activo"
                        },
                        color = if (abierto) Ambar else Tenue, fontSize = 11.sp
                    )
                }
                if (!abierto && Caja.tieneClave(s.numero)) {
                    Boton("Liberar", Modifier.width(96.dp), relleno = false, color = Ambar) {
                        Caja.resetear(s.numero)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
