package com.tesoreria.caja.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.EstadoPago
import com.tesoreria.caja.data.fechaCorta
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.soles

@Composable
fun PantallaMovimientos() {

    var verGastos by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth()) {

        Row(
            Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(12.dp))
                .border(BorderStroke(1.dp, Borde), RoundedCornerShape(12.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Pestana("Ingresos", !verGastos, Verde, Modifier.weight(1f)) { verGastos = false }
            Pestana("Gastos", verGastos, Rojo, Modifier.weight(1f)) { verGastos = true }
        }

        Spacer(Modifier.height(12.dp))

        if (!verGastos) {
            val lista = Caja.pagos
                .filter { it.estado == EstadoPago.APROBADO }
                .sortedByDescending { it.enviado }
            Tarjeta {
                FilaEntre {
                    Etiqueta("Total ingresado", Verde)
                    Text(soles(Caja.ingresos()), color = Texto, fontSize = 16.sp, style = cifra)
                }
            }
            Spacer(Modifier.height(10.dp))
            if (lista.isEmpty()) Vacio("Todavía no hay ingresos aprobados.")
            lista.forEach { p ->
                Renglon(
                    titulo = Caja.socio(p.socio)?.nombre ?: "Socio ${p.socio}",
                    detalle = "N° ${p.socio}  ·  op. ${p.operacion}  ·  ${fechaCorta(p.enviado)}",
                    monto = "+ " + soles(p.monto),
                    color = Verde
                )
            }
        } else {
            Tarjeta {
                FilaEntre {
                    Etiqueta("Total gastado", Rojo)
                    Text(soles(Caja.egresos()), color = Texto, fontSize = 16.sp, style = cifra)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Un gasto solo baja el saldo cuando tiene las dos firmas: tesorero y presidente.",
                    color = Tenue, fontSize = 11.sp
                )
            }
            Spacer(Modifier.height(10.dp))
            if (Caja.gastos.isEmpty()) Vacio("Todavía no hay gastos registrados.")
            Caja.gastos.sortedByDescending { it.fecha }.forEach { g ->
                Renglon(
                    titulo = g.concepto,
                    detalle = fechaCorta(g.fecha) +
                        if (g.aprobado) "  ·  2 firmas" else "  ·  falta 1 firma",
                    monto = "− " + soles(g.monto),
                    color = if (g.aprobado) Rojo else Ambar
                )
            }
        }
    }
}

@Composable
fun PantallaArchivo() {
    Column(Modifier.fillMaxWidth()) {
        Titulo("Cobros cerrados")
        Spacer(Modifier.height(4.dp))
        Text(
            "Cada acta se guarda sola al vencer el plazo. Nadie puede editarla después.",
            color = Tenue, fontSize = 12.sp
        )
        Spacer(Modifier.height(12.dp))

        if (Caja.actas.isEmpty()) Vacio("Aún no se cierra ningún cobro.")

        Caja.actas.sortedByDescending { it.cierre }.forEach { a ->
            Tarjeta {
                FilaEntre {
                    Text(a.titulo, color = Texto, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(soles(a.recaudado), color = Verde, fontSize = 15.sp, style = cifra)
                }
                Spacer(Modifier.height(4.dp))
                Text("Cerrado el ${fechaHora(a.cierre)}", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Text(
                    "${a.pagaron.size} de ${a.pagaron.size + a.faltaron.size} pagaron  ·  cuota ${soles(a.monto)}",
                    color = Texto, fontSize = 13.sp, style = cifra
                )
                if (a.faltaron.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "No pagaron: " + a.faltaron.joinToString(", "),
                        color = Rojo, fontSize = 12.sp
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        Spacer(Modifier.height(8.dp))
        Titulo("Bitácora")
        Spacer(Modifier.height(4.dp))
        Text("Todo lo que pasó, con hora. Nada se borra.", color = Tenue, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Tarjeta {
            Caja.bitacora.take(25).forEach {
                Text(it, color = Tenue, fontSize = 11.sp, style = cifra)
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}

@Composable
fun Pestana(
    texto: String,
    activa: Boolean,
    color: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
    alTocar: () -> Unit
) {
    Box(
        modifier
            .height(38.dp)
            .background(
                if (activa) color.copy(alpha = 0.15f) else androidx.compose.ui.graphics.Color.Transparent,
                RoundedCornerShape(9.dp)
            )
            .clickable { alTocar() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            texto,
            color = if (activa) color else Tenue,
            fontSize = 14.sp,
            fontWeight = if (activa) FontWeight.Medium else FontWeight.Normal
        )
    }
}

@Composable
fun Renglon(titulo: String, detalle: String, monto: String, color: androidx.compose.ui.graphics.Color) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(11.dp))
            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(11.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(titulo, color = Texto, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(3.dp))
            Text(detalle, color = Tenue, fontSize = 11.sp)
        }
        Text(monto, color = color, fontSize = 14.sp, style = cifra)
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
fun Vacio(texto: String) {
    Tarjeta { Text(texto, color = Tenue, fontSize = 13.sp) }
    Spacer(Modifier.height(10.dp))
}
