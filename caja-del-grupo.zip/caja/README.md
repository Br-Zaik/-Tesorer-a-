# Caja del grupo — maqueta

App Android para llevar los cobros de un grupo de 35 socios. Esta versión es **solo la
interfaz**: no se conecta a internet ni a ningún servidor. Los datos viven en la memoria
del teléfono y se reinician al cerrar la app. Sirve para ver cómo va a quedar y decidir
qué cambiar antes de conectar Supabase.

## Cómo compilar el APK sin PC

1. Crea un repositorio **público** en GitHub (público para que los minutos de compilación
   sean gratis) y sube todo el contenido de esta carpeta.
2. Entra a la pestaña **Actions** del repositorio. Si te pregunta, dale a habilitar los
   workflows.
3. La compilación arranca sola con cada subida. También puedes lanzarla a mano:
   Actions → "Compilar APK" → "Run workflow".
4. Cuando termine (unos 3–5 minutos la primera vez), abre la ejecución y baja el archivo
   de la sección **Artifacts**: `caja-del-grupo-apk`.
5. Descomprímelo, instala el APK en tu celular. Hay que permitir "instalar apps de
   fuentes desconocidas".

El APK es de tipo *debug*, así que ya viene firmado con la llave de pruebas de Android y
se instala sin problema. Cuando la app esté lista para repartirla al grupo generamos una
llave propia y firmamos una versión *release*.

## Cómo entrar en la maqueta

- Contraseña de todos: `123456`
- Número **1** → tesorero (ve el panel completo)
- Número **2** → presidente (solo firma gastos)
- Número **12** o **27** → todavía no tienen clave, para ver el primer ingreso
- Cualquier otro número del 1 al 35 → socio normal

## Qué se puede probar

- Entrar con número de lista, confirmar el nombre y crear contraseña.
- Ver el saldo del grupo: sale de sumar ingresos aprobados y restar gastos firmados.
  No es un número escrito a mano.
- La franja roja de arriba con los números que faltan pagar.
- El cuadro de los 35 con verde (aprobado), ámbar (envió, falta revisar) y rojo (no envió).
  Tocar un número muestra su detalle.
- Subir un comprobante: la app simula la lectura de la captura y muestra el monto
  detectado para confirmarlo.
- Panel del tesorero: aprobar o rechazar pagos con los avisos de monto distinto,
  fuera de plazo y operación repetida; abrir y cerrar cobros; registrar gastos;
  liberar contraseñas por 24 horas.
- Panel del presidente: firmar los gastos. Sin su firma el gasto no baja el saldo.
- Historiales separados de ingresos y gastos, archivo de cobros cerrados y bitácora.

## Qué falta (la siguiente etapa)

- Conectar Supabase: base de datos, login real y guardado de las capturas.
- Cámara y galería reales, con compresión antes de subir.
- OCR de verdad con Google ML Kit leyendo el monto de la constancia.
- Cierre automático del plazo con una tarea programada en el servidor.
- Generar el acta en PDF al cerrar cada cobro.
- Hash de la imagen para detectar capturas repetidas.

Todo eso toca solo el archivo `data/Caja.kt`. Las pantallas quedan igual.

## Estructura

```
app/src/main/java/com/tesoreria/caja/
  MainActivity.kt        navegación y barras
  data/Caja.kt           modelo de datos, saldo y datos de prueba
  ui/Estilo.kt           colores, tipografía y piezas reutilizables
  ui/Login.kt            inicio de sesión con la animación
  ui/Inicio.kt           saldo, franja de faltantes y cuadro de los 35
  ui/Subir.kt            subir comprobante con OCR simulado
  ui/Movimientos.kt      historiales y archivo de actas
  ui/Panel.kt            panel de tesorería y firmas del presidente
```
