# Tesorería — maqueta premium offline v0.4.1

Maqueta Android nativa (Kotlin + Jetpack Compose) para probar el diseño y los flujos sin servidor.

## Diseño v0.4.1
- Identidad visual verde oscuro + verde neón inspirada en Gana Geo.
- Splash animado y acceso visual premium.
- Selector Usuario / Administrador.
- Confirmación de identidad y creación/entrada de contraseña.
- Botones con respuesta animada al toque.
- Inicio con saludo, saldo, cobro activo y estados de pago.
- Navegación inferior con iconos contables/funcionales, sin iconos de personas.
- Tarjetas, bordes, estados y controles rediseñados para verse como una app terminada.
- Nombre visual: **Tesorería**. No usa “Caja del grupo” en la interfaz.

## Datos de la demo
- 30 personas cargadas.
- Puestos 31–35 libres.
- N.º 22: Brian Pacco Huayhua — Tesorero.
- Contraseña inicial de demo: `123456` para cuentas ya creadas.
- N.º 12 y 27 conservan el flujo de primera entrada para probar creación de contraseña.

## Estado técnico
Esta versión es deliberadamente offline. Los datos viven en memoria y se reinician al cerrar la app. Supabase, OCR real, cámara/galería real y sincronización se conectarán después de aprobar el diseño y los flujos.

## GitHub Actions
Incluye dos workflows:
- `.github/workflows/apk.yml`: compila cuando el código fuente está en el repo.
- `.github/workflows/auto-build-zip.yml`: detecta un ZIP con cualquier nombre, busca automáticamente `settings.gradle(.kts)` dentro y compila el APK.
