# Tesorería v2.2.0

VersionCode: 52 · VersionName: 2.2.0

Pagos por partes (adelantos):
- Al abrir un cobro oficial: interruptor "Pagar en partes". Cada persona puede pagar hasta en 4 partes, sin mínimo, hasta completar el total.
- Registrar pago (tesorero y admins con permiso): en cobros por partes se elige la persona, se ve cuánto lleva, sus partes con foto (se pueden quitar) y se escribe el monto de la nueva parte con su captura.
- Lista de Inicio: azul y se llena según lo pagado; verde al completar. Al tocar se abre la galería con todas sus capturas y se desliza al costado (puntos arriba, monto/fecha/falta abajo). Todos lo ven.
- Arriba en Inicio: "Te falta S/ X · quedan N días" con barra, más el número Yape para copiar. Tarjeta "Tú" con las 4 partes y "Ver mis pagos".
- Movimientos: cada parte aparece con su foto, nombre y "Parte i de n".
- Actas: quienes pagaron por partes aparecen con foto, cantidad de partes y lo que les faltó.
- Notificaciones: aviso cuando se registra tu parte y recordatorio diario los últimos 3 días si falta pagar.

Servidor:
- `cobros.permite_partes`, tabla `abonos` (RLS: visible a miembros), política de Storage para sus capturas.
- `crear_cobro_v4`, `registrar_abono` (máx. 4, no supera el total, foto única), `anular_abono`.
- Al completar, se crea el pago aprobado; saldo y actas suman las partes sin contar doble.
- Bloqueo de envíos Yape del usuario en cobros por partes.
