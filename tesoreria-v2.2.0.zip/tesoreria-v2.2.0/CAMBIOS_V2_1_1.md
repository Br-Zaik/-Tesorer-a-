# Tesorería v2.1.1

VersionCode: 51 · VersionName: 2.1.1

- Todos los usuarios ven el acta completa (nombres, medio, monto, hora) y sacan el PDF completo.
- Se quitó el permiso "Exportar actas" (ya no hace falta).
- Servidor: `acta_detalle` visible para todos los miembros.
