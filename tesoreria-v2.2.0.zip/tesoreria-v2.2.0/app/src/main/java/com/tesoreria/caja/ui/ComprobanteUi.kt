package com.tesoreria.caja.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Gasto
import com.tesoreria.caja.data.MedioPago
import com.tesoreria.caja.data.Miniaturas
import com.tesoreria.caja.data.Pago
import com.tesoreria.caja.data.fechaHoraLarga
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Vista previa de una imagen local (antes de subirla). */
@Composable
fun MiniaturaComprobante(
    bitmap: Bitmap?,
    modifier: Modifier = Modifier,
    alTocar: (() -> Unit)? = null
) {
    val imagen = remember(bitmap) { bitmap?.takeIf { !it.isRecycled }?.asImageBitmap() }
    val base = modifier
        .fillMaxWidth()
        .height(184.dp)
        .clip(RoundedCornerShape(18.dp))
        .background(FondoProfundo)
        .border(1.dp, Borde, RoundedCornerShape(18.dp))
    Box(
        if (alTocar != null) base.presionable { alTocar() } else base,
        contentAlignment = Alignment.Center
    ) {
        if (imagen != null) {
            Image(
                bitmap = imagen,
                contentDescription = "Comprobante",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            if (alTocar != null) {
                Row(
                    Modifier.align(Alignment.BottomEnd).padding(10.dp)
                        .background(Color.Black.copy(alpha = .62f), RoundedCornerShape(99.dp))
                        .padding(horizontal = 11.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.ZoomIn, null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Ver", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            Icon(Icons.Rounded.ReceiptLong, null, tint = Tenue, modifier = Modifier.size(42.dp))
        }
    }
}

/** Miniatura de un comprobante guardado en el servidor (con caché). */
@Composable
fun MiniaturaPago(path: String, modifier: Modifier = Modifier, radio: Dp = 10.dp) {
    var bmp by remember(path) { mutableStateOf(Miniaturas.enMemoria(path)) }
    var fallo by remember(path) { mutableStateOf(false) }
    LaunchedEffect(path) {
        if (bmp == null && path.isNotBlank()) {
            bmp = Caja.miniaturaComprobante(path)
            fallo = bmp == null
        }
    }
    val imagen = remember(bmp) { bmp?.asImageBitmap() }
    val aparece by animateFloatAsState(if (imagen != null) 1f else 0f, tween(450, easing = CurvaSuave), label = "miniatura")
    val forma = RoundedCornerShape(radio)
    Box(
        modifier
            .clip(forma)
            .then(if (imagen == null && !fallo) Modifier.brilloCarga(forma) else Modifier.background(PanelAlto, forma)),
        contentAlignment = Alignment.Center
    ) {
        when {
            imagen != null -> Image(
                bitmap = imagen,
                contentDescription = "Captura",
                modifier = Modifier.fillMaxSize().graphicsLayer { alpha = aparece; scaleX = .9f + .1f * aparece; scaleY = .9f + .1f * aparece },
                contentScale = ContentScale.Crop
            )
            fallo -> Icon(Icons.Rounded.Photo, null, tint = Tenue, modifier = Modifier.fillMaxSize(.55f))
        }
    }
}

/**
 * Visor tipo galería: fondo negro, la imagen entra creciendo, zoom con dos dedos,
 * doble toque para acercar, deslizar hacia abajo para cerrar y datos abajo.
 * Mientras llega la versión HD se muestra la miniatura (sin cuadros grises) y
 * luego la HD aparece encima con un fundido suave.
 */
@Composable
private fun Galeria(
    bitmap: Bitmap?,
    cargando: Boolean,
    error: String,
    titulo: String,
    cerrar: () -> Unit,
    previa: Bitmap? = null,
    info: (@Composable ColumnScope.() -> Unit)? = null
) {
    Dialog(
        onDismissRequest = cerrar,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        val scope = rememberCoroutineScope()
        val entrada = remember { Animatable(0f) }
        LaunchedEffect(Unit) { entrada.animateTo(1f, tween(520, easing = CurvaSuave)) }
        var escala by remember { mutableFloatStateOf(1f) }
        var desp by remember { mutableStateOf(Offset.Zero) }
        var arrastre by remember { mutableFloatStateOf(0f) }
        var mostrarInfo by remember { mutableStateOf(true) }
        val imagen = remember(bitmap) { bitmap?.asImageBitmap() }
        val baja = remember(previa) { previa?.asImageBitmap() }
        val hdAlpha by animateFloatAsState(if (imagen != null) 1f else 0f, tween(520, easing = CurvaSuave), label = "hd")
        val fondoAlpha = (1f - abs(arrastre) / 900f).coerceIn(.35f, 1f) * entrada.value
        val hayImagen = imagen != null || baja != null

        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = fondoAlpha))) {
            if (hayImagen) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .pointerInput(hayImagen) {
                            detectTapGestures(
                                onTap = { mostrarInfo = !mostrarInfo },
                                onDoubleTap = { punto ->
                                    scope.launch {
                                        val destino = if (escala > 1.05f) 1f else 2.6f
                                        val inicioE = escala
                                        val inicioD = desp
                                        val centro = Offset(size.width / 2f, size.height / 2f)
                                        val destinoD = if (destino == 1f) Offset.Zero else (centro - punto) * (destino - 1f)
                                        animate(0f, 1f, animationSpec = tween(360, easing = CurvaSuave)) { v, _ ->
                                            escala = inicioE + (destino - inicioE) * v
                                            desp = inicioD + (destinoD - inicioD) * v
                                        }
                                    }
                                }
                            )
                        }
                        .pointerInput(hayImagen) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                do {
                                    val evento = awaitPointerEvent()
                                    val dedos = evento.changes.count { it.pressed }
                                    val zoom = evento.calculateZoom()
                                    val pan = evento.calculatePan()
                                    if (dedos >= 2 || escala > 1.01f) {
                                        escala = (escala * zoom).coerceIn(1f, 5f)
                                        val maxX = size.width * (escala - 1f) / 2f
                                        val maxY = size.height * (escala - 1f) / 2f
                                        desp = Offset(
                                            (desp.x + pan.x).coerceIn(-maxX, maxX),
                                            (desp.y + pan.y).coerceIn(-maxY, maxY)
                                        )
                                        evento.changes.forEach { if (it.positionChanged()) it.consume() }
                                    } else if (dedos == 1) {
                                        arrastre += pan.y
                                        if (abs(arrastre) > 8f) evento.changes.forEach { if (it.positionChanged()) it.consume() }
                                    }
                                } while (evento.changes.any { it.pressed })
                                if (escala <= 1.01f) {
                                    escala = 1f
                                    desp = Offset.Zero
                                    if (abs(arrastre) > 220f) {
                                        cerrar()
                                    } else if (arrastre != 0f) {
                                        val desde = arrastre
                                        scope.launch {
                                            animate(desde, 0f, animationSpec = spring(dampingRatio = .72f, stiffness = 360f)) { v, _ -> arrastre = v }
                                        }
                                    }
                                }
                            }
                        }
                        .graphicsLayer {
                            val e = escala * (.88f + .12f * entrada.value) * (1f - abs(arrastre) / 3200f)
                            scaleX = e
                            scaleY = e
                            translationX = desp.x
                            translationY = desp.y + arrastre + (1f - entrada.value) * 60f
                            alpha = entrada.value
                        }
                ) {
                    if (baja != null) {
                        Image(
                            bitmap = baja,
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize().graphicsLayer { alpha = 1f - hdAlpha * .999f }
                        )
                    }
                    if (imagen != null) {
                        Image(
                            bitmap = imagen,
                            contentDescription = titulo,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize().graphicsLayer { alpha = hdAlpha }
                        )
                    }
                }
                if (imagen == null && cargando) {
                    Row(
                        Modifier.align(Alignment.Center).padding(top = 240.dp)
                            .background(Color.Black.copy(alpha = .55f), RoundedCornerShape(99.dp))
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Cargando HD", color = Color.White, fontSize = 13.sp)
                    }
                }
            } else if (cargando) {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(Modifier.size(30.dp), color = Texto, strokeWidth = 2.5.dp)
                    Spacer(Modifier.height(12.dp))
                    Text("Abriendo comprobante…", color = Color.White.copy(alpha = .7f), fontSize = 14.sp)
                }
            } else {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.BrokenImage, null, tint = Rojo, modifier = Modifier.size(44.dp))
                    Spacer(Modifier.height(10.dp))
                    Text(error.ifBlank { "No hay imagen disponible" }, color = Color.White, fontSize = 15.sp)
                }
            }

            AnimatedVisibility(
                visible = mostrarInfo,
                enter = fadeIn(tween(300)),
                exit = fadeOut(tween(220)),
                modifier = Modifier.align(Alignment.TopCenter)
            ) {
                Row(
                    Modifier.fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .75f), Color.Transparent)))
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(titulo, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                    BotonCerrar(cerrar)
                }
            }

            if (info != null) {
                AnimatedVisibility(
                    visible = mostrarInfo && arrastre == 0f,
                    enter = slideInVertically(tween(420, delayMillis = 120, easing = CurvaSuave)) { it / 2 } + fadeIn(tween(340, delayMillis = 120)),
                    exit = slideOutVertically(tween(240)) { it / 2 } + fadeOut(tween(200)),
                    modifier = Modifier.align(Alignment.BottomCenter)
                ) {
                    Column(
                        Modifier.fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .88f), Color.Black)))
                            .navigationBarsPadding()
                            .padding(start = 20.dp, end = 20.dp, top = 36.dp, bottom = 18.dp)
                    ) { info(this) }
                }
            }
        }
    }
}

/** Imagen del comprobante en HD: muestra primero la miniatura y luego funde a la HD. */
@Composable
fun ImagenHD(path: String, modifier: Modifier = Modifier, radio: Dp = 18.dp, escala: ContentScale = ContentScale.Crop) {
    var hdBmp by remember(path) { mutableStateOf(Miniaturas.hdEnMemoria(path)) }
    var miniBmp by remember(path) { mutableStateOf(Miniaturas.enMemoria(path)) }
    LaunchedEffect(path) {
        if (miniBmp == null && hdBmp == null) miniBmp = Caja.miniaturaComprobante(path)
        if (hdBmp == null) hdBmp = Caja.comprobanteHD(path)
    }
    val hd = remember(hdBmp) { hdBmp?.asImageBitmap() }
    val mini = remember(miniBmp) { miniBmp?.asImageBitmap() }
    val hdAlpha by animateFloatAsState(if (hd != null) 1f else 0f, tween(600, easing = CurvaSuave), label = "hdPreview")
    val forma = RoundedCornerShape(radio)
    Box(
        modifier.clip(forma).then(if (hd == null && mini == null) Modifier.brilloCarga(forma) else Modifier.background(Color.White, forma))
    ) {
        if (mini != null) Image(bitmap = mini, contentDescription = null, contentScale = escala, modifier = Modifier.fillMaxSize())
        if (hd != null) Image(bitmap = hd, contentDescription = "Comprobante", contentScale = escala, modifier = Modifier.fillMaxSize().graphicsLayer { alpha = hdAlpha })
    }
}

@Composable
private fun DatoGaleria(icono: ImageVector, texto: String, color: Color = Color.White.copy(alpha = .82f)) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icono, null, tint = color, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(8.dp))
        Text(texto, color = color, fontSize = 14.sp)
    }
}

@Composable
fun VisorBitmapDialog(bitmap: Bitmap, cerrar: () -> Unit) {
    Galeria(bitmap = bitmap, cargando = false, error = "", titulo = "Imagen", cerrar = cerrar)
}

@Composable
fun VisorPagoDialog(pago: Pago, cerrar: () -> Unit) {
    var bitmap by remember(pago.serverId) { mutableStateOf(Miniaturas.hdEnMemoria(pago.capturaPath)) }
    var error by remember(pago.serverId) { mutableStateOf("") }
    var cargando by remember(pago.serverId) { mutableStateOf(bitmap == null) }
    val previa = remember(pago.serverId) { Miniaturas.enMemoria(pago.capturaPath) }

    LaunchedEffect(pago.serverId) {
        if (bitmap != null) return@LaunchedEffect
        cargando = true
        error = ""
        try {
            bitmap = Caja.comprobanteHD(pago.capturaPath)
                ?: throw IllegalStateException("No se pudo abrir la captura")
        } catch (e: Exception) {
            error = e.message ?: "No se pudo abrir el comprobante"
        } finally {
            cargando = false
        }
    }

    val socio = Caja.socio(pago.socio)
    val numeros = if (pago.grupoNumeros.isNotEmpty()) pago.grupoNumeros.distinct().sorted() else listOf(pago.socio)
    val yape = pago.medio == MedioPago.YAPE
    Galeria(
        bitmap = bitmap,
        cargando = cargando,
        error = error,
        titulo = "Comprobante · N.º ${pago.socio}",
        cerrar = cerrar,
        previa = previa
    ) {
        Text(socio?.nombre ?: "N.º ${pago.socio}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(soles(pago.monto * numeros.size), color = if (yape) MoradoYape else Verde, fontSize = 26.sp, style = cifra)
            Spacer(Modifier.width(12.dp))
            Row(
                Modifier.background((if (yape) MoradoYape else Verde).copy(alpha = .18f), RoundedCornerShape(99.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(if (yape) Icons.Rounded.QrCode2 else Icons.Rounded.Payments, null, tint = if (yape) MoradoYape else Verde, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(5.dp))
                Text(if (yape) "Yape" else "Manual", color = if (yape) MoradoYape else Verde, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(10.dp))
        DatoGaleria(Icons.Rounded.Schedule, fechaHoraLarga(pago.enviado))
        if (numeros.size > 1) {
            Spacer(Modifier.height(6.dp))
            DatoGaleria(Icons.Rounded.Groups, "Incluye N.º " + numeros.joinToString(", ") + " · ${soles(pago.monto)} c/u")
        }
        pago.revisadoPor?.let {
            Spacer(Modifier.height(6.dp))
            DatoGaleria(Icons.Rounded.VerifiedUser, "Revisó N.º $it")
        }
        Spacer(Modifier.height(10.dp))
        Text("Desliza hacia abajo para cerrar", color = Color.White.copy(alpha = .45f), fontSize = 12.sp)
    }
}

@Composable
fun VisorGastoDialog(gasto: Gasto, cerrar: () -> Unit) {
    var bitmap by remember(gasto.serverId) { mutableStateOf<Bitmap?>(null) }
    var error by remember(gasto.serverId) { mutableStateOf("") }
    var cargando by remember(gasto.serverId) { mutableStateOf(true) }

    LaunchedEffect(gasto.serverId) {
        cargando = true
        error = ""
        try {
            val bytes = Caja.comprobanteGastoBytes(gasto)
            bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: throw IllegalStateException("No se pudo abrir la imagen")
        } catch (e: Exception) {
            error = e.message ?: "No se pudo abrir el comprobante"
        } finally {
            cargando = false
        }
    }

    Galeria(
        bitmap = bitmap,
        cargando = cargando,
        error = error,
        titulo = "Comprobante del gasto",
        cerrar = cerrar
    ) {
        Text(gasto.concepto, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("− " + soles(gasto.monto), color = Rojo, fontSize = 26.sp, style = cifra)
        Spacer(Modifier.height(10.dp))
        DatoGaleria(Icons.Rounded.ShoppingBag, "Gasto registrado")
        Spacer(Modifier.height(6.dp))
        DatoGaleria(Icons.Rounded.Schedule, fechaHoraLarga(gasto.fecha))
    }
}

@Composable
private fun BotonCerrar(cerrar: () -> Unit) {
    Box(
        Modifier.size(40.dp).background(Color.White.copy(alpha = .14f), CircleShape)
            .presionable { cerrar() },
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.Close, "Cerrar", tint = Color.White, modifier = Modifier.size(21.dp))
    }
}

/**
 * Galería de un pago por partes: abre en la primera captura y se desliza al costado
 * para ver las demás (hasta 4). Abajo: parte, monto, fecha y cuánto falta.
 */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun GaleriaPartesDialog(cobroId: Int, numero: Int, inicio: Int = 0, cerrar: () -> Unit) {
    val cobro = Caja.cobros.firstOrNull { it.id == cobroId }
    val partes = Caja.abonosDe(cobroId, numero)
    val socio = Caja.socio(numero)
    if (cobro == null || partes.isEmpty()) { LaunchedEffect(Unit) { cerrar() }; return }
    val pagado = partes.sumOf { it.monto }
    val falta = (cobro.monto - pagado).coerceAtLeast(0L)

    Dialog(
        onDismissRequest = cerrar,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        val estadoPager = androidx.compose.foundation.pager.rememberPagerState(
            initialPage = inicio.coerceIn(0, partes.lastIndex),
            pageCount = { partes.size }
        )
        val entrada = remember { Animatable(0f) }
        LaunchedEffect(Unit) { entrada.animateTo(1f, tween(520, easing = CurvaSuave)) }
        var arrastre by remember { mutableFloatStateOf(0f) }
        var mostrarInfo by remember { mutableStateOf(true) }
        val scopeG = rememberCoroutineScope()
        val fondoAlpha = (1f - abs(arrastre) / 900f).coerceIn(.35f, 1f) * entrada.value

        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = fondoAlpha))) {
            androidx.compose.foundation.pager.HorizontalPager(
                state = estadoPager,
                modifier = Modifier.fillMaxSize().graphicsLayer {
                    alpha = entrada.value
                    translationY = arrastre + (1f - entrada.value) * 60f
                    val e = (.9f + .1f * entrada.value) * (1f - abs(arrastre) / 3200f)
                    scaleX = e; scaleY = e
                },
                pageSpacing = 16.dp,
                key = { partes[it].serverId }
            ) { pagina ->
                PaginaZoom(
                    path = partes[pagina].capturaPath,
                    alTocar = { mostrarInfo = !mostrarInfo },
                    alArrastrar = { dy -> arrastre += dy },
                    alSoltar = {
                        if (abs(arrastre) > 220f) {
                            cerrar()
                        } else {
                            val desde = arrastre
                            scopeG.launch { animate(desde, 0f, animationSpec = spring(dampingRatio = .72f, stiffness = 360f)) { v, _ -> arrastre = v } }
                        }
                    }
                )
            }

            AnimatedVisibility(
                visible = mostrarInfo,
                enter = fadeIn(tween(300)),
                exit = fadeOut(tween(220)),
                modifier = Modifier.align(Alignment.TopCenter)
            ) {
                Column(
                    Modifier.fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .75f), Color.Transparent)))
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Pagos · N.º $numero", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        BotonCerrar(cerrar)
                    }
                    if (partes.size > 1) {
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                            partes.indices.forEach { i ->
                                val activo = estadoPager.currentPage == i
                                val ancho by animateFloatAsState(if (activo) 22f else 8f, tween(300, easing = CurvaSuave), label = "punto$i")
                                Box(
                                    Modifier.padding(horizontal = 3.dp).height(8.dp).width(ancho.dp)
                                        .background(if (activo) Color.White else Color.White.copy(alpha = .35f), RoundedCornerShape(99.dp))
                                )
                            }
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = mostrarInfo && arrastre == 0f,
                enter = slideInVertically(tween(420, delayMillis = 120, easing = CurvaSuave)) { it / 2 } + fadeIn(tween(340, delayMillis = 120)),
                exit = slideOutVertically(tween(240)) { it / 2 } + fadeOut(tween(200)),
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                val actual = partes.getOrNull(estadoPager.currentPage) ?: partes.first()
                Column(
                    Modifier.fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .88f), Color.Black)))
                        .navigationBarsPadding()
                        .padding(start = 20.dp, end = 20.dp, top = 36.dp, bottom = 18.dp)
                ) {
                    Text(socio?.nombre ?: "N.º $numero", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(soles(actual.monto), color = Azul, fontSize = 26.sp, style = cifra)
                        Spacer(Modifier.width(10.dp))
                        Text("Parte ${estadoPager.currentPage + 1} de ${partes.size}", color = Color.White.copy(alpha = .8f), fontSize = 14.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    DatoGaleria(Icons.Rounded.Schedule, fechaHoraLarga(actual.fecha))
                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.fillMaxWidth().height(8.dp).background(Color.White.copy(alpha = .15f), RoundedCornerShape(99.dp))) {
                        val f by animateFloatAsState(if (cobro.monto > 0) (pagado.toFloat() / cobro.monto).coerceIn(0f, 1f) else 0f, tween(800, easing = CurvaSuave), label = "avanceGaleria")
                        Box(Modifier.fillMaxWidth(f).fillMaxHeight().background(if (falta == 0L) Verde else Azul, RoundedCornerShape(99.dp)))
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (falta == 0L) "Completó ${soles(cobro.monto)} ✓" else "Pagó ${soles(pagado)} de ${soles(cobro.monto)} · Le falta ${soles(falta)}",
                        color = if (falta == 0L) Verde else Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold
                    )
                    if (partes.size > 1) {
                        Spacer(Modifier.height(6.dp))
                        Text("Desliza al costado para ver las demás", color = Color.White.copy(alpha = .45f), fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

/**
 * Una página de la galería: zoom con dos dedos y doble toque; si deslizas hacia abajo
 * (sin zoom) avisa para cerrar; si deslizas al costado deja que pase a la otra foto.
 */
@Composable
private fun PaginaZoom(path: String, alTocar: () -> Unit, alArrastrar: (Float) -> Unit, alSoltar: () -> Unit) {
    val scope = rememberCoroutineScope()
    var hd by remember(path) { mutableStateOf(Miniaturas.hdEnMemoria(path)) }
    val mini = remember(path) { Miniaturas.enMemoria(path) }
    LaunchedEffect(path) { if (hd == null && path.isNotBlank()) hd = Caja.comprobanteHD(path) }
    val imgHd = remember(hd) { hd?.asImageBitmap() }
    val imgMini = remember(mini) { mini?.asImageBitmap() }
    val hdAlpha by animateFloatAsState(if (imgHd != null) 1f else 0f, tween(520, easing = CurvaSuave), label = "hdPagina")
    var escala by remember { mutableFloatStateOf(1f) }
    var desp by remember { mutableStateOf(Offset.Zero) }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(path) {
                detectTapGestures(
                    onTap = { alTocar() },
                    onDoubleTap = { punto ->
                        scope.launch {
                            val destino = if (escala > 1.05f) 1f else 2.6f
                            val inicioE = escala
                            val inicioD = desp
                            val centro = Offset(size.width / 2f, size.height / 2f)
                            val destinoD = if (destino == 1f) Offset.Zero else (centro - punto) * (destino - 1f)
                            animate(0f, 1f, animationSpec = tween(360, easing = CurvaSuave)) { v, _ ->
                                escala = inicioE + (destino - inicioE) * v
                                desp = inicioD + (destinoD - inicioD) * v
                            }
                        }
                    }
                )
            }
            .pointerInput(path) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    var total = Offset.Zero
                    var modo = 0 // 0 sin decidir, 1 zoom, 2 vertical, 3 horizontal (lo maneja la galería)
                    do {
                        val evento = awaitPointerEvent()
                        val dedos = evento.changes.count { it.pressed }
                        val zoom = evento.calculateZoom()
                        val pan = evento.calculatePan()
                        total += pan
                        if (modo == 0) {
                            modo = when {
                                dedos >= 2 || escala > 1.01f -> 1
                                abs(total.y) > 18f && abs(total.y) > abs(total.x) -> 2
                                abs(total.x) > 18f -> 3
                                else -> 0
                            }
                        }
                        when (modo) {
                            1 -> {
                                escala = (escala * zoom).coerceIn(1f, 5f)
                                val maxX = size.width * (escala - 1f) / 2f
                                val maxY = size.height * (escala - 1f) / 2f
                                desp = Offset((desp.x + pan.x).coerceIn(-maxX, maxX), (desp.y + pan.y).coerceIn(-maxY, maxY))
                                evento.changes.forEach { if (it.positionChanged()) it.consume() }
                            }
                            2 -> {
                                alArrastrar(pan.y)
                                evento.changes.forEach { if (it.positionChanged()) it.consume() }
                            }
                        }
                    } while (evento.changes.any { it.pressed })
                    if (modo == 2) alSoltar()
                    if (escala <= 1.01f) { escala = 1f; desp = Offset.Zero }
                }
            }
            .graphicsLayer {
                scaleX = escala; scaleY = escala
                translationX = desp.x; translationY = desp.y
            },
        contentAlignment = Alignment.Center
    ) {
        when {
            path.isBlank() -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.Payments, null, tint = Color.White.copy(alpha = .7f), modifier = Modifier.size(54.dp))
                Spacer(Modifier.height(10.dp))
                Text("Pago sin foto", color = Color.White.copy(alpha = .8f), fontSize = 15.sp)
            }
            else -> {
                if (imgMini != null) Image(bitmap = imgMini, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().graphicsLayer { alpha = 1f - hdAlpha * .999f })
                if (imgHd != null) Image(bitmap = imgHd, contentDescription = "Comprobante", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().graphicsLayer { alpha = hdAlpha })
                if (imgHd == null && imgMini == null) CircularProgressIndicator(Modifier.size(26.dp), color = Color.White, strokeWidth = 2.dp)
            }
        }
    }
}
