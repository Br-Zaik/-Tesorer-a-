package com.tesoreria.caja.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Inbox
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.List
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.animation.core.tween
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Acta
import com.tesoreria.caja.data.TipoCobro
import com.tesoreria.caja.data.EstadoPago
import com.tesoreria.caja.data.MedioPago
import com.tesoreria.caja.data.Pago
import com.tesoreria.caja.data.PdfExporter
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.fechaLarga
import com.tesoreria.caja.data.horaCorta
import com.tesoreria.caja.data.PE
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.launch

@Composable
fun PantallaMovimientos() {
    var verGastos by remember { mutableStateOf(false) }
    var verComprobante by remember { mutableStateOf<Pago?>(null) }
    var verComprobanteGasto by remember { mutableStateOf<com.tesoreria.caja.data.Gasto?>(null) }
    var verPartes by remember { mutableStateOf<Triple<Int, Int, Int>?>(null) }

    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(2.dp))
        CabeceraSeccion(Icons.Rounded.SwapVert, "Libro de caja", ColorMovimientos)
        Spacer(Modifier.height(12.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(13.dp))
                .border(BorderStroke(1.dp, Borde), RoundedCornerShape(13.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Pestana("Ingresos", !verGastos, Verde, Modifier.weight(1f)) { verGastos = false }
            Pestana("Gastos", verGastos, Rojo, Modifier.weight(1f)) { verGastos = true }
        }

        Spacer(Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 8.dp)
        ) {
            if (!verGastos) {
                val propios = Caja.pagos.filter { it.socio == Caja.sesion.value?.numero && it.medio == MedioPago.YAPE && Caja.cobros.firstOrNull { c -> c.id == it.cobroId }?.tipo != TipoCobro.RAPIDO }
                    .sortedByDescending { it.enviado }
                if (propios.isNotEmpty()) {
                    item {
                        Tarjeta(borde = Azul.copy(alpha = .25f), fondo = PanelAlto) {
                            Etiqueta("MIS COMPROBANTES", Azul)
                            Spacer(Modifier.height(4.dp))
                            Text("Puedes volver a abrir exactamente lo que enviaste.", color = Tenue, fontSize = 12.sp)
                        }
                    }
                    items(propios) { p ->
                        Row(
                            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(13.dp))
                                .border(BorderStroke(1.dp, Borde), RoundedCornerShape(13.dp))
                                .clickable(enabled = p.capturaPath.isNotBlank()) { verComprobante = p }
                                .padding(13.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(soles(p.monto), color = Texto, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(3.dp))
                                Text("${fechaLarga(p.enviado)} · ${horaCorta(p.enviado)}", color = Tenue, fontSize = 12.sp)
                            }
                            Pastilla(
                                when (p.estado) {
                                    EstadoPago.APROBADO -> "Aprobado"
                                    EstadoPago.PENDIENTE -> "Pendiente"
                                    EstadoPago.RECHAZADO -> "Rechazado"
                                    EstadoPago.SIN_ENVIAR -> "No enviado"
                                    EstadoPago.NO_PAGA -> "No participa"
                                },
                                colorDe(p.estado)
                            )
                        }
                    }
                }
                item { ResumenIngresosCard() }
                // Pagos completos normales + cada parte de los cobros por partes (sin contar dos veces).
                val lista = Caja.pagos.filter { it.estado == EstadoPago.APROBADO && !it.deAbonos && Caja.cobros.firstOrNull { c -> c.id == it.cobroId }?.tipo != TipoCobro.RAPIDO }
                val partes = Caja.abonos.filter { a -> Caja.cobros.firstOrNull { it.id == a.cobroId }?.tipo != TipoCobro.RAPIDO }
                val filas: List<Any> = (lista + partes).sortedByDescending { if (it is Pago) it.enviado else (it as com.tesoreria.caja.data.Abono).fecha }
                if (filas.isEmpty()) item { Vacio("Todavía no hay ingresos aprobados.") }
                itemsIndexed(filas, key = { _, f -> if (f is Pago) "p-${f.serverId}" else "a-${(f as com.tesoreria.caja.data.Abono).serverId}" }) { i, f ->
                    if (f is Pago) {
                        FilaIngreso(f, Modifier.cascada(i)) { if (f.capturaPath.isNotBlank()) verComprobante = f }
                    } else if (f is com.tesoreria.caja.data.Abono) {
                        FilaParte(f, Modifier.cascada(i)) { verPartes = Triple(f.cobroId, f.socio, Caja.abonosDe(f.cobroId, f.socio).indexOfFirst { it.serverId == f.serverId }.coerceAtLeast(0)) }
                    }
                }
            } else {
                item { ResumenGastosCard() }
                val gastos = Caja.gastos.sortedByDescending { it.fecha }
                if (gastos.isEmpty()) item { Vacio("Todavía no hay gastos registrados.") }
                itemsIndexed(gastos, key = { _, g -> g.serverId }) { i, g ->
                    val estado = if (g.anulado) "ANULADO" else "REGISTRADO"
                    val color = if (g.anulado) Tenue else Rojo
                    MovimientoCard(
                        modifier = Modifier.cascada(i),
                        titulo = g.concepto,
                        detalle = "${fechaLarga(g.fecha)} · ${horaCorta(g.fecha)}",
                        monto = "− ${soles(g.monto)}",
                        color = color,
                        estado = estado,
                        accionTexto = if (g.comprobantePath.isNotBlank()) "Ver comprobante" else null,
                        alTocar = if (g.comprobantePath.isNotBlank()) ({ verComprobanteGasto = g }) else null
                    )
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
    }
    verComprobante?.let { p -> VisorPagoDialog(p) { verComprobante = null } }
    verComprobanteGasto?.let { g -> VisorGastoDialog(g) { verComprobanteGasto = null } }
    verPartes?.let { (c, n, i) -> GaleriaPartesDialog(c, n, i) { verPartes = null } }
}

@Composable
private fun ResumenIngresosCard() {
    val lista = Caja.pagos.filter { it.estado == EstadoPago.APROBADO && !it.deAbonos && Caja.cobros.firstOrNull { c -> c.id == it.cobroId }?.tipo != TipoCobro.RAPIDO } +
        Caja.abonos.filter { a -> Caja.cobros.firstOrNull { it.id == a.cobroId }?.tipo != TipoCobro.RAPIDO }
    Column(
        Modifier.fillMaxWidth()
            .background(Brush.linearGradient(listOf(Azul.copy(alpha = .22f), Panel)), RoundedCornerShape(22.dp))
            .border(BorderStroke(1.dp, Azul.copy(alpha = .35f)), RoundedCornerShape(22.dp))
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.TrendingUp, null, tint = Azul, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Etiqueta("TOTAL INGRESADO", Azul)
        }
        Spacer(Modifier.height(8.dp))
        DineroAnimado(Caja.ingresos(), Texto, 30.sp)
        Spacer(Modifier.height(4.dp))
        Text("${lista.size} ${if (lista.size == 1) "pago aprobado" else "pagos aprobados"}", color = Tenue, fontSize = 13.sp)
    }
}

@Composable
private fun ResumenGastosCard() {
    Tarjeta(borde = Rojo.copy(alpha = 0.24f)) {
        FilaEntre {
            Column {
                Etiqueta("TOTAL DESCONTADO", Rojo)
                Spacer(Modifier.height(3.dp))
                Text("Gastos registrados", color = Tenue, fontSize = 13.sp)
            }
            Text(soles(Caja.egresos()), color = Rojo, fontSize = 21.sp, style = cifra)
        }
        if (Caja.comprometidoPendiente() > 0) {
            Spacer(Modifier.height(10.dp))
            Pastilla("Pendiente ${soles(Caja.comprometidoPendiente())}", Ambar)
        }
    }
}

@Composable
fun PantallaArchivo() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var seccion by remember { mutableStateOf(0) } // 0 oficial, 1 rápido, 2 bitácora
    var borrarActa by remember { mutableStateOf<Acta?>(null) }
    var actaExpandida by remember { mutableStateOf<String?>(null) }
    var grupoExpandido by remember { mutableStateOf<String?>(null) }
    var verComprobante by remember { mutableStateOf<Pago?>(null) }
    var verComprobanteGasto by remember { mutableStateOf<com.tesoreria.caja.data.Gasto?>(null) }
    var pdfGuardado by remember { mutableStateOf<PdfExporter.PdfGuardado?>(null) }
    var errorPdf by remember { mutableStateOf("") }
    // Todos ven el acta completa y sacan el PDF completo.
    val puedeDetalleActas = true

    val tipoSeleccionado = if (seccion == 1) TipoCobro.RAPIDO else TipoCobro.OFICIAL
    val actasSeleccionadas = Caja.actas.filter { it.tipo == tipoSeleccionado }.sortedByDescending { it.cierre }

    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(2.dp))
        CabeceraSeccion(
            Icons.Rounded.FolderOpen,
            when (seccion) {
                0 -> "Actas oficiales"
                1 -> "Actas rápidas"
                else -> "Bitácora"
            },
            ColorActas
        )
        Spacer(Modifier.height(10.dp))

        // Esta barra queda fija mientras se desplaza el contenido.
        Row(
            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(13.dp))
                .border(BorderStroke(1.dp, Borde), RoundedCornerShape(13.dp)).padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Pestana("Oficiales", seccion == 0, Ambar, Modifier.weight(1f)) { seccion = 0 }
            Pestana("Rápidas", seccion == 1, Ambar, Modifier.weight(1f)) { seccion = 1 }
            Pestana("Bitácora", seccion == 2, Ambar, Modifier.weight(1f)) { seccion = 2 }
        }
        Spacer(Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 12.dp)
        ) {
            if (seccion != 2) {
                item {
                    Text(
                        when {
                            seccion == 1 -> "Resúmenes de cobros rápidos. Puedes guardarlos en PDF y limpiarlos después."
                            else -> "Cobros cerrados. Toca una foto para ver el comprobante."
                        },
                        color = Tenue,
                        fontSize = 13.sp
                    )
                }

                if (actasSeleccionadas.isEmpty()) {
                    item { Vacio(if (seccion == 1) "Aún no hay actas rápidas." else "Aún no hay actas oficiales.") }
                }

                items(actasSeleccionadas, key = { it.serverId }) { a ->
                    ActaArchivoCard(
                        acta = a,
                        expandida = actaExpandida == a.serverId,
                        grupoExpandido = grupoExpandido,
                        onGrupo = { clave -> grupoExpandido = if (grupoExpandido == clave) null else clave },
                        onExpandir = { actaExpandida = if (actaExpandida == a.serverId) null else a.serverId },
                        onVerComprobante = { verComprobante = it },
                        onGuardarPdf = {
                            runCatching { PdfExporter.guardarActa(context, a, puedeDetalleActas) }
                                .onSuccess { pdfGuardado = it; errorPdf = "" }
                                .onFailure { errorPdf = it.message ?: "No se pudo guardar el PDF" }
                        },
                        onEliminar = if (Caja.esOwner) ({ borrarActa = a }) else null
                    )
                }
            } else {
                item {
                    FilaEntre {
                        Text(if (Caja.esOwner) "Historial completo" else "Eventos importantes", color = Tenue, fontSize = 13.sp)
                        Pastilla("${if (Caja.esOwner) Caja.bitacora.size else Caja.bitacoraPublica().size} eventos", Ambar)
                    }
                    Spacer(Modifier.height(8.dp))
                    Boton("Guardar en PDF", Modifier.fillMaxWidth(), relleno = false, color = Ambar, icono = Icons.Rounded.PictureAsPdf) {
                        runCatching { PdfExporter.guardarBitacora(context, Caja.esOwner) }
                            .onSuccess { pdfGuardado = it; errorPdf = "" }
                            .onFailure { errorPdf = it.message ?: "No se pudo guardar el PDF" }
                    }
                    if (errorPdf.isNotBlank()) {
                        Spacer(Modifier.height(7.dp))
                        Text(errorPdf, color = Rojo, fontSize = 13.sp)
                    }
                }

                val eventos = if (Caja.esOwner) Caja.bitacora.take(80) else Caja.bitacoraPublica().take(40)
                if (eventos.isEmpty()) {
                    item { Vacio("Todavía no hay acciones registradas.") }
                } else {
                    eventos.mapNotNull(::parseEventoBitacora).groupBy { it.fechaKey }.forEach { (_, grupo) ->
                        item(key = "bit-${grupo.first().fechaKey}") {
                            Column(
                                Modifier.fillMaxWidth().cascada(0)
                                    .background(Panel, RoundedCornerShape(18.dp))
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Text(grupo.first().fechaTitulo, color = Tenue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(8.dp))
                                grupo.forEachIndexed { i, e ->
                                    EventoBitacoraLinea(e, ultimo = i == grupo.lastIndex)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    borrarActa?.let { acta ->
        Hoja(onDismissRequest = { borrarActa = null }) {
            var clave by remember(acta.serverId) { mutableStateOf("") }
            var borrando by remember(acta.serverId) { mutableStateOf(false) }
            var error by remember(acta.serverId) { mutableStateOf("") }
            Tarjeta(borde = Rojo.copy(alpha=.5f), fondo = PanelAlto) {
                Etiqueta("ELIMINAR ACTA", Rojo)
                Spacer(Modifier.height(6.dp))
                Text(acta.titulo, color = Texto, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Guarda el PDF si quieres conservar una copia. Para eliminar, confirma tu contraseña.", color = Tenue, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Boton("Guardar PDF primero", Modifier.fillMaxWidth(), relleno = false, color = Verde) {
                    runCatching { PdfExporter.guardarActa(context, acta, true) }
                        .onSuccess { pdfGuardado = it; error = "" }
                        .onFailure { error = it.message ?: "No se pudo guardar el PDF" }
                }
                Spacer(Modifier.height(9.dp))
                Campo(clave, { clave = it; error = "" }, "Tu contraseña", clave = true)
                if (error.isNotBlank()) { Spacer(Modifier.height(7.dp)); Text(error, color = Rojo, fontSize = 13.sp) }
                Spacer(Modifier.height(11.dp))
                Boton(if (borrando) "Eliminando…" else "Eliminar definitivamente", Modifier.fillMaxWidth(), color = Rojo, activo = clave.length >= 6 && !borrando) {
                    borrando = true
                    error = ""
                    scope.launch {
                        try {
                            Caja.eliminarActaConClave(acta, clave)
                            borrarActa = null
                        } catch (e: Exception) {
                            error = e.message ?: "No se pudo eliminar"
                            borrando = false
                        }
                    }
                }
                Spacer(Modifier.height(7.dp))
                Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue, activo = !borrando) { borrarActa = null }
            }
        }
    }

    pdfGuardado?.let { pdf ->
        Hoja(onDismissRequest = { pdfGuardado = null }) {
            Tarjeta(borde = Verde.copy(alpha = .5f), fondo = PanelAlto) {
                Etiqueta("PDF GUARDADO", Verde)
                Spacer(Modifier.height(7.dp))
                Text(pdf.nombre, color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(5.dp))
                Text("Guardado en Descargas/Tesoreria.", color = Tenue, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Boton("Abrir", Modifier.weight(1f), color = Verde) { PdfExporter.abrir(context, pdf) }
                    Boton("Cerrar", Modifier.weight(1f), relleno = false, color = Tenue) { pdfGuardado = null }
                }
            }
        }
    }

    verComprobante?.let { p -> VisorPagoDialog(p) { verComprobante = null } }
}

@Composable
private fun ActaArchivoCard(
    acta: Acta,
    expandida: Boolean,
    grupoExpandido: String?,
    onGrupo: (String) -> Unit,
    onExpandir: () -> Unit,
    onVerComprobante: (Pago) -> Unit,
    onGuardarPdf: () -> Unit,
    onEliminar: (() -> Unit)?
) {
    val aprobados = acta.estados.filterValues { it == EstadoPago.APROBADO }.keys.sorted()
    val pendientes = acta.estados.filterValues { it == EstadoPago.PENDIENTE }.keys.sorted()
    val rechazados = acta.estados.filterValues { it == EstadoPago.RECHAZADO }.keys.sorted()
    val noEnviaron = acta.estados.filterValues { it == EstadoPago.SIN_ENVIAR }.keys.sorted()
    val noPagan = acta.estados.filterValues { it == EstadoPago.NO_PAGA }.keys.sorted()
    val cobroOriginal = Caja.cobros.firstOrNull { it.id == acta.cobroId }
    val color = if (acta.tipo == TipoCobro.RAPIDO) Naranja else Ambar

    val pagosActa = Caja.pagos.filter { it.cobroId == acta.cobroId && it.estado == EstadoPago.APROBADO }
    val conPartes = Caja.abonos.filter { it.cobroId == acta.cobroId }.map { it.socio }.toSet()
    val personasPago = (pagosActa.map { it.socio } + conPartes).distinct().sorted()
    var verPartesActa by remember(acta.serverId) { mutableStateOf<Int?>(null) }
    Tarjeta(borde = Borde) {
        // Encabezado simple: título, fecha y total.
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(color.copy(alpha = .14f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Description, null, tint = color, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(acta.titulo, color = Texto, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(
                    "${fechaLarga(acta.cierre)}" + (cobroOriginal?.let { " · ${duracionArchivo(acta.cierre - it.creado)}" } ?: ""),
                    color = Tenue, fontSize = 12.5.sp
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(soles(acta.recaudado), color = Texto, fontSize = 28.sp, style = cifra)
            Spacer(Modifier.width(8.dp))
            Text("recaudado", color = Tenue, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
        }
        Spacer(Modifier.height(12.dp))
        // Resumen con íconos, sin cajas de colores.
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ResumenActa(Icons.Rounded.Check, "${aprobados.size}", "Pagaron", Verde, Modifier.weight(1f))
            ResumenActa(Icons.Rounded.Close, "${noEnviaron.size + rechazados.size + pendientes.size}", "Faltaron", Rojo, Modifier.weight(1f))
            if (noPagan.isNotEmpty()) ResumenActa(Icons.Rounded.Block, "${noPagan.size}", "No pagan", Tenue, Modifier.weight(1f))
        }

        // Galería de quienes pagaron: foto, nombre y monto. Visible para todos.
        if (personasPago.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text("Pagaron", color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                personasPago.forEachIndexed { i, n ->
                    val p = pagosActa.firstOrNull { it.socio == n }
                    if (n in conPartes) {
                        TarjetaPartesActa(acta.cobroId, n, acta.monto, Modifier.cascada(i)) { verPartesActa = n }
                    } else if (p != null) {
                        TarjetaPagoActa(p, Modifier.cascada(i)) { if (p.capturaPath.isNotBlank()) onVerComprobante(p) }
                    }
                }
            }
        }

        // Quiénes faltaron: se abre al tocar.
        val faltaron = (noEnviaron + rechazados + pendientes).sorted()
        if (faltaron.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            val abierto = grupoExpandido == "${acta.serverId}:faltan"
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp))
                    .presionable { onGrupo("${acta.serverId}:faltan") }
                    .padding(horizontal = 12.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Ver quiénes faltaron", color = Texto, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Icon(if (abierto) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null, tint = Tenue, modifier = Modifier.size(22.dp))
            }
            androidx.compose.animation.AnimatedVisibility(
                visible = abierto,
                enter = androidx.compose.animation.expandVertically(tween(380, easing = CurvaSuave)) + androidx.compose.animation.fadeIn(tween(260)),
                exit = androidx.compose.animation.shrinkVertically(tween(300, easing = CurvaSuave)) + androidx.compose.animation.fadeOut(tween(180))
            ) {
                Column(Modifier.padding(top = 6.dp)) {
                    faltaron.forEach { n ->
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(n.toString().padStart(2, '0'), color = Rojo, fontSize = 13.sp, style = cifra, modifier = Modifier.width(30.dp))
                            Text(acta.detalles[n]?.nombreSnapshot?.ifBlank { null } ?: Caja.socio(n)?.nombre ?: "N.º $n", color = Texto, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 1)
                            val abonado = Caja.abonosDe(acta.cobroId, n).sumOf { it.monto }
                            if (abonado > 0) Text("pagó ${soles(abonado)}", color = Azul, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        verPartesActa?.let { n -> GaleriaPartesDialog(acta.cobroId, n) { verPartesActa = null } }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Boton("PDF", Modifier.weight(1f), relleno = false, color = color, icono = Icons.Rounded.PictureAsPdf) { onGuardarPdf() }
            if (onEliminar != null) {
                Boton("Eliminar", Modifier.weight(1f), relleno = false, color = Rojo.copy(alpha = .85f), icono = Icons.Rounded.Delete) { onEliminar() }
            }
        }

        run {
            Spacer(Modifier.height(7.dp))
            Boton(if (expandida) "Ocultar detalle" else "Detalle completo", Modifier.fillMaxWidth(), relleno = false, color = Tenue, icono = Icons.Rounded.List) { onExpandir() }
            if (expandida) {
                Spacer(Modifier.height(9.dp))
                acta.detalles.values.sortedBy { it.socioNumero }.forEach { d ->
                    val pago = Caja.pagos.filter { it.cobroId == acta.cobroId && it.socio == d.socioNumero }.maxByOrNull { it.enviado }
                    val nombre = d.nombreSnapshot.ifBlank { Caja.socio(d.socioNumero)?.nombre ?: "Socio" }
                    val estadoTexto = when (d.estado) {
                        EstadoPago.APROBADO -> "APROBADO"
                        EstadoPago.PENDIENTE -> "PENDIENTE"
                        EstadoPago.RECHAZADO -> "RECHAZADO"
                        EstadoPago.SIN_ENVIAR -> "NO ENVIÓ"
                        EstadoPago.NO_PAGA -> "NO PARTICIPA"
                    }
                    val info = buildList {
                        d.monto?.let { add(soles(it)) }
                        d.medio?.let { add(if (it == MedioPago.MANUAL) "Manual" else "Yape") }
                        pago?.let { add("${fechaLarga(it.enviado)} ${horaCorta(it.enviado)}") }
                    }.joinToString(" · ")
                    Row(
                        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(11.dp))
                            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(11.dp))
                            .clickable(enabled = pago?.capturaPath?.isNotBlank() == true) { if (pago != null) onVerComprobante(pago) }
                            .padding(11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("N° ${d.socioNumero} · $nombre", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            if (info.isNotBlank()) { Spacer(Modifier.height(3.dp)); Text(info, color = Tenue, fontSize = 11.sp) }
                            if (d.estado == EstadoPago.NO_PAGA && d.motivoNoPago.isNotBlank()) { Spacer(Modifier.height(3.dp)); Text("Motivo: ${d.motivoNoPago}", color = Cian, fontSize = 11.sp) }
                            if (pago?.capturaPath?.isNotBlank() == true) { Spacer(Modifier.height(3.dp)); Text("Toca para ver el comprobante completo", color = Cian, fontSize = 11.sp) }
                        }
                        Spacer(Modifier.width(8.dp))
                        Pastilla(estadoTexto, colorDe(d.estado))
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
    }
}

private data class EventoBitacoraUi(val fechaKey: String, val fechaTitulo: String, val hora: String, val texto: String)

private fun parseEventoBitacora(raw: String): EventoBitacoraUi? {
    val m = Regex("^(\\d{2}/\\d{2}/\\d{4}) (\\d{2}:\\d{2})\\s+·\\s+(.*)$").find(raw) ?: return null
    val fecha = m.groupValues[1]
    val hora = m.groupValues[2]
    val resto = m.groupValues[3].replace(Regex("\\s+·\\s+"), " · ")
    val millis = runCatching { java.text.SimpleDateFormat("dd/MM/yyyy", PE).parse(fecha)?.time }.getOrNull() ?: return null
    return EventoBitacoraUi(fecha, fechaLarga(millis), hora, resto)
}

@Composable
private fun EventoBitacoraLinea(e: EventoBitacoraUi, ultimo: Boolean) {
    val t = e.texto.lowercase()
    val icono = when {
        "pago" in t || "yape" in t || "captura" in t -> Icons.Rounded.Payments
        "cobro" in t -> Icons.Rounded.CalendarMonth
        "gasto" in t -> Icons.Rounded.ShoppingBag
        "lista" in t || "miembro" in t || "plaza" in t || "código" in t || "codigo" in t -> Icons.Rounded.Person
        else -> Icons.Rounded.Info
    }
    // Quita el "N.º X ·" del inicio para que se lea más limpio.
    val actor = Regex("^(N\\.º \\d+) · ").find(e.texto)?.groupValues?.get(1)
    val texto = e.texto.replace(Regex("^N\\.º \\d+ · "), "")
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(30.dp)) {
            Box(Modifier.size(28.dp).background(PanelAlto, CircleShape), contentAlignment = Alignment.Center) {
                Icon(icono, null, tint = Ambar, modifier = Modifier.size(15.dp))
            }
            if (!ultimo) Box(Modifier.width(2.dp).fillMaxHeight().background(Borde))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f).padding(bottom = if (ultimo) 0.dp else 12.dp)) {
            Text(texto, color = Texto, fontSize = 14.sp, lineHeight = 19.sp)
            Spacer(Modifier.height(2.dp))
            Text(if (actor != null) "${e.hora} · $actor" else e.hora, color = Tenue, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ResumenActa(icono: androidx.compose.ui.graphics.vector.ImageVector, valor: String, texto: String, color: Color, modifier: Modifier = Modifier) {
    Row(
        modifier.background(Panel, RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icono, null, tint = color, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Column {
            Text(valor, color = Texto, fontSize = 16.sp, style = cifra, fontWeight = FontWeight.Bold)
            Text(texto, color = Tenue, fontSize = 11.5.sp)
        }
    }
}

/** Tarjetita con la foto del comprobante, el nombre y el monto. */
@Composable
private fun TarjetaPagoActa(p: Pago, modifier: Modifier = Modifier, alTocar: () -> Unit) {
    val socio = Caja.socio(p.socio)
    val yape = p.medio == MedioPago.YAPE
    Column(
        modifier.width(112.dp)
            .background(Panel, RoundedCornerShape(16.dp))
            .presionable(enabled = p.capturaPath.isNotBlank()) { alTocar() }
            .padding(8.dp)
    ) {
        Box(Modifier.fillMaxWidth().height(120.dp)) {
            if (p.capturaPath.isNotBlank()) {
                MiniaturaPago(p.capturaPath, Modifier.fillMaxSize(), radio = 11.dp)
            } else {
                Box(
                    Modifier.fillMaxSize().background(Verde.copy(alpha = .10f), RoundedCornerShape(11.dp)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Payments, null, tint = Verde, modifier = Modifier.size(30.dp)) }
            }
            Box(
                Modifier.align(Alignment.TopStart).padding(6.dp)
                    .background(Color.Black.copy(alpha = .6f), RoundedCornerShape(99.dp))
                    .padding(horizontal = 7.dp, vertical = 2.dp)
            ) { Text(p.socio.toString(), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(7.dp))
        Text(socio?.nombre?.substringBefore(" ") ?: "N.º ${p.socio}", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(6.dp).background(if (yape) MoradoYape else Verde, CircleShape))
            Spacer(Modifier.width(5.dp))
            Text(soles(p.monto), color = Tenue, fontSize = 12.sp)
        }
    }
}

private fun duracionArchivo(ms: Long): String {
    val min = (ms / 60000L).coerceAtLeast(0L)
    val dias = min / 1440
    val horas = (min % 1440) / 60
    val minutos = min % 60
    return buildList {
        if (dias > 0) add("$dias d")
        if (horas > 0) add("$horas h")
        if (minutos > 0 || isEmpty()) add("$minutos min")
    }.joinToString(" ")
}

@Composable
private fun GrupoNumerosActa(titulo: String, numeros: List<Int>, color: Color, expandido: Boolean, alTocar: () -> Unit) {
    Spacer(Modifier.height(7.dp))
    Row(
        Modifier.fillMaxWidth()
            .background(color.copy(alpha = .07f), RoundedCornerShape(11.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = .20f)), RoundedCornerShape(11.dp))
            .clickable { alTocar() }
            .padding(horizontal = 11.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$titulo (${numeros.size})", color = color, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(if (expandido) "Ocultar" else "Ver", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
    if (expandido) {
        Spacer(Modifier.height(5.dp))
        Box(
            Modifier.fillMaxWidth().background(FondoProfundo, RoundedCornerShape(10.dp)).border(BorderStroke(1.dp, Borde), RoundedCornerShape(10.dp)).padding(10.dp)
        ) {
            Text(if (numeros.isEmpty()) "Ninguno" else numeros.joinToString(", ") { "N° $it" }, color = Texto, fontSize = 13.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
fun Pestana(
    texto: String,
    activa: Boolean,
    color: Color,
    modifier: Modifier = Modifier,
    alTocar: () -> Unit
) {
    Box(
        modifier
            .height(44.dp)
            .background(
                if (activa) color.copy(alpha = 0.18f) else Color.Transparent,
                RoundedCornerShape(10.dp)
            )
            .clickable { alTocar() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            texto,
            color = if (activa) color else Tenue,
            fontSize = 13.5.sp,
            fontWeight = if (activa) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
private fun MovimientoCard(
    modifier: Modifier = Modifier,
    titulo: String,
    detalle: String,
    monto: String,
    color: Color,
    estado: String,
    acentoCargo: Color? = null,
    accionTexto: String? = null,
    alTocar: (() -> Unit)? = null
) {
    val base = modifier
        .fillMaxWidth()
        .background(Panel, RoundedCornerShape(16.dp))
        .border(BorderStroke(1.dp, acentoCargo?.copy(alpha = .42f) ?: Borde), RoundedCornerShape(16.dp))
    Row(
        (if (alTocar != null) base.presionable { alTocar() } else base)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(titulo, color = acentoCargo ?: Texto, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Text(detalle, color = Tenue, fontSize = 13.sp)
            Spacer(Modifier.height(7.dp))
            Pastilla(estado, color)
            if (!accionTexto.isNullOrBlank()) {
                Spacer(Modifier.height(7.dp))
                Text(accionTexto, color = Cian, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Text(monto, color = color, fontSize = 14.sp, style = cifra)
    }
}

@Composable
private fun EventoBitacoraCard(evento: String) {
    val visual = visualEvento(evento)
    Row(
        Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(10.dp))
            .border(BorderStroke(1.dp, visual.color.copy(alpha = 0.20f)), RoundedCornerShape(10.dp))
            .padding(horizontal = 11.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(visual.icono, color = visual.color, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Column(Modifier.weight(1f)) {
            Text(visual.titulo, color = visual.color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(2.dp))
            Text(evento, color = Texto, fontSize = 12.5.sp, lineHeight = 15.sp)
        }
    }
}

private data class EventoVisual(val titulo: String, val color: Color, val icono: String)

private fun visualEvento(evento: String): EventoVisual {
    val e = evento.lowercase()
    return when {
        "rechazó" in e || "anul" in e -> EventoVisual("Evento crítico", Rojo, "!")
        "corrig" in e || "ajustó" in e || "extend" in e || "liber" in e -> EventoVisual("Cambio importante", Ambar, "↺")
        "aprobó" in e || "pagó" in e || "envió comprobante" in e -> EventoVisual("Movimiento confirmado", Verde, "✓")
        "abrió el cobro" in e || "cerró el cobro" in e -> EventoVisual("Gestión de cobro", Cian, "▣")
        "sistema" in e -> EventoVisual("Sistema", Tenue, "•")
        else -> EventoVisual("Actividad", Cian, "•")
    }
}

@Composable
fun Vacio(texto: String) {
    Column(
        Modifier.fillMaxWidth().cascada(0).background(Suave, RoundedCornerShape(20.dp)).padding(vertical = 26.dp, horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(54.dp).background(Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Inbox, null, tint = Tenue, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(texto, color = Tenue, fontSize = 14.sp)
    }
}


/** Fila de ingreso: miniatura de la captura, nombre, fecha y monto. */
@Composable
private fun FilaIngreso(p: Pago, modifier: Modifier = Modifier, alTocar: () -> Unit) {
    val socio = Caja.socio(p.socio)
    val yape = p.medio == MedioPago.YAPE
    val colorMedio = if (yape) MoradoYape else Verde
    Row(
        modifier.fillMaxWidth()
            .background(Panel, RoundedCornerShape(16.dp))
            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(16.dp))
            .presionable(enabled = p.capturaPath.isNotBlank()) { alTocar() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (p.capturaPath.isNotBlank()) {
            MiniaturaPago(p.capturaPath, Modifier.size(width = 46.dp, height = 54.dp), radio = 11.dp)
        } else {
            Box(
                Modifier.size(width = 46.dp, height = 54.dp).background(colorMedio.copy(alpha = .12f), RoundedCornerShape(11.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(if (yape) Icons.Rounded.QrCode2 else Icons.Rounded.Payments, null, tint = colorMedio, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(socio?.nombre ?: "N.º ${p.socio}", color = Texto, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Spacer(Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("N.º ${p.socio}", color = Tenue, fontSize = 12.5.sp)
                Text("  ·  ", color = Tenue, fontSize = 12.5.sp)
                Text("${fechaCorta(p.enviado)} ${horaCorta(p.enviado)}", color = Tenue, fontSize = 12.5.sp)
            }
            Spacer(Modifier.height(5.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(colorMedio, RoundedCornerShape(99.dp)))
                Spacer(Modifier.width(5.dp))
                Text(if (yape) "Yape" else "Manual", color = colorMedio, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                if (p.capturaPath.isNotBlank()) {
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Rounded.Photo, null, tint = Tenue, modifier = Modifier.size(14.dp))
                }
            }
        }
        Text("+ ${soles(p.monto)}", color = Verde, fontSize = 16.sp, style = cifra)
    }
}

private fun fechaCorta(ms: Long): String =
    java.text.SimpleDateFormat("dd/MM", java.util.Locale("es", "PE")).format(java.util.Date(ms))


/** Fila de una parte de un cobro por partes. */
@Composable
private fun FilaParte(a: com.tesoreria.caja.data.Abono, modifier: Modifier = Modifier, alTocar: () -> Unit) {
    val socio = Caja.socio(a.socio)
    val cobro = Caja.cobros.firstOrNull { it.id == a.cobroId }
    val todas = Caja.abonosDe(a.cobroId, a.socio)
    val indice = todas.indexOfFirst { it.serverId == a.serverId } + 1
    Row(
        modifier.fillMaxWidth()
            .background(Panel, RoundedCornerShape(16.dp))
            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(16.dp))
            .presionable { alTocar() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (a.capturaPath.isNotBlank()) {
            MiniaturaPago(a.capturaPath, Modifier.size(width = 46.dp, height = 54.dp), radio = 11.dp)
        } else {
            Box(
                Modifier.size(width = 46.dp, height = 54.dp).background(Azul.copy(alpha = .12f), RoundedCornerShape(11.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.Payments, null, tint = Azul, modifier = Modifier.size(22.dp)) }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(socio?.nombre ?: "N.º ${a.socio}", color = Texto, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Spacer(Modifier.height(3.dp))
            Text("N.º ${a.socio}  ·  ${fechaCorta(a.fecha)} ${horaCorta(a.fecha)}", color = Tenue, fontSize = 12.5.sp)
            Spacer(Modifier.height(5.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(Azul, RoundedCornerShape(99.dp)))
                Spacer(Modifier.width(5.dp))
                Text("Parte $indice de ${todas.size}" + (cobro?.let { " · ${it.titulo}" } ?: ""), color = Azul, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
        }
        Text("+ ${soles(a.monto)}", color = Verde, fontSize = 16.sp, style = cifra)
    }
}


/** Tarjetita de una persona que pagó por partes: foto de la 1ª parte y cuánto lleva. */
@Composable
private fun TarjetaPartesActa(cobroId: Int, numero: Int, total: Long, modifier: Modifier = Modifier, alTocar: () -> Unit) {
    val socio = Caja.socio(numero)
    val partes = Caja.abonosDe(cobroId, numero)
    val pagado = partes.sumOf { it.monto }
    val completo = pagado >= total
    val foto = partes.firstOrNull { it.capturaPath.isNotBlank() }?.capturaPath.orEmpty()
    Column(
        modifier.width(112.dp)
            .background(Panel, RoundedCornerShape(16.dp))
            .presionable { alTocar() }
            .padding(8.dp)
    ) {
        Box(Modifier.fillMaxWidth().height(120.dp)) {
            if (foto.isNotBlank()) MiniaturaPago(foto, Modifier.fillMaxSize(), radio = 11.dp)
            else Box(Modifier.fillMaxSize().background(Azul.copy(alpha = .10f), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Payments, null, tint = Azul, modifier = Modifier.size(30.dp))
            }
            Box(
                Modifier.align(Alignment.TopStart).padding(6.dp)
                    .background(Color.Black.copy(alpha = .6f), RoundedCornerShape(99.dp))
                    .padding(horizontal = 7.dp, vertical = 2.dp)
            ) { Text(numero.toString(), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            if (partes.size > 1) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(6.dp)
                        .background(Azul, RoundedCornerShape(99.dp))
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                ) { Text("${partes.size}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(socio?.nombre?.substringBefore(" ") ?: "N.º $numero", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text(
            if (completo) soles(total) else "${soles(pagado)} · falta ${soles(total - pagado)}",
            color = if (completo) Verde else Azul, fontSize = 11.5.sp, maxLines = 1
        )
    }
}
