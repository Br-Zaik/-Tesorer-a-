# Tesorería v2.1.0

VersionCode: 50 · VersionName: 2.1.0

App:
- Acceso en Gestionar miembro con 3 opciones: Usuario · Admin completo · Elegir (permisos uno por uno).
- Admin completo: todos los permisos de trabajo de una vez, con resumen de lo que puede y no puede.
- Nuevo permiso "Generar códigos de 24 h" (individual, no masivo).
- Un admin solo ve Invitar/Gestionar donde tiene permiso y solo gestiona usuarios normales.
- Panel › Owner: "Movimientos de admins" con filtro por persona, solo visible para el owner.

Servidor:
- Nuevo valor de permiso `generar_codigos`.
- Función `generar-codigo` (v5): permite al owner y a administradores con `generar_codigos`; un admin solo puede generarlo para usuarios normales.
- Nueva función `owner_movimientos_admin` (solo owner).
- Siguen siendo solo del owner/tesorero: dar administración, limpiar servidor, borrar códigos, códigos masivos, eliminar actas, liberar plazas y ver conexión.
