package com.tesoreria.caja.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.EstadoMiembro
import com.tesoreria.caja.data.MedioPago
import com.tesoreria.caja.data.Pago
import com.tesoreria.caja.data.Permiso
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.parseCentavos
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.launch

@Composable
fun PantallaPanel() {
    val yo = Caja.sesion.value ?: return
    if (!Caja.puedeAbrirPanel(yo)) {
        Tarjeta {
            Titulo("Sin permisos administrativos")
            Spacer(Modifier.height(6.dp))
            Text("Tu rol actual no tiene herramientas asignadas.", color = Tenue, fontSize = 12.sp)
        }
        return
    }

    var seccion by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxWidth()) {
        Etiqueta("ADMINISTRACIÓN")
        Spacer(Modifier.height(5.dp))
        Titulo(if (yo.rol == Rol.TESORERO) "Panel del tesorero" else "Panel administrativo")
        Spacer(Modifier.height(4.dp))
        Spacer(Modifier.height(12.dp))

        SelectorAdmin(seccion) { seccion = it }
        Spacer(Modifier.height(12.dp))
        when (seccion) {
            0 -> PagosAdmin()
            1 -> CobroAdmin()
            2 -> GastosAdmin()
            3 -> YapeAdmin()
            else -> MiembrosAdmin()
        }
    }
}

@Composable
private fun PagosAdmin() {
    val yo = Caja.sesion.value
    val puedeManual = Caja.tienePermiso(yo, Permiso.REGISTRAR_PAGO_MANUAL)
    val puedeYape = Caja.tienePermiso(yo, Permiso.GESTIONAR_YAPE)
    if (!puedeManual && !puedeYape) {
        SinPermiso()
        return
    }

    var mostrarManual by remember { mutableStateOf(false) }
    var corregir by remember { mutableStateOf<Pago?>(null) }
    var rechazar by remember { mutableStateOf<Pago?>(null) }
    var verComprobante by remember { mutableStateOf<Pago?>(null) }

    if (puedeManual) {
        Boton("Registrar pago manual", Modifier.fillMaxWidth(), color = Verde) { mostrarManual = true }
        Spacer(Modifier.height(12.dp))
    }

    if (puedeYape) {
        Etiqueta("YAPES POR REVISAR", Ambar)
        Spacer(Modifier.height(8.dp))
        val lista = Caja.pendientes()
        if (lista.isEmpty()) Vacio("No hay comprobantes por revisar.")

        lista.forEach { p ->
            val s = Caja.socio(p.socio)
            val cobro = Caja.cobros.firstOrNull { it.id == p.cobroId }
            val fuera = cobro != null && p.enviado > cobro.cierra
            Tarjeta(borde = if (fuera) Ambar.copy(alpha = .55f) else Borde) {
                FilaEntre {
                    Column(Modifier.weight(1f)) {
                        Etiqueta("N.º ${p.socio} · YAPE")
                        Spacer(Modifier.height(3.dp))
                        Text(s?.nombre.orEmpty(), color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Text(soles(p.monto), color = Verde, fontSize = 17.sp, style = cifra)
                }
                Spacer(Modifier.height(6.dp))
                Text(fechaHora(p.enviado), color = Tenue, fontSize = 10.sp)
                if (fuera) {
                    Spacer(Modifier.height(7.dp))
                    Pastilla("Fuera del plazo", Ambar)
                }
                if (p.capturaPath.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Boton("Ver comprobante", Modifier.fillMaxWidth(), relleno = false, color = Cian) { verComprobante = p }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Boton("Aprobar", Modifier.weight(1f), color = Verde) { Caja.aprobarPago(p.id) }
                    Boton("Rechazar", Modifier.weight(1f), relleno = false, color = Rojo) { rechazar = p }
                    Boton("Corregir", Modifier.weight(1f), relleno = false, color = Ambar) { corregir = p }
                }
            }
            Spacer(Modifier.height(9.dp))
        }
    }

    if (mostrarManual) Dialog(onDismissRequest = { mostrarManual = false }) {
        PagoManualDialog { mostrarManual = false }
    }
    corregir?.let { p -> Dialog(onDismissRequest = { corregir = null }) { CorregirPagoDialog(p) { corregir = null } } }
    rechazar?.let { p -> Dialog(onDismissRequest = { rechazar = null }) { RechazarDialog(p) { rechazar = null } } }
    verComprobante?.let { p -> VisorPagoDialog(p) { verComprobante = null } }
}

@Composable
private fun PagoManualDialog(cerrar: () -> Unit) {
    val cobro = Caja.cobroActivo()
    var buscar by remember { mutableStateOf("") }
    var seleccionado by remember { mutableStateOf<Int?>(null) }
    var monto by remember(cobro?.id) { mutableStateOf(cobro?.let { (it.monto / 100).toString() + "." + (it.monto % 100).toString().padStart(2, '0') } ?: "") }
    var aviso by remember { mutableStateOf("") }
    val q = buscar.trim()
    val resultados = if (q.isBlank()) emptyList() else Caja.socios.filter {
        it.estado != EstadoMiembro.RETIRADO && (it.numero.toString() == q || it.nombre.contains(q, ignoreCase = true))
    }.take(6)

    Tarjeta(borde = Verde.copy(alpha = .5f), fondo = PanelAlto) {
        Etiqueta("REGISTRAR PAGO MANUAL", Verde)
        Spacer(Modifier.height(5.dp))
        Text("Busca por número o nombre. Verifica a la persona antes de marcar el pago.", color = Tenue, fontSize = 11.sp)
        Spacer(Modifier.height(12.dp))
        Campo(buscar, { buscar = it; seleccionado = null; aviso = "" }, "Ej. 17 o Delia")
        if (resultados.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            resultados.forEach { s ->
                Row(
                    Modifier.fillMaxWidth().background(if (seleccionado == s.numero) Verde.copy(alpha = .11f) else Fondo, RoundedCornerShape(10.dp))
                        .border(BorderStroke(1.dp, if (seleccionado == s.numero) Verde.copy(alpha = .45f) else Borde), RoundedCornerShape(10.dp))
                        .clickable { seleccionado = s.numero }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${s.numero.toString().padStart(2, '0')}", color = Verde, fontSize = 13.sp, style = cifra)
                    Spacer(Modifier.width(10.dp))
                    Text(s.nombre, color = Texto, fontSize = 12.sp, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(5.dp))
            }
        }
        seleccionado?.let { n ->
            val s = Caja.socio(n)
            Spacer(Modifier.height(9.dp))
            Text("Confirmas: N.º $n · ${s?.nombre}", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(9.dp))
            Etiqueta("MONTO")
            Spacer(Modifier.height(5.dp))
            Campo(monto, { monto = it; aviso = "" }, "4.00", numerico = true)
        }
        if (aviso.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(aviso, color = Rojo, fontSize = 11.sp) }
        Spacer(Modifier.height(14.dp))
        Boton("✓ Confirmar pago manual", Modifier.fillMaxWidth(), color = Verde, activo = seleccionado != null && cobro != null) {
            val n = seleccionado
            val c = cobro
            val cent = parseCentavos(monto) ?: 0L
            when {
                c == null -> aviso = "No hay un cobro activo"
                n == null -> aviso = "Selecciona a la persona"
                cent <= 0L -> aviso = "Monto inválido"
                else -> { Caja.registrarPagoManual(c.id, n, cent); cerrar() }
            }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
}

@Composable
private fun CorregirPagoDialog(pago: Pago, cerrar: () -> Unit) {
    var destino by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    val n = destino.toIntOrNull()
    val s = n?.let(Caja::socio)
    Tarjeta(borde = Ambar.copy(alpha = .5f), fondo = PanelAlto) {
        Etiqueta("CORREGIR PERSONA DEL PAGO", Ambar)
        Spacer(Modifier.height(7.dp))
        Text("Ahora está asignado al N.º ${pago.socio} · ${Caja.socio(pago.socio)?.nombre}", color = Texto, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Campo(destino, { destino = it.filter(Char::isDigit).take(2); aviso = "" }, "Número correcto", numerico = true)
        if (s != null) {
            Spacer(Modifier.height(9.dp))
            Text("¿Es ${s.nombre}?", color = Texto, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("N.º ${s.numero}", color = Tenue, fontSize = 11.sp)
        }
        if (aviso.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(aviso, color = Rojo, fontSize = 11.sp) }
        Spacer(Modifier.height(14.dp))
        Boton("Sí, corregir asignación", Modifier.fillMaxWidth(), color = Ambar, activo = s != null && n != pago.socio) {
            if (n == null || s == null) aviso = "Selecciona un número válido" else { Caja.corregirAsignacionPago(pago.id, n); cerrar() }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
}

@Composable
private fun RechazarDialog(pago: Pago, cerrar: () -> Unit) {
    var motivo by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    Tarjeta(borde = Rojo.copy(alpha = .45f), fondo = PanelAlto) {
        Etiqueta("RECHAZAR YAPE", Rojo)
        Spacer(Modifier.height(8.dp))
        Text("N.º ${pago.socio} · ${Caja.socio(pago.socio)?.nombre}", color = Texto, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Campo(motivo, { motivo = it; aviso = "" }, "Motivo")
        if (aviso.isNotEmpty()) { Spacer(Modifier.height(7.dp)); Text(aviso, color = Rojo, fontSize = 11.sp) }
        Spacer(Modifier.height(12.dp))
        Boton("Confirmar rechazo", Modifier.fillMaxWidth(), color = Rojo) {
            if (motivo.trim().length < 4) aviso = "Escribe un motivo claro" else { Caja.rechazarPago(pago.id, motivo); cerrar() }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
}

@Composable
private fun CobroAdmin() {
    val yo = Caja.sesion.value
    if (!(Caja.tienePermiso(yo, Permiso.GESTIONAR_COBROS) || Caja.esAdmin)) {
        SinPermiso()
        return
    }
    val activo = Caja.cobroActivo()
    var titulo by remember { mutableStateOf("") }
    var monto by remember { mutableStateOf("") }
    var horas by remember { mutableStateOf("5") }
    var extender by remember { mutableStateOf(false) }
    var extra by remember { mutableStateOf("10") }
    var cerrarCobro by remember { mutableStateOf(false) }
    var aviso by remember { mutableStateOf("") }

    if (activo != null) {
        Tarjeta(borde = Verde.copy(alpha = .42f), fondo = PanelAlto) {
            FilaEntre {
                Column(Modifier.weight(1f)) {
                    Etiqueta("COBRO ACTIVO", Verde)
                    Spacer(Modifier.height(4.dp))
                    Text(activo.titulo, color = Texto, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                }
                Text(soles(activo.monto), color = Verde, fontSize = 18.sp, style = cifra)
            }
            Spacer(Modifier.height(7.dp))
            Text("Cierra ${fechaHora(activo.cierra)}", color = Tenue, fontSize = 11.sp)
            if (activo.extensionTexto.isNotBlank()) {
                Spacer(Modifier.height(7.dp))
                Pastilla(activo.extensionTexto, Ambar)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Boton("Ajustar plazo", Modifier.weight(1f), color = Verde) { extender = true }
                Boton("Cerrar", Modifier.weight(1f), relleno = false, color = Rojo) { cerrarCobro = true }
            }
        }
    } else {
        Tarjeta {
            Titulo("Abrir nuevo cobro")
            Spacer(Modifier.height(12.dp))
            Campo(titulo, { titulo = it; aviso = "" }, "Concepto")
            Spacer(Modifier.height(9.dp))
            Campo(monto, { monto = it; aviso = "" }, "Monto · 4.00", numerico = true)
            Spacer(Modifier.height(9.dp))
            Campo(horas, { horas = it.filter(Char::isDigit).take(3); aviso = "" }, "Plazo en horas", numerico = true)
            if (aviso.isNotEmpty()) { Spacer(Modifier.height(7.dp)); Text(aviso, color = Rojo, fontSize = 11.sp) }
            Spacer(Modifier.height(12.dp))
            Boton("Abrir cobro", Modifier.fillMaxWidth()) {
                val c = parseCentavos(monto) ?: 0L
                val h = horas.toIntOrNull() ?: 0
                when {
                    titulo.isBlank() -> aviso = "Falta el concepto"
                    c <= 0 -> aviso = "Monto inválido"
                    h <= 0 -> aviso = "Plazo inválido"
                    else -> Caja.crearCobro(titulo.trim(), c, h)
                }
            }
        }
    }

    if (extender && activo != null) Dialog(onDismissRequest = { extender = false }) {
        var avisoExt by remember { mutableStateOf("") }
        val cierreActual = fechaHora(activo.cierra)
        val preview = run {
            val m = extra.toIntOrNull() ?: 0
            if (m == 0) "Sin cambios" else fechaHora(activo.cierra + m * 60_000L)
        }
        Tarjeta(borde = Verde.copy(alpha = .5f), fondo = PanelAlto) {
            Etiqueta("AJUSTAR PLAZO", Verde)
            Spacer(Modifier.height(6.dp))
            Text("Cierre actual: $cierreActual", color = Texto, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Text("Nuevo cierre: $preview", color = Tenue, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                Boton("-10 min", Modifier.weight(1f), relleno = false, color = Ambar) { extra = (((extra.toIntOrNull() ?: 0) - 10).coerceAtLeast(-999)).toString() }
                Boton("+10 min", Modifier.weight(1f), relleno = false, color = Verde) { extra = (((extra.toIntOrNull() ?: 0) + 10).coerceAtMost(999)).toString() }
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                Boton("-1 h", Modifier.weight(1f), relleno = false, color = Ambar) { extra = (((extra.toIntOrNull() ?: 0) - 60).coerceAtLeast(-999)).toString() }
                Boton("+1 h", Modifier.weight(1f), relleno = false, color = Verde) { extra = (((extra.toIntOrNull() ?: 0) + 60).coerceAtMost(999)).toString() }
            }
            Spacer(Modifier.height(10.dp))
            Campo(extra, { extra = it.filter { c -> c.isDigit() || c == '-' }.take(4); avisoExt = "" }, "Minutos (+ / -)", numerico = true)
            if (avisoExt.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(avisoExt, color = Rojo, fontSize = 11.sp) }
            Spacer(Modifier.height(12.dp))
            Boton("Guardar plazo", Modifier.fillMaxWidth(), color = Verde) {
                val minutos = extra.toIntOrNull() ?: 0
                if (minutos == 0) avisoExt = "Escribe un ajuste válido"
                else {
                    val nuevo = activo.cierra + minutos * 60_000L
                    if (nuevo <= System.currentTimeMillis() + 60_000L) avisoExt = "El nuevo cierre debe quedar en el futuro"
                    else { Caja.ajustarCobro(activo.id, minutos); extender = false }
                }
            }
            Spacer(Modifier.height(7.dp))
            Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { extender = false }
        }
    }

    if (cerrarCobro && activo != null) Dialog(onDismissRequest = { cerrarCobro = false }) {
        Tarjeta(borde = Rojo.copy(alpha = .45f), fondo = PanelAlto) {
            Titulo("¿Cerrar el cobro?")
            Spacer(Modifier.height(8.dp))
            Text("Se guardará el acta con el estado actual.", color = Tenue, fontSize = 12.sp)
            Spacer(Modifier.height(13.dp))
            Boton("Sí, cerrar", Modifier.fillMaxWidth(), color = Rojo) { Caja.cerrarCobro(activo.id); cerrarCobro = false }
            Spacer(Modifier.height(7.dp))
            Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrarCobro = false }
        }
    }
}

@Composable
private fun GastosAdmin() {
    val yo = Caja.sesion.value
    if (!(Caja.tienePermiso(yo, Permiso.REGISTRAR_GASTOS) || Caja.esAdmin)) {
        SinPermiso()
        return
    }
    var concepto by remember { mutableStateOf("") }
    var monto by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    Tarjeta {
        Titulo("Registrar gasto")
        Spacer(Modifier.height(6.dp))
        Text("El gasto se registra directamente. No requiere firma del presidente.", color = Tenue, fontSize = 11.sp)
        Spacer(Modifier.height(11.dp))
        Campo(concepto, { concepto = it; aviso = "" }, "Concepto")
        Spacer(Modifier.height(9.dp))
        Campo(monto, { monto = it; aviso = "" }, "Monto", numerico = true)
        if (aviso.isNotEmpty()) { Spacer(Modifier.height(7.dp)); Text(aviso, color = Rojo, fontSize = 11.sp) }
        Spacer(Modifier.height(12.dp))
        Boton("Registrar gasto", Modifier.fillMaxWidth(), color = Ambar) {
            val c = parseCentavos(monto) ?: 0L
            when { concepto.isBlank() -> aviso = "Falta concepto"; c <= 0 -> aviso = "Monto inválido"; c > Caja.disponibleParaGastos() -> aviso = "No alcanza: ${soles(Caja.disponibleParaGastos())}"; else -> { Caja.crearGasto(concepto.trim(), c); concepto = ""; monto = "" } }
        }
    }
}

@Composable
private fun YapeAdmin() {
    if (!Caja.tienePermiso(Caja.sesion.value, Permiso.GESTIONAR_YAPE)) {
        SinPermiso()
        return
    }
    val config = Caja.yapeConfig.value
    var numero by remember(config.numeroYape) { mutableStateOf(config.numeroYape) }
    var aviso by remember { mutableStateOf("") }

    Tarjeta(borde = Verde.copy(alpha = .35f), fondo = PanelAlto) {
        Etiqueta("NÚMERO YAPE", Verde)
        Spacer(Modifier.height(10.dp))
        Campo(numero, { numero = it.filter(Char::isDigit).take(9); aviso = "" }, "Ej. 987654765", numerico = true)
        if (aviso.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(aviso, color = Verde, fontSize = 11.sp)
        }
        Spacer(Modifier.height(13.dp))
        Boton("Guardar número Yape", Modifier.fillMaxWidth(), color = Verde, activo = numero.trim().length >= 9) {
            Caja.guardarConfigYape(numero)
            aviso = "Guardando…"
        }
    }
}

@Composable
private fun MiembrosAdmin() {
    val clipboard = LocalClipboardManager.current
    if (!Caja.esAdmin) {
        Vacio("Solo el tesorero puede gestionar miembros y roles.")
        return
    }
    var invitar by remember { mutableStateOf<Int?>(null) }
    var editar by remember { mutableStateOf<Int?>(null) }
    var liberar by remember { mutableStateOf<Int?>(null) }

    Tarjeta(fondo = PanelAlto) {
        Etiqueta("PLAZAS 1–35")
    }
    Spacer(Modifier.height(10.dp))

    (1..35).forEach { numero ->
        val s = Caja.socio(numero)
        Tarjeta(borde = if (s == null) Borde else if (s.estado == EstadoMiembro.BLOQUEADO) Rojo.copy(alpha = .4f) else Borde) {
            FilaEntre {
                Column(Modifier.weight(1f)) {
                    Text(if (s == null) "${numero.toString().padStart(2, '0')} · PLAZA LIBRE" else "${numero.toString().padStart(2, '0')} · ${s.nombre}", color = Texto, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(3.dp))
                    Text(
                        if (s == null) "Bloqueada hasta invitación" else "${s.rol.name.lowercase().replaceFirstChar { it.uppercase() }} · ${s.estado.name.lowercase().replaceFirstChar { it.uppercase() }}",
                        color = if (s == null) Tenue else if (s.estado == EstadoMiembro.BLOQUEADO) Rojo else Verde,
                        fontSize = 9.sp
                    )
                }
                when {
                    s == null -> Boton("Invitar", Modifier.width(84.dp), color = Verde, relleno = false) { invitar = numero }
                    s.rol != Rol.TESORERO -> Boton("Gestionar", Modifier.width(98.dp), color = Cian, relleno = false) { editar = numero }
                }
            }
            if (s != null && s.rol != Rol.TESORERO) {
                Spacer(Modifier.height(7.dp))
                val activo = Caja.reseteoAbierto(numero)
                Boton(if (activo) "Mostrar código" else "Generar código 24 h", Modifier.fillMaxWidth(), relleno = false, color = Ambar) {
                    Caja.ultimoCodigoTemporal.value = Caja.codigoLocal(numero)
                    Caja.codigoTemporalPara.value = numero
                    liberar = numero
                }
                if (activo) {
                    Spacer(Modifier.height(5.dp))
                    val min = (Caja.horasDeReseteo(numero) / 60000L).coerceAtLeast(0L)
                    Text("Código activo · vence en ${min / 60} h ${min % 60} min", color = Ambar, fontSize = 9.sp)
                }
            }
        }
        Spacer(Modifier.height(7.dp))
    }

    invitar?.let { n -> Dialog(onDismissRequest = { invitar = null }) { InvitarDialog(n) { invitar = null } } }
    editar?.let { n -> Dialog(onDismissRequest = { editar = null }) { GestionarMiembroDialog(n) { editar = null } } }
    liberar?.let { n -> Dialog(onDismissRequest = { liberar = null }) {
        val codigo = Caja.ultimoCodigoTemporal.value.takeIf { Caja.codigoTemporalPara.value == n }
        var copiado by remember(n, codigo) { mutableStateOf(false) }
        Tarjeta(borde = Ambar.copy(alpha = .45f), fondo = PanelAlto) {
            Etiqueta("CÓDIGO TEMPORAL", Ambar)
            Spacer(Modifier.height(6.dp))
            Text("N.º $n · ${Caja.socio(n)?.nombre}", color = Texto, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Text("El código dura 24 horas y sirve para activar o cambiar la contraseña desde la app.", color = Tenue, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            val activo = Caja.reseteoAbierto(n)
            if (!activo) {
                Boton("Generar código 24 h", Modifier.fillMaxWidth(), color = Ambar) { Caja.resetear(n) }
            } else if (codigo != null) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(codigo, color = VerdeBrillante, fontSize = 30.sp, style = cifra, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(10.dp))
                    Boton(if (copiado) "Copiado" else "Copiar", Modifier.width(92.dp), relleno = false, color = VerdeBrillante) {
                        clipboard.setText(AnnotatedString(codigo))
                        copiado = true
                    }
                }
                Spacer(Modifier.height(6.dp))
                val min = (Caja.horasDeReseteo(n) / 60000L).coerceAtLeast(0L)
                Text("Activo por ${min / 60} h ${min % 60} min más. Dale este código únicamente al socio N.º $n.", color = Tenue, fontSize = 10.sp)
            } else {
                Pastilla("Código activo", Ambar)
                Spacer(Modifier.height(6.dp))
                val min = (Caja.horasDeReseteo(n) / 60000L).coerceAtLeast(0L)
                Text("Ya hay un código activo y vence en ${min / 60} h ${min % 60} min. Por seguridad el servidor no guarda el código en texto. Genera uno nuevo recién cuando venza.", color = Tenue, fontSize = 10.sp)
            }
            Caja.ultimoError.value?.let { err -> Spacer(Modifier.height(8.dp)); Text(err, color = Rojo, fontSize = 10.sp) }
            Spacer(Modifier.height(10.dp))
            Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { liberar = null }
        }
    } }
}

@Composable
private fun InvitarDialog(numero: Int, cerrar: () -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var rol by remember { mutableStateOf(Rol.SOCIO) }
    Tarjeta(borde = Verde.copy(alpha = .5f), fondo = PanelAlto) {
        Etiqueta("INVITAR EN PLAZA $numero", Verde)
        Spacer(Modifier.height(10.dp))
        Campo(nombre, { nombre = it }, "Nombre completo")
        Spacer(Modifier.height(10.dp))
        Text("Rol inicial", color = Tenue, fontSize = 10.sp)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pestana("Socio", rol == Rol.SOCIO, Verde, Modifier.weight(1f)) { rol = Rol.SOCIO }
            Pestana("Presidente", rol == Rol.PRESIDENTE, Verde, Modifier.weight(1f)) { rol = Rol.PRESIDENTE }
            Pestana("Personal", rol == Rol.PERSONALIZADO, Verde, Modifier.weight(1f)) { rol = Rol.PERSONALIZADO }
        }
        Spacer(Modifier.height(12.dp))
        Boton("Crear invitación", Modifier.fillMaxWidth(), color = Verde, activo = nombre.trim().length >= 3) { Caja.invitarMiembro(numero, nombre, rol, emptySet()); cerrar() }
        Spacer(Modifier.height(7.dp)); Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
}

@Composable
private fun GestionarMiembroDialog(numero: Int, cerrar: () -> Unit) {
    val s = Caja.socio(numero) ?: return
    var nombre by remember(s) { mutableStateOf(s.nombre) }
    var rol by remember(s) { mutableStateOf(s.rol) }
    var manual by remember(s) { mutableStateOf(Permiso.REGISTRAR_PAGO_MANUAL in s.permisosExtra) }
    var cobros by remember(s) { mutableStateOf(Permiso.GESTIONAR_COBROS in s.permisosExtra) }
    var gastos by remember(s) { mutableStateOf(Permiso.REGISTRAR_GASTOS in s.permisosExtra) }
    var yape by remember(s) { mutableStateOf(Permiso.GESTIONAR_YAPE in s.permisosExtra) }
    Tarjeta(borde = Cian.copy(alpha = .45f), fondo = PanelAlto) {
        Etiqueta("ROL Y ACCESO", Cian)
        Spacer(Modifier.height(5.dp))
        Text("N.º $numero", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        Etiqueta("NOMBRE")
        Spacer(Modifier.height(5.dp))
        Campo(nombre, { nombre = it.take(80) }, "Nombre completo")
        Spacer(Modifier.height(10.dp))
        Etiqueta("ROL")
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Pestana("Socio", rol == Rol.SOCIO, Cian, Modifier.weight(1f)) {
                rol = Rol.SOCIO; manual = false; cobros = false; gastos = false; yape = false
            }
            Pestana("Presid.", rol == Rol.PRESIDENTE, Cian, Modifier.weight(1f)) {
                rol = Rol.PRESIDENTE; manual = false; cobros = false; gastos = false; yape = false
            }
            Pestana("Personal", rol == Rol.PERSONALIZADO, Cian, Modifier.weight(1f)) { rol = Rol.PERSONALIZADO }
        }
        Spacer(Modifier.height(10.dp))
        PermisoToggle("Registrar pagos manuales", manual, rol == Rol.PERSONALIZADO) { manual = !manual }
        PermisoToggle("Gestionar cobros", cobros, rol == Rol.PERSONALIZADO) { cobros = !cobros }
        PermisoToggle("Registrar gastos", gastos, rol == Rol.PERSONALIZADO) { gastos = !gastos }
        PermisoToggle("Gestionar Yape", yape, rol == Rol.PERSONALIZADO) { yape = !yape }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Boton(if (s.estado == EstadoMiembro.BLOQUEADO) "Desbloquear" else "Bloquear", Modifier.weight(1f), relleno = false, color = if (s.estado == EstadoMiembro.BLOQUEADO) Verde else Rojo) {
                Caja.cambiarEstadoMiembro(numero, if (s.estado == EstadoMiembro.BLOQUEADO) EstadoMiembro.ACTIVO else EstadoMiembro.BLOQUEADO)
            }
            Boton("Guardar", Modifier.weight(1f), color = Cian, activo = nombre.trim().length >= 3) {
                val permisos = buildSet {
                    if (rol == Rol.PERSONALIZADO) {
                        if (manual) add(Permiso.REGISTRAR_PAGO_MANUAL)
                        if (cobros) add(Permiso.GESTIONAR_COBROS)
                        if (gastos) add(Permiso.REGISTRAR_GASTOS)
                        if (yape) add(Permiso.GESTIONAR_YAPE)
                    }
                }
                Caja.guardarMiembro(numero, nombre.trim(), rol, permisos)
                cerrar()
            }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
}

@Composable
private fun PermisoToggle(texto: String, activo: Boolean, habilitado: Boolean = true, alTocar: () -> Unit) {
    val fondo by animateColorAsState(
        if (activo && habilitado) Verde.copy(alpha = .095f) else Fondo,
        tween(220),
        label = "permisoFondo"
    )
    val borde by animateColorAsState(
        if (activo && habilitado) Verde.copy(alpha = .45f) else if (habilitado) Borde else Borde.copy(alpha = .55f),
        tween(220),
        label = "permisoBorde"
    )
    val thumbX by animateDpAsState(if (activo) 24.dp else 3.dp, tween(260, easing = FastOutSlowInEasing), label = "switchThumb")
    val glow by animateFloatAsState(if (activo) 1f else .28f, tween(220), label = "switchGlow")

    Row(
        Modifier.fillMaxWidth().background(fondo, RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, borde), RoundedCornerShape(12.dp))
            .clickable(enabled = habilitado) { alTocar() }.padding(horizontal = 11.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(texto, color = if (habilitado) Texto else Tenue, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Box(
            Modifier.width(52.dp).height(29.dp)
                .background(if (!habilitado) Panel.copy(alpha = .75f) else if (activo) Verde.copy(alpha = .17f) else Panel, RoundedCornerShape(99.dp))
                .border(BorderStroke(1.dp, if (!habilitado) Borde.copy(alpha = .55f) else if (activo) Verde.copy(alpha = .55f) else Borde), RoundedCornerShape(99.dp))
        ) {
            if (activo) {
                Box(
                    Modifier.offset(x = 15.dp, y = 8.dp).width(24.dp).height(12.dp)
                        .background(VerdeBrillante.copy(alpha = .10f * glow), RoundedCornerShape(99.dp))
                )
            }
            Box(
                Modifier.offset(x = thumbX, y = 3.dp).size(23.dp)
                    .background(if (!habilitado) Tenue.copy(alpha = .25f) else if (activo) VerdeBrillante else Tenue.copy(alpha = .55f), RoundedCornerShape(99.dp))
                    .border(BorderStroke(1.dp, if (!habilitado) Borde.copy(alpha = .55f) else if (activo) VerdeNeon.copy(alpha = .75f) else Borde), RoundedCornerShape(99.dp))
            )
        }
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun SinPermiso() {
    Box(
        Modifier.fillMaxWidth().padding(vertical = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Text("No tienes permiso", color = Ambar, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SelectorAdmin(seccion: Int, cambiar: (Int) -> Unit) {
    val titulos = listOf("Pagos", "Cobro", "Gastos", "Yape", "Miembros")
    BoxWithConstraints(
        Modifier.fillMaxWidth().height(48.dp).background(Panel, RoundedCornerShape(14.dp))
            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(14.dp)).padding(4.dp)
    ) {
        val ancho = (maxWidth - 8.dp) / titulos.size.toFloat()
        val x by animateDpAsState(ancho * seccion.toFloat(), tween(280, easing = FastOutSlowInEasing), label = "adminSelector")
        Box(
            Modifier.offset(x = x).width(ancho).fillMaxHeight()
                .background(GradientePrincipal, RoundedCornerShape(11.dp))
        )
        Row(Modifier.fillMaxSize()) {
            titulos.forEachIndexed { i, titulo ->
                val color by animateColorAsState(if (seccion == i) FondoProfundo else Tenue, tween(200), label = "adminText$i")
                Box(
                    Modifier.weight(1f).fillMaxHeight().clickable { cambiar(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(titulo, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

