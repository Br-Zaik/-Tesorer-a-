package com.tesoreria.caja.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.absoluteValue

val PE: Locale = Locale("es", "PE")

fun soles(centavos: Long): String = String.format(PE, "S/ %,.2f", centavos / 100.0)
fun fechaHora(t: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", PE).format(Date(t))
fun fechaCorta(t: Long): String = SimpleDateFormat("dd/MM/yyyy", PE).format(Date(t))
fun fechaLarga(t: Long): String {
    val raw = SimpleDateFormat("d 'de' MMMM 'de' yyyy", PE).format(Date(t))
    return raw.replaceFirstChar { if (it.isLowerCase()) it.titlecase(PE) else it.toString() }
}
fun horaCorta(t: Long): String = SimpleDateFormat("HH:mm", PE).format(Date(t))
fun fechaHoraLarga(t: Long): String = "${fechaLarga(t)} · ${horaCorta(t)}"

fun parseCentavos(texto: String): Long? {
    var s = texto.trim().replace("S/", "", ignoreCase = true).replace(" ", "")
    if (s.isBlank()) return null
    s = when {
        s.contains(',') && s.contains('.') -> s.replace(",", "")
        s.contains(',') -> s.replace(',', '.')
        else -> s
    }
    if (!s.matches(Regex("\\d+(\\.\\d{0,2})?"))) return null
    val partes = s.split('.')
    val entero = partes[0].toLongOrNull() ?: return null
    val dec = when {
        partes.size == 1 || partes[1].isEmpty() -> 0L
        partes[1].length == 1 -> partes[1].toLong() * 10L
        else -> partes[1].take(2).toLong()
    }
    return entero * 100L + dec
}

enum class EstadoPago { SIN_ENVIAR, PENDIENTE, APROBADO, RECHAZADO }
enum class MedioPago { YAPE, MANUAL }
enum class TipoCobro { OFICIAL, RAPIDO }
enum class Rol { SOCIO, PRESIDENTE, TESORERO, PERSONALIZADO }
enum class EstadoMiembro { ACTIVO, BLOQUEADO, RETIRADO }
enum class Permiso { REGISTRAR_PAGO_MANUAL, GESTIONAR_COBROS, REGISTRAR_GASTOS, GESTIONAR_YAPE }

data class Socio(
    val numero: Int,
    val nombre: String,
    val rol: Rol = Rol.SOCIO,
    val estado: EstadoMiembro = EstadoMiembro.ACTIVO,
    val permisosExtra: Set<Permiso> = emptySet()
)

data class Cobro(
    val id: Int,
    val serverId: String,
    val titulo: String,
    val monto: Long,
    val creado: Long,
    val cierra: Long,
    val cerrado: Boolean = false,
    val extensionTexto: String = "",
    val tipo: TipoCobro = TipoCobro.OFICIAL
)

data class Pago(
    val id: Int,
    val serverId: String,
    val cobroId: Int,
    val socio: Int,
    val monto: Long,
    val estado: EstadoPago,
    val enviado: Long,
    val nota: String = "",
    val medio: MedioPago = MedioPago.YAPE,
    val capturaPath: String = "",
    val capturaSha256: String = "",
    val revisadoPor: Int? = null,
    val recibidoPor: Int? = null
)

data class Gasto(
    val id: Int,
    val serverId: String,
    val concepto: String,
    val monto: Long,
    val fecha: Long,
    val anulado: Boolean = false,
    val motivoAnulacion: String = ""
) {
    val aprobado: Boolean get() = !anulado
    val firmaTesorero: Boolean get() = !anulado
    val firmaPresidente: Boolean get() = true
}

data class DetalleActa(
    val socioNumero: Int,
    val nombreSnapshot: String = "",
    val estado: EstadoPago,
    val medio: MedioPago? = null,
    val monto: Long? = null
)

data class Acta(
    val serverId: String,
    val cobroId: Int,
    val titulo: String,
    val monto: Long,
    val cierre: Long,
    val recaudado: Long,
    val pagaron: List<Int>,
    val faltaron: List<Int>,
    val estados: Map<Int, EstadoPago> = emptyMap(),
    val detalles: Map<Int, DetalleActa> = emptyMap(),
    val tipo: TipoCobro = TipoCobro.OFICIAL
)

data class EstadoCuenta(
    val numero: Int,
    val nombre: String,
    val rol: Rol,
    val estado: EstadoMiembro,
    val activada: Boolean,
    val reseteoActivo: Boolean
)

data class YapeConfig(
    val numeroYape: String = "",
    val qrPath: String = "",
    val actualizado: Long = 0L
)

enum class EstadoConexionMiembro { CONECTADO, DESCONECTADO, SIN_ACTIVAR, BLOQUEADO, LIBRE }

data class PresenciaMiembro(
    val numero: Int,
    val estado: EstadoConexionMiembro,
    val ultimaActividad: Long? = null,
    val appVersion: String = ""
)

object Caja {
    val socios = mutableStateListOf<Socio>()
    val cobros = mutableStateListOf<Cobro>()
    val pagos = mutableStateListOf<Pago>()
    val gastos = mutableStateListOf<Gasto>()
    val actas = mutableStateListOf<Acta>()
    val bitacora = mutableStateListOf<String>()
    val yapeConfig = mutableStateOf(YapeConfig())
    val sesion = mutableStateOf<Socio?>(null)
    val cargando = mutableStateOf(false)
    val ultimoError = mutableStateOf<String?>(null)
    val ultimoCodigoTemporal = mutableStateOf<String?>(null)
    val codigoTemporalPara = mutableStateOf<Int?>(null)
    val cobroSubidaId = mutableStateOf<Int?>(null)
    val codigosActivos = mutableStateMapOf<Int, Long>()
    val presencias = mutableStateMapOf<Int, PresenciaMiembro>()
    val presenciasCargadas = mutableStateOf(false)
    val appEnPrimerPlano = mutableStateOf(false)
    val conectado = NetworkMonitor.conectado

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var appContext: Context? = null
    private var refrescoEnCurso = false
    private val operacionesEnCurso = mutableSetOf<String>()

    val esAdmin: Boolean get() = sesion.value?.rol == Rol.TESORERO
    val esPresidente: Boolean get() = sesion.value?.rol == Rol.PRESIDENTE

    fun initialize(context: Context) {
        appContext = context.applicationContext
        SupabaseApi.initialize(context)
        cargarCodigosLocales()
    }

    suspend fun restaurarSesion(): Boolean = try {
        if (!SupabaseApi.restaurarSesion()) {
            false
        } else {
            // No mostramos Inicio hasta tener el snapshot completo del servidor.
            // Así nunca aparece durante unos segundos saldo/cobros en cero.
            cargarTodo()
            sesion.value != null
        }
    } catch (_: Exception) { false }

    suspend fun consultarCuenta(numero: Int): EstadoCuenta {
        val j = SupabaseApi.estadoCuenta(numero)
        return EstadoCuenta(
            numero = j.getInt("numero"),
            nombre = j.getString("nombre"),
            rol = rolDe(j.optString("rol")),
            estado = estadoMiembroDe(j.optString("estado")),
            activada = j.optBoolean("activada"),
            reseteoActivo = j.optBoolean("reseteo_activo")
        )
    }

    suspend fun iniciarSesion(numero: Int, clave: String): Socio {
        SupabaseApi.iniciarSesion(numero, clave)
        // Una sola carga compacta del servidor antes de abrir Inicio.
        // El usuario entra cuando saldo, cobro, pagos y permisos ya están listos.
        cargarTodo()
        return sesion.value ?: throw IllegalStateException("No se pudo cargar tu cuenta")
    }

    suspend fun activarCuenta(numero: Int, codigo: String, clave: String): Socio {
        SupabaseApi.activarCuenta(numero, codigo, clave)
        SupabaseApi.iniciarSesion(numero, clave)
        cargarTodo()
        return sesion.value ?: throw IllegalStateException("La cuenta se activó, pero no se pudo cargar")
    }


    fun cerrarSesion() {
        scope.launch {
            try { SupabaseApi.marcarDesconectado() } catch (_: Exception) { }
            SupabaseApi.cerrarSesion()
        }
        sesion.value = null
        limpiarDatos()
    }

    private fun limpiarDatos() {
        socios.clear(); cobros.clear(); pagos.clear(); gastos.clear(); actas.clear(); bitacora.clear(); codigosActivos.clear(); presencias.clear(); presenciasCargadas.value = false
    }

    suspend fun cargarTodo() = withContext(Dispatchers.IO) {
        // Antes se abrían 12+ peticiones HTTP independientes. En red móvil eso
        // hacía que Inicio apareciera vacío y se rellenara varios segundos después.
        // Ahora Supabase entrega un snapshot coherente en una sola petición.
        val snapshot = SupabaseApi.snapshotApp()
        fun array(nombre: String): JSONArray = snapshot.optJSONArray(nombre) ?: JSONArray()

        val miembros = array("miembros")
        val permisos = array("permisos")
        val cobrosJ = array("cobros")
        val pagosJ = array("pagos")
        val privados = array("privados")
        val gastosJ = array("gastos")
        val actasJ = array("actas")
        val detallePublicoJ = array("detalle_publico")
        val detallePrivadoJ = array("detalle_privado")
        val bitJ = array("bitacora")
        val yapeJ = array("yape_config")
        val reseteosJ = array("reseteos")
        val miNumero = if (snapshot.has("mi_numero") && !snapshot.isNull("mi_numero")) snapshot.optInt("mi_numero") else null

        val permisosPor = mutableMapOf<Int, MutableSet<Permiso>>()
        for (i in 0 until permisos.length()) {
            val p = permisos.getJSONObject(i)
            val n = p.getInt("socio_numero")
            permisoDe(p.getString("permiso"))?.let { permisosPor.getOrPut(n) { mutableSetOf() }.add(it) }
        }

        val nuevosSocios = mutableListOf<Socio>()
        for (i in 0 until miembros.length()) {
            val m = miembros.getJSONObject(i)
            nuevosSocios += Socio(
                m.getInt("numero"), m.optString("nombre"), rolDe(m.optString("rol")),
                estadoMiembroDe(m.optString("estado")), permisosPor[m.getInt("numero")] ?: emptySet()
            )
        }

        val nuevosCobros = mutableListOf<Cobro>()
        val cobroMap = mutableMapOf<String, Int>()
        for (i in 0 until cobrosJ.length()) {
            val c = cobrosJ.getJSONObject(i); val sid = c.getString("id"); val lid = localId(sid); cobroMap[sid] = lid
            nuevosCobros += Cobro(lid, sid, c.getString("titulo"), c.getLong("monto_centavos"), iso(c.getString("creado_at")), iso(c.getString("cierra_at")), !c.isNull("cerrado_at"), c.optString("extension_texto"), tipoCobroDe(c.optString("tipo", "oficial")))
        }

        val privadosMap = mutableMapOf<String, JSONObject>()
        for (i in 0 until privados.length()) privadosMap[privados.getJSONObject(i).getString("pago_id")] = privados.getJSONObject(i)
        val nuevosPagos = mutableListOf<Pago>()
        for (i in 0 until pagosJ.length()) {
            val p = pagosJ.getJSONObject(i); val sid = p.getString("id"); val priv = privadosMap[sid]
            nuevosPagos += Pago(
                id = localId(sid), serverId = sid, cobroId = cobroMap[p.getString("cobro_id")] ?: localId(p.getString("cobro_id")),
                socio = p.getInt("socio_numero"), monto = p.getLong("monto_centavos"), estado = estadoPagoDe(p.getString("estado")),
                enviado = iso(p.getString("enviado_at")), nota = priv?.optString("motivo_rechazo").orEmpty(),
                medio = if (p.optString("medio") == "manual") MedioPago.MANUAL else MedioPago.YAPE,
                capturaPath = priv?.optString("captura_path").orEmpty(),
                capturaSha256 = priv?.optString("captura_sha256").orEmpty(),
                revisadoPor = if (p.isNull("revisado_por")) null else p.optInt("revisado_por"),
                recibidoPor = if (p.isNull("recibido_por")) null else p.optInt("recibido_por")
            )
        }

        val nuevosGastos = mutableListOf<Gasto>()
        for (i in 0 until gastosJ.length()) {
            val g = gastosJ.getJSONObject(i); val sid = g.getString("id")
            nuevosGastos += Gasto(localId(sid), sid, g.getString("concepto"), g.getLong("monto_centavos"), iso(g.getString("registrado_at")), !g.isNull("anulado_at"), g.optString("motivo_anulacion"))
        }

        val resumenPorActa = mutableMapOf<String, MutableList<JSONObject>>()
        for (i in 0 until detallePublicoJ.length()) {
            val d = detallePublicoJ.getJSONObject(i)
            resumenPorActa.getOrPut(d.getString("acta_id")) { mutableListOf() }.add(d)
        }
        val privadoPorClave = mutableMapOf<Pair<String, Int>, JSONObject>()
        for (i in 0 until detallePrivadoJ.length()) {
            val d = detallePrivadoJ.getJSONObject(i)
            privadoPorClave[d.getString("acta_id") to d.getInt("socio_numero")] = d
        }

        val nuevasActas = mutableListOf<Acta>()
        for (i in 0 until actasJ.length()) {
            val a = actasJ.getJSONObject(i)
            val sid = a.getString("id")
            val resumen = resumenPorActa[sid].orEmpty()
            val detalles = resumen.associate { r ->
                val numero = r.getInt("socio_numero")
                val privado = privadoPorClave[sid to numero]
                val medio = if (privado == null || privado.isNull("medio")) null else when (privado.optString("medio")) {
                    "manual" -> MedioPago.MANUAL
                    "yape" -> MedioPago.YAPE
                    else -> null
                }
                numero to DetalleActa(
                    socioNumero = numero,
                    nombreSnapshot = if (privado == null || privado.isNull("nombre_snapshot")) "" else privado.optString("nombre_snapshot"),
                    estado = estadoActaDe(r.getString("estado")),
                    medio = medio,
                    monto = if (privado == null || privado.isNull("monto_centavos")) null else privado.optLong("monto_centavos")
                )
            }
            val estados = detalles.mapValues { it.value.estado }
            nuevasActas += Acta(
                serverId = sid,
                cobroId = cobroMap[a.getString("cobro_id")] ?: localId(a.getString("cobro_id")),
                titulo = a.getString("titulo"),
                monto = a.getLong("cuota_centavos"),
                cierre = iso(a.getString("cerrado_at")),
                recaudado = a.getLong("recaudado_centavos"),
                pagaron = estados.filterValues { it == EstadoPago.APROBADO }.keys.sorted(),
                faltaron = estados.filterValues { it != EstadoPago.APROBADO }.keys.sorted(),
                estados = estados,
                detalles = detalles,
                tipo = tipoCobroDe(a.optString("tipo", "oficial"))
            )
        }

        val nuevosEventos = mutableListOf<String>()
        for (i in 0 until bitJ.length()) {
            val b = bitJ.getJSONObject(i)
            val actorNumero = if (b.isNull("actor_numero")) null else b.getInt("actor_numero")
            val actor = actorNumero?.let { "N.º $it" } ?: "Sistema"
            val detalleOriginal = b.optString("detalle", b.optString("evento")).trim()
            // Varias entradas antiguas ya incluyen el actor al inicio del detalle.
            // Como la UI agrega el actor en una columna propia, quitamos solo ese prefijo
            // para evitar textos como "N.º 22 · N.º 22 aprobó...".
            val detalle = if (actorNumero != null) {
                detalleOriginal.replaceFirst(
                    Regex("^N[.º°\\s]*\\.?\\s*${actorNumero}\\s*[·:–—-]?\\s*", RegexOption.IGNORE_CASE),
                    ""
                ).trim()
            } else {
                detalleOriginal.replaceFirst(Regex("^Sistema\\s*[·:–—-]?\\s*", RegexOption.IGNORE_CASE), "").trim()
            }
            nuevosEventos += "${fechaHora(iso(b.getString("creado_at")))}  ·  $actor  ·  $detalle"
        }

        val nuevoYape = if (yapeJ.length() > 0) {
            val y = yapeJ.getJSONObject(0)
            YapeConfig(
                numeroYape = y.optString("numero_yape"),
                qrPath = "",
                actualizado = isoOrNull(y.optString("actualizado_at")) ?: 0L
            )
        } else YapeConfig()

        val ahoraServidor = System.currentTimeMillis()
        val resetsActivos = mutableMapOf<Int, Long>()
        for (i in 0 until reseteosJ.length()) {
            val r = reseteosJ.getJSONObject(i)
            if (!r.isNull("usado_at") || !r.isNull("cancelado_at")) continue
            val vence = isoOrNull(r.optString("vence_at")) ?: continue
            if (vence > ahoraServidor) {
                val n = r.getInt("socio_numero")
                if ((resetsActivos[n] ?: 0L) < vence) resetsActivos[n] = vence
            }
        }

        withContext(Dispatchers.Main) {
            socios.clear(); socios.addAll(nuevosSocios)
            cobros.clear(); cobros.addAll(nuevosCobros)
            pagos.clear(); pagos.addAll(nuevosPagos)
            gastos.clear(); gastos.addAll(nuevosGastos)
            actas.clear(); actas.addAll(nuevasActas)
            bitacora.clear(); bitacora.addAll(nuevosEventos)
            yapeConfig.value = nuevoYape
            codigosActivos.clear(); codigosActivos.putAll(resetsActivos)
            limpiarCodigosLocalesVencidos()
            if (miNumero != null) {
                val yo = socios.firstOrNull { it.numero == miNumero }
                    ?: throw IllegalStateException("No se pudo cargar tu cuenta")
                if (yo.estado == EstadoMiembro.BLOQUEADO) throw IllegalStateException("Esta cuenta está bloqueada")
                if (yo.estado == EstadoMiembro.RETIRADO) throw IllegalStateException("Esta cuenta ya no está activa")
                sesion.value = yo
            } else {
                throw SesionInvalidaException()
            }
        }
    }

    fun refrescar() {
        if (!conectado.value || sesion.value == null || refrescoEnCurso) return
        refrescoEnCurso = true
        scope.launch {
            try {
                cargarTodo()
                ultimoError.value = null
            } catch (e: SesionInvalidaException) {
                ultimoError.value = e.message
                sesion.value = null
                limpiarDatos()
            } catch (e: Exception) {
                if (e !is SinConexionException && e !is ServidorTemporalException) {
                    ultimoError.value = mensajeAmigable(e)
                }
            } finally {
                refrescoEnCurso = false
            }
        }
    }

    fun permisosDelegables(): Set<Permiso> = setOf(Permiso.REGISTRAR_PAGO_MANUAL, Permiso.GESTIONAR_COBROS, Permiso.REGISTRAR_GASTOS, Permiso.GESTIONAR_YAPE)
    fun puedeAbrirPanel(socio: Socio?): Boolean = socio != null && socio.estado == EstadoMiembro.ACTIVO && (socio.rol == Rol.TESORERO || socio.permisosExtra.any { it in permisosDelegables() })
    fun permisosBase(rol: Rol): Set<Permiso> = if (rol == Rol.TESORERO) permisosDelegables() else emptySet()
    fun tienePermiso(socio: Socio?, permiso: Permiso): Boolean = socio != null && socio.estado == EstadoMiembro.ACTIVO && (permiso in permisosBase(socio.rol) || permiso in socio.permisosExtra)

    fun ingresos(): Long = pagos.filter { p -> p.estado == EstadoPago.APROBADO && cobros.firstOrNull { it.id == p.cobroId }?.tipo != TipoCobro.RAPIDO }.sumOf { it.monto }
    fun egresos(): Long = gastos.filter { it.aprobado }.sumOf { it.monto }
    fun saldo(): Long = ingresos() - egresos()
    fun comprometidoPendiente(): Long = 0L
    fun disponibleParaGastos(): Long = saldo().coerceAtLeast(0L)
    fun cobrosActivos(): List<Cobro> = cobros.filter { !it.cerrado && it.cierra > System.currentTimeMillis() }.sortedWith(compareBy<Cobro> { it.tipo == TipoCobro.RAPIDO }.thenByDescending { it.creado })
    fun cobroActivo(): Cobro? = cobrosActivos().firstOrNull { it.tipo == TipoCobro.OFICIAL }
    fun cobroParaSubir(): Cobro? = cobroSubidaId.value?.let { id -> cobrosActivos().firstOrNull { it.id == id } } ?: cobrosActivos().firstOrNull()
    fun cobrosRapidosActivos(): List<Cobro> = cobrosActivos().filter { it.tipo == TipoCobro.RAPIDO }
    private fun ultimoPago(cobroId: Int, numero: Int): Pago? = pagos.filter { it.cobroId == cobroId && it.socio == numero }.maxByOrNull { it.enviado }
    fun estadoDe(cobroId: Int, numero: Int): EstadoPago = ultimoPago(cobroId, numero)?.estado ?: EstadoPago.SIN_ENVIAR
    fun pagoDe(cobroId: Int, numero: Int): Pago? = ultimoPago(cobroId, numero)
    fun miembrosActivos(): List<Socio> = socios.filter { it.estado != EstadoMiembro.RETIRADO }
    fun faltantes(cobroId: Int): List<Int> = miembrosActivos().map { it.numero }.filter { estadoDe(cobroId, it) != EstadoPago.APROBADO }.sorted()
    fun noEnviaron(cobroId: Int): List<Int> = miembrosActivos().map { it.numero }.filter { estadoDe(cobroId, it) == EstadoPago.SIN_ENVIAR }.sorted()
    fun porRevisar(cobroId: Int): List<Int> = miembrosActivos().map { it.numero }.filter { estadoDe(cobroId, it) == EstadoPago.PENDIENTE }.sorted()
    fun rechazados(cobroId: Int): List<Int> = miembrosActivos().map { it.numero }.filter { estadoDe(cobroId, it) == EstadoPago.RECHAZADO }.sorted()
    fun aprobados(cobroId: Int): Int = miembrosActivos().count { estadoDe(cobroId, it.numero) == EstadoPago.APROBADO }
    fun recaudado(cobroId: Int): Long = pagos.filter { it.cobroId == cobroId && it.estado == EstadoPago.APROBADO }.sumOf { it.monto }
    fun socio(numero: Int): Socio? = socios.firstOrNull { it.numero == numero }
    fun pendientes(): List<Pago> = pagos.filter { it.estado == EstadoPago.PENDIENTE }.sortedByDescending { it.enviado }

    fun crearCobro(titulo: String, monto: Long, duracionMinutos: Int, tipo: TipoCobro = TipoCobro.OFICIAL) = operar("crear_cobro_v2", JSONObject().put("p_titulo", titulo).put("p_monto_centavos", monto).put("p_duracion_minutos", duracionMinutos).put("p_tipo", if (tipo == TipoCobro.RAPIDO) "rapido" else "oficial"))
    fun marcarPagoRapido(cobroId: Int, pagado: Boolean) { cobros.firstOrNull { it.id == cobroId && it.tipo == TipoCobro.RAPIDO }?.let { operar("marcar_pago_rapido", JSONObject().put("p_cobro_id", it.serverId).put("p_pagado", pagado)) } }
    fun ajustarCobro(id: Int, minutosDelta: Int) { cobros.firstOrNull { it.id == id }?.let { operar("ajustar_cobro", JSONObject().put("p_cobro_id", it.serverId).put("p_minutos_delta", minutosDelta)) } }
    fun cerrarCobro(id: Int) { cobros.firstOrNull { it.id == id }?.let { operar("cerrar_cobro", JSONObject().put("p_cobro_id", it.serverId)) } }
    fun registrarPagoManual(cobroId: Int, numero: Int, monto: Long) { cobros.firstOrNull { it.id == cobroId }?.let { operar("registrar_pago_manual", JSONObject().put("p_cobro_id", it.serverId).put("p_socio_numero", numero).put("p_monto_centavos", monto)) } }
    fun corregirAsignacionPago(id: Int, nuevoNumero: Int) { pagos.firstOrNull { it.id == id }?.let { operar("corregir_asignacion_pago", JSONObject().put("p_pago_id", it.serverId).put("p_nuevo_socio", nuevoNumero)) } }
    fun aprobarPago(id: Int) { pagos.firstOrNull { it.id == id }?.let { operar("revisar_pago_yape", JSONObject().put("p_pago_id", it.serverId).put("p_aprobar", true).put("p_motivo_rechazo", JSONObject.NULL)) } }
    fun rechazarPago(id: Int, motivo: String) { pagos.firstOrNull { it.id == id }?.let { operar("revisar_pago_yape", JSONObject().put("p_pago_id", it.serverId).put("p_aprobar", false).put("p_motivo_rechazo", motivo)) } }
    fun crearGasto(concepto: String, monto: Long) = operar("registrar_gasto", JSONObject().put("p_concepto", concepto).put("p_monto_centavos", monto))
    fun gastosPorFirmar(): List<Gasto> = emptyList()
    fun firmarGasto(id: Int, comoPresidente: Boolean) = Unit

    suspend fun enviarComprobante(
        cobro: Cobro,
        bytes: ByteArray,
        mime: String,
        capturaDHash: Long,
        onProgress: (Int) -> Unit = {}
    ) {
        val yo = sesion.value ?: throw IllegalStateException("Sesión no válida")
        if (!conectado.value) throw SinConexionException()
        val hash = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        val ext = when (mime) { "image/png" -> "png"; "image/webp" -> "webp"; else -> "jpg" }
        val path = "${yo.numero}/${cobro.serverId}/${System.currentTimeMillis()}-$hash.$ext"

        val validacionRaw = SupabaseApi.rpc("validar_comprobante_yape_foto", JSONObject()
            .put("p_cobro_id", cobro.serverId)
            .put("p_captura_sha256", hash)
            .put("p_captura_dhash", capturaDHash))
        val validacion = runCatching { JSONObject(validacionRaw) }.getOrNull()
        if (validacion != null && !validacion.optBoolean("ok", false)) {
            throw IllegalStateException(validacion.optString("mensaje", "Esta captura ya fue utilizada"))
        }

        onProgress(12)
        SupabaseApi.uploadComprobante(path, bytes, mime)
        onProgress(62)
        SupabaseApi.rpc("enviar_pago_yape_foto", JSONObject()
            .put("p_cobro_id", cobro.serverId)
            .put("p_captura_path", path)
            .put("p_captura_sha256", hash)
            .put("p_captura_dhash", capturaDHash))
        onProgress(94)
        try { cargarTodo() } catch (_: Exception) { }
        onProgress(100)
    }

    suspend fun verificarEnvio(cobro: Cobro): Boolean {
        if (!conectado.value) return false
        return try {
            cargarTodo()
            pagoDe(cobro.id, sesion.value?.numero ?: return false)?.estado == EstadoPago.PENDIENTE
        } catch (_: Exception) { false }
    }

    suspend fun comprobanteBytes(pago: Pago): ByteArray = SupabaseApi.descargarComprobante(pago.capturaPath)

    fun guardarConfigYape(numeroYape: String, onFin: (Boolean, String) -> Unit = { _, _ -> }) {
        if (!tienePermiso(sesion.value, Permiso.GESTIONAR_YAPE)) { ultimoError.value = "No tienes permiso"; onFin(false, "No tienes permiso"); return }
        if (!conectado.value) { ultimoError.value = "Sin conexión a Internet"; onFin(false, "Sin conexión a Internet"); return }
        scope.launch {
            try {
                val numero = numeroYape.filter(Char::isDigit).take(9)
                if (numero.length != 9) throw IllegalStateException("Escribe un número Yape válido de 9 dígitos")
                SupabaseApi.rpcIdempotente("guardar_yape_config", JSONObject().put("p_numero_yape", numero).put("p_qr_path", JSONObject.NULL))
                ultimoError.value = null
                yapeConfig.value = yapeConfig.value.copy(numeroYape = numero, actualizado = System.currentTimeMillis())
                try { cargarTodo() } catch (_: Exception) { }
                onFin(true, "Guardado")
            } catch (e: Exception) {
                val m = mensajeAmigable(e).ifBlank { "No se pudo guardar" }
                if (e !is SinConexionException && e !is ServidorTemporalException) ultimoError.value = m
                onFin(false, m)
            }
        }
    }

    fun actualizarNombre(numero: Int, nombre: String) {
        operar("actualizar_nombre_miembro", JSONObject().put("p_numero", numero).put("p_nombre", nombre.trim()))
    }

    fun resetear(numero: Int) {
        val local = codigoLocal(numero)
        if (reseteoAbierto(numero) && !local.isNullOrBlank()) {
            ultimoCodigoTemporal.value = local
            codigoTemporalPara.value = numero
            return
        }
        ultimoCodigoTemporal.value = null; codigoTemporalPara.value = numero
        scope.launch {
            try {
                val j = SupabaseApi.generarCodigo(numero)
                val codigo = j.getString("codigo")
                val vence = isoOrNull(j.optString("vence_at")) ?: (System.currentTimeMillis() + 24L * 60L * 60L * 1000L)
                ultimoCodigoTemporal.value = codigo
                codigoTemporalPara.value = numero
                codigosActivos[numero] = vence
                guardarCodigoLocal(numero, codigo, vence)
                ultimoError.value = null
            } catch (e: Exception) { ultimoError.value = mensajeAmigable(e) }
        }
    }

    fun tieneClave(numero: Int): Boolean = true
    fun reseteoAbierto(numero: Int): Boolean = (codigosActivos[numero] ?: 0L) > System.currentTimeMillis()
    fun horasDeReseteo(numero: Int): Long = ((codigosActivos[numero] ?: 0L) - System.currentTimeMillis()).coerceAtLeast(0L)
    fun codigoLocal(numero: Int): String? {
        val ctx = appContext ?: return null
        val p = ctx.getSharedPreferences("tesoreria_codigos", Context.MODE_PRIVATE)
        val vence = p.getLong("vence_$numero", 0L)
        if (vence <= System.currentTimeMillis()) {
            p.edit().remove("codigo_$numero").remove("vence_$numero").apply()
            return null
        }
        return p.getString("codigo_$numero", null)
    }
    private fun guardarCodigoLocal(numero: Int, codigo: String, vence: Long) {
        appContext?.getSharedPreferences("tesoreria_codigos", Context.MODE_PRIVATE)?.edit()
            ?.putString("codigo_$numero", codigo)?.putLong("vence_$numero", vence)?.apply()
    }
    private fun cargarCodigosLocales() {
        limpiarCodigosLocalesVencidos()
    }
    private fun limpiarCodigosLocalesVencidos() {
        val ctx = appContext ?: return
        val p = ctx.getSharedPreferences("tesoreria_codigos", Context.MODE_PRIVATE)
        val e = p.edit()
        for (n in 1..35) {
            val vence = p.getLong("vence_$n", 0L)
            if (vence > 0L && vence <= System.currentTimeMillis()) { e.remove("codigo_$n").remove("vence_$n") }
        }
        e.apply()
    }
    fun necesitaCrearClave(numero: Int): Boolean = false
    fun crearClave(numero: Int, clave: String) = Unit
    fun validar(numero: Int, clave: String): Boolean = false
    fun cerrarSesiones(numero: Int) = Unit

    fun invitarMiembro(numero: Int, nombre: String, rol: Rol, permisos: Set<Permiso>) {
        if (!conectado.value) { ultimoError.value = "Sin conexión a Internet"; return }
        scope.launch {
            try {
                SupabaseApi.rpcIdempotente("invitar_miembro", JSONObject().put("p_numero", numero).put("p_nombre", nombre.trim()).put("p_rol", rolSql(rol)))
                if (rol == Rol.PERSONALIZADO) {
                    val arr = JSONArray(); permisos.forEach { arr.put(permisoSql(it)) }
                    SupabaseApi.rpcIdempotente("guardar_rol_permisos", JSONObject().put("p_numero", numero).put("p_rol", rolSql(rol)).put("p_permisos", arr))
                }
                ultimoError.value = null
                try { cargarTodo() } catch (_: Exception) { }
            } catch (e: Exception) { if (e !is SinConexionException && e !is ServidorTemporalException) ultimoError.value = mensajeAmigable(e) }
        }
    }
    fun cambiarRol(numero: Int, rol: Rol, permisos: Set<Permiso>) {
        val arr = JSONArray(); permisos.forEach { arr.put(permisoSql(it)) }
        operar("guardar_rol_permisos", JSONObject().put("p_numero", numero).put("p_rol", rolSql(rol)).put("p_permisos", arr))
    }

    fun guardarMiembro(numero: Int, nombre: String, rol: Rol, permisos: Set<Permiso>) {
        if (!conectado.value) { ultimoError.value = "Sin conexión a Internet"; return }
        scope.launch {
            try {
                val actual = socio(numero)
                if (actual != null && actual.nombre.trim() != nombre.trim()) {
                    SupabaseApi.rpcIdempotente("actualizar_nombre_miembro", JSONObject().put("p_numero", numero).put("p_nombre", nombre.trim()))
                }
                val arr = JSONArray(); permisos.forEach { arr.put(permisoSql(it)) }
                SupabaseApi.rpcIdempotente("guardar_rol_permisos", JSONObject().put("p_numero", numero).put("p_rol", rolSql(rol)).put("p_permisos", arr))
                ultimoError.value = null
                try { cargarTodo() } catch (_: Exception) { }
            } catch (e: SesionInvalidaException) {
                ultimoError.value = e.message; sesion.value = null; limpiarDatos()
            } catch (e: Exception) {
                ultimoError.value = mensajeAmigable(e)
            }
        }
    }
    fun cambiarEstadoMiembro(numero: Int, estado: EstadoMiembro) = operar("cambiar_estado_miembro", JSONObject().put("p_numero", numero).put("p_estado", estadoSql(estado)))
    fun liberarPlaza(numero: Int, onFin: (Boolean, String) -> Unit = { _, _ -> }) {
        if (!esAdmin) { onFin(false, "No tienes permiso"); return }
        scope.launch {
            try {
                SupabaseApi.liberarPlaza(numero)
                ultimoError.value = null
                try { cargarTodo() } catch (_: Exception) { }
                onFin(true, "Plaza liberada")
            } catch (e: Exception) {
                val m = mensajeAmigable(e).ifBlank { "No se pudo liberar la plaza" }
                ultimoError.value = m
                onFin(false, m)
            }
        }
    }

    suspend fun registrarPresenciaAhora() {
        if (sesion.value == null || !conectado.value || !appEnPrimerPlano.value) return
        try { SupabaseApi.registrarPresencia() } catch (_: Exception) { }
    }

    fun marcarDesconectadoAsync() {
        if (sesion.value == null) return
        scope.launch {
            try { SupabaseApi.marcarDesconectado() } catch (_: Exception) { }
        }
    }

    suspend fun refrescarPresenciasAdmin() {
        if (!esAdmin || !conectado.value) return
        try {
            val arr = SupabaseApi.presenciaAdmin()
            val nuevos = mutableMapOf<Int, PresenciaMiembro>()
            for (i in 0 until arr.length()) {
                val j = arr.optJSONObject(i) ?: continue
                val numero = j.optInt("numero", 0)
                if (numero !in 1..35) continue
                val estado = when (j.optString("estado")) {
                    "conectado" -> EstadoConexionMiembro.CONECTADO
                    "sin_activar" -> EstadoConexionMiembro.SIN_ACTIVAR
                    "bloqueado" -> EstadoConexionMiembro.BLOQUEADO
                    "libre" -> EstadoConexionMiembro.LIBRE
                    else -> EstadoConexionMiembro.DESCONECTADO
                }
                nuevos[numero] = PresenciaMiembro(
                    numero = numero,
                    estado = estado,
                    ultimaActividad = isoOrNull(j.optString("ultima_actividad")),
                    appVersion = j.optString("app_version")
                )
            }
            withContext(Dispatchers.Main) {
                presencias.clear()
                presencias.putAll(nuevos)
                presenciasCargadas.value = true
            }
        } catch (_: Exception) {
            // La presencia es informativa; nunca bloquea el panel administrativo.
        }
    }

    suspend fun eliminarActaConClave(acta: Acta, clave: String) {
        val yo = sesion.value ?: throw IllegalStateException("Sesión no válida")
        if (yo.rol != Rol.TESORERO) throw IllegalStateException("No tienes permiso")
        SupabaseApi.iniciarSesion(yo.numero, clave)
        SupabaseApi.rpcIdempotente("eliminar_acta", JSONObject().put("p_acta_id", acta.serverId))
        cargarTodo()
    }
    fun revisarVencidos() = refrescar()
    fun bitacoraPublica(): List<String> = bitacora

    private fun operar(nombre: String, params: JSONObject) {
        if (!conectado.value) return
        val clave = "$nombre:${params}"
        synchronized(operacionesEnCurso) {
            if (!operacionesEnCurso.add(clave)) return
        }
        val requestId = UUID.randomUUID().toString()
        scope.launch {
            try {
                // Es seguro reintentar: el servidor reconoce requestId y jamás duplica la acción.
                SupabaseApi.rpcIdempotente(nombre, params, requestId)
                ultimoError.value = null
                // Una falla de sincronización posterior NO convierte una acción ya guardada
                // en error para el usuario. Se recuperará automáticamente al reconectar.
                try { cargarTodo() } catch (_: Exception) { }
            } catch (e: SesionInvalidaException) {
                ultimoError.value = e.message
                sesion.value = null
                limpiarDatos()
            } catch (e: Exception) {
                if (e !is SinConexionException && e !is ServidorTemporalException) {
                    ultimoError.value = mensajeAmigable(e)
                }
            } finally {
                synchronized(operacionesEnCurso) { operacionesEnCurso.remove(clave) }
            }
        }
    }

    private fun mensajeAmigable(e: Exception): String {
        val raw = e.message.orEmpty()
        val n = raw.lowercase(Locale.ROOT)
        return when {
            "permission denied" in n || "row-level security" in n || "not authorized" in n -> "No tienes permiso"
            e is SinConexionException || e is ServidorTemporalException || "timeout" in n || "tardó demasiado" in n -> ""
            raw.isBlank() -> "No se pudo actualizar"
            else -> raw
        }
    }

    private fun localId(uuid: String): Int = uuid.hashCode().absoluteValue
    private fun rolDe(v: String) = when (v) { "tesorero" -> Rol.TESORERO; "presidente" -> Rol.PRESIDENTE; "personalizado" -> Rol.PERSONALIZADO; else -> Rol.SOCIO }
    private fun rolSql(v: Rol) = when (v) { Rol.TESORERO -> "tesorero"; Rol.PRESIDENTE -> "presidente"; Rol.PERSONALIZADO -> "personalizado"; Rol.SOCIO -> "socio" }
    private fun estadoMiembroDe(v: String) = when (v) { "bloqueado" -> EstadoMiembro.BLOQUEADO; "retirado" -> EstadoMiembro.RETIRADO; else -> EstadoMiembro.ACTIVO }
    private fun estadoSql(v: EstadoMiembro) = when (v) { EstadoMiembro.BLOQUEADO -> "bloqueado"; EstadoMiembro.RETIRADO -> "retirado"; EstadoMiembro.ACTIVO -> "activo" }
    private fun tipoCobroDe(v: String): TipoCobro = if (v.lowercase(Locale.ROOT) == "rapido") TipoCobro.RAPIDO else TipoCobro.OFICIAL
    private fun permisoDe(v: String): Permiso? = when (v) { "registrar_pago_manual" -> Permiso.REGISTRAR_PAGO_MANUAL; "gestionar_cobros" -> Permiso.GESTIONAR_COBROS; "registrar_gastos" -> Permiso.REGISTRAR_GASTOS; "gestionar_yape" -> Permiso.GESTIONAR_YAPE; else -> null }
    private fun permisoSql(v: Permiso) = when (v) { Permiso.REGISTRAR_PAGO_MANUAL -> "registrar_pago_manual"; Permiso.GESTIONAR_COBROS -> "gestionar_cobros"; Permiso.REGISTRAR_GASTOS -> "registrar_gastos"; Permiso.GESTIONAR_YAPE -> "gestionar_yape" }
    private fun estadoPagoDe(v: String) = when (v) { "aprobado" -> EstadoPago.APROBADO; "rechazado" -> EstadoPago.RECHAZADO; else -> EstadoPago.PENDIENTE }
    private fun estadoActaDe(v: String) = when (v) { "aprobado" -> EstadoPago.APROBADO; "pendiente" -> EstadoPago.PENDIENTE; "rechazado" -> EstadoPago.RECHAZADO; else -> EstadoPago.SIN_ENVIAR }
    private fun isoOrNull(v: String): Long? = try {
        if (v.isBlank() || v == "null") null else {
            val fixed = v.replace(Regex("\\.(\\d{3})\\d+([+-]\\d{2}:?\\d{2}|Z)$"), ".$1$2")
            val patterns = listOf("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX")
            patterns.firstNotNullOfOrNull { p -> try { SimpleDateFormat(p, Locale.US).parse(fixed)?.time } catch (_: Exception) { null } }
        }
    } catch (_: Exception) { null }

    private fun iso(v: String): Long = try {
        val fixed = v.replace(Regex("\\.(\\d{3})\\d+([+-]\\d{2}:?\\d{2}|Z)$"), ".$1$2")
        val patterns = listOf("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX")
        patterns.firstNotNullOfOrNull { p -> try { SimpleDateFormat(p, Locale.US).parse(fixed)?.time } catch (_: Exception) { null } } ?: System.currentTimeMillis()
    } catch (_: Exception) { System.currentTimeMillis() }
}
