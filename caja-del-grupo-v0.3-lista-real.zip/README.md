# Caja del grupo — maqueta offline v0.3

App Android para probar la interfaz y los flujos de una caja común con capacidad para 35 puestos. Actualmente hay 30 miembros cargados y 5 puestos libres.
Esta versión es **intencionalmente local**: no usa internet, Supabase, cámara real ni OCR real.
Los datos viven en memoria y se reinician al cerrar la app.

La meta de esta maqueta es probar con calma cómo se ve y se siente la aplicación antes de
conectar el servidor.

## Cómo compilar el APK sin PC

1. Crea un repositorio **público** en GitHub.
2. Sube **el contenido de esta carpeta directamente a la raíz del repo**. Debes ver
   `settings.gradle.kts`, `app/` y `.github/` en la portada del repositorio.
3. Entra a **Actions** y habilita los workflows si GitHub te lo pide.
4. El workflow **Compilar APK** se ejecuta con cada subida. También puedes usar
   Actions → Compilar APK → Run workflow.
5. Al terminar, abre la ejecución y descarga el artifact `caja-del-grupo-apk`.

## Usuarios de prueba

- Clave general de demo: `123456`
- N° **22 — Brian Pacco Huayhua** → tesorero
- N° **12** y **27** → simulan primera entrada sin contraseña creada
- N° **1–30** → miembros cargados con sus nombres reales de la lista entregada
- N° **31–35** → puestos libres/reservados; todavía no pueden iniciar sesión ni cuentan como faltantes
- Presidente → pendiente de asignar cuando se indique su número

## Mejoras incluidas en v0.3

- Lista real de 30 miembros cargada para el inicio de sesión.
- N° 22 configurado como tesorero.
- Puestos 31–35 visibles como **LIBRE** y excluidos del conteo de pagos.
- Inicio más limpio y con el saldo como dato principal.
- Cobro activo con cuenta regresiva y barra de avance.
- Separación visual entre **no enviaron**, **esperando revisión** y **deben reenviar**.
- Cuadro 1–35 en 5 columnas, con fichas más grandes.
- Cuatro estados diferenciados: aprobado, pendiente, no enviado y rechazado.
- Estado propio del socio explicado debajo del cuadro.
- Flujo de comprobante en 3 pasos: Captura → Revisar → Enviar.
- OCR simulado con monto, fecha y número de operación editables.
- Panel del tesorero reorganizado y con confirmaciones antes de acciones importantes.
- Rechazo de pago con motivo obligatorio.
- Confirmación antes de cerrar un cobro y congelar el acta.
- Confirmación antes de registrar un gasto.
- Panel de liberación de contraseña con confirmación de 24 horas.
- Historiales con mejor jerarquía visual y bitácora con actor y hora.
- Montos convertidos a céntimos sin usar `Double` al ingresar dinero.
- Un pago rechazado ya no se elimina al reenviar; queda en el historial local.
- La ventana de liberación de contraseña deja de quedar abierta indefinidamente.
- Los gastos pendientes se tienen en cuenta para evitar comprometer más dinero del disponible.

## Qué sigue siendo simulado a propósito

- Supabase / servidor / Realtime / RLS.
- Cámara y galería reales.
- Compresión real de imágenes.
- OCR real con Google ML Kit.
- Hash de imagen.
- Cierre con tarea programada del servidor.
- PDF del acta.
- Notificaciones push.

## Estructura

```text
app/src/main/java/com/tesoreria/caja/
  MainActivity.kt
  data/Caja.kt
  ui/Estilo.kt
  ui/Login.kt
  ui/Inicio.kt
  ui/Subir.kt
  ui/Movimientos.kt
  ui/Panel.kt
```

Cuando se conecte Supabase se conservará el diseño, pero no se asume que únicamente
cambiará `Caja.kt`: también habrá que añadir dependencias, permisos y componentes para
imagen/OCR según corresponda.
