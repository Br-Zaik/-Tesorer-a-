package com.tesoreria.caja.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.data.Socio

private enum class Paso { NUMERO, CONFIRMAR, CLAVE, NUEVA_CLAVE }

@Composable
fun PantallaLogin(alEntrar: (Socio) -> Unit) {
    var paso by remember { mutableStateOf(Paso.NUMERO) }
    var numero by remember { mutableStateOf("") }
    var clave by remember { mutableStateOf("") }
    var clave2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var listo by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { listo = true }
    val entrada by animateFloatAsState(
        targetValue = if (listo) 1f else 0f,
        animationSpec = tween(700),
        label = "entrada"
    )

    val socio = numero.toIntOrNull()?.let { Caja.socio(it) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Fondo)
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        AnilloVivo()
        Spacer(Modifier.height(20.dp))
        Text(
            "Caja del grupo",
            color = Texto,
            fontSize = 27.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.alpha(entrada)
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Libro de caja digital · 30 miembros + 5 puestos libres",
            color = Tenue,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.alpha(entrada)
        )
        Spacer(Modifier.height(8.dp))
        Pastilla("MAQUETA LOCAL · SIN INTERNET", Cian)
        Spacer(Modifier.height(26.dp))

        Box(Modifier.alpha(entrada)) {
            Tarjeta(borde = Cian.copy(alpha = 0.22f), fondo = PanelAlto) {
                when (paso) {
                    Paso.NUMERO -> {
                        Etiqueta("NÚMERO DE LISTA")
                        Spacer(Modifier.height(7.dp))
                        Text("Entra con tu número del 1 al 35.", color = Tenue, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        Campo(
                            numero,
                            { numero = it.filter { c -> c.isDigit() }.take(2); error = "" },
                            "Ejemplo: 12",
                            numerico = true
                        )
                        Spacer(Modifier.height(14.dp))
                        Boton("Continuar", Modifier.fillMaxWidth()) {
                            val n = numero.toIntOrNull()
                            when {
                                n == null || n !in 1..35 -> error = "Usa un número del 1 al 35"
                                socio == null && n in 31..35 -> error = "Ese puesto está libre por ahora"
                                socio == null -> error = "Ese número no está en la lista"
                                else -> paso = Paso.CONFIRMAR
                            }
                        }
                    }

                    Paso.CONFIRMAR -> {
                        FilaEntre {
                            Etiqueta("CONFIRMAR IDENTIDAD")
                            Pastilla(
                                when (socio?.rol) {
                                    Rol.TESORERO -> "TESORERO"
                                    Rol.PRESIDENTE -> "PRESIDENTE"
                                    else -> "SOCIO"
                                },
                                if (socio?.rol == Rol.SOCIO) Cian else Violeta
                            )
                        }
                        Spacer(Modifier.height(11.dp))
                        Text("¿Eres ${socio?.nombre}?", color = Texto, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(5.dp))
                        Text("Número ${socio?.numero.toString().padStart(2, '0')}", color = Tenue, fontSize = 12.sp)
                        Spacer(Modifier.height(16.dp))
                        Boton("Sí, soy yo", Modifier.fillMaxWidth()) {
                            paso = if (Caja.necesitaCrearClave(socio!!.numero)) Paso.NUEVA_CLAVE else Paso.CLAVE
                        }
                        Spacer(Modifier.height(8.dp))
                        Boton("No, volver", Modifier.fillMaxWidth(), relleno = false, color = Tenue) {
                            numero = ""; clave = ""; error = ""; paso = Paso.NUMERO
                        }
                    }

                    Paso.CLAVE -> {
                        Etiqueta("CONTRASEÑA")
                        Spacer(Modifier.height(6.dp))
                        Text("Hola, ${socio?.nombre?.substringBefore(" ")}.", color = Texto, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(12.dp))
                        Campo(clave, { clave = it; error = "" }, "Tu contraseña", clave = true)
                        Spacer(Modifier.height(14.dp))
                        Boton("Entrar", Modifier.fillMaxWidth()) {
                            if (Caja.validar(socio!!.numero, clave)) alEntrar(socio!!)
                            else error = "Contraseña incorrecta"
                        }
                        Spacer(Modifier.height(11.dp))
                        Text("¿La olvidaste? Pídele al tesorero que la libere por 24 horas.", color = Tenue, fontSize = 11.sp)
                    }

                    Paso.NUEVA_CLAVE -> {
                        val esLiberacion = socio?.let { Caja.tieneClave(it.numero) } == true
                        Etiqueta(if (esLiberacion) "CONTRASEÑA LIBERADA" else "PRIMERA ENTRADA", if (esLiberacion) Ambar else Cian)
                        Spacer(Modifier.height(6.dp))
                        Text("Crea tu contraseña", color = Texto, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(5.dp))
                        Text(
                            if (esLiberacion) "La ventana estará abierta aproximadamente ${Caja.horasDeReseteo(socio!!.numero)} h."
                            else "Nadie más la verá, ni el tesorero.",
                            color = Tenue,
                            fontSize = 12.sp
                        )
                        Spacer(Modifier.height(12.dp))
                        Campo(clave, { clave = it; error = "" }, "Nueva contraseña", clave = true)
                        Spacer(Modifier.height(8.dp))
                        Campo(clave2, { clave2 = it; error = "" }, "Repítela", clave = true)
                        Spacer(Modifier.height(10.dp))
                        Text("Mínimo 6 caracteres · no uses tu número de lista", color = Tenue, fontSize = 10.sp)
                        Spacer(Modifier.height(14.dp))
                        Boton("Crear y entrar", Modifier.fillMaxWidth()) {
                            val n = socio!!.numero
                            when {
                                esLiberacion && !Caja.reseteoAbierto(n) -> error = "La ventana de 24 horas venció. Pide al tesorero que la libere otra vez."
                                clave.length < 6 -> error = "Debe tener al menos 6 caracteres"
                                clave != clave2 -> error = "Las dos contraseñas no coinciden"
                                clave == n.toString() || clave == n.toString().padStart(2, '0') -> error = "No uses tu número de lista"
                                else -> {
                                    Caja.crearClave(n, clave)
                                    alEntrar(socio!!)
                                }
                            }
                        }
                    }
                }

                if (error.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(error, color = Rojo, fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(18.dp))
        Text(
            "Prueba: clave 123456 · N° 22 tesorero · N° 12 y 27 prueban primera entrada",
            color = Tenue.copy(alpha = 0.72f),
            fontSize = 10.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.alpha(entrada)
        )
    }
}

@Composable
private fun AnilloVivo() {
    val giro = rememberInfiniteTransition(label = "giro")
    val a by giro.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(5400, easing = LinearEasing), RepeatMode.Restart),
        label = "a"
    )
    val b by giro.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(7600, easing = LinearEasing), RepeatMode.Restart),
        label = "b"
    )
    val pulso by giro.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(1300), RepeatMode.Reverse),
        label = "pulso"
    )

    Box(Modifier.size(82.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(76.dp).rotate(a)) {
            drawArc(Cian.copy(alpha = pulso), -70f, 205f, false, style = Stroke(width = 3.dp.toPx()))
        }
        Canvas(Modifier.size(60.dp).rotate(b)) {
            drawArc(Violeta.copy(alpha = 0.62f), 50f, 210f, false, style = Stroke(width = 2.dp.toPx()))
        }
        Canvas(Modifier.size(18.dp)) {
            drawCircle(Cian.copy(alpha = 0.11f), radius = size.minDimension / 2)
            drawCircle(Cian, radius = 3.dp.toPx(), center = Offset(size.width / 2, size.height / 2))
        }
    }
}
