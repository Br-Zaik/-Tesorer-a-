package com.tesoreria.caja

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.ui.Borde
import com.tesoreria.caja.ui.Boton
import com.tesoreria.caja.ui.CajaTheme
import com.tesoreria.caja.ui.Cian
import com.tesoreria.caja.ui.Fondo
import com.tesoreria.caja.ui.Panel
import com.tesoreria.caja.ui.PantallaArchivo
import com.tesoreria.caja.ui.PantallaInicio
import com.tesoreria.caja.ui.PantallaLogin
import com.tesoreria.caja.ui.PantallaMovimientos
import com.tesoreria.caja.ui.PantallaPanel
import com.tesoreria.caja.ui.PantallaSubir
import com.tesoreria.caja.ui.Tenue
import com.tesoreria.caja.ui.Texto

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Caja.cargarDemo()
        setContent { CajaTheme { App() } }
    }
}

private enum class Vista { INICIO, SUBIR, MOVIMIENTOS, ARCHIVO, PANEL }

@Composable
fun App() {
    val yo = Caja.sesion.value
    var vista by remember { mutableStateOf(Vista.INICIO) }

    if (yo == null) {
        PantallaLogin { s ->
            Caja.sesion.value = s
            Caja.revisarVencidos()
            vista = Vista.INICIO
        }
        return
    }

    val conPanel = yo.rol == Rol.TESORERO || yo.rol == Rol.PRESIDENTE
    val rolTexto = when (yo.rol) {
        Rol.TESORERO -> "TESORERO"
        Rol.PRESIDENTE -> "PRESIDENTE"
        Rol.SOCIO -> "SOCIO"
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Fondo)
    ) {
        // Barra superior sobria: identidad + rol + estado de la maqueta.
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Caja del grupo",
                        color = Texto,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.width(8.dp))
                    ChipSuperior("DEMO LOCAL", Cian)
                }
                Spacer(Modifier.height(5.dp))
                Text(
                    "N° ${yo.numero} · ${yo.nombre.substringBefore(" ")} · $rolTexto",
                    color = Tenue,
                    fontSize = 10.sp
                )
            }
            Boton("Salir", Modifier.width(72.dp), relleno = false, color = Tenue) {
                Caja.sesion.value = null
                vista = Vista.INICIO
            }
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
                .padding(bottom = 20.dp)
        ) {
            when (vista) {
                Vista.INICIO -> PantallaInicio { vista = Vista.SUBIR }
                Vista.SUBIR -> PantallaSubir { vista = Vista.INICIO }
                Vista.MOVIMIENTOS -> PantallaMovimientos()
                Vista.ARCHIVO -> PantallaArchivo()
                Vista.PANEL -> PantallaPanel()
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .background(Panel)
                .border(BorderStroke(1.dp, Borde), RoundedCornerShape(0.dp))
                .padding(horizontal = 8.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Tab("Inicio", vista == Vista.INICIO || vista == Vista.SUBIR, Modifier.weight(1f)) {
                vista = Vista.INICIO
            }
            Tab("Movimientos", vista == Vista.MOVIMIENTOS, Modifier.weight(1f)) {
                vista = Vista.MOVIMIENTOS
            }
            Tab("Archivo", vista == Vista.ARCHIVO, Modifier.weight(1f)) {
                vista = Vista.ARCHIVO
            }
            if (conPanel) {
                Tab("Panel", vista == Vista.PANEL, Modifier.weight(1f)) { vista = Vista.PANEL }
            }
        }
    }
}

@Composable
private fun ChipSuperior(texto: String, color: Color) {
    Box(
        Modifier
            .background(color.copy(alpha = 0.10f), RoundedCornerShape(7.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.28f)), RoundedCornerShape(7.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    ) {
        Text(texto, color = color, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Tab(texto: String, activa: Boolean, modifier: Modifier = Modifier, alTocar: () -> Unit) {
    Column(
        modifier
            .height(48.dp)
            .background(
                if (activa) Cian.copy(alpha = 0.10f) else Color.Transparent,
                RoundedCornerShape(12.dp)
            )
            .clickable { alTocar() },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            texto,
            color = if (activa) Cian else Tenue,
            fontSize = 11.sp,
            fontWeight = if (activa) FontWeight.SemiBold else FontWeight.Normal
        )
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .width(if (activa) 20.dp else 4.dp)
                .height(2.dp)
                .background(if (activa) Cian else Color.Transparent, RoundedCornerShape(2.dp))
        )
    }
}
