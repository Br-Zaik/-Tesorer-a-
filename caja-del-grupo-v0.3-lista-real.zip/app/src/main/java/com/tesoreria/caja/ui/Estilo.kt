package com.tesoreria.caja.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Azul medianoche + cian: serio, legible y con estados contables bien diferenciados.
val Fondo = Color(0xFF070A12)
val Panel = Color(0xFF0F1523)
val PanelAlto = Color(0xFF151D30)
val Borde = Color(0xFF26334E)
val Cian = Color(0xFF2DE2E6)
val Violeta = Color(0xFF8B7CF6)
val Verde = Color(0xFF3DD68C)
val Ambar = Color(0xFFF5A524)
val Rojo = Color(0xFFF0525B)
val Texto = Color(0xFFE7EEF9)
val Tenue = Color(0xFF8A99B4)
val Suave = Color(0xFF111A2B)

private val esquema = darkColorScheme(
    primary = Cian,
    onPrimary = Color(0xFF041419),
    background = Fondo,
    onBackground = Texto,
    surface = Panel,
    onSurface = Texto,
    error = Rojo
)

@Composable
fun CajaTheme(contenido: @Composable () -> Unit) {
    MaterialTheme(colorScheme = esquema, content = contenido)
}

/** Cifras de dinero: monoespaciado, como un libro de caja. */
val cifra = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.Medium,
    letterSpacing = 0.sp
)

@Composable
fun Tarjeta(
    modifier: Modifier = Modifier,
    borde: Color = Borde,
    fondo: Color = Panel,
    contenido: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(fondo, RoundedCornerShape(18.dp))
            .border(BorderStroke(1.dp, borde), RoundedCornerShape(18.dp))
            .padding(16.dp),
        content = contenido
    )
}

@Composable
fun Etiqueta(texto: String, color: Color = Tenue) {
    Text(texto, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
fun Titulo(texto: String) {
    Text(texto, color = Texto, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
fun Subtitulo(texto: String) {
    Text(texto, color = Tenue, fontSize = 12.sp)
}

@Composable
fun Boton(
    texto: String,
    modifier: Modifier = Modifier,
    color: Color = Cian,
    relleno: Boolean = true,
    activo: Boolean = true,
    alTocar: () -> Unit
) {
    val fondo = when {
        !activo -> Color.Transparent
        relleno -> color
        else -> Color.Transparent
    }
    val letra = when {
        !activo -> Tenue
        relleno -> Color(0xFF041419)
        else -> color
    }
    Box(
        modifier = modifier
            .height(48.dp)
            .background(fondo, RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, if (activo) color else Borde), RoundedCornerShape(12.dp))
            .clickable(enabled = activo) { alTocar() },
        contentAlignment = Alignment.Center
    ) {
        Text(texto, color = letra, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Campo(
    valor: String,
    alCambiar: (String) -> Unit,
    pista: String,
    modifier: Modifier = Modifier,
    numerico: Boolean = false,
    clave: Boolean = false
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .background(Fondo, RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        if (valor.isEmpty()) Text(pista, color = Tenue.copy(alpha = 0.75f), fontSize = 14.sp)
        BasicTextField(
            value = valor,
            onValueChange = alCambiar,
            singleLine = true,
            textStyle = TextStyle(color = Texto, fontSize = 15.sp),
            cursorBrush = SolidColor(Cian),
            visualTransformation = if (clave) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(
                keyboardType = when {
                    clave -> KeyboardType.Password
                    numerico -> KeyboardType.Decimal
                    else -> KeyboardType.Text
                }
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun Pastilla(texto: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.38f)), RoundedCornerShape(8.dp))
            .padding(horizontal = 9.dp, vertical = 5.dp)
    ) {
        Text(texto, color = color, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun MiniDato(etiqueta: String, valor: String, color: Color) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.22f)), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(etiqueta, color = color, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        Text(valor, color = Texto, fontSize = 13.sp, style = cifra)
    }
}

@Composable
fun FilaEntre(contenido: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        content = contenido
    )
}
