package com.tesoreria.caja.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.EstadoPago
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.delay

@Composable
fun PantallaInicio(irASubir: () -> Unit) {
    val yo = Caja.sesion.value ?: return
    val cobro = Caja.cobroActivo()
    var detalle by remember { mutableStateOf<Int?>(null) }
    var ahora by remember { mutableStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            ahora = System.currentTimeMillis()
            Caja.revisarVencidos()
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Text("Resumen del grupo", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))

        // Saldo protagonista.
        Tarjeta(borde = Cian.copy(alpha = 0.38f), fondo = PanelAlto) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Etiqueta("SALDO DISPONIBLE", Cian)
                    Spacer(Modifier.height(5.dp))
                    Text(soles(Caja.saldo()), color = Texto, fontSize = 34.sp, style = cifra)
                }
                Pastilla("CALCULADO", Cian)
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { MiniDato("INGRESOS", soles(Caja.ingresos()), Verde) }
                Box(Modifier.weight(1f)) { MiniDato("GASTOS", soles(Caja.egresos()), Rojo) }
            }
            Spacer(Modifier.height(11.dp))
            Text(
                "Se calcula con pagos aprobados menos gastos con las dos firmas. No se escribe a mano.",
                color = Tenue, fontSize = 11.sp
            )
        }

        Spacer(Modifier.height(14.dp))

        if (cobro == null) {
            Tarjeta {
                Etiqueta("COBRO ACTUAL")
                Spacer(Modifier.height(7.dp))
                Titulo("No hay cobro abierto")
                Spacer(Modifier.height(6.dp))
                Text(
                    if (Caja.esAdmin) "Puedes abrir uno desde Panel → Cobro."
                    else "Cuando el tesorero abra un cobro aparecerá aquí automáticamente.",
                    color = Tenue, fontSize = 13.sp
                )
            }
            return@Column
        }

        val noEnviaron = Caja.noEnviaron(cobro.id)
        val porRevisar = Caja.porRevisar(cobro.id)
        val rechazados = Caja.rechazados(cobro.id)
        val pagaron = Caja.aprobados(cobro.id)
        val progreso = if (Caja.socios.isEmpty()) 0f else pagaron.toFloat() / Caja.socios.size.toFloat()
        val restante = cobro.cierra - ahora

        // Cobro activo primero: contexto, progreso y plazo.
        Tarjeta(borde = if (restante > 0) Borde else Rojo.copy(alpha = 0.55f)) {
            FilaEntre {
                Column(Modifier.weight(1f)) {
                    Etiqueta("COBRO ACTIVO", Cian)
                    Spacer(Modifier.height(4.dp))
                    Text(cobro.titulo, color = Texto, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                }
                Text(soles(cobro.monto), color = Cian, fontSize = 18.sp, style = cifra)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (restante > 0) "Cierra en ${cuenta(restante)}" else "Plazo vencido",
                color = if (restante > 0) Ambar else Rojo,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(12.dp))
            BarraProgreso(progreso)
            Spacer(Modifier.height(7.dp))
            FilaEntre {
                Text("$pagaron de ${Caja.socios.size} aprobados", color = Tenue, fontSize = 11.sp)
                Text(soles(Caja.recaudado(cobro.id)), color = Verde, fontSize = 12.sp, style = cifra)
            }
        }

        Spacer(Modifier.height(10.dp))

        // Separar estados evita llamar moroso a quien ya envió comprobante.
        when {
            noEnviaron.isEmpty() && porRevisar.isEmpty() && rechazados.isEmpty() ->
                FranjaResumen("✓ Todos al día", "Todos los miembros asignados están aprobados.", Verde)
            else -> {
                if (noEnviaron.isNotEmpty()) {
                    FranjaResumen(
                        "✕ No enviaron (${noEnviaron.size})",
                        noEnviaron.joinToString(", "),
                        Rojo
                    )
                    Spacer(Modifier.height(7.dp))
                }
                if (porRevisar.isNotEmpty()) {
                    FranjaResumen(
                        "• Esperando revisión (${porRevisar.size})",
                        porRevisar.joinToString(", "),
                        Ambar
                    )
                    Spacer(Modifier.height(7.dp))
                }
                if (rechazados.isNotEmpty()) {
                    FranjaResumen(
                        "✕ Deben reenviar (${rechazados.size})",
                        rechazados.joinToString(", "),
                        Rojo
                    )
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        Tarjeta {
            FilaEntre {
                Column {
                    Etiqueta("ESTADO DEL GRUPO")
                    Spacer(Modifier.height(3.dp))
                    Text("Toca un número para ver su estado", color = Tenue, fontSize = 11.sp)
                }
                Text("$pagaron/${Caja.socios.size}", color = Cian, fontSize = 15.sp, style = cifra)
            }
            Spacer(Modifier.height(14.dp))
            Cuadro(cobro.id) { detalle = it }
            Spacer(Modifier.height(14.dp))
            LeyendaCompleta()

            val mio = Caja.estadoDe(cobro.id, yo.numero)
            Spacer(Modifier.height(14.dp))
            EstadoPropio(mio, cobro.id, yo.numero)

            if (mio == EstadoPago.SIN_ENVIAR || mio == EstadoPago.RECHAZADO) {
                Spacer(Modifier.height(12.dp))
                Boton(
                    if (mio == EstadoPago.RECHAZADO) "Volver a enviar comprobante" else "Subir mi comprobante",
                    Modifier.fillMaxWidth()
                ) { irASubir() }
            }
        }
    }

    // A partir de aquí necesitamos un cobro no nulo para el diálogo de detalle.
    if (cobro == null) return

    detalle?.let { n ->
        Dialog(onDismissRequest = { detalle = null }) {
            Tarjeta(borde = Borde, fondo = PanelAlto) {
                val s = Caja.socio(n)
                val p = Caja.pagoDe(cobro.id, n)
                val estado = Caja.estadoDe(cobro.id, n)

                FilaEntre {
                    Column(Modifier.weight(1f)) {
                        Etiqueta("SOCIO N° $n")
                        Spacer(Modifier.height(4.dp))
                        Text(s?.nombre ?: "", color = Texto, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Pastilla(textoEstado(estado), colorDe(estado))
                }

                Spacer(Modifier.height(14.dp))
                if (p == null) {
                    Text("Todavía no ha enviado un comprobante para este cobro.", color = Tenue, fontSize = 13.sp)
                } else {
                    Text("Monto · ${soles(p.monto)}", color = Texto, fontSize = 14.sp, style = cifra)
                    Spacer(Modifier.height(4.dp))
                    Text("Enviado · ${fechaHora(p.enviado)}", color = Tenue, fontSize = 12.sp)

                    // Los datos sensibles del comprobante se reservan para el tesorero en esta maqueta.
                    if (yo.rol == Rol.TESORERO || yo.numero == n) {
                        Spacer(Modifier.height(4.dp))
                        Text("Operación · ${p.operacion}", color = Tenue, fontSize = 12.sp)
                    }
                    if (estado == EstadoPago.RECHAZADO && p.nota.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .background(Rojo.copy(alpha = 0.09f), RoundedCornerShape(10.dp))
                                .border(BorderStroke(1.dp, Rojo.copy(alpha = 0.25f)), RoundedCornerShape(10.dp))
                                .padding(10.dp)
                        ) {
                            Text("Motivo: ${p.nota}", color = Rojo, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false) { detalle = null }
            }
        }
    }
}

@Composable
private fun FranjaResumen(titulo: String, numeros: String, color: Color) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.09f), RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.28f)), RoundedCornerShape(12.dp))
            .padding(horizontal = 13.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(titulo, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.width(9.dp))
        Text(numeros, color = Texto, fontSize = 11.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun BarraProgreso(valor: Float) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(7.dp)
            .background(Borde.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
    ) {
        Box(
            Modifier
                .fillMaxWidth(valor.coerceIn(0f, 1f))
                .height(7.dp)
                .background(Verde, RoundedCornerShape(8.dp))
        )
    }
}

@Composable
fun Cuadro(cobroId: Int, alTocar: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        // Siempre conserva 35 puestos. Los 31–35 quedan visibles como libres hasta asignarlos.
        (1..35).toList().chunked(5).forEach { fila ->
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                fila.forEach { numero ->
                    val asignado = Caja.socio(numero) != null
                    if (!asignado) {
                        Box(
                            Modifier
                                .weight(1f)
                                .height(50.dp)
                                .background(Tenue.copy(alpha = 0.05f), RoundedCornerShape(10.dp))
                                .border(BorderStroke(1.dp, Borde.copy(alpha = 0.55f)), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$numero", color = Tenue, fontSize = 12.sp, style = cifra)
                                Text("LIBRE", color = Tenue, fontSize = 7.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    } else {
                        val estado = Caja.estadoDe(cobroId, numero)
                        val c = colorDe(estado)
                        val borde = if (estado == EstadoPago.RECHAZADO) c else c.copy(alpha = 0.42f)
                        Box(
                            Modifier
                                .weight(1f)
                                .height(50.dp)
                                .background(c.copy(alpha = if (estado == EstadoPago.RECHAZADO) 0.18f else 0.10f), RoundedCornerShape(10.dp))
                                .border(BorderStroke(if (estado == EstadoPago.RECHAZADO) 2.dp else 1.dp, borde), RoundedCornerShape(10.dp))
                                .clickable { alTocar(numero) },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$numero", color = Texto, fontSize = 12.sp, style = cifra)
                                Text(marcaDe(estado), color = c, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LeyendaCompleta() {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Leyenda(Verde, "✓ Aprobado")
            Leyenda(Ambar, "• Por revisar")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Leyenda(Rojo, "✕ No envió")
            Leyenda(Rojo, "▣ Rechazado")
        }
    }
}

@Composable
private fun Leyenda(color: Color, texto: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(color, RoundedCornerShape(3.dp)))
        Spacer(Modifier.width(6.dp))
        Text(texto, color = Tenue, fontSize = 10.sp)
    }
}

@Composable
private fun EstadoPropio(estado: EstadoPago, cobroId: Int, numero: Int) {
    val p = Caja.pagoDe(cobroId, numero)
    val color = colorDe(estado)
    Box(
        Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.24f)), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Column {
            Text("Tu estado · ${textoEstado(estado)}", color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                when (estado) {
                    EstadoPago.APROBADO -> "El tesorero confirmó que el dinero llegó."
                    EstadoPago.PENDIENTE -> "Tu comprobante llegó. Falta que el tesorero lo revise."
                    EstadoPago.RECHAZADO -> "Debes volver a enviar. ${p?.nota.orEmpty()}"
                    EstadoPago.SIN_ENVIAR -> "Aún no has enviado un comprobante para este cobro."
                },
                color = Tenue,
                fontSize = 11.sp
            )
        }
    }
}

fun colorDe(estado: EstadoPago): Color = when (estado) {
    EstadoPago.APROBADO -> Verde
    EstadoPago.PENDIENTE -> Ambar
    EstadoPago.RECHAZADO -> Rojo
    EstadoPago.SIN_ENVIAR -> Rojo
}

fun marcaDe(estado: EstadoPago): String = when (estado) {
    EstadoPago.APROBADO -> "✓"
    EstadoPago.PENDIENTE -> "•"
    EstadoPago.RECHAZADO -> "!"
    EstadoPago.SIN_ENVIAR -> "✕"
}

fun textoEstado(estado: EstadoPago): String = when (estado) {
    EstadoPago.APROBADO -> "Aprobado"
    EstadoPago.PENDIENTE -> "Por revisar"
    EstadoPago.RECHAZADO -> "Rechazado"
    EstadoPago.SIN_ENVIAR -> "No enviado"
}

fun cuenta(ms: Long): String {
    val s = ms.coerceAtLeast(0L) / 1000
    val d = s / 86400
    val h = (s % 86400) / 3600
    val m = (s % 3600) / 60
    val seg = s % 60
    return if (d > 0) "$d d $h h $m min" else "$h h $m min $seg s"
}
