# Caja del Grupo · Tesorería v1.5.0

Versión con firma permanente y actualizador integrado desde GitHub Releases.

- versionCode: 16
- versionName: 1.4.0
- applicationId: com.tesoreria.caja

Consulta `ACTUALIZACIONES_V1_1_0.md` para la configuración única de GitHub Secrets y el flujo de actualización.

---

# Caja del Grupo · Tesorería v1.0.0

Versión 1 enfocada en comprobantes Yape, revisión del tesorero, estabilidad de red y seguridad.

- versionCode: 15
- versionName: 1.0.0
- applicationId: com.tesoreria.caja

Consulta `VALIDACION_V1_0_0.md` para el detalle de cambios.

---

# Tesorería v0.9.0-server

Aplicación Android nativa en Kotlin + Jetpack Compose conectada al proyecto Supabase de Tesorería.

## Cambios principales
- Un solo inicio de sesión por número de lista + contraseña.
- El N.º 22 obtiene permisos de tesorero automáticamente por su rol del servidor.
- Sin pestaña separada "Administrador".
- Estado de pagos usa únicamente el diseño A.
- Solo el tesorero puede aprobar/rechazar Yapes.
- Presidente queda como cargo informativo, sin firma de gastos.
- Datos reales desde Supabase: miembros, cobros, pagos, gastos, actas y bitácora.
- Activación/restablecimiento desde la app mediante código temporal de 6 dígitos.
- Capturas Yape reales a Storage privado, máximo 2 MB.
- Cierre automático de cobros en servidor mediante pg_cron.
- Realtime preparado en servidor; la app sincroniza periódicamente para mantener la UI actualizada.

## Versión
- versionCode: 13
- versionName: 0.9.0-server


## v0.9.1-server-fix
- Corrige compilación Kotlin de Login.kt restaurando FondoAnimado y BarraCarga.
- versionCode 14.
- No se modificaron los workflows de GitHub Actions.


## v1.5.0 · Yape seguro
OCR de apoyo, validación de formato Yape y detección fuerte de comprobantes duplicados.


## v1.5.1 — estabilidad de acceso
El login usa reintentos seguros, evita falsos estados offline y carga el perfil con una sola operación de servidor.


## v1.6.0
Login simplificado, Yape con OCR solo de monto, actas desplegables, QR/número Yape configurable y exportación PDF.
