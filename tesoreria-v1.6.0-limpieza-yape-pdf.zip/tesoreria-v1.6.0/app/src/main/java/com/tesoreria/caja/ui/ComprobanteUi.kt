package com.tesoreria.caja.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Pago
import com.tesoreria.caja.data.soles

@Composable
fun MiniaturaComprobante(
    bitmap: Bitmap?,
    modifier: Modifier = Modifier,
    alTocar: (() -> Unit)? = null
) {
    val base = modifier
        .fillMaxWidth()
        .height(184.dp)
        .background(FondoProfundo, RoundedCornerShape(16.dp))
        .border(1.dp, Borde, RoundedCornerShape(16.dp))
    Box(
        if (alTocar != null) base.clickable { alTocar() } else base,
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null && !bitmap.isRecycled) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Comprobante",
                modifier = Modifier.fillMaxSize().padding(8.dp),
                contentScale = ContentScale.Fit
            )
            if (alTocar != null) {
                Box(
                    Modifier.align(Alignment.BottomEnd).padding(10.dp)
                        .background(PanelAlto.copy(alpha = .94f), RoundedCornerShape(99.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) { Text("Ver completa", color = VerdeBrillante, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            }
        } else {
            Icon(Icons.Rounded.ReceiptLong, null, tint = Tenue, modifier = Modifier.size(42.dp))
        }
    }
}

@Composable
fun VisorBitmapDialog(bitmap: Bitmap, cerrar: () -> Unit) {
    Dialog(
        onDismissRequest = cerrar,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            Modifier.fillMaxSize().background(FondoProfundo.copy(alpha = .78f)).padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier.fillMaxWidth().fillMaxHeight(.92f)
                    .background(PanelAlto, RoundedCornerShape(22.dp))
                    .border(1.dp, Borde, RoundedCornerShape(22.dp))
                    .padding(14.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Comprobante", color = Texto, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    BotonCerrar(cerrar)
                }
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
                        .background(FondoProfundo, RoundedCornerShape(14.dp)).padding(8.dp),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Comprobante completo",
                        modifier = Modifier.fillMaxWidth().heightIn(min = 300.dp),
                        contentScale = ContentScale.FillWidth
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text("Desliza para revisar toda la imagen.", color = Tenue, fontSize = 10.sp)
                Spacer(Modifier.height(8.dp))
                Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
            }
        }
    }
}

@Composable
fun VisorPagoDialog(pago: Pago, cerrar: () -> Unit) {
    var bitmap by remember(pago.serverId) { mutableStateOf<Bitmap?>(null) }
    var error by remember(pago.serverId) { mutableStateOf("") }
    var cargando by remember(pago.serverId) { mutableStateOf(true) }

    LaunchedEffect(pago.serverId) {
        cargando = true
        error = ""
        try {
            val bytes = Caja.comprobanteBytes(pago)
            bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: throw IllegalStateException("No se pudo abrir la captura")
        } catch (e: Exception) {
            error = e.message ?: "No se pudo abrir el comprobante"
        } finally {
            cargando = false
        }
    }

    Dialog(
        onDismissRequest = cerrar,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            Modifier.fillMaxSize().background(FondoProfundo.copy(alpha = .78f)).padding(horizontal = 12.dp, vertical = 18.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier.fillMaxWidth().fillMaxHeight(.94f)
                    .background(PanelAlto, RoundedCornerShape(24.dp))
                    .border(1.dp, Borde, RoundedCornerShape(24.dp))
                    .padding(14.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Etiqueta("COMPROBANTE YAPE", VerdeBrillante)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "N.º ${pago.socio} · ${Caja.socio(pago.socio)?.nombre.orEmpty()}",
                            color = Texto,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    BotonCerrar(cerrar)
                }
                Spacer(Modifier.height(10.dp))

                // Solo esta zona se desplaza. El encabezado y el botón Cerrar siempre quedan visibles.
                Column(
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
                        .padding(end = 2.dp)
                ) {
                    when {
                        cargando -> Box(
                            Modifier.fillMaxWidth().height(150.dp).background(FondoProfundo, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Abriendo comprobante…", color = Tenue, fontSize = 12.sp)
                        }
                        bitmap != null -> Box(
                            Modifier.fillMaxWidth().background(FondoProfundo, RoundedCornerShape(14.dp)).padding(7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                bitmap = bitmap!!.asImageBitmap(),
                                contentDescription = "Captura enviada",
                                modifier = Modifier.fillMaxWidth().heightIn(min = 230.dp, max = 410.dp),
                                contentScale = ContentScale.Fit
                            )
                        }
                        else -> Box(
                            Modifier.fillMaxWidth().height(150.dp).background(FondoProfundo, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Rounded.BrokenImage, null, tint = Rojo, modifier = Modifier.size(34.dp))
                                Spacer(Modifier.height(7.dp))
                                Text(error.ifBlank { "No hay imagen disponible" }, color = Rojo, fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    MiniDato("MONTO", soles(pago.monto), Verde)
                    Spacer(Modifier.height(7.dp))
                    MiniDato("N.º DE OPERACIÓN", pago.operacion.ifBlank { "No detectado" }, Cian)
                    Spacer(Modifier.height(7.dp))
                    Text("Fecha, hora y código se revisan directamente en la imagen original.", color = Tenue, fontSize = 10.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Puedes deslizar hacia abajo para revisar la captura completa.", color = Tenue, fontSize = 10.sp)
                    Spacer(Modifier.height(4.dp))
                }

                Spacer(Modifier.height(10.dp))
                Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
            }
        }
    }
}

@Composable
private fun BotonCerrar(cerrar: () -> Unit) {
    Box(
        Modifier.size(38.dp).background(FondoProfundo, CircleShape)
            .border(1.dp, Borde, CircleShape).clickable { cerrar() },
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.Close, "Cerrar", tint = Texto, modifier = Modifier.size(20.dp))
    }
}
