package com.tesoreria.caja.data

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date

object PdfExporter {
    fun compartirActa(context: Context, acta: Acta, admin: Boolean) {
        val lineas = mutableListOf<String>()
        val cobro = Caja.cobros.firstOrNull { it.id == acta.cobroId }
        lineas += "ACTA DE COBRO CERRADO"
        lineas += "Cobro: ${acta.titulo}"
        lineas += "Cuota: ${soles(acta.monto)}"
        lineas += "Recaudado: ${soles(acta.recaudado)}"
        cobro?.let {
            lineas += "Apertura: ${fechaHora(it.creado)}"
            lineas += "Cierre programado: ${fechaHora(it.cierra)}"
        }
        lineas += "Cierre real: ${fechaHora(acta.cierre)}"
        cobro?.let { lineas += "Duración: ${duracion(it.cierra - it.creado)}" }
        lineas += ""
        fun grupo(titulo: String, estado: EstadoPago) {
            val numeros = acta.estados.filterValues { it == estado }.keys.sorted()
            lineas += "$titulo (${numeros.size})"
            if (admin) {
                if (numeros.isEmpty()) lineas += "  - Ninguno"
                numeros.forEach { n ->
                    val d = acta.detalles[n]
                    val nombre = d?.nombreSnapshot?.ifBlank { Caja.socio(n)?.nombre.orEmpty() } ?: Caja.socio(n)?.nombre.orEmpty()
                    val pago = Caja.pagos.filter { it.cobroId == acta.cobroId && it.socio == n }.maxByOrNull { it.enviado }
                    val info = buildList {
                        add("N° $n")
                        if (nombre.isNotBlank()) add(nombre)
                        pago?.let { add(soles(it.monto)); add(if (it.medio == MedioPago.MANUAL) "Manual" else "Yape"); if (it.operacion.isNotBlank()) add("Op. ${it.operacion}"); add(fechaHora(it.enviado)) }
                    }.joinToString(" · ")
                    lineas += "  - $info"
                }
            } else {
                lineas += if (numeros.isEmpty()) "  - Ninguno" else "  - " + numeros.joinToString(", ") { "N° $it" }
            }
            lineas += ""
        }
        grupo("Pagaron", EstadoPago.APROBADO)
        grupo("Pendientes", EstadoPago.PENDIENTE)
        grupo("Rechazados", EstadoPago.RECHAZADO)
        grupo("No enviaron", EstadoPago.SIN_ENVIAR)
        compartirPdf(context, "acta-${limpio(acta.titulo)}.pdf", lineas)
    }

    fun compartirBitacora(context: Context, admin: Boolean) {
        val eventos = if (admin) Caja.bitacora else Caja.bitacoraPublica()
        val lineas = mutableListOf<String>()
        lineas += "BITÁCORA DE TESORERÍA"
        lineas += "Generado: ${fechaHora(System.currentTimeMillis())}"
        lineas += "Eventos: ${eventos.size}"
        lineas += ""
        if (eventos.isEmpty()) lineas += "No hay eventos registrados."
        eventos.forEachIndexed { i, e -> lineas += "${i + 1}. $e" }
        compartirPdf(context, "bitacora-tesoreria.pdf", lineas)
    }

    private fun compartirPdf(context: Context, nombre: String, lineas: List<String>) {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, nombre)
        val doc = PdfDocument()
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 55, 35); textSize = 18f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(25, 25, 25); textSize = 10.5f }
        val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(90, 90, 90); textSize = 8.5f }
        val pageW = 595
        val pageH = 842
        val left = 42f
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
        var y = 48f
        fun footer() {
            page.canvas.drawText("Tesorería · Respaldo PDF · Página $pageNo", left, pageH - 28f, small)
        }
        fun newPage() {
            footer()
            doc.finishPage(page)
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
            y = 48f
        }
        lineas.forEachIndexed { idx, raw ->
            val paint = if (idx == 0) title else body
            val wrapped = wrap(raw, if (idx == 0) 54 else 92)
            wrapped.forEach { linea ->
                if (y > pageH - 58f) newPage()
                page.canvas.drawText(linea, left, y, paint)
                y += if (idx == 0) 24f else 16f
            }
            if (raw.isBlank()) y += 4f
        }
        footer()
        doc.finishPage(page)
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Compartir PDF"))
    }

    private fun wrap(text: String, max: Int): List<String> {
        if (text.isBlank()) return listOf("")
        val out = mutableListOf<String>()
        var line = ""
        text.split(" ").forEach { word ->
            if ((line.length + word.length + 1) > max && line.isNotBlank()) {
                out += line
                line = word
            } else line = if (line.isBlank()) word else "$line $word"
        }
        if (line.isNotBlank()) out += line
        return out
    }

    private fun limpio(v: String): String = v.lowercase(PE).replace(Regex("[^a-z0-9]+"), "-").trim('-').ifBlank { "cobro" }
    private fun duracion(ms: Long): String {
        val min = (ms / 60000L).coerceAtLeast(0)
        val h = min / 60
        val m = min % 60
        return if (h > 0) "$h h $m min" else "$m min"
    }
}
