package com.tesoreria.caja.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja

@Composable
fun YapeInfoUsuarioCard(compacta: Boolean = false) {
    val config = Caja.yapeConfig.value
    val clipboard = LocalClipboardManager.current
    var bitmap by remember(config.qrPath) { mutableStateOf<Bitmap?>(null) }
    var aviso by remember { mutableStateOf("") }

    LaunchedEffect(config.qrPath) {
        bitmap = null
        if (config.qrPath.isNotBlank()) {
            runCatching {
                val bytes = Caja.qrYapeBytes()
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }.onSuccess { bitmap = it }
        }
    }

    if (config.numeroYape.isBlank() && config.qrPath.isBlank()) return

    Tarjeta(borde = Verde.copy(alpha = .30f), fondo = PanelAlto) {
        Etiqueta("DATOS PARA YAPE", Verde)
        Spacer(Modifier.height(6.dp))
        Text("Usa estos datos para pagar. No se pueden editar desde cuentas normales.", color = Tenue, fontSize = 10.sp)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.size(if (compacta) 82.dp else 104.dp)
                    .background(FondoProfundo, RoundedCornerShape(14.dp))
                    .border(1.dp, Borde, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (bitmap != null) {
                    Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "QR Yape", modifier = Modifier.fillMaxSize().padding(6.dp), contentScale = ContentScale.Fit)
                } else {
                    Icon(Icons.Rounded.QrCode2, null, tint = Tenue, modifier = Modifier.size(38.dp))
                }
            }
            Column(Modifier.weight(1f)) {
                Text("Número Yape", color = Tenue, fontSize = 10.sp)
                Spacer(Modifier.height(3.dp))
                Text(config.numeroYape.ifBlank { "No configurado" }, color = Texto, fontSize = 20.sp, style = cifra, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Boton("Copiar número", Modifier.fillMaxWidth(), relleno = false, color = Cian, activo = config.numeroYape.isNotBlank()) {
                    clipboard.setText(AnnotatedString(config.numeroYape))
                    aviso = "Número copiado"
                }
            }
        }
        if (aviso.isNotBlank()) {
            Spacer(Modifier.height(7.dp))
            Text(aviso, color = Verde, fontSize = 10.sp)
        }
    }
}
