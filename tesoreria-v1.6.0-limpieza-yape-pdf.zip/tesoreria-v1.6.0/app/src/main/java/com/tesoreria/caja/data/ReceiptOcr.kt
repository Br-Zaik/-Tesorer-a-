package com.tesoreria.caja.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

/** OCR local reducido: solo sugiere el monto. La imagen es la prueba principal. */
object ReceiptOcr {
    data class Resultado(
        val bytes: ByteArray,
        val mime: String,
        val bitmap: Bitmap,
        val monto: String,
        val operacion: String,
        val fecha: String,
        val hora: String,
        val codigoSeguridad: String,
        val textoDetectado: String,
        val esYape: Boolean,
        val confianzaYape: Int,
        val capturaDHash: Long
    )

    suspend fun leer(context: Context, uri: Uri): Resultado = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val mime = resolver.getType(uri)?.lowercase(Locale.ROOT) ?: "image/jpeg"
        if (mime !in setOf("image/jpeg", "image/png", "image/webp", "image/heic", "image/heif")) {
            throw IllegalStateException("Selecciona una imagen de Yape")
        }
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("No se pudo abrir la imagen")
        if (bytes.isEmpty()) throw IllegalStateException("La imagen está vacía")
        if (bytes.size > 10 * 1024 * 1024) throw IllegalStateException("La imagen supera 10 MB")

        val bitmap = decodificar(bytes) ?: throw IllegalStateException("No se pudo leer la captura")

        // Primera pasada: imagen original. Si faltan campos importantes, se hace una segunda
        // pasada ampliada y con mayor contraste. Esto mejora bastante el texto pequeño de Yape.
        val texto1 = reconocer(bitmap)
        var combinado = limpiarTexto(texto1)
        var lineas = lineasUtiles(combinado)
        var monto = extraerMonto(combinado)
        val operacion = ""
        val fecha = ""
        val hora = ""
        val codigo = ""

        val necesitaRefuerzo = monto.isBlank()
        if (necesitaRefuerzo) {
            val mejorado = mejorarParaOcr(bitmap)
            try {
                val texto2 = reconocer(mejorado)
                combinado = combinarTextos(combinado, limpiarTexto(texto2))
                lineas = lineasUtiles(combinado)
                if (monto.isBlank()) monto = extraerMonto(combinado)
            } finally {
                if (mejorado !== bitmap && !mejorado.isRecycled) mejorado.recycle()
            }
        }

        val evaluacionYape = evaluarComprobanteYape(combinado, monto, operacion, fecha, hora, codigo)
        val dhash = calcularDHash(bitmap)

        Resultado(
            bytes = bytes,
            mime = normalizarMime(mime),
            bitmap = bitmap,
            monto = monto,
            operacion = operacion,
            fecha = fecha,
            hora = hora,
            codigoSeguridad = codigo,
            textoDetectado = combinado,
            esYape = evaluacionYape.first,
            confianzaYape = evaluacionYape.second,
            capturaDHash = dhash
        )
    }

    private fun reconocer(bitmap: Bitmap): String {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        return try {
            val task = recognizer.process(InputImage.fromBitmap(bitmap, 0))
            Tasks.await(task, 12, TimeUnit.SECONDS).text.orEmpty()
        } catch (_: Exception) {
            ""
        } finally {
            recognizer.close()
        }
    }

    private fun limpiarTexto(v: String): String = v
        .replace('\r', '\n')
        .replace(Regex("[\\t ]+"), " ")
        .replace(Regex("\\n{2,}"), "\n")
        .trim()

    private fun lineasUtiles(texto: String): List<String> = texto.lines().map { it.trim() }.filter { it.isNotBlank() }

    private fun combinarTextos(a: String, b: String): String {
        val vistas = LinkedHashSet<String>()
        (lineasUtiles(a) + lineasUtiles(b)).forEach { linea ->
            val clave = normalizar(linea)
            if (clave.isNotBlank() && vistas.none { normalizar(it) == clave }) vistas += linea
        }
        return vistas.joinToString("\n")
    }

    private fun normalizarMime(v: String): String = when (v) {
        "image/png" -> "image/png"
        "image/webp" -> "image/webp"
        else -> "image/jpeg"
    }

    private fun decodificar(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > 2800) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null
        val orientation = runCatching {
            ExifInterface(ByteArrayInputStream(bytes)).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
        }
        if (matrix.isIdentity) return decoded
        val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (rotated !== decoded && !decoded.isRecycled) decoded.recycle()
        return rotated
    }

    private fun mejorarParaOcr(original: Bitmap): Bitmap {
        val ladoMayor = max(original.width, original.height).coerceAtLeast(1)
        val escala = min(1.65f, 3200f / ladoMayor.toFloat()).coerceAtLeast(1.12f)
        val w = (original.width * escala).toInt().coerceAtLeast(1)
        val h = (original.height * escala).toInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val matrix = Matrix().apply { setScale(escala, escala) }
        val contrast = 1.18f
        val translate = (-.5f * contrast + .5f) * 255f
        val color = ColorMatrix().apply {
            set(floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            ))
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(color)
        }
        canvas.drawBitmap(original, matrix, paint)
        return out
    }

    private fun normalizar(s: String): String = Normalizer.normalize(s, Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .lowercase(Locale.ROOT)
        .replace('º', 'o')
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun candidatosNumericos(linea: String, minLen: Int, maxLen: Int): List<String> {
        // Trabaja por segmentos para no convertir letras del rótulo en números.
        val segmentos = Regex("[0-9OQDIL|SBZG][0-9OQDIL|SBZG ._-]{2,24}", RegexOption.IGNORE_CASE)
            .findAll(linea).map { it.value }.toList()
        return segmentos.mapNotNull { seg ->
            val convertido = buildString {
                seg.forEach { c ->
                    append(
                        when (c.uppercaseChar()) {
                            in '0'..'9' -> c
                            'O', 'Q', 'D' -> '0'
                            'I', 'L', '|' -> '1'
                            'Z' -> '2'
                            'S' -> '5'
                            'G' -> '6'
                            'B' -> '8'
                            else -> ' '
                        }
                    )
                }
            }.filter(Char::isDigit)
            convertido.takeIf { it.length in minLen..maxLen }
        }.distinct()
    }

    private fun extraerMonto(texto: String): String {
        val patrones = listOf(
            Regex("(?i)S\\s*/\\s*\\.?\\s*([0-9]{1,7}(?:[.,][0-9]{1,2})?)"),
            Regex("(?i)(?:importe|monto)\\s*[:=-]?\\s*S?\\s*/?\\s*([0-9]{1,7}(?:[.,][0-9]{1,2})?)")
        )
        for (regex in patrones) {
            regex.findAll(texto).forEach { m ->
                val raw = m.groupValues[1].replace(',', '.')
                val n = raw.toDoubleOrNull()
                if (n != null && n > 0.0 && n < 1_000_000.0) return raw
            }
        }
        return ""
    }

    private fun extraerOperacion(lineas: List<String>, texto: String): String {
        val directo = Regex(
            "(?i)(?:n(?:ro|ro\\.|umero|úmero)?\\s*(?:de\\s*)?)?operaci[oó0]n\\s*[:#.-]?\\s*([0-9][0-9 .-]{5,22})"
        ).find(texto)?.groupValues?.getOrNull(1)?.filter(Char::isDigit)
        if (!directo.isNullOrBlank() && directo.length in 6..20) return directo

        val indices = lineas.indices.filter { i ->
            val n = normalizar(lineas[i])
            n.contains("operacion") || n.contains("operaci0n") ||
                (n.contains("nro") && n.contains("oper")) ||
                (n.contains("numero") && n.contains("oper"))
        }
        for (idx in indices) {
            for (i in idx..minOf(idx + 4, lineas.lastIndex)) {
                val cand = candidatosNumericos(lineas[i], 6, 20)
                if (cand.isNotEmpty()) return cand.maxByOrNull { it.length }.orEmpty()
            }
        }

        // Yape suele colocar "Datos de la transacción" seguido por celular, destino y operación.
        val datosIdx = lineas.indexOfFirst { normalizar(it).contains("datos de la transaccion") }
        if (datosIdx >= 0) {
            for (i in datosIdx..minOf(datosIdx + 8, lineas.lastIndex)) {
                val n = normalizar(lineas[i])
                if (n.contains("celular") || n.contains("seguridad")) continue
                val cand = candidatosNumericos(lineas[i], 7, 12)
                if (cand.isNotEmpty()) return cand.maxByOrNull { it.length }.orEmpty()
            }
        }
        return ""
    }

    private fun extraerCodigo(lineas: List<String>, texto: String): String {
        Regex("(?is)c[oó0]digo\\s+(?:de\\s+)?seguridad[^0-9]{0,40}([0-9](?:[ .-]*[0-9]){2})")
            .find(texto)?.groupValues?.getOrNull(1)?.filter(Char::isDigit)?.takeIf { it.length == 3 }?.let { return it }
        val idx = lineas.indexOfFirst { normalizar(it).contains("seguridad") }
        if (idx >= 0) {
            for (i in idx..minOf(idx + 4, lineas.lastIndex)) {
                candidatosNumericos(lineas[i], 3, 3).firstOrNull()?.let { return it }
                val sueltos = Regex("(?<!\\d)(\\d)\\s+(\\d)\\s+(\\d)(?!\\d)").find(lineas[i])
                if (sueltos != null) return sueltos.groupValues.drop(1).joinToString("")
            }
        }
        return ""
    }

    private fun extraerFecha(texto: String): String {
        Regex("\\b(\\d{1,2})[/-](\\d{1,2})[/-](\\d{2,4})\\b").find(texto)?.let { m ->
            val d = m.groupValues[1].toIntOrNull() ?: return@let
            val mo = m.groupValues[2].toIntOrNull() ?: return@let
            var y = m.groupValues[3].toIntOrNull() ?: return@let
            if (y in 0..99) y += 2000
            if (d in 1..31 && mo in 1..12 && y in 2020..2100) return "%02d/%02d/%04d".format(d, mo, y)
        }
        val meses = mapOf(
            "ene" to 1, "feb" to 2, "mar" to 3, "abr" to 4, "may" to 5, "jun" to 6,
            "jul" to 7, "ago" to 8, "sep" to 9, "sept" to 9, "set" to 9,
            "oct" to 10, "nov" to 11, "dic" to 12
        )
        Regex("(?i)\\b(\\d{1,2})\\s+(ene|feb|mar|abr|may|jun|jul|ago|sep|sept|set|oct|nov|dic)\\.?\\s+(\\d{4})\\b")
            .find(texto)?.let { m ->
                val d = m.groupValues[1].toIntOrNull() ?: return@let
                val mo = meses[m.groupValues[2].lowercase(Locale.ROOT)] ?: return@let
                val y = m.groupValues[3].toIntOrNull() ?: return@let
                if (d in 1..31 && y in 2020..2100) return "%02d/%02d/%04d".format(d, mo, y)
            }
        return ""
    }

    private fun extraerHora(texto: String): String {
        Regex("(?i)\\b(\\d{1,2})[:.]([0-5]\\d)\\s*([ap])\\s*\\.?\\s*m\\.?").find(texto)?.let { m ->
            var h = m.groupValues[1].toIntOrNull() ?: return@let
            val min = m.groupValues[2].toIntOrNull() ?: return@let
            val ap = m.groupValues[3].lowercase(Locale.ROOT)
            if (h !in 1..12 || min !in 0..59) return@let
            if (ap == "p" && h != 12) h += 12
            if (ap == "a" && h == 12) h = 0
            return "%02d:%02d".format(h, min)
        }
        Regex("\\b([01]?\\d|2[0-3])[:.]([0-5]\\d)\\b").find(texto)?.let { m ->
            return "%02d:%02d".format(m.groupValues[1].toInt(), m.groupValues[2].toInt())
        }
        return ""
    }


    /**
     * Valida estructura de un comprobante Yape sin usar el OCR para aprobar pagos.
     * Solo bloquea imágenes claramente ajenas a Yape. La aprobación final sigue siendo del tesorero.
     */
    private fun evaluarComprobanteYape(
        texto: String,
        monto: String,
        operacion: String,
        fecha: String,
        hora: String,
        codigo: String
    ): Pair<Boolean, Int> {
        val n = normalizar(texto)
        var score = 0
        val marcaYape = n.contains("yape") || n.contains("yapeaste") || n.contains("yapear")
        val tieneOperacion = n.contains("operacion") || n.contains("operaci0n")
        val tieneSeguridad = n.contains("codigo de seguridad") || n.contains("seguridad")
        val tieneTransaccion = n.contains("datos de la transaccion") || n.contains("transaccion")
        val tieneSoles = n.contains("s/") || n.contains("s /") || n.contains("soles")

        if (marcaYape) score += 4
        if (tieneOperacion) score += 2
        if (tieneSeguridad) score += 2
        if (tieneTransaccion) score += 2
        if (tieneSoles || monto.isNotBlank()) score += 1
        if (operacion.isNotBlank()) score += 1
        if (fecha.isNotBlank()) score += 1
        if (hora.isNotBlank()) score += 1
        if (codigo.isNotBlank()) score += 1

        // Una captura Yape normal supera holgadamente este umbral. Si el logotipo no fue
        // reconocido, se exige la estructura característica operación/transacción/seguridad.
        val estructuraFuerte = tieneOperacion && (tieneSeguridad || tieneTransaccion) &&
            (monto.isNotBlank() || tieneSoles)
        val valido = (marcaYape && score >= 6) || (!marcaYape && estructuraFuerte && score >= 7)
        return valido to score
    }

    /** dHash de 64 bits para detectar la misma captura aunque haya sido recomprimida o retocada levemente. */
    private fun calcularDHash(bitmap: Bitmap): Long {
        val reducido = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
        return try {
            var hash = 0L
            var bit = 0
            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    val a = reducido.getPixel(x, y)
                    val b = reducido.getPixel(x + 1, y)
                    val ga = ((android.graphics.Color.red(a) * 299) +
                        (android.graphics.Color.green(a) * 587) +
                        (android.graphics.Color.blue(a) * 114)) / 1000
                    val gb = ((android.graphics.Color.red(b) * 299) +
                        (android.graphics.Color.green(b) * 587) +
                        (android.graphics.Color.blue(b) * 114)) / 1000
                    if (ga > gb) hash = hash or (1L shl bit)
                    bit++
                }
            }
            hash
        } finally {
            if (reducido !== bitmap && !reducido.isRecycled) reducido.recycle()
        }
    }

    fun fechaHoraIso(fecha: String, hora: String): String? {
        if (fecha.isBlank() || hora.isBlank()) return null
        return runCatching {
            val f = SimpleDateFormat("dd/MM/yyyy HH:mm", PE).apply { isLenient = false }
            val date = f.parse("${fecha.trim()} ${hora.trim()}") ?: return@runCatching null
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(date)
        }.getOrNull()
    }
}
