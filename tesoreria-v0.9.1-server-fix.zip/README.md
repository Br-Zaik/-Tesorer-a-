# Tesorería v0.9.0-server

Aplicación Android nativa en Kotlin + Jetpack Compose conectada al proyecto Supabase de Tesorería.

## Cambios principales
- Un solo inicio de sesión por número de lista + contraseña.
- El N.º 22 obtiene permisos de tesorero automáticamente por su rol del servidor.
- Sin pestaña separada "Administrador".
- Estado de pagos usa únicamente el diseño A.
- Solo el tesorero puede aprobar/rechazar Yapes.
- Presidente queda como cargo informativo, sin firma de gastos.
- Datos reales desde Supabase: miembros, cobros, pagos, gastos, actas y bitácora.
- Activación/restablecimiento desde la app mediante código temporal de 6 dígitos.
- Capturas Yape reales a Storage privado, máximo 2 MB.
- Cierre automático de cobros en servidor mediante pg_cron.
- Realtime preparado en servidor; la app sincroniza periódicamente para mantener la UI actualizada.

## Versión
- versionCode: 13
- versionName: 0.9.0-server


## v0.9.1-server-fix
- Corrige compilación Kotlin de Login.kt restaurando FondoAnimado y BarraCarga.
- versionCode 14.
- No se modificaron los workflows de GitHub Actions.
