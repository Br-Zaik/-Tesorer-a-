# Tesorería v1.1.0 · Firma permanente + actualizaciones

- versionCode: 16
- versionName: 1.1.0
- applicationId: com.tesoreria.caja

## Firma permanente
GitHub Actions ahora debe compilar `assembleRelease` con una firma permanente guardada en GitHub Secrets.
Nunca guardar el keystore o sus contraseñas dentro del repositorio/ZIP público.

Secrets requeridos:
- KEYSTORE_BASE64
- KEYSTORE_PASSWORD
- KEY_ALIAS
- KEY_PASSWORD

El workflow reconstruye el keystore solo dentro del runner temporal y lo elimina al terminar el job.

## Actualizador integrado
La APK consulta el último GitHub Release del mismo repositorio desde el que fue compilada.
El repositorio se inyecta automáticamente usando `GITHUB_REPOSITORY` durante GitHub Actions.

Cuando encuentra un release con tag:
`tesoreria-v<VERSION_NAME>-vc<VERSION_CODE>`

y un asset `.apk`, muestra un cuadro dentro de la app para descargar e instalar la actualización.

Antes de abrir el instalador se comprueba:
- packageName correcto (`com.tesoreria.caja`)
- versionCode esperado
- Android exige la misma firma criptográfica al instalar encima

Android siempre muestra su confirmación normal de instalación.
En Android 8+ el usuario debe habilitar una sola vez “Permitir desde esta fuente” para Tesorería.

## GitHub Release automático
`auto-build-zip.yml`:
1. detecta el ZIP subido;
2. extrae el proyecto;
3. reconstruye la firma desde GitHub Secrets;
4. compila APK release;
5. sube el APK como artifact;
6. crea/actualiza un GitHub Release con `tesoreria.apk`.

La app usa ese Release para detectar y descargar futuras versiones.
