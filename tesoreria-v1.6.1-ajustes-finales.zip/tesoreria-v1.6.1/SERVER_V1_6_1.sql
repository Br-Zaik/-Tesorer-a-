-- Aplicado en Supabase para Tesorería v1.6.1
update public.yape_config set qr_path = '' where id = 'principal';

create or replace function public.guardar_yape_config(p_numero_yape text, p_qr_path text default null)
returns void
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_actor smallint;
  v_numero text;
begin
  v_actor := public.mi_numero();
  if v_actor is null then raise exception 'Debes iniciar sesión'; end if;
  if not public.es_tesorero() then raise exception 'No tienes permiso'; end if;

  v_numero := left(regexp_replace(coalesce(p_numero_yape,''), '[^0-9]', '', 'g'), 9);
  if char_length(v_numero) <> 9 then raise exception 'Escribe un número Yape válido de 9 dígitos'; end if;

  insert into public.yape_config(id, numero_yape, qr_path, actualizado_por, actualizado_at)
  values ('principal', v_numero, '', v_actor, now())
  on conflict (id) do update set
    numero_yape = excluded.numero_yape,
    qr_path = '',
    actualizado_por = excluded.actualizado_por,
    actualizado_at = now();
end;
$function$;
