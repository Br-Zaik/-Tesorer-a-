# Caja del Grupo v1.0
# R8 ya ofusca el código release; estas reglas conservan metadatos usados por Compose/ML Kit.
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-dontwarn com.google.mlkit.**
-dontwarn org.json.**
