package com.tesoreria.caja.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateOf

/**
 * El monitor sirve para la UI, pero NO decide si una petición puede salir.
 * Android puede tardar unos instantes en marcar una red como VALIDATED aunque
 * Supabase ya sea accesible. Las peticiones reales son la fuente de verdad.
 */
object NetworkMonitor {
    val conectado = mutableStateOf(false)

    private var initialized = false
    private var cm: ConnectivityManager? = null
    private val main = Handler(Looper.getMainLooper())

    @Synchronized
    fun initialize(context: Context) {
        if (initialized) return
        initialized = true
        val manager = context.applicationContext
            .getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm = manager

        fun actualizar() {
            main.post { conectado.value = hayRutaDeRed() }
        }

        actualizar()
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = actualizar()
            override fun onLost(network: Network) = actualizar()
            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) = actualizar()
        }

        runCatching { manager.registerDefaultNetworkCallback(callback) }
            .recoverCatching {
                manager.registerNetworkCallback(
                    NetworkRequest.Builder()
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        .build(),
                    callback
                )
            }
    }

    /** Red disponible físicamente. No exige VALIDATED para evitar falsos offline. */
    fun hayRutaDeRed(): Boolean {
        val manager = cm ?: return false
        val activo = manager.activeNetwork ?: return false
        val caps = manager.getNetworkCapabilities(activo) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** Una respuesta real del servidor confirma Internet aunque Android aún no lo haya validado. */
    fun reportarExito() {
        main.post { conectado.value = true }
    }

    /** Solo se marca offline cuando Android confirma que ya no existe ruta de red. */
    fun reportarFallo() {
        if (!hayRutaDeRed()) main.post { conectado.value = false }
    }
}
