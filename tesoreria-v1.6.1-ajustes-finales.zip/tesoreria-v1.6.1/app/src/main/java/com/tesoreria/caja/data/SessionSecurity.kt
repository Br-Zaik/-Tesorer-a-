package com.tesoreria.caja.data

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock

/**
 * Cierre local de sesión por inactividad, similar a una app financiera.
 * Se guarda la última interacción para que también funcione si Android mata
 * el proceso mientras la app está en segundo plano.
 */
object SessionSecurity {
    private const val PREFS = "tesoreria_session_security"
    private const val KEY_LAST_ACTIVE = "last_active_wall_ms"
    private const val KEY_LAST_WRITE = "last_write_elapsed_ms"
    private const val KEY_SESSION_ACTIVE = "session_active"
    private const val DEFAULT_TIMEOUT_SECONDS = 300

    @Volatile private var prefs: SharedPreferences? = null
    @Volatile private var timeoutMs: Long = DEFAULT_TIMEOUT_SECONDS * 1000L
    @Volatile private var lastActiveWallMs: Long = 0L
    @Volatile private var lastWriteElapsedMs: Long = 0L
    @Volatile private var pendingReason: String? = null

    fun initialize(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        lastActiveWallMs = p.getLong(KEY_LAST_ACTIVE, 0L)
        lastWriteElapsedMs = p.getLong(KEY_LAST_WRITE, 0L)
    }

    fun hasTrackedSession(): Boolean = prefs?.getBoolean(KEY_SESSION_ACTIVE, false) == true

    fun configureTimeout(seconds: Int) {
        // Evita configuraciones accidentales demasiado cortas o absurdamente largas.
        timeoutMs = seconds.coerceIn(60, 3600) * 1000L
    }

    fun recordInteraction(forcePersist: Boolean = false) {
        val nowWall = System.currentTimeMillis()
        val nowElapsed = SystemClock.elapsedRealtime()
        lastActiveWallMs = nowWall

        if (forcePersist || nowElapsed - lastWriteElapsedMs >= 15_000L) {
            lastWriteElapsedMs = nowElapsed
            prefs?.edit()
                ?.putLong(KEY_LAST_ACTIVE, nowWall)
                ?.putLong(KEY_LAST_WRITE, nowElapsed)
                ?.apply()
        }
    }

    fun expired(): Boolean {
        val last = lastActiveWallMs
        if (last <= 0L) return false
        val delta = System.currentTimeMillis() - last
        // Si el reloj del dispositivo retrocede, no cerrar por error.
        return delta >= timeoutMs && delta >= 0L
    }

    fun markLogin() {
        prefs?.edit()?.putBoolean(KEY_SESSION_ACTIVE, true)?.apply()
        recordInteraction(forcePersist = true)
    }

    fun markLogout() {
        prefs?.edit()?.putBoolean(KEY_SESSION_ACTIVE, false)?.apply()
        resetClock()
    }

    fun markInactivityLogout() {
        pendingReason = "Sesión cerrada por inactividad. Vuelve a iniciar sesión."
        prefs?.edit()?.putBoolean(KEY_SESSION_ACTIVE, false)?.apply()
        resetClock()
    }

    fun consumeReason(): String? = pendingReason.also { pendingReason = null }

    fun resetClock() {
        val now = System.currentTimeMillis()
        lastActiveWallMs = now
        prefs?.edit()?.putLong(KEY_LAST_ACTIVE, now)?.apply()
    }
}
