package com.tesoreria.caja.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.BuildConfig
import com.tesoreria.caja.data.UpdateManager

@Composable
fun DialogoActualizacion(
    context: Context,
    info: UpdateManager.UpdateInfo,
    descargando: Boolean,
    progreso: Float,
    error: String?,
    onActualizar: () -> Unit,
    onMasTarde: () -> Unit
) {
    Dialog(onDismissRequest = { if (!info.obligatoria && !descargando) onMasTarde() }) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(PanelAlto, RoundedCornerShape(24.dp))
                .border(androidx.compose.foundation.BorderStroke(1.dp, VerdeNeon.copy(alpha = .42f)), RoundedCornerShape(24.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(54.dp).background(VerdeNeon.copy(alpha = .10f), RoundedCornerShape(17.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Download, null, tint = VerdeNeon, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.height(14.dp))
            Text(
                if (info.obligatoria) "Nueva actualización disponible" else "Actualización disponible",
                color = Texto,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(Modifier.height(5.dp))
            Text("Tesorería ${info.versionName}", color = Tenue, fontSize = 13.sp)

            if (descargando) {
                Spacer(Modifier.height(18.dp))
                LinearProgressIndicator(
                    progress = { progreso.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = VerdeNeon,
                    trackColor = FondoProfundo
                )
                Spacer(Modifier.height(7.dp))
                Text("Descargando ${(progreso * 100).toInt()}%", color = Tenue, fontSize = 11.sp)
            }

            if (!error.isNullOrBlank()) {
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier.fillMaxWidth().background(Rojo.copy(alpha = .08f), RoundedCornerShape(12.dp)).padding(10.dp)
                ) { Text(error, color = Rojo, fontSize = 11.sp) }
            }

            Spacer(Modifier.height(18.dp))
            Boton(
                if (descargando) "Descargando…" else "Actualizar ahora",
                Modifier.fillMaxWidth(),
                activo = !descargando
            ) { onActualizar() }

            if (!info.obligatoria) {
                Spacer(Modifier.height(8.dp))
                Boton("Más tarde", Modifier.fillMaxWidth(), relleno = false, color = Tenue, activo = !descargando) { onMasTarde() }
            }
        }
    }
}
