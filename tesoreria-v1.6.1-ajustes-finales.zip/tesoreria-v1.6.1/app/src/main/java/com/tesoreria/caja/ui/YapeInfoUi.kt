package com.tesoreria.caja.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja

@Composable
fun YapeInfoUsuarioCard(compacta: Boolean = false) {
    val numero = Caja.yapeConfig.value.numeroYape.trim()
    if (numero.isBlank()) return

    val clipboard = LocalClipboardManager.current
    var aviso by remember { mutableStateOf("") }

    Tarjeta(borde = Verde.copy(alpha = .30f), fondo = PanelAlto) {
        Etiqueta("PAGA POR YAPE", Verde)
        Spacer(Modifier.height(7.dp))
        Text("Número Yape", color = Tenue, fontSize = 10.sp)
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(numero, color = Texto, fontSize = if (compacta) 22.sp else 24.sp, style = cifra, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(10.dp))
            Icon(Icons.Rounded.ContentCopy, null, tint = Cian, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.height(10.dp))
        Boton("Copiar número", Modifier.fillMaxWidth(), relleno = false, color = Cian) {
            clipboard.setText(AnnotatedString(numero))
            aviso = "Número copiado"
        }
        if (aviso.isNotBlank()) {
            Spacer(Modifier.height(7.dp))
            Text(aviso, color = Verde, fontSize = 10.sp)
        }
    }
}
