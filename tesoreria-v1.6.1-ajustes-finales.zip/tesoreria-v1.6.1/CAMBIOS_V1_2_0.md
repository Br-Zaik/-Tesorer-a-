# Tesorería 1.2.0 · corrección integral

- Login optimizado: carga primero la sesión/perfil y deja la sincronización completa en segundo plano.
- Evita refrescos simultáneos y baja la frecuencia de actualización automática para reducir trabas.
- Navegación entre Inicio, Movimientos, Actas y Panel con transición corta y fondo estable.
- Mensajes de permisos normalizados: los errores de RLS/privilegios se muestran como “No tienes permiso”.
- Panel: las secciones sin privilegios ya no muestran una tarjeta grande vacía; muestran solo “No tienes permiso”.
- Visor de comprobante Yape rediseñado: scroll vertical real, imagen adaptada, encabezado y botón Cerrar fijos.
- Visor de imagen completa con desplazamiento.
- OCR local reforzado: segunda pasada ampliada/contrastada cuando faltan datos; parseo mejorado de monto, operación, fecha, hora y código de seguridad.
- Número de operación exige al menos 6 dígitos antes de enviar.
- Icono renovado con balanza dorada y marca Tesorería.
- Splash Android 12+ con fondo verde, icono renovado y splash interno con logo HD.
- versionCode 17 / versionName 1.2.0.
