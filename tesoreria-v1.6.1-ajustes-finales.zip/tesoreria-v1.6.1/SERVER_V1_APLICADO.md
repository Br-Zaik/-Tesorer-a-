# Servidor Supabase · cambios v1 aplicados

Se aplicaron directamente al proyecto Supabase configurado por la app:

- RLS reafirmado en tablas sensibles.
- `actualizar_nombre_miembro(...)`: solo tesorero autenticado.
- `enviar_pago_yape(...)` reforzado:
  - sesión real obligatoria;
  - cuenta activa;
  - operación numérica válida;
  - ruta de comprobante obligatoriamente dentro de la carpeta del propio socio;
  - comprobación de existencia del archivo en Storage;
  - SHA-256 válido;
  - código de seguridad de 3 dígitos cuando exista;
  - rechazo de reutilización de operación/captura mediante índices únicos.
- Ejecución de RPC sensibles restringida a `authenticated`.
- Edge Function `activar-cuenta` actualizada para bloquear un código temporal después de 5 intentos fallidos.

La clave `service_role` continúa únicamente del lado del servidor. El APK solo contiene la clave pública de Supabase, que no es un secreto y depende de RLS/RPC para autorización.
