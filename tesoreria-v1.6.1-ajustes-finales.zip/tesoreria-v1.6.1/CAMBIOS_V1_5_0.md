# Tesorería v1.5.0 · Yape seguro

- El OCR queda como apoyo: nunca aprueba un pago por sí solo.
- La captura original siempre es la prueba principal para el tesorero.
- La app bloquea imágenes claramente ajenas a comprobantes Yape.
- Se calcula SHA-256 para duplicados exactos y dHash visual para copias recomprimidas o levemente modificadas.
- El servidor rechaza reutilizar la misma operación, la misma captura exacta o una captura visualmente casi igual, incluso desde otra cuenta.
- Se realiza una prevalidación antes de subir la imagen y una segunda validación transaccional al registrar el pago.
- Los campos OCR siguen siendo editables para corregir errores de lectura.
- versionCode 20 / versionName 1.5.0.
