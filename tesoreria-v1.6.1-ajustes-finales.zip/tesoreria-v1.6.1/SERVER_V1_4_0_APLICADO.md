# Servidor v1.4.0 aplicado

Cambios ya aplicados en Supabase del proyecto Tesorería:

- Nueva tabla `public.acta_detalle_publico` con solo `acta_id`, `socio_numero` y `estado`.
- RLS: cualquier usuario autenticado válido puede leer ese resumen numérico.
- `public.acta_detalle` quedó restringida por RLS al propio socio o al tesorero.
- Trigger `trg_sincronizar_acta_detalle_publico` mantiene el resumen público sincronizado con el detalle privado.
- Los registros de actas existentes fueron copiados al resumen público.
- El cierre automático existente continúa activo mediante `pg_cron` cada minuto con `public.cerrar_cobros_vencidos()`.

Objetivo: todos pueden ver la lista por números y estado; solo el tesorero accede al detalle completo con nombres y datos privados.
