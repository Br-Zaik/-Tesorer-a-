alter table public.pagos_privados
  add column if not exists captura_dhash bigint;

create index if not exists pagos_privados_captura_dhash_idx
  on public.pagos_privados(captura_dhash)
  where captura_dhash is not null;

create or replace function public.distancia_dhash(p_a bigint, p_b bigint)
returns integer
language sql
immutable
strict
as $$
  select bit_count((p_a # p_b)::bit(64))::integer;
$$;

create or replace function public.validar_comprobante_yape_v2(
  p_cobro_id uuid,
  p_captura_sha256 text,
  p_captura_dhash bigint,
  p_operacion text,
  p_fecha_operacion timestamptz,
  p_monto_centavos bigint,
  p_codigo_seguridad text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_socio smallint;
  v_pago_actual uuid;
  v_hash text := lower(trim(coalesce(p_captura_sha256, '')));
  v_operacion text := trim(coalesce(p_operacion, ''));
begin
  v_socio := public.mi_numero();
  if v_socio is null then
    raise exception 'Debes iniciar sesión';
  end if;

  select p.id into v_pago_actual
  from public.pagos p
  where p.cobro_id = p_cobro_id
    and p.socio_numero = v_socio
    and p.vigente = true
  limit 1;

  if v_hash !~ '^[a-f0-9]{64}$' then
    return jsonb_build_object('ok', false, 'codigo', 'HUELLA_INVALIDA', 'mensaje', 'No se pudo validar la imagen');
  end if;

  if p_captura_dhash is null then
    return jsonb_build_object('ok', false, 'codigo', 'HUELLA_VISUAL_INVALIDA', 'mensaje', 'No se pudo validar visualmente la imagen');
  end if;

  if exists (
    select 1
    from public.pagos_privados pp
    where lower(trim(pp.captura_sha256)) = v_hash
      and (v_pago_actual is null or pp.pago_id <> v_pago_actual)
  ) then
    return jsonb_build_object('ok', false, 'codigo', 'DUPLICADO_EXACTO', 'mensaje', 'Este comprobante ya fue utilizado en otra cuenta o pago');
  end if;

  if v_operacion <> '' and exists (
    select 1
    from public.pagos_privados pp
    where trim(pp.operacion) = v_operacion
      and (v_pago_actual is null or pp.pago_id <> v_pago_actual)
  ) then
    return jsonb_build_object('ok', false, 'codigo', 'OPERACION_REPETIDA', 'mensaje', 'Este número de operación ya fue utilizado');
  end if;

  -- La huella visual nunca bloquea por sí sola: muchos comprobantes Yape comparten diseño.
  -- Solo se considera duplicado visual si además coinciden monto y minuto de operación.
  if p_fecha_operacion is not null and exists (
    select 1
    from public.pagos_privados pp
    join public.pagos p on p.id = pp.pago_id
    where pp.captura_dhash is not null
      and public.distancia_dhash(pp.captura_dhash, p_captura_dhash) <= 3
      and p.monto_centavos = p_monto_centavos
      and date_trunc('minute', pp.fecha_operacion) = date_trunc('minute', p_fecha_operacion)
      and (v_pago_actual is null or pp.pago_id <> v_pago_actual)
  ) then
    return jsonb_build_object('ok', false, 'codigo', 'IMAGEN_SIMILAR', 'mensaje', 'Esta captura parece ser el mismo comprobante usado anteriormente');
  end if;

  if p_fecha_operacion is not null
     and p_codigo_seguridad is not null
     and p_codigo_seguridad ~ '^[0-9]{3}$'
     and exists (
       select 1
       from public.pagos_privados pp
       join public.pagos p on p.id = pp.pago_id
       where date_trunc('minute', pp.fecha_operacion) = date_trunc('minute', p_fecha_operacion)
         and pp.ocr_codigo_seguridad = p_codigo_seguridad
         and p.monto_centavos = p_monto_centavos
         and (v_pago_actual is null or pp.pago_id <> v_pago_actual)
     ) then
    return jsonb_build_object('ok', false, 'codigo', 'DATOS_REPETIDOS', 'mensaje', 'Los datos de este comprobante coinciden con uno utilizado anteriormente');
  end if;

  return jsonb_build_object('ok', true);
end;
$$;

revoke all on function public.validar_comprobante_yape_v2(uuid,text,bigint,text,timestamptz,bigint,text) from public, anon;
grant execute on function public.validar_comprobante_yape_v2(uuid,text,bigint,text,timestamptz,bigint,text) to authenticated;

create or replace function public.enviar_pago_yape_v2(
  p_cobro_id uuid,
  p_monto_centavos bigint,
  p_operacion text,
  p_captura_path text,
  p_captura_sha256 text,
  p_captura_dhash bigint,
  p_yape_score integer,
  p_fecha_operacion timestamptz default null,
  p_ocr_monto_centavos bigint default null,
  p_ocr_operacion text default null,
  p_ocr_fecha_operacion timestamptz default null,
  p_ocr_codigo_seguridad text default null,
  p_metadata_ocr jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_socio smallint;
  v_cobro public.cobros%rowtype;
  v_pago public.pagos%rowtype;
  v_pago_id uuid;
  v_operacion text;
  v_hash text;
  v_validacion jsonb;
  v_tenia_pago boolean := false;
begin
  v_socio := public.mi_numero();
  if v_socio is null then raise exception 'Debes iniciar sesión'; end if;

  if not exists(select 1 from public.miembros where numero = v_socio and estado = 'activo') then
    raise exception 'Cuenta no habilitada';
  end if;

  select * into v_cobro from public.cobros where id = p_cobro_id for update;
  if not found or v_cobro.cerrado_at is not null or v_cobro.cierra_at <= now() then
    raise exception 'El cobro está cerrado';
  end if;

  if p_monto_centavos is null or p_monto_centavos <= 0 or p_monto_centavos > 100000000 then
    raise exception 'Monto inválido';
  end if;

  v_operacion := trim(coalesce(p_operacion, ''));
  if v_operacion !~ '^[0-9]{6,20}$' then
    raise exception 'Número de operación inválido';
  end if;

  v_hash := lower(trim(coalesce(p_captura_sha256, '')));
  if v_hash !~ '^[a-f0-9]{64}$' then
    raise exception 'Huella de comprobante inválida';
  end if;

  if p_captura_dhash is null then
    raise exception 'No se pudo validar visualmente el comprobante';
  end if;

  if coalesce(p_yape_score, 0) < 6 then
    raise exception 'La imagen no parece un comprobante de Yape válido';
  end if;

  if trim(coalesce(p_captura_path, '')) = '' or split_part(p_captura_path, '/', 1) <> v_socio::text then
    raise exception 'Ruta de comprobante inválida';
  end if;

  if not exists(
    select 1 from storage.objects
    where bucket_id = 'comprobantes-yape' and name = p_captura_path
  ) then
    raise exception 'El comprobante no existe en el almacenamiento';
  end if;

  if p_ocr_codigo_seguridad is not null and p_ocr_codigo_seguridad !~ '^[0-9]{3}$' then
    raise exception 'Código de seguridad inválido';
  end if;

  select * into v_pago
  from public.pagos
  where cobro_id = p_cobro_id and socio_numero = v_socio and vigente = true
  limit 1 for update;
  v_tenia_pago := found;

  v_validacion := public.validar_comprobante_yape_v2(
    p_cobro_id,
    v_hash,
    p_captura_dhash,
    v_operacion,
    p_fecha_operacion,
    p_monto_centavos,
    p_ocr_codigo_seguridad
  );
  if not coalesce((v_validacion->>'ok')::boolean, false) then
    raise exception '%', coalesce(v_validacion->>'mensaje', 'Este comprobante ya fue utilizado');
  end if;

  if v_tenia_pago then
    if v_pago.estado = 'aprobado' then raise exception 'Este cobro ya está pagado'; end if;
    if v_pago.estado = 'pendiente' then raise exception 'Ya tienes un comprobante pendiente'; end if;
    v_pago_id := v_pago.id;
    update public.pagos
    set medio='yape', estado='pendiente', monto_centavos=p_monto_centavos,
        enviado_at=now(), revisado_at=null, revisado_por=null, recibido_por=null
    where id=v_pago_id;
  else
    insert into public.pagos(cobro_id,socio_numero,medio,estado,monto_centavos)
    values(p_cobro_id,v_socio,'yape','pendiente',p_monto_centavos)
    returning id into v_pago_id;
  end if;

  insert into public.pagos_privados(
    pago_id,operacion,fecha_operacion,ocr_monto_centavos,ocr_operacion,
    ocr_fecha_operacion,ocr_codigo_seguridad,captura_path,captura_sha256,captura_dhash,
    motivo_rechazo,metadata_ocr
  ) values(
    v_pago_id,v_operacion,p_fecha_operacion,p_ocr_monto_centavos,
    nullif(trim(coalesce(p_ocr_operacion,'')),''),p_ocr_fecha_operacion,
    p_ocr_codigo_seguridad,p_captura_path,v_hash,p_captura_dhash,null,
    coalesce(p_metadata_ocr,'{}'::jsonb)
  )
  on conflict (pago_id) do update set
    operacion=excluded.operacion,
    fecha_operacion=excluded.fecha_operacion,
    ocr_monto_centavos=excluded.ocr_monto_centavos,
    ocr_operacion=excluded.ocr_operacion,
    ocr_fecha_operacion=excluded.ocr_fecha_operacion,
    ocr_codigo_seguridad=excluded.ocr_codigo_seguridad,
    captura_path=excluded.captura_path,
    captura_sha256=excluded.captura_sha256,
    captura_dhash=excluded.captura_dhash,
    motivo_rechazo=null,
    metadata_ocr=excluded.metadata_ocr;

  insert into public.bitacora(actor_numero,nivel,publico,evento,entidad,entidad_id,detalle)
  values(v_socio,'info',false,'Comprobante Yape enviado','pago',v_pago_id::text,
    'El socio N.º ' || v_socio || ' envió un comprobante Yape validado para revisión.');

  return v_pago_id;
exception
  when unique_violation then
    raise exception 'Este número de operación o comprobante ya fue utilizado';
end;
$$;

revoke all on function public.enviar_pago_yape_v2(uuid,bigint,text,text,text,bigint,integer,timestamptz,bigint,text,timestamptz,text,jsonb) from public, anon;
grant execute on function public.enviar_pago_yape_v2(uuid,bigint,text,text,text,bigint,integer,timestamptz,bigint,text,timestamptz,text,jsonb) to authenticated;
