# Tesorería v1.6.1

versionCode 23

Versión enfocada en simplificar la interfaz y corregir el flujo probado en celulares reales.

- Actualización obligatoria simplificada: solo versión nueva y botón Actualizar ahora.
- Datos Yape removidos de Inicio; aparecen solo dentro de Subir comprobante.
- QR eliminado de la interfaz y de la configuración: queda únicamente el número Yape con botón Copiar.
- OCR reducido a monto + número de operación; fecha, hora y código se revisan en la captura.
- Segunda pasada OCR si falta monto u operación.
- Comprobantes con Ver imagen completa, zoom y desplazamiento.
- Actas y Bitácora separadas por pestañas.
- Bitácora agrupada por fecha con líneas compactas por hora.
- Actas con fecha larga, hora de apertura/cierre y duración.
- Movimientos muestran fechas legibles.
- Códigos temporales de 24 h muestran estado activo; no se ofrece generar otro mientras siga vigente.
- PDF de actas y bitácora usa fechas legibles y agrupación por fecha.
- Servidor Yape actualizado para guardar solo número de 9 dígitos y limpiar el QR anterior.
