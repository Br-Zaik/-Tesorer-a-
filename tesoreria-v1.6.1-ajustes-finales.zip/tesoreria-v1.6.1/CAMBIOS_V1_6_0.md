# Tesorería v1.6.0

Versión enfocada en estabilidad, simplicidad y respaldo.

- Login simple en una sola pantalla: número de lista + contraseña.
- Activación/restablecimiento en el mismo panel, sin pasos animados ni pantallas vacías.
- Se quitaron transiciones pesadas entre secciones principales.
- Yape simplificado: la imagen original queda como prueba principal.
- OCR reducido: solo intenta sugerir el monto; operación se escribe manualmente.
- Ya no se muestran campos de fecha, hora ni código de seguridad en el envío del usuario.
- Actas con listas desplegables: Pagaron, Pendientes, Rechazados, No enviaron.
- Los usuarios normales ven solo números de lista.
- El tesorero conserva el detalle completo y puede abrir comprobantes.
- Exportación de actas y bitácora a PDF.
- Configuración de Yape para tesorero: QR + número editable solo por admin.
- Usuarios ven QR/número y pueden copiar el número.
- Servidor actualizado con tabla y función segura para datos de Yape.
