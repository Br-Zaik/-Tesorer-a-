# Tesorería 1.3.0 · actualización obligatoria y sesión segura

- versionCode 18 / versionName 1.3.0.
- Toda versión nueva publicada por GitHub Actions se marca `[OBLIGATORIA]`.
- Las versiones antiguas no ofrecen “Más tarde”; deben actualizar para continuar.
- La app comprueba la versión antes de restaurar la sesión.
- Revisión periódica de nuevas versiones mientras la app permanece abierta.
- Descarga e instalación mediante el APK firmado publicado en GitHub Releases.
- Se mantiene la verificación de package/version y Android valida la firma al instalar.
- Cierre automático de sesión tras 5 minutos sin interacción.
- La inactividad también cuenta mientras la app está en segundo plano o si Android mata el proceso.
- La duración se lee desde Supabase (`sesion_inactividad_segundos`) y queda configurada en 300 segundos.
- Al cerrar por inactividad se muestra un aviso claro y se exige volver a iniciar sesión.
- Cada petición al servidor incluye `X-App-Version-Code` y `X-App-Version-Name` para trazabilidad y futuras reglas de servidor.
- Supabase tiene `forzar_actualizaciones=true` y versión mínima actual 17 para no bloquear la v1.2.0 antes de publicar la v1.3.0.
