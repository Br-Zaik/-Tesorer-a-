# Caja del Grupo · v1.0.0

## Versión
- applicationId: `com.tesoreria.caja`
- versionCode: `15`
- versionName: `1.0.0`

## Flujo de comprobantes
- Selección desde Fotos o Archivos.
- Miniatura y visor antes de enviar.
- OCR local ML Kit para monto, operación, fecha, hora y código de seguridad.
- Ningún valor faltante se inventa: se deja para corrección manual.
- Revisión editable antes del envío.
- Progreso de envío ligado a etapas reales.
- Si la conexión se corta, el pago no se marca como enviado hasta verificar el servidor.
- Usuario y tesorero pueden volver a abrir la captura almacenada.
- El tesorero puede abrir los comprobantes pendientes desde Inicio y Panel.

## Red y estabilidad
- Monitor de conectividad Android.
- Sin Internet no se envían cambios ni se cierra la sesión activa.
- Errores temporales del servidor no borran la sesión.
- Un 401 confirmado tras fallar la renovación sí exige volver a iniciar sesión.
- Timeouts y errores de red se convierten en mensajes controlados.

## Seguridad
- Refresh token cifrado con Android Keystore (AES/GCM).
- No se guarda el access token de forma persistente.
- R8/minificación habilitados también para el APK debug generado por GitHub Actions.
- cleartext HTTP deshabilitado y backup de la app deshabilitado.
- El servidor valida rutas de comprobante, huellas SHA-256, operaciones y rol del tesorero.
- Operación y SHA del comprobante tienen unicidad para reducir reutilización/duplicados.
- Código temporal de activación: máximo 5 intentos antes de bloquearse.
- Edición de nombre de miembros validada por el servidor y solo para el tesorero.

## Ícono
- Balanza dorada sobre fondo verde oscuro.
- Adaptive icon y fallback para Android 7+.

## Nota de compilación
Este entorno no contiene Android SDK/Gradle completo. Se realizaron validaciones estáticas de Kotlin/XML y la compilación final queda a cargo del workflow GitHub Actions incluido en el ZIP.
