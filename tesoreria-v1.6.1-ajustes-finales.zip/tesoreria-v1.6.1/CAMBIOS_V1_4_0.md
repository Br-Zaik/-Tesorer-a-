# Tesorería v1.4.0 — Actas públicas por número y detalle privado

- Las actas cerradas muestran a todos únicamente números de lista, separados por estado: pagaron, pendientes, rechazados y no enviaron.
- Los nombres no aparecen en la vista pública del acta.
- El tesorero puede desplegar un detalle completo con número, nombre histórico, estado, monto, medio, operación, fecha/hora y acceso al comprobante cuando exista.
- El servidor mantiene `acta_detalle_publico` con solo número y estado para todos; `acta_detalle` queda protegido por RLS para el propio socio o el tesorero.
- La lectura directa de `acta_detalle` queda limitada al propio socio o al tesorero para reducir exposición desde clientes antiguos.
- El cierre automático existente se mantiene: `pg_cron` ejecuta cada minuto `cerrar_cobros_vencidos()` y genera el acta con snapshot de los miembros aplicables.
- En el libro de caja, los socios normales ven el número del pagador; el nombre se conserva solo para el tesorero.
- versionCode 19 / versionName 1.4.0.
