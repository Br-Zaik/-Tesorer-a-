# Tesorería v1.5.1 — acceso resiliente

- Corrige falsos avisos de “Sin conexión” al abrir la app.
- El estado de ConnectivityManager ya no bloquea el login: la petición real a Supabase decide si hay conexión.
- Reintentos automáticos y silenciosos solo para operaciones seguras de acceso (estado de cuenta, autenticación, refresh y perfil).
- Diferencia red realmente desconectada de servidor lento/temporalmente no disponible.
- El botón de acceso no queda deshabilitado por un estado de red transitorio.
- El aviso offline espera antes de mostrarse para evitar parpadeos al iniciar.
- El perfil inicial se carga con un único RPC autenticado, en vez de tres consultas paralelas.
- `estado-cuenta` del servidor pasa a una sola consulta/RPC de base de datos.
- Mantiene intactos pagos, OCR/Yape seguro, actas, permisos y actualización obligatoria.

Servidor aplicado en Supabase:
- `estado_cuenta_prelogin(smallint)` accesible solo por `service_role`.
- `mi_perfil_login()` accesible solo por usuarios autenticados.
- Edge Function `estado-cuenta` v3.
