package com.tesoreria.caja.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.tesoreria.caja.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.security.KeyStore
import java.util.UUID
import java.util.Date
import java.util.Locale
import java.text.SimpleDateFormat
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class SinConexionException(message: String = "Sin conexión a Internet") : IOException(message)
class ServidorTemporalException(message: String = "El servidor tardó en responder. Inténtalo nuevamente") : IOException(message)
class SesionInvalidaException(message: String = "Tu sesión venció. Vuelve a iniciar sesión") : IllegalStateException(message)

object SupabaseApi {
    const val BASE_URL = "https://kgglijozytmbauehmvpq.supabase.co"
    const val PUBLISHABLE_KEY = "sb_publishable_XZKYZY-aPKnXAz3g3aTR1A_s0Aik4k4"

    private const val PREFS = "tesoreria_auth_secure"
    private const val TOKEN_KEY = "refresh_token_enc"
    private const val KEY_ALIAS = "tesoreria_refresh_token_v1"

    private var appContext: Context? = null
    @Volatile var accessToken: String? = null
        private set
    @Volatile private var refreshToken: String? = null
    private val refreshMutex = Mutex()

    fun initialize(context: Context) {
        appContext = context.applicationContext
        NetworkMonitor.initialize(context.applicationContext)
        refreshToken = decrypt(prefs()?.getString(TOKEN_KEY, null))
        if (refreshToken.isNullOrBlank()) {
            // Migración de v0.9.x: mueve el refresh token antiguo a Keystore y borra el texto plano.
            val legacy = appContext?.getSharedPreferences("tesoreria_auth", Context.MODE_PRIVATE)
            val old = legacy?.getString("refresh_token", null)
            if (!old.isNullOrBlank()) {
                refreshToken = old
                prefs()?.edit()?.putString(TOKEN_KEY, encrypt(old))?.apply()
                legacy.edit().remove("refresh_token").apply()
            }
        }
    }

    fun hayInternet(): Boolean = NetworkMonitor.hayRutaDeRed() || NetworkMonitor.conectado.value

    private fun prefs() = appContext?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun saveTokens(access: String?, refresh: String?) {
        accessToken = access
        refreshToken = refresh
        prefs()?.edit()?.apply {
            if (refresh == null) remove(TOKEN_KEY) else putString(TOKEN_KEY, encrypt(refresh))
        }?.apply()
    }

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(value: String): String? = runCatching {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
        val payload = Base64.encodeToString(cipher.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
        "$iv:$payload"
    }.getOrNull()

    private fun decrypt(value: String?): String? {
        if (value.isNullOrBlank()) return null
        return runCatching {
            val parts = value.split(':', limit = 2)
            if (parts.size != 2) return@runCatching null
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val data = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(data), Charsets.UTF_8)
        }.getOrNull()
    }

    data class HttpResponse(val code: Int, val body: String) {
        val ok: Boolean get() = code in 200..299
    }

    private data class ByteResponse(val code: Int, val body: ByteArray, val errorText: String = "") {
        val ok: Boolean get() = code in 200..299
    }

    private fun requireConnection() {
        if (!NetworkMonitor.conectado.value) throw SinConexionException()
    }

    private suspend fun rawRequest(
        method: String,
        url: String,
        body: String? = null,
        token: String? = null,
        contentType: String = "application/json; charset=utf-8",
        extraHeaders: Map<String, String> = emptyMap(),
        bytes: ByteArray? = null
    ): HttpResponse = withContext(Dispatchers.IO) {
        try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 12_000
                readTimeout = 22_000
                instanceFollowRedirects = false
                setRequestProperty("apikey", PUBLISHABLE_KEY)
                setRequestProperty("Accept", "application/json")
                setRequestProperty("X-App-Version-Code", BuildConfig.VERSION_CODE.toString())
                setRequestProperty("X-App-Version-Name", BuildConfig.VERSION_NAME)
                token?.let { setRequestProperty("Authorization", "Bearer $it") }
                extraHeaders.forEach { (k, v) -> setRequestProperty(k, v) }
                if (body != null || bytes != null) {
                    doOutput = true
                    setRequestProperty("Content-Type", contentType)
                }
            }
            if (bytes != null) conn.outputStream.use { it.write(bytes) }
            else if (body != null) conn.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.let { s -> BufferedReader(InputStreamReader(s, Charsets.UTF_8)).use { it.readText() } }.orEmpty()
            conn.disconnect()
            NetworkMonitor.reportarExito()
            HttpResponse(code, text)
        } catch (_: SocketTimeoutException) {
            NetworkMonitor.reportarFallo()
            throw ServidorTemporalException("El servidor tardó en responder. Reintentando puede resolverlo")
        } catch (_: IOException) {
            NetworkMonitor.reportarFallo()
            if (!NetworkMonitor.hayRutaDeRed()) throw SinConexionException()
            throw ServidorTemporalException("No se pudo contactar al servidor temporalmente")
        }
    }

    private suspend fun rawBytes(method: String, url: String, token: String?): ByteResponse = withContext(Dispatchers.IO) {
        try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 12_000
                readTimeout = 25_000
                instanceFollowRedirects = false
                setRequestProperty("apikey", PUBLISHABLE_KEY)
                setRequestProperty("X-App-Version-Code", BuildConfig.VERSION_CODE.toString())
                setRequestProperty("X-App-Version-Name", BuildConfig.VERSION_NAME)
                token?.let { setRequestProperty("Authorization", "Bearer $it") }
            }
            val code = conn.responseCode
            val result = if (code in 200..299) {
                ByteResponse(code, conn.inputStream.use { it.readBytes() })
            } else {
                val err = conn.errorStream?.let { String(it.readBytes(), Charsets.UTF_8) }.orEmpty()
                ByteResponse(code, ByteArray(0), err)
            }
            conn.disconnect()
            NetworkMonitor.reportarExito()
            result
        } catch (_: SocketTimeoutException) {
            NetworkMonitor.reportarFallo()
            throw ServidorTemporalException("El servidor tardó en responder")
        } catch (_: IOException) {
            NetworkMonitor.reportarFallo()
            if (!NetworkMonitor.hayRutaDeRed()) throw SinConexionException()
            throw ServidorTemporalException("No se pudo contactar al servidor temporalmente")
        }
    }

    private suspend fun rawRequestResiliente(
        method: String,
        url: String,
        body: String? = null,
        token: String? = null,
        intentos: Int = 3
    ): HttpResponse {
        var ultimoError: Exception? = null
        repeat(intentos.coerceAtLeast(1)) { intento ->
            try {
                val r = rawRequest(method, url, body, token)
                if (r.code !in setOf(500, 502, 503, 504) || intento == intentos - 1) return r
            } catch (e: SinConexionException) {
                ultimoError = e
                if (intento == intentos - 1) throw e
            } catch (e: ServidorTemporalException) {
                ultimoError = e
                if (intento == intentos - 1) throw e
            }
            delay(if (intento == 0) 350L else 850L)
        }
        throw ultimoError ?: ServidorTemporalException()
    }

    private suspend fun refreshAccess(): Boolean = refreshMutex.withLock {
        val rt = refreshToken ?: return false
        val r = rawRequestResiliente(
            "POST",
            "$BASE_URL/auth/v1/token?grant_type=refresh_token",
            JSONObject().put("refresh_token", rt).toString(),
            intentos = 3
        )
        if (!r.ok) {
            if (r.code == 400 || r.code == 401) {
                saveTokens(null, null)
                return false
            }
            throw IllegalStateException("Servidor no disponible. Inténtalo nuevamente")
        }
        val j = runCatching { JSONObject(r.body) }.getOrNull() ?: return false
        val access = j.optString("access_token")
        val refresh = j.optString("refresh_token", rt)
        if (access.isBlank()) return false
        saveTokens(access, refresh)
        true
    }

    private suspend fun request(
        method: String,
        url: String,
        body: String? = null,
        auth: Boolean = false,
        contentType: String = "application/json; charset=utf-8",
        extraHeaders: Map<String, String> = emptyMap(),
        bytes: ByteArray? = null
    ): HttpResponse {
        val first = rawRequest(method, url, body, if (auth) accessToken else null, contentType, extraHeaders, bytes)
        if (!auth || first.code != 401) return first
        if (!refreshAccess()) return first
        return rawRequest(method, url, body, accessToken, contentType, extraHeaders, bytes)
    }

    private suspend fun requestResiliente(
        method: String,
        url: String,
        body: String? = null,
        auth: Boolean = false,
        intentos: Int = 3
    ): HttpResponse {
        var ultimoError: Exception? = null
        repeat(intentos.coerceAtLeast(1)) { intento ->
            try {
                val r = request(method, url, body, auth = auth)
                if (r.code !in setOf(500, 502, 503, 504)) return r
                ultimoError = ServidorTemporalException()
                // Un HTTP 5xx confirma que sí hay conexión. Reintentamos, pero
                // no mostramos la pantalla "sin Internet" por un error del servidor.
                if (intento == intentos - 1) return r
            } catch (e: SinConexionException) {
                ultimoError = e
                if (intento == intentos - 1) {
                    NetworkMonitor.reportarFalloConfirmado()
                    throw e
                }
            } catch (e: ServidorTemporalException) {
                ultimoError = e
                if (intento == intentos - 1) {
                    NetworkMonitor.reportarFalloConfirmado()
                    throw e
                }
            }
            delay(if (intento == 0) 300L else 700L)
        }
        NetworkMonitor.reportarFalloConfirmado()
        throw ultimoError ?: ServidorTemporalException()
    }

    /** Comprobación corta usada por la pantalla automática de reconexión. */
    suspend fun verificarConexionRapida(): Boolean = withContext(Dispatchers.IO) {
        try {
            val conn = (URL("$BASE_URL/rest/v1/app_actualizacion_config?select=id&limit=1").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3_500
                readTimeout = 3_500
                setRequestProperty("apikey", PUBLISHABLE_KEY)
                setRequestProperty("Accept", "application/json")
            }
            val ok = conn.responseCode in 200..299
            conn.disconnect()
            if (ok) NetworkMonitor.reportarExito()
            ok
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Mutaciones seguras para reintento. El servidor guarda request_id y si la
     * respuesta se pierde, repetir la misma solicitud NO duplica la operación.
     */
    suspend fun rpcIdempotente(name: String, params: JSONObject, requestId: String = UUID.randomUUID().toString()): String {
        val body = JSONObject()
            .put("p_request_id", requestId)
            .put("p_operacion", name)
            .put("p_params", params)
        val r = requestResiliente(
            "POST",
            "$BASE_URL/rest/v1/rpc/ejecutar_operacion_idempotente",
            body.toString(),
            auth = true,
            intentos = 4
        )
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok) throw IllegalStateException(errorText(r.body, "No se pudo completar la operación"))
        return r.body
    }

    suspend fun configuracionActualizacion(): JSONObject? {
        return try {
            val r = requestResiliente(
                "GET",
                "$BASE_URL/rest/v1/app_actualizacion_config?id=eq.android&select=min_version_code,mensaje,forzar_actualizaciones,sesion_inactividad_segundos,actualizado_at",
                intentos = 2
            )
            if (!r.ok || r.body.isBlank()) return null
            val arr = JSONArray(r.body)
            if (arr.length() == 0) null else arr.optJSONObject(0)
        } catch (_: Exception) {
            null
        }
    }

    suspend fun estadoCuenta(numero: Int): JSONObject {
        val r = requestResiliente("POST", "$BASE_URL/functions/v1/estado-cuenta", JSONObject().put("numero", numero).toString(), intentos = 3)
        val j = if (r.body.isBlank()) JSONObject() else JSONObject(r.body)
        if (!r.ok) throw IllegalStateException(j.optString("error", "No se pudo consultar la cuenta"))
        return j
    }

    suspend fun activarCuenta(numero: Int, codigo: String, password: String) {
        val requestId = UUID.randomUUID().toString()
        val body = JSONObject().put("numero", numero).put("codigo", codigo).put("password", password).put("request_id", requestId)
        val r = requestResiliente("POST", "$BASE_URL/functions/v1/activar-cuenta", body.toString(), intentos = 4)
        val j = if (r.body.isBlank()) JSONObject() else JSONObject(r.body)
        if (!r.ok || !j.optBoolean("ok", false)) throw IllegalStateException(j.optString("error", "No se pudo activar la cuenta"))
    }

    suspend fun iniciarSesion(numero: Int, password: String) {
        val email = "lista${numero}@tesoreria.app"
        val body = JSONObject().put("email", email).put("password", password)
        val r = requestResiliente("POST", "$BASE_URL/auth/v1/token?grant_type=password", body.toString(), intentos = 3)
        val j = if (r.body.isBlank()) JSONObject() else JSONObject(r.body)
        if (!r.ok) {
            val raw = j.optString("msg", j.optString("error_description", "Contraseña incorrecta"))
            val n = raw.lowercase()
            val msg = when {
                "invalid login" in n || "invalid credentials" in n || "email not confirmed" in n -> "Contraseña incorrecta"
                "rate limit" in n || "too many" in n -> "Demasiados intentos. Espera un momento"
                else -> raw.ifBlank { "Contraseña incorrecta" }
            }
            throw IllegalStateException(msg)
        }
        val access = j.optString("access_token")
        val refresh = j.optString("refresh_token")
        if (access.isBlank() || refresh.isBlank()) throw IllegalStateException("No se recibió una sesión válida")
        saveTokens(access, refresh)
    }

    suspend fun perfilActual(): JSONObject {
        val r = requestResiliente(
            "POST",
            "$BASE_URL/rest/v1/rpc/mi_perfil_login",
            "{}",
            auth = true,
            intentos = 3
        )
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok) throw IllegalStateException(errorText(r.body, "No se pudo cargar tu perfil"))
        return if (r.body.isBlank()) JSONObject() else JSONObject(r.body)
    }

    suspend fun snapshotApp(): JSONObject {
        val r = requestResiliente(
            "POST",
            "$BASE_URL/rest/v1/rpc/cargar_app_snapshot_v1",
            "{}",
            auth = true,
            intentos = 3
        )
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok) throw IllegalStateException(errorText(r.body, "No se pudieron cargar los datos de Tesorería"))
        if (r.body.isBlank()) throw IllegalStateException("El servidor devolvió una respuesta vacía")
        return JSONObject(r.body)
    }

    suspend fun restaurarSesion(): Boolean {
        if (refreshToken == null) return false
        return refreshAccess()
    }

    suspend fun cerrarSesion() {
        try {
            if (NetworkMonitor.conectado.value && accessToken != null) request("POST", "$BASE_URL/auth/v1/logout", "{}", auth = true)
        } catch (_: Exception) {
            // La sesión local siempre se cierra aunque el servidor esté temporalmente fuera.
        }
        saveTokens(null, null)
    }

    suspend fun getArray(resourceAndQuery: String): JSONArray {
        val r = request("GET", "$BASE_URL/rest/v1/$resourceAndQuery", auth = true)
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok) throw IllegalStateException(errorText(r.body, "Error consultando datos"))
        return if (r.body.isBlank()) JSONArray() else JSONArray(r.body)
    }

    suspend fun rpc(name: String, params: JSONObject = JSONObject()): String {
        val r = request("POST", "$BASE_URL/rest/v1/rpc/$name", params.toString(), auth = true)
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok) throw IllegalStateException(errorText(r.body, "No se pudo completar la operación"))
        return r.body
    }

    suspend fun liberarPlaza(numero: Int) {
        val r = requestResiliente(
            "POST", "$BASE_URL/functions/v1/liberar-plaza",
            JSONObject().put("numero", numero).toString(), auth = true, intentos = 3
        )
        val j = if (r.body.isBlank()) JSONObject() else JSONObject(r.body)
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok || !j.optBoolean("ok", false)) throw IllegalStateException(j.optString("error", "No se pudo liberar la plaza"))
    }

    suspend fun generarCodigo(numero: Int): JSONObject {
        val r = requestResiliente(
            "POST", "$BASE_URL/functions/v1/generar-codigo",
            JSONObject().put("numero", numero).toString(), auth = true, intentos = 3
        )
        val j = if (r.body.isBlank()) JSONObject() else JSONObject(r.body)
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok || !j.optBoolean("ok", false)) throw IllegalStateException(j.optString("error", "No se pudo generar el código"))
        return j
    }

    suspend fun codigosMasivos(accion: String = "listar", cantidad: Int = 30): JSONObject {
        val r = requestResiliente(
            "POST", "$BASE_URL/functions/v1/codigos-masivos",
            JSONObject().put("accion", accion).put("cantidad", cantidad.coerceIn(1, 30)).toString(),
            auth = true, intentos = 3
        )
        val j = if (r.body.isBlank()) JSONObject() else JSONObject(r.body)
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok || !j.optBoolean("ok", false)) throw IllegalStateException(j.optString("error", "No se pudieron gestionar los códigos"))
        return j
    }

    suspend fun ownerLimpiar(accion: String, desde: Long?, hasta: Long?, todo: Boolean): JSONObject {
        val body = JSONObject()
            .put("accion", accion)
            .put("todo", todo)
        if (!todo) {
            body.put("desde", desde?.let { SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(Date(it)) } ?: JSONObject.NULL)
            body.put("hasta", hasta?.let { SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(Date(it)) } ?: JSONObject.NULL)
        }
        val r = requestResiliente(
            "POST", "$BASE_URL/functions/v1/owner-limpiar", body.toString(),
            auth = true, intentos = if (accion == "limpiar") 2 else 3
        )
        val j = if (r.body.isBlank()) JSONObject() else JSONObject(r.body)
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok || !j.optBoolean("ok", false)) throw IllegalStateException(j.optString("error", "No se pudo completar la limpieza"))
        return j
    }

    suspend fun registrarPresencia() {
        val r = request(
            "POST",
            "$BASE_URL/rest/v1/rpc/registrar_presencia",
            JSONObject().put("p_app_version", BuildConfig.VERSION_NAME).toString(),
            auth = true
        )
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok) throw IllegalStateException(errorText(r.body, "No se pudo actualizar la presencia"))
    }

    suspend fun marcarDesconectado() {
        val r = request(
            "POST",
            "$BASE_URL/rest/v1/rpc/marcar_desconectado",
            "{}",
            auth = true
        )
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok) throw IllegalStateException(errorText(r.body, "No se pudo cerrar la presencia"))
    }

    suspend fun presenciaAdmin(): JSONArray {
        val r = request(
            "POST",
            "$BASE_URL/rest/v1/rpc/presencia_admin",
            "{}",
            auth = true
        )
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok) throw IllegalStateException(errorText(r.body, "No se pudo consultar la presencia"))
        return if (r.body.isBlank()) JSONArray() else JSONArray(r.body)
    }

    suspend fun uploadComprobante(path: String, data: ByteArray, mime: String) {
        uploadArchivoPrivado("comprobantes-yape", path, data, mime, upsert = false, fallback = "No se pudo subir el comprobante")
    }

    suspend fun uploadArchivoPrivado(bucket: String, path: String, data: ByteArray, mime: String, upsert: Boolean = false, fallback: String = "No se pudo subir el archivo") {
        val encodedPath = encodePath(path)
        val r = request(
            "POST",
            "$BASE_URL/storage/v1/object/$bucket/$encodedPath",
            auth = true,
            contentType = mime,
            extraHeaders = mapOf("x-upsert" to upsert.toString()),
            bytes = data
        )
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok) throw IllegalStateException(errorText(r.body, fallback))
    }

    suspend fun descargarComprobante(path: String): ByteArray {
        return descargarArchivoPrivado("comprobantes-yape", path, "No se pudo abrir el comprobante", "La captura está vacía")
    }

    suspend fun descargarArchivoPrivado(bucket: String, path: String, fallback: String = "No se pudo abrir el archivo", emptyMessage: String = "El archivo está vacío"): ByteArray {
        if (path.isBlank()) throw IllegalStateException("No hay archivo disponible")
        val encodedPath = encodePath(path)
        var r = rawBytes("GET", "$BASE_URL/storage/v1/object/authenticated/$bucket/$encodedPath", accessToken)
        if (r.code == 401 && refreshAccess()) {
            r = rawBytes("GET", "$BASE_URL/storage/v1/object/authenticated/$bucket/$encodedPath", accessToken)
        }
        if (r.code == 401) throw SesionInvalidaException()
        if (!r.ok) throw IllegalStateException(errorText(r.errorText, fallback))
        if (r.body.isEmpty()) throw IllegalStateException(emptyMessage)
        return r.body
    }

    private fun encodePath(path: String): String = path.split('/').joinToString("/") {
        URLEncoder.encode(it, "UTF-8").replace("+", "%20")
    }

    private fun errorText(raw: String, fallback: String): String {
        val msg = try {
            val j = JSONObject(raw)
            j.optString("message", j.optString("error", j.optString("hint", fallback))).ifBlank { fallback }
        } catch (_: Exception) { fallback }
        val n = msg.lowercase()
        return when {
            "permission denied" in n || "row-level security" in n || "not authorized" in n || "insufficient privilege" in n -> "No tienes permiso"
            "jwt" in n && ("expired" in n || "invalid" in n) -> "Tu sesión venció. Vuelve a iniciar sesión"
            else -> msg
        }
    }
}
