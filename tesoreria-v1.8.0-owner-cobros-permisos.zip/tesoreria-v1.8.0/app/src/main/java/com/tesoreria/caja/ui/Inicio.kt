package com.tesoreria.caja.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.EstadoPago
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.data.TipoCobro
import com.tesoreria.caja.data.MedioPago
import com.tesoreria.caja.data.Permiso
import com.tesoreria.caja.data.Cobro
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.delay

@Composable
fun PantallaInicio(irASubir: () -> Unit) {
    val yo = Caja.sesion.value ?: return
    val activos = Caja.cobrosActivos()
    var detalle by remember { mutableStateOf<Pair<Cobro, Int>?>(null) }
    var mostrarPendientes by remember { mutableStateOf<Cobro?>(null) }
    var verPago by remember { mutableStateOf<com.tesoreria.caja.data.Pago?>(null) }
    var noPagar by remember { mutableStateOf<Cobro?>(null) }
    var ahora by remember { mutableStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) { delay(1000); ahora = System.currentTimeMillis() }
    }

    Column(Modifier.fillMaxWidth()) {
        Text("Resumen", color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        ResumenInicioA()
        Spacer(Modifier.height(14.dp))

        if (activos.isEmpty()) {
            Tarjeta {
                Etiqueta("COBROS")
                Spacer(Modifier.height(7.dp))
                Titulo("No hay cobros abiertos")
                if (Caja.tienePermiso(yo, Permiso.GESTIONAR_COBROS)) { Spacer(Modifier.height(6.dp)); Text("Puedes abrir uno desde Panel > Cobro.", color = Tenue, fontSize = 12.sp) }
            }
            return@Column
        }

        activos.forEach { cobro ->
            val rapido = cobro.tipo == TipoCobro.RAPIDO
            val color = if (rapido) Ambar else Verde
            val noEnviaron = Caja.noEnviaron(cobro.id)
            val porRevisar = Caja.porRevisar(cobro.id)
            val rechazados = Caja.rechazados(cobro.id)
            val noParticipan = Caja.noParticipan(cobro.id)
            val pagaron = Caja.aprobados(cobro.id)
            val totalActivos = Caja.miembrosParticipantes().size
            val restante = cobro.cierra - ahora
            val miEstado = Caja.estadoDe(cobro.id, yo.numero)
            val miPago = Caja.pagoDe(cobro.id, yo.numero)

            if (miEstado == EstadoPago.RECHAZADO) {
                AlertaImportanteRechazo(miPago?.nota?.ifBlank { "Debes reenviar el comprobante." } ?: "Debes reenviar el comprobante.") {
                    Caja.cobroSubidaId.value = cobro.id
                    irASubir()
                }
                Spacer(Modifier.height(10.dp))
            }

            Tarjeta(borde = color.copy(alpha = .50f), fondo = if (rapido) Ambar.copy(alpha=.035f) else PanelAlto) {
                FilaEntre {
                    Column(Modifier.weight(1f)) {
                        Etiqueta(if (rapido) "COBRO RÁPIDO" else "COBRO OFICIAL", color)
                        Spacer(Modifier.height(4.dp))
                        Text(cobro.titulo, color = Texto, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(soles(cobro.monto), color = color, fontSize = 18.sp, style = cifra)
                }
                Spacer(Modifier.height(7.dp))
                Text(if (restante > 0) "Cierra en ${cuenta(restante)}" else "Plazo vencido", color = if (restante > 0) color else Rojo, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(9.dp))
                FilaEntre {
                    Pastilla("$pagaron / $totalActivos pagaron", color)
                    Text(soles(Caja.recaudado(cobro.id)), color = color, fontSize = 13.sp, style = cifra)
                }
                if (cobro.extensionTexto.isNotBlank()) { Spacer(Modifier.height(7.dp)); Pastilla(cobro.extensionTexto, Ambar) }
            }

            Spacer(Modifier.height(8.dp))

            if (yo.participaCobros) EstadoPropio(miEstado, cobro.id, yo.numero) else {
                Box(Modifier.fillMaxWidth().background(Cian.copy(alpha=.08f), RoundedCornerShape(12.dp)).border(BorderStroke(1.dp, Cian.copy(alpha=.24f)), RoundedCornerShape(12.dp)).padding(12.dp)) {
                    Text("Tu cuenta está en modo solo visualización · no estás incluido en este cobro.", color = Cian, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                if (noEnviaron.isNotEmpty()) AlertaEstado("No enviaron", "${noEnviaron.size} pendientes", noEnviaron.joinToString(", "), Rojo)
                if (porRevisar.isNotEmpty()) AlertaEstado("Esperando revisión", "${porRevisar.size} comprobantes", porRevisar.joinToString(", "), Ambar, alTocar = if (Caja.puedeVerYape(yo)) ({ mostrarPendientes = cobro }) else null)
                if (rechazados.isNotEmpty()) AlertaEstado("Deben reenviar", "${rechazados.size} observados", rechazados.joinToString(", "), Rojo)
                if (noParticipan.isNotEmpty()) AlertaEstado("No participan", "${noParticipan.size} declarados", noParticipan.joinToString(", "), Cian)
            }
            Spacer(Modifier.height(10.dp))
            Tarjeta(borde = if (rapido) Ambar.copy(alpha = .34f) else Borde) {
                FilaEntre {
                    Etiqueta(if (rapido) "ESTADO · COBRO RÁPIDO" else "ESTADO DE PAGOS", if (rapido) Ambar else Cian)
                    Text("$pagaron/$totalActivos", color = if (rapido) Ambar else Cian, fontSize = 15.sp, style = cifra)
                }
                Spacer(Modifier.height(10.dp))
                Cuadro(cobro.id, 0) { numero -> if (Caja.puedeVerYape(yo) || numero == yo.numero) detalle = cobro to numero }
                Spacer(Modifier.height(10.dp))
                LeyendaCompleta()
                if (!yo.participaCobros) {
                    Spacer(Modifier.height(11.dp))
                    Pastilla("Solo visualización · no participa en cobros", Tenue)
                } else if (miEstado == EstadoPago.SIN_ENVIAR || miEstado == EstadoPago.RECHAZADO) {
                    Spacer(Modifier.height(11.dp))
                    Boton(
                        if (miEstado == EstadoPago.RECHAZADO) "Volver a enviar comprobante" else "Subir mi comprobante",
                        Modifier.fillMaxWidth(),
                        color = if (rapido) Ambar else Verde
                    ) {
                        Caja.cobroSubidaId.value = cobro.id
                        irASubir()
                    }
                    Spacer(Modifier.height(7.dp))
                    Boton("No quiero pagar este cobro", Modifier.fillMaxWidth(), relleno = false, color = Cian) { noPagar = cobro }
                } else if (miEstado == EstadoPago.NO_PAGA) {
                    Spacer(Modifier.height(11.dp))
                    Boton("Cambiar decisión y pagar", Modifier.fillMaxWidth(), relleno = false, color = Verde) {
                        Caja.cancelarNoPago(cobro.id) { ok, _ -> if (ok) { Caja.cobroSubidaId.value = cobro.id; irASubir() } }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }
    }

    mostrarPendientes?.let { cobro ->
        Dialog(onDismissRequest = { mostrarPendientes = null }) {
            Tarjeta(borde = Ambar.copy(alpha=.45f), fondo = PanelAlto) {
                Etiqueta("COMPROBANTES PENDIENTES", Ambar)
                Spacer(Modifier.height(9.dp))
                val lista = Caja.pendientes().filter { it.cobroId == cobro.id }
                lista.forEach { p ->
                    Row(Modifier.fillMaxWidth().background(Fondo, RoundedCornerShape(12.dp)).border(BorderStroke(1.dp, Ambar.copy(alpha=.25f)), RoundedCornerShape(12.dp)).clickable { verPago = p }.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("N.º ${p.socio} · ${Caja.socio(p.socio)?.nombre.orEmpty()}", color = Texto, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(3.dp)); Text(soles(p.monto), color = Tenue, fontSize = 10.sp)
                        }
                        Pastilla("Ver", Cian)
                    }
                    Spacer(Modifier.height(7.dp))
                }
                if (lista.isEmpty()) Text("Ya no hay comprobantes pendientes.", color = Tenue, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp)); Boton("Cerrar", Modifier.fillMaxWidth(), relleno=false, color=Tenue) { mostrarPendientes=null }
            }
        }
    }

    detalle?.let { (cobro,n) ->
        Dialog(onDismissRequest = { detalle = null }) {
            Tarjeta(borde=Borde, fondo=PanelAlto) {
                val socio = Caja.socio(n); val p = Caja.pagoDe(cobro.id,n); val estado = if (socio?.participaCobros == false) EstadoPago.NO_PAGA else Caja.estadoDe(cobro.id,n)
                FilaEntre {
                    Column(Modifier.weight(1f)) { Etiqueta("N.º $n"); Spacer(Modifier.height(4.dp)); Text(socio?.nombre ?: "", color=Texto, fontSize=18.sp, fontWeight=FontWeight.SemiBold) }
                    Pastilla(textoEstado(estado), colorDe(estado))
                }
                Spacer(Modifier.height(12.dp))
                if (estado == EstadoPago.NO_PAGA) {
                    Text(if (socio?.participaCobros == false) "Cuenta en modo solo visualización; no está incluida en los cobros." else "Indicó que no participará en este cobro.", color=Cian, fontSize=13.sp)
                    val motivo = if (socio?.participaCobros == false) "" else Caja.motivoNoPago(cobro.id, n)
                    if (motivo.isNotBlank()) { Spacer(Modifier.height(7.dp)); Text("Motivo: $motivo", color=Texto, fontSize=12.sp) }
                } else if (p == null) Text("Todavía no registra pago.", color=Tenue, fontSize=13.sp) else {
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Pastilla(if (p.medio == MedioPago.YAPE) "Yape" else "Manual", if (p.medio == MedioPago.YAPE) Violeta else Verde)
                        Text(soles(p.monto), color=Texto, fontSize=14.sp, style=cifra)
                    }
                    Spacer(Modifier.height(5.dp)); Text("${fechaHora(p.enviado)}", color=Tenue, fontSize=12.sp)
                    p.revisadoPor?.let { Spacer(Modifier.height(4.dp)); Text("Revisó N.º $it", color=Tenue, fontSize=10.sp) }
                    if (p.capturaPath.isNotBlank() && (Caja.puedeVerYape(yo) || yo.numero == n)) {
                        Spacer(Modifier.height(10.dp)); Boton("Ver comprobante completo", Modifier.fillMaxWidth(), relleno=false, color=Cian) { verPago=p }
                    }
                    if (estado == EstadoPago.RECHAZADO && p.nota.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text("Motivo: ${p.nota}", color=Rojo, fontSize=12.sp) }
                }
                Spacer(Modifier.height(14.dp)); Boton("Cerrar", Modifier.fillMaxWidth(), relleno=false) { detalle=null }
            }
        }
    }
    noPagar?.let { cobro ->
        Dialog(onDismissRequest = { noPagar = null }) {
            var motivo by remember(cobro.id) { mutableStateOf("") }
            var aviso by remember(cobro.id) { mutableStateOf("") }
            var guardando by remember(cobro.id) { mutableStateOf(false) }
            Tarjeta(borde = Cian.copy(alpha = .45f), fondo = PanelAlto) {
                Etiqueta("NO PARTICIPAR EN ESTE COBRO", Cian)
                Spacer(Modifier.height(7.dp))
                Text(cobro.titulo, color = Texto, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Tu decisión y el motivo quedarán guardados en el acta y en el PDF cuando cierre el cobro.", color = Tenue, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Campo(motivo, { motivo = it.take(300); aviso = "" }, "Motivo · mínimo 4 caracteres")
                if (aviso.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text(aviso, color = Rojo, fontSize = 11.sp) }
                Spacer(Modifier.height(11.dp))
                Boton(if (guardando) "Guardando…" else "Confirmar que no pagaré", Modifier.fillMaxWidth(), color = Cian, activo = !guardando) {
                    if (motivo.trim().length < 4) aviso = "Escribe un motivo claro" else {
                        guardando = true
                        Caja.declararNoPago(cobro.id, motivo) { ok, msg ->
                            guardando = false
                            if (ok) noPagar = null else aviso = msg
                        }
                    }
                }
                Spacer(Modifier.height(7.dp))
                Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue, activo = !guardando) { noPagar = null }
            }
        }
    }
    verPago?.let { p -> VisorPagoDialog(p) { verPago=null } }
}

@Composable
private fun ResumenInicioA() {
    TarjetaPremium {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Etiqueta("SALDO DISPONIBLE", Cian)
                Spacer(Modifier.height(5.dp))
                Text(soles(Caja.saldo()), color = Texto, fontSize = 34.sp, style = cifra)
            }
            Pastilla("CALCULADO", Cian)
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) { MiniDato("INGRESOS", soles(Caja.ingresos()), Verde) }
            Box(Modifier.weight(1f)) { MiniDato("GASTOS", soles(Caja.egresos()), Rojo) }
        }
    }
}

@Composable
private fun ResumenInicioB() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TarjetaPremium {
            Etiqueta("SALDO ACTUAL", Verde)
            Spacer(Modifier.height(6.dp))
            Text(soles(Caja.saldo()), color = Texto, fontSize = 32.sp, style = cifra)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tarjeta(Modifier.weight(1f), borde = Verde.copy(alpha = .3f)) {
                Etiqueta("INGRESOS", Verde)
                Spacer(Modifier.height(6.dp))
                Text(soles(Caja.ingresos()), color = Verde, fontSize = 20.sp, style = cifra)
            }
            Tarjeta(Modifier.weight(1f), borde = Rojo.copy(alpha = .3f)) {
                Etiqueta("GASTOS", Rojo)
                Spacer(Modifier.height(6.dp))
                Text(soles(Caja.egresos()), color = Rojo, fontSize = 20.sp, style = cifra)
            }
        }
    }
}

@Composable
private fun ResumenInicioC() {
    TarjetaPremium {
        FilaEntre {
            Column(Modifier.weight(1f)) {
                Etiqueta("TABLERO", Ambar)
                Spacer(Modifier.height(4.dp))
                Text(soles(Caja.saldo()), color = Texto, fontSize = 28.sp, style = cifra)
            }
            Column(horizontalAlignment = Alignment.End) {
                Pastilla("Ingreso ${soles(Caja.ingresos())}", Verde)
                Spacer(Modifier.height(6.dp))
                Pastilla("Gasto ${soles(Caja.egresos())}", Rojo)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ResumenChip("Cobros", Caja.cobros.count { !it.cerrado }.toString(), Cian, Modifier.weight(1f))
            ResumenChip("Pagos", Caja.pagos.count { it.estado == EstadoPago.APROBADO }.toString(), Verde, Modifier.weight(1f))
            ResumenChip("Actas", Caja.actas.size.toString(), Ambar, Modifier.weight(1f))
        }
    }
}

@Composable
private fun ResumenChip(titulo: String, valor: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier
            .background(color.copy(alpha = .1f), RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = .3f)), RoundedCornerShape(12.dp))
            .padding(vertical = 10.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(valor, color = color, fontSize = 16.sp, style = cifra, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(2.dp))
            Text(titulo, color = Tenue, fontSize = 10.sp)
        }
    }
}

@Composable
private fun AlertaEstado(titulo: String, contador: String, detalle: String, color: Color, alTocar: (() -> Unit)? = null) {
    val base = Modifier
        .fillMaxWidth()
        .background(color.copy(alpha = 0.085f), RoundedCornerShape(14.dp))
        .border(BorderStroke(1.dp, color.copy(alpha = 0.28f)), RoundedCornerShape(14.dp))
    Row(
        (if (alTocar != null) base.clickable { alTocar() } else base)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            Modifier.size(34.dp).background(color.copy(alpha = 0.14f), RoundedCornerShape(11.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(if (color == Ambar) "•" else if (color == Verde) "✓" else "!", color = color, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f)) {
            Text(titulo, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(detalle, color = Texto, fontSize = 11.sp)
        }
        Pastilla(contador, color)
    }
}

@Composable
private fun AlertaImportanteRechazo(motivo: String, reenviar: () -> Unit) {
    Tarjeta(borde = Rojo.copy(alpha = .45f), fondo = PanelAlto) {
        Etiqueta("AVISO IMPORTANTE", Rojo)
        Spacer(Modifier.height(8.dp))
        Text("Tu comprobante fue rechazado", color = Texto, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("Motivo", color = Rojo, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .background(Rojo.copy(alpha = 0.10f), RoundedCornerShape(12.dp))
                .border(BorderStroke(1.dp, Rojo.copy(alpha = 0.28f)), RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text(motivo, color = Texto, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(14.dp))
        Boton("Reenviar ahora", Modifier.fillMaxWidth(), color = Rojo) { reenviar() }
    }
}

@Composable
private fun BarraProgreso(valor: Float) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(8.dp)
            .background(Borde.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
    ) {
        Box(
            Modifier
                .fillMaxWidth(valor.coerceIn(0f, 1f))
                .height(8.dp)
                .background(Verde, RoundedCornerShape(8.dp))
        )
    }
}

@Composable
fun Cuadro(cobroId: Int, estilo: Int, alTocar: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        (1..35).toList().chunked(5).forEach { fila ->
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                fila.forEach { numero ->
                    val socio = Caja.socio(numero)
                    val asignado = socio != null
                    val participa = socio?.participaCobros == true
                    val estado = if (asignado && participa) Caja.estadoDe(cobroId, numero) else null
                    val pago = if (asignado && participa) Caja.pagoDe(cobroId, numero) else null
                    val estadoColor = if (asignado && !participa) Cian else estado?.let { colorDe(it) } ?: Tenue
                    val medioMarcaColor = when {
                        estado == EstadoPago.APROBADO && pago?.medio == MedioPago.YAPE -> Violeta
                        estado == EstadoPago.APROBADO && pago?.medio == MedioPago.MANUAL -> Verde.copy(alpha = .78f)
                        else -> null
                    }
                    val marca = when {
                        estado == EstadoPago.APROBADO && pago?.medio == MedioPago.YAPE -> "Y"
                        estado == EstadoPago.APROBADO && pago?.medio == MedioPago.MANUAL -> "M"
                        asignado && !participa -> "VIS"
                        else -> estado?.let { marcaDe(it) } ?: "LIBRE"
                    }
                    val cellModifier = Modifier.weight(1f).height(if (estilo == 1) 54.dp else 50.dp)
                    when (estilo) {
                        0 -> CeldaCuadroA(cellModifier, numero, asignado, estadoColor, marca, estado, medioMarcaColor, alTocar)
                        1 -> CeldaCuadroB(cellModifier, numero, asignado, estadoColor, marca, estado, medioMarcaColor, alTocar)
                        else -> CeldaCuadroC(cellModifier, numero, asignado, estadoColor, marca, estado, medioMarcaColor, alTocar)
                    }
                }
            }
        }
    }
}

@Composable
private fun CeldaCuadroA(
    modifier: Modifier,
    numero: Int,
    asignado: Boolean,
    color: Color,
    marca: String,
    estado: EstadoPago?,
    marcaColor: Color?,
    alTocar: (Int) -> Unit
) {
    val bg = if (!asignado) Tenue.copy(alpha = 0.05f) else color.copy(alpha = if (estado == EstadoPago.RECHAZADO) 0.18f else 0.10f)
    val border = if (!asignado) Borde.copy(alpha = 0.55f) else if (estado == EstadoPago.RECHAZADO) color else color.copy(alpha = 0.48f)
    Box(
        modifier
            .background(bg, RoundedCornerShape(10.dp))
            .border(BorderStroke(if (estado == EstadoPago.RECHAZADO) 2.dp else 1.dp, border), RoundedCornerShape(10.dp))
            .clickable(enabled = asignado) { alTocar(numero) },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$numero", color = if (asignado) Texto else Tenue, fontSize = 12.sp, style = cifra)
            Text(
                if (asignado) marca else "LIBRE",
                color = if (asignado) (marcaColor ?: color) else Tenue,
                fontSize = if (asignado) 13.sp else 7.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun CeldaCuadroB(
    modifier: Modifier,
    numero: Int,
    asignado: Boolean,
    color: Color,
    marca: String,
    estado: EstadoPago?,
    marcaColor: Color?,
    alTocar: (Int) -> Unit
) {
    val mColor = marcaColor ?: color
    Box(
        modifier
            .background(if (asignado) PanelAlto else Suave, RoundedCornerShape(13.dp))
            .border(BorderStroke(1.dp, if (asignado) color.copy(alpha = 0.45f) else Borde.copy(alpha = 0.55f)), RoundedCornerShape(13.dp))
            .clickable(enabled = asignado) { alTocar(numero) },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .background(if (asignado) mColor.copy(alpha = 0.14f) else Tenue.copy(alpha = 0.08f), RoundedCornerShape(99.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(if (asignado) marca else "-", color = if (asignado) mColor else Tenue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(4.dp))
            Text("$numero", color = if (asignado) Texto else Tenue, fontSize = 13.sp, style = cifra)
            if (!asignado) Text("LIBRE", color = Tenue, fontSize = 7.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun CeldaCuadroC(
    modifier: Modifier,
    numero: Int,
    asignado: Boolean,
    color: Color,
    marca: String,
    estado: EstadoPago?,
    marcaColor: Color?,
    alTocar: (Int) -> Unit
) {
    Box(
        modifier
            .background(if (asignado) color.copy(alpha = 0.12f) else Suave, RoundedCornerShape(9.dp))
            .border(BorderStroke(if (estado == EstadoPago.RECHAZADO) 2.dp else 1.dp, if (asignado) color.copy(alpha = 0.55f) else Borde.copy(alpha = 0.55f)), RoundedCornerShape(9.dp))
            .clickable(enabled = asignado) { alTocar(numero) }
            .padding(6.dp)
    ) {
        if (!asignado) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.align(Alignment.Center)) {
                Text("$numero", color = Tenue, fontSize = 12.sp, style = cifra)
                Text("LIBRE", color = Tenue, fontSize = 7.sp, fontWeight = FontWeight.SemiBold)
            }
        } else {
            Text("$numero", color = Texto, fontSize = 11.sp, style = cifra, modifier = Modifier.align(Alignment.TopStart))
            Text(marca, color = marcaColor ?: color, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomEnd))
        }
    }
}

@Composable
private fun LeyendaCompleta() {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Leyenda(Verde, "✓ Aprobado")
            Leyenda(Ambar, "• Por revisar")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Leyenda(Rojo, "✕ No envió")
            Leyenda(Rojo, "▣ Rechazado")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Leyenda(Violeta, "Y · Yape")
            Leyenda(Verde, "M · Manual")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Leyenda(Cian, "N · No participa")
        }
    }
}

@Composable
private fun Leyenda(color: Color, texto: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(color, RoundedCornerShape(3.dp)))
        Spacer(Modifier.width(6.dp))
        Text(texto, color = Tenue, fontSize = 10.sp)
    }
}

@Composable
private fun EstadoPropio(estado: EstadoPago, cobroId: Int, numero: Int) {
    val p = Caja.pagoDe(cobroId, numero)
    val color = colorDe(estado)
    Box(
        Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.24f)), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Column {
            Text("Tu estado · ${textoEstado(estado)}", color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                when (estado) {
                    EstadoPago.APROBADO -> "Pago confirmado."
                    EstadoPago.PENDIENTE -> "Comprobante enviado. Falta revisión."
                    EstadoPago.RECHAZADO -> "Debes volver a enviar. ${p?.nota.orEmpty()}"
                    EstadoPago.SIN_ENVIAR -> "Aún no enviaste tu comprobante."
                    EstadoPago.NO_PAGA -> "Indicaste que no participarás en este cobro."
                },
                color = Tenue,
                fontSize = 11.sp
            )
        }
    }
}

fun colorDe(estado: EstadoPago): Color = when (estado) {
    EstadoPago.APROBADO -> Verde
    EstadoPago.PENDIENTE -> Ambar
    EstadoPago.RECHAZADO -> Rojo
    EstadoPago.SIN_ENVIAR -> Rojo
    EstadoPago.NO_PAGA -> Cian
}

fun marcaDe(estado: EstadoPago): String = when (estado) {
    EstadoPago.APROBADO -> "✓"
    EstadoPago.PENDIENTE -> "•"
    EstadoPago.RECHAZADO -> "!"
    EstadoPago.SIN_ENVIAR -> "✕"
    EstadoPago.NO_PAGA -> "N"
}

fun textoEstado(estado: EstadoPago): String = when (estado) {
    EstadoPago.APROBADO -> "Aprobado"
    EstadoPago.PENDIENTE -> "Por revisar"
    EstadoPago.RECHAZADO -> "Rechazado"
    EstadoPago.SIN_ENVIAR -> "No enviado"
    EstadoPago.NO_PAGA -> "No participa"
}

fun cuenta(ms: Long): String {
    val s = ms.coerceAtLeast(0L) / 1000
    val d = s / 86400
    val h = (s % 86400) / 3600
    val m = (s % 3600) / 60
    val seg = s % 60
    return if (d > 0) "$d d $h h $m min" else "$h h $m min $seg s"
}
