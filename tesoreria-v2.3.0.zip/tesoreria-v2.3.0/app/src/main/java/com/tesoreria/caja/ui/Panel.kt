package com.tesoreria.caja.ui

import android.graphics.Bitmap
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.animation.core.spring
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.PersonRemove
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Cobro
import com.tesoreria.caja.data.ComprobanteImagen
import com.tesoreria.caja.data.EstadoConexionMiembro
import com.tesoreria.caja.data.EstadoCodigoMasivo
import com.tesoreria.caja.data.EstadoMiembro
import com.tesoreria.caja.data.EstadoPago
import com.tesoreria.caja.data.MedioPago
import com.tesoreria.caja.data.NivelAcceso
import com.tesoreria.caja.data.Pago
import com.tesoreria.caja.data.Permiso
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.data.TipoCobro
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.parseCentavos
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.UUID

@Composable
fun PantallaPanel() {
    val yo = Caja.sesion.value ?: return
    if (!Caja.puedeAbrirPanel(yo)) {
        Tarjeta {
            Titulo("Sin permisos administrativos")
            Spacer(Modifier.height(6.dp))
            Text("Tu cuenta no tiene herramientas administrativas asignadas.", color = Tenue, fontSize = 13.5.sp)
        }
        return
    }

    val seccionesDisponibles = buildList {
        if (Caja.esOwner || Caja.tienePermiso(yo, Permiso.REGISTRAR_PAGO_MANUAL) || Caja.puedeVerYape(yo)) add(0 to "Pagos")
        if (Caja.esOwner || Caja.tienePermiso(yo, Permiso.GESTIONAR_COBROS)) add(1 to "Cobro")
        if (Caja.esOwner || Caja.tienePermiso(yo, Permiso.REGISTRAR_GASTOS)) add(2 to "Gastos")
        if (Caja.esOwner || Caja.tienePermiso(yo, Permiso.GESTIONAR_NUMERO_YAPE) || Caja.tienePermiso(yo, Permiso.GESTIONAR_YAPE)) add(3 to "Yape")
        if (Caja.esOwner || Caja.tienePermiso(yo, Permiso.GESTIONAR_MIEMBROS) || Caja.tienePermiso(yo, Permiso.GENERAR_CODIGOS)) add(4 to "Miembros")
        if (Caja.esOwner) add(5 to "Owner")
    }
    var seccion by remember { mutableStateOf(seccionesDisponibles.firstOrNull()?.first ?: 0) }
    LaunchedEffect(seccionesDisponibles) {
        if (seccionesDisponibles.none { it.first == seccion }) {
            seccion = seccionesDisponibles.firstOrNull()?.first ?: 0
        }
    }
    Column(Modifier.fillMaxWidth()) {
        Etiqueta(if (Caja.esOwner) "PANEL DEL OWNER" else "PANEL", ColorPanel)
        Spacer(Modifier.height(10.dp))

        SelectorAdmin(seccion, seccionesDisponibles) { seccion = it }
        Spacer(Modifier.height(14.dp))
        androidx.compose.animation.AnimatedContent(
            targetState = seccion,
            transitionSpec = {
                (fadeIn(tween(380, delayMillis = 60)) + androidx.compose.animation.slideInVertically(tween(420, easing = CurvaSuave)) { it / 14 })
                    .togetherWith(fadeOut(tween(160)))
            },
            label = "seccionPanel"
        ) { sec ->
            Column {
                val titulo = seccionesDisponibles.firstOrNull { it.first == sec }?.second.orEmpty()
                CabeceraSeccion(iconoSeccion(sec), titulo, colorSeccion(sec))
                Spacer(Modifier.height(12.dp))
                when (sec) {
                    0 -> PagosAdmin()
                    1 -> CobroAdmin()
                    2 -> GastosAdmin()
                    3 -> YapeAdmin()
                    4 -> MiembrosAdmin()
                    else -> OwnerAdmin()
                }
            }
        }
    }
}

@Composable
private fun PagosAdmin() {
    val yo = Caja.sesion.value
    val puedeManual = Caja.tienePermiso(yo, Permiso.REGISTRAR_PAGO_MANUAL)
    val puedeYape = Caja.puedeVerYape(yo)
    val puedeRevisar = Caja.puedeRevisarYape(yo)
    if (!puedeManual && !puedeYape) { SinPermiso(); return }

    var mostrarManual by remember { mutableStateOf(false) }
    var corregir by remember { mutableStateOf<Pago?>(null) }
    var rechazar by remember { mutableStateOf<Pago?>(null) }
    var rechazarGrupo by remember { mutableStateOf<Pair<String, List<Pago>>?>(null) }
    var aprobarConfirmacion by remember { mutableStateOf<Pair<Pago, List<Pago>>?>(null) }
    var verComprobante by remember { mutableStateOf<Pago?>(null) }

    if (puedeManual) {
        Boton("Registrar pago", Modifier.fillMaxWidth(), color = Verde, icono = Icons.Rounded.AddAPhoto) { mostrarManual = true }
        Spacer(Modifier.height(12.dp))
    }

    if (puedeYape) {
        PartesPorRevisar(puedeRevisar)
        Etiqueta("YAPES POR REVISAR", Naranja)
        Spacer(Modifier.height(8.dp))
        val pendientes = Caja.pendientes()
        val grupos = pendientes.groupBy { p -> p.grupoId.takeIf { it.isNotBlank() } ?: "p:${p.serverId}" }
        if (grupos.isEmpty()) Vacio(if (Caja.abonosPorRevisar().isEmpty()) "No hay comprobantes por revisar." else "No hay otros comprobantes por revisar.")

        grupos.values.sortedByDescending { g -> g.maxOfOrNull { it.enviado } ?: 0L }.forEach { grupo ->
            val rep = grupo.firstOrNull { it.capturaPath.isNotBlank() } ?: grupo.first()
            val cobro = Caja.cobros.firstOrNull { it.id == rep.cobroId }
            val esGrupo = rep.grupoId.isNotBlank() && (rep.grupoNumeros.size > 1 || grupo.size > 1)
            val numeros = if (rep.grupoNumeros.isNotEmpty()) rep.grupoNumeros else grupo.map { it.socio }.distinct().sorted()
            val pagador = rep.pagadorNumero ?: rep.socio
            val fuera = cobro != null && rep.enviado > cobro.cierra
            Tarjeta(borde = if (fuera) Ambar.copy(alpha = .55f) else Borde) {
                FilaEntre {
                    Column(Modifier.weight(1f)) {
                        Etiqueta(if (esGrupo) "YAPE EN CONJUNTO" else "N.º ${rep.socio} · YAPE")
                        Spacer(Modifier.height(3.dp))
                        if (esGrupo) {
                            Text("Enviado por N.º $pagador · ${Caja.socio(pagador)?.nombre.orEmpty()}", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(3.dp))
                            Text("Incluye: ${numeros.joinToString(", ") { it.toString().padStart(2, '0') }}", color = Cian, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        } else {
                            Text(Caja.socio(rep.socio)?.nombre.orEmpty(), color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                        cobro?.let { c ->
                            Spacer(Modifier.height(3.dp))
                            Text("${if (c.tipo == TipoCobro.RAPIDO) "Rápido" else "Oficial"} · ${c.titulo}", color = if (c.tipo == TipoCobro.RAPIDO) Ambar else Cian, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Text(soles(grupo.sumOf { it.monto }), color = Verde, fontSize = 17.sp, style = cifra)
                }
                Spacer(Modifier.height(6.dp))
                Text(fechaHora(rep.enviado), color = Tenue, fontSize = 12.sp)
                if (fuera) { Spacer(Modifier.height(7.dp)); Pastilla("Fuera del plazo", Ambar) }
                if (rep.capturaPath.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Boton("Ver comprobante", Modifier.fillMaxWidth(), relleno = false, color = Cian) { verComprobante = rep }
                }
                Spacer(Modifier.height(10.dp))
                if (puedeRevisar) {
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Boton("Aprobar", Modifier.weight(1f), color = Verde) {
                            aprobarConfirmacion = rep to grupo
                        }
                        Boton("Rechazar", Modifier.weight(1f), relleno = false, color = Rojo) {
                            if (esGrupo) rechazarGrupo = rep.grupoId to grupo else rechazar = rep
                        }
                        if (!esGrupo && Caja.esOwner) Boton("Corregir", Modifier.weight(1f), relleno = false, color = Ambar) { corregir = rep }
                    }
                } else {
                    Pastilla("Solo lectura · no puedes aprobar ni rechazar", Cian)
                }
            }
            Spacer(Modifier.height(9.dp))
        }
    }

    if (mostrarManual) Hoja(onDismissRequest = { mostrarManual = false }) { PagoManualDialog { mostrarManual = false } }
    corregir?.let { p -> Hoja(onDismissRequest = { corregir = null }) { CorregirPagoDialog(p) { corregir = null } } }
    rechazar?.let { p -> Hoja(onDismissRequest = { rechazar = null }) { RechazarDialog(p) { rechazar = null } } }
    rechazarGrupo?.let { item -> Hoja(onDismissRequest = { rechazarGrupo = null }) { RechazarGrupoDialog(item.first, item.second) { rechazarGrupo = null } } }
    aprobarConfirmacion?.let { item ->
        val rep = item.first
        val grupo = item.second
        val esGrupo = rep.grupoId.isNotBlank() && (rep.grupoNumeros.size > 1 || grupo.size > 1)
        val numeros = if (rep.grupoNumeros.isNotEmpty()) rep.grupoNumeros else grupo.map { it.socio }.distinct().sorted()
        Hoja(onDismissRequest = { aprobarConfirmacion = null }) {
            Tarjeta(borde = Verde.copy(alpha = .5f), fondo = PanelAlto) {
                Titulo(if (esGrupo) "¿Aprobar pago en conjunto?" else "¿Aprobar este Yape?")
                Spacer(Modifier.height(7.dp))
                Text("Incluye N.º ${numeros.joinToString(", ")}", color = Texto, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text("Total: ${soles(grupo.sumOf { it.monto })}", color = Verde, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text("Confirma solo si el comprobante coincide con el pago recibido.", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Boton("Sí, aprobar", Modifier.fillMaxWidth(), color = Verde) {
                    if (esGrupo) Caja.aprobarGrupoYape(rep.grupoId) else Caja.aprobarPago(rep.id)
                    aprobarConfirmacion = null
                }
                Spacer(Modifier.height(7.dp))
                Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { aprobarConfirmacion = null }
            }
        }
    }
    verComprobante?.let { p -> VisorPagoDialog(p) { verComprobante = null } }
}

@Composable
private fun PagoManualDialog(cerrar: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var captura by remember { mutableStateOf<ComprobanteImagen.Resultado?>(null) }
    var verGrande by remember { mutableStateOf<Bitmap?>(null) }
    var progresoFoto by remember { mutableStateOf(0) }
    var enviandoFoto by remember { mutableStateOf(false) }
    var listoFoto by remember { mutableStateOf(false) }
    fun elegirCaptura(uri: Uri?) {
        if (uri == null) return
        scope.launch {
            try { captura = ComprobanteImagen.leerParaYape(context, uri) }
            catch (e: Exception) { }
        }
    }
    val selectorFotos = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> elegirCaptura(uri) }
    val selectorArchivos = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> elegirCaptura(uri) }
    val activos = Caja.cobrosActivos()
    var cobroId by remember { mutableStateOf<Int?>(activos.firstOrNull()?.id) }
    val cobro = activos.firstOrNull { it.id == cobroId }
    val porPartes = cobro?.permitePartes == true
    var montoParte by remember { mutableStateOf("") }
    var buscar by remember { mutableStateOf("") }
    var enConjunto by remember { mutableStateOf(false) }
    var seleccionados by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var aviso by remember { mutableStateOf("") }
    var guardando by remember { mutableStateOf(false) }
    val focusBuscar = remember { FocusRequester() }
    val q = buscar.trim()
    val resultados = if (q.isBlank()) emptyList() else Caja.socios.filter {
        it.estado == EstadoMiembro.ACTIVO && it.participaCobros && (it.numero.toString() == q || it.nombre.contains(q, ignoreCase = true))
    }.take(8)

    if (enviandoFoto || listoFoto) {
        Tarjeta(borde = Verde.copy(alpha = .5f), fondo = PanelAlto) {
            AnimacionEnvio(progresoFoto, listoFoto, MoradoYape, "Subiendo captura…")
        }
        return
    }

    Tarjeta(borde = Verde.copy(alpha = .5f), fondo = PanelAlto) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Payments, null, tint = Verde, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
            Text("Registrar pago", color = Texto, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))

        if (activos.isEmpty()) {
            Vacio("No hay cobros activos.")
        } else {
            Etiqueta("ELIGE EL COBRO")
            Spacer(Modifier.height(6.dp))
            activos.forEach { c ->
                val elegido = c.id == cobroId
                val color = if (c.tipo == TipoCobro.RAPIDO) Ambar else Verde
                Row(
                    Modifier.fillMaxWidth()
                        .background(if (elegido) color.copy(alpha = .12f) else Fondo, RoundedCornerShape(11.dp))
                        .border(BorderStroke(1.dp, if (elegido) color.copy(alpha = .55f) else Borde), RoundedCornerShape(11.dp))
                        .clickable { cobroId = c.id; seleccionados = emptySet(); enConjunto = false; montoParte = ""; aviso = "" }
                        .padding(horizontal = 11.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(if (c.tipo == TipoCobro.RAPIDO) "Rápido · ${c.titulo}" else if (c.permitePartes) "Por partes · ${c.titulo}" else "Oficial · ${c.titulo}", color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(2.dp)); Text(soles(c.monto), color = color, fontSize = 13.sp)
                    }
                    if (elegido) Pastilla("Elegido", color)
                }
                Spacer(Modifier.height(5.dp))
            }

            Spacer(Modifier.height(7.dp))
            if (!porPartes) Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Pestana("Un pago", !enConjunto, Verde, Modifier.weight(1f)) { enConjunto = false; seleccionados = seleccionados.firstOrNull()?.let { setOf(it) } ?: emptySet(); aviso = "" }
                Pestana("Varios", enConjunto, Celeste, Modifier.weight(1f)) { enConjunto = true; aviso = "" }
            }
            Spacer(Modifier.height(8.dp))
            Campo(buscar, { buscar = it; aviso = "" }, if (enConjunto) "Agregar número o nombre" else "Número o nombre", focusRequester = focusBuscar)

            if (resultados.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                resultados.forEach { socio ->
                    val elegido = socio.numero in seleccionados
                    Row(
                        Modifier.fillMaxWidth().background(if (elegido) Verde.copy(alpha = .11f) else Fondo, RoundedCornerShape(10.dp))
                            .border(BorderStroke(1.dp, if (elegido) Verde.copy(alpha = .45f) else Borde), RoundedCornerShape(10.dp))
                            .clickable {
                                seleccionados = if (enConjunto) {
                                    if (elegido) seleccionados - socio.numero else seleccionados + socio.numero
                                } else setOf(socio.numero)
                                buscar = ""; aviso = ""
                            }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(socio.numero.toString().padStart(2, '0'), color = Verde, fontSize = 15.sp, style = cifra)
                        Spacer(Modifier.width(10.dp))
                        Text(socio.nombre, color = Texto, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        if (elegido) Pastilla("Incluido", Verde)
                    }
                    Spacer(Modifier.height(5.dp))
                }
            }

            if (seleccionados.isNotEmpty()) {
                Spacer(Modifier.height(9.dp))
                Etiqueta(if (seleccionados.size > 1) "INCLUIDOS · ${seleccionados.size}" else "SELECCIONADO", if (seleccionados.size > 1) Cian else Verde)
                Spacer(Modifier.height(5.dp))
                seleccionados.sorted().forEach { n ->
                    val socio = Caja.socio(n)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("${n.toString().padStart(2, '0')} · ${socio?.nombre.orEmpty()}", color = Texto, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        if (enConjunto) Icon(Icons.Rounded.Close, "Quitar", tint = Rojo, modifier = Modifier.size(22.dp).clickable { seleccionados = seleccionados - n })
                    }
                    Spacer(Modifier.height(3.dp))
                }
                cobro?.let { c ->
                    Spacer(Modifier.height(4.dp))
                    Text("Total registrado: ${soles(c.monto * seleccionados.size)}", color = if (c.tipo == TipoCobro.RAPIDO) Ambar else Verde, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        val elegidoParte = seleccionados.firstOrNull()
        if (porPartes && cobro != null && elegidoParte != null) {
            val partes = Caja.abonosDe(cobro.id, elegidoParte)
            val pagado = Caja.pagadoDe(cobro.id, elegidoParte)
            val falta = (cobro.monto - pagado).coerceAtLeast(0L)
            Spacer(Modifier.height(12.dp))
            Column(Modifier.fillMaxWidth().background(Azul.copy(alpha = .08f), RoundedCornerShape(16.dp)).padding(12.dp)) {
                FilaEntre {
                    Text("Lleva ${soles(pagado)} de ${soles(cobro.monto)}", color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("${partes.size}/4", color = Azul, fontSize = 13.sp, style = cifra)
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(8.dp).background(Borde, RoundedCornerShape(99.dp))) {
                    val f by animateFloatAsState(if (cobro.monto > 0) (pagado.toFloat() / cobro.monto).coerceIn(0f, 1f) else 0f, tween(700, easing = CurvaSuave), label = "avanceParte")
                    Box(Modifier.fillMaxWidth(f).fillMaxHeight().background(if (falta == 0L) Verde else Azul, RoundedCornerShape(99.dp)))
                }
                partes.forEachIndexed { i, a ->
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (a.capturaPath.isNotBlank()) MiniaturaPago(a.capturaPath, Modifier.size(width = 30.dp, height = 36.dp), radio = 7.dp)
                        else Box(Modifier.size(width = 30.dp, height = 36.dp).background(Panel, RoundedCornerShape(7.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Payments, null, tint = Tenue, modifier = Modifier.size(16.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Parte ${i + 1} · ${soles(a.monto)}", color = Texto, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                            Text(fechaHora(a.fecha), color = Tenue, fontSize = 12.sp)
                        }
                        Icon(
                            Icons.Rounded.Close, "Quitar parte", tint = Rojo.copy(alpha = .8f),
                            modifier = Modifier.size(22.dp).clickable(enabled = !guardando) {
                                guardando = true
                                Caja.anularAbono(a) { ok, msg -> guardando = false; aviso = if (ok) "✓ $msg" else msg }
                            }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    if (falta == 0L) "Ya completó el cobro" else if (partes.size >= 4) "Ya tiene 4 partes" else "Le falta ${soles(falta)}",
                    color = if (falta == 0L) Verde else if (partes.size >= 4) Rojo else Azul, fontSize = 13.5.sp, fontWeight = FontWeight.Bold
                )
            }
            if (falta > 0L && partes.size < 4) {
                Spacer(Modifier.height(10.dp))
                Campo(montoParte, { montoParte = it; aviso = "" }, "Monto de esta parte · máx ${soles(falta)}", numerico = true)
            }
        }

        if (activos.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Photo, null, tint = MoradoYape, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Captura del Yape (opcional)", color = MoradoYape, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(7.dp))
            val img = captura
            if (img == null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Boton("Foto", Modifier.weight(1f), color = MoradoYape, icono = Icons.Rounded.PhotoLibrary, activo = !guardando) {
                        selectorFotos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    Boton("Archivo", Modifier.weight(1f), relleno = false, color = MoradoYape, icono = Icons.Rounded.FolderOpen, activo = !guardando) {
                        selectorArchivos.launch(arrayOf("image/*"))
                    }
                }
            } else {
                Box(Modifier.height(150.dp)) { MiniaturaComprobante(img.bitmap) { verGrande = img.bitmap } }
                Spacer(Modifier.height(7.dp))
                Boton("Quitar captura", Modifier.fillMaxWidth(), relleno = false, color = Rojo, icono = Icons.Rounded.Delete, activo = !guardando) { captura = null }
            }
        }

        if (aviso.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            AvisoEstado(aviso, ocupado = guardando)
        }
        Spacer(Modifier.height(14.dp))
        Boton(
            if (guardando) "Registrando…" else if (porPartes) "Registrar parte" else if (seleccionados.size > 1) "Confirmar ${seleccionados.size} pagos" else "Confirmar pago",
            Modifier.fillMaxWidth(), color = Verde,
            activo = seleccionados.isNotEmpty() && cobro != null && !guardando,
            icono = if (captura != null) Icons.Rounded.Send else Icons.Rounded.Check
        ) {
            val c = cobro
            val nums = seleccionados.sorted()
            if (c == null) aviso = "Selecciona el cobro"
            else if (nums.isEmpty()) aviso = "Selecciona a la persona"
            else {
                guardando = true; aviso = "Registrando pago…"
                val fin: (Boolean, String) -> Unit = { ok, mensaje ->
                    guardando = false
                    if (ok) {
                        aviso = if (nums.size > 1) "✓ ${nums.size} pagos registrados" else "✓ Pago registrado · N.º ${nums.first()}"
                        buscar = ""; seleccionados = emptySet(); focusBuscar.requestFocus()
                    } else aviso = mensaje.ifBlank { "No se pudo registrar el pago" }
                }
                val img = captura
                if (porPartes) {
                    val n = nums.first()
                    val falta = (c.monto - Caja.pagadoDe(c.id, n)).coerceAtLeast(0L)
                    val m = parseCentavos(montoParte) ?: 0L
                    when {
                        nums.size != 1 -> { guardando = false; aviso = "Elige una sola persona" }
                        Caja.abonosDe(c.id, n).size >= 4 -> { guardando = false; aviso = "Ya tiene 4 partes" }
                        falta <= 0L -> { guardando = false; aviso = "Ya completó el cobro" }
                        m <= 0L -> { guardando = false; aviso = "Escribe el monto de esta parte" }
                        m > falta -> { guardando = false; aviso = "Máximo ${soles(falta)}" }
                        else -> {
                            enviandoFoto = true; progresoFoto = 0; aviso = ""
                            scope.launch {
                                try {
                                    Caja.registrarAbono(c, n, m, img) { progresoFoto = it }
                                    listoFoto = true
                                    enviandoFoto = false
                                    captura = null
                                    montoParte = ""
                                    aviso = if (m == falta) "✓ N.º $n completó el cobro" else "✓ Parte registrada · le falta ${soles(falta - m)}"
                                    guardando = false
                                    delay(2300)
                                    listoFoto = false
                                } catch (e: Exception) {
                                    enviandoFoto = false
                                    listoFoto = false
                                    guardando = false
                                    aviso = e.message ?: "No se pudo registrar la parte"
                                }
                            }
                        }
                    }
                } else if (img != null) {
                    enviandoFoto = true; progresoFoto = 0; aviso = ""
                    scope.launch {
                        try {
                            Caja.registrarPagoManualFoto(c, nums, img) { progresoFoto = it }
                            listoFoto = true
                            enviandoFoto = false
                            captura = null
                            buscar = ""
                            seleccionados = emptySet()
                            aviso = if (nums.size > 1) "✓ ${nums.size} pagos con captura" else "✓ Pago con captura · N.º ${nums.first()}"
                            guardando = false
                            delay(2300)
                            listoFoto = false
                        } catch (e: Exception) {
                            enviandoFoto = false
                            listoFoto = false
                            guardando = false
                            aviso = e.message ?: "No se pudo registrar el pago"
                        }
                    }
                } else if (nums.size > 1 || enConjunto) Caja.registrarPagoManualGrupo(c.id, nums, fin)
                else Caja.registrarPagoManual(c.id, nums.first(), c.monto, fin)
            }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
    verGrande?.let { b -> VisorBitmapDialog(b) { verGrande = null } }
}

@Composable
private fun CorregirPagoDialog(pago: Pago, cerrar: () -> Unit) {
    var destino by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    val n = destino.toIntOrNull()
    val s = n?.let(Caja::socio)?.takeIf { it.participaCobros }
    Tarjeta(borde = Ambar.copy(alpha = .5f), fondo = PanelAlto) {
        Etiqueta("CORREGIR PERSONA DEL PAGO", Ambar)
        Spacer(Modifier.height(7.dp))
        Text("Ahora está asignado al N.º ${pago.socio} · ${Caja.socio(pago.socio)?.nombre}", color = Texto, fontSize = 13.5.sp)
        Spacer(Modifier.height(10.dp))
        Campo(destino, { destino = it.filter(Char::isDigit).take(2); aviso = "" }, "Número correcto", numerico = true)
        if (s != null) {
            Spacer(Modifier.height(9.dp))
            Text("¿Es ${s.nombre}?", color = Texto, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("N.º ${s.numero}", color = Tenue, fontSize = 13.sp)
        }
        if (aviso.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(aviso, color = Rojo, fontSize = 13.sp) }
        Spacer(Modifier.height(14.dp))
        Boton("Sí, corregir asignación", Modifier.fillMaxWidth(), color = Ambar, activo = s != null && n != pago.socio) {
            if (n == null || s == null) aviso = "Selecciona un número válido" else { Caja.corregirAsignacionPago(pago.id, n); cerrar() }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
}

@Composable
private fun RechazarDialog(pago: Pago, cerrar: () -> Unit) {
    var motivo by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    Tarjeta(borde = Rojo.copy(alpha = .45f), fondo = PanelAlto) {
        Etiqueta("RECHAZAR YAPE", Rojo)
        Spacer(Modifier.height(8.dp))
        Text("N.º ${pago.socio} · ${Caja.socio(pago.socio)?.nombre}", color = Texto, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Campo(motivo, { motivo = it; aviso = "" }, "Motivo")
        if (aviso.isNotEmpty()) { Spacer(Modifier.height(7.dp)); Text(aviso, color = Rojo, fontSize = 13.sp) }
        Spacer(Modifier.height(12.dp))
        Boton("Confirmar rechazo", Modifier.fillMaxWidth(), color = Rojo) {
            if (motivo.trim().length < 4) aviso = "Escribe un motivo claro" else { Caja.rechazarPago(pago.id, motivo); cerrar() }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
}

@Composable
private fun RechazarGrupoDialog(grupoId: String, pagos: List<Pago>, cerrar: () -> Unit) {
    var motivo by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    val numeros = pagos.flatMap { if (it.grupoNumeros.isNotEmpty()) it.grupoNumeros else listOf(it.socio) }.distinct().sorted()
    Tarjeta(borde = Rojo.copy(alpha = .45f), fondo = PanelAlto) {
        Etiqueta("RECHAZAR YAPE EN CONJUNTO", Rojo)
        Spacer(Modifier.height(8.dp))
        Text("Incluye N.º ${numeros.joinToString(", ")}", color = Texto, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Campo(motivo, { motivo = it; aviso = "" }, "Motivo")
        if (aviso.isNotEmpty()) { Spacer(Modifier.height(7.dp)); Text(aviso, color = Rojo, fontSize = 13.sp) }
        Spacer(Modifier.height(12.dp))
        Boton("Confirmar rechazo", Modifier.fillMaxWidth(), color = Rojo) {
            if (motivo.trim().length < 4) aviso = "Escribe un motivo claro" else { Caja.rechazarGrupoYape(grupoId, motivo); cerrar() }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
}

@Composable
private fun CobroAdmin() {
    val yo = Caja.sesion.value
    if (!Caja.tienePermiso(yo, Permiso.GESTIONAR_COBROS)) {
        SinPermiso()
        return
    }

    val context = LocalContext.current
    val activos = Caja.cobrosActivos()
    val oficialesActivos = activos.count { it.tipo == TipoCobro.OFICIAL }
    val rapidosActivos = activos.count { it.tipo == TipoCobro.RAPIDO }
    var titulo by remember { mutableStateOf("") }
    var monto by remember { mutableStateOf("") }
    var duracion by remember { mutableStateOf("1") }
    var unidad by remember { mutableStateOf(1) } // 0 min, 1 h, 2 días, 3 fecha/hora
    var cierreExacto by remember { mutableStateOf<Long?>(null) }
    var tipo by remember { mutableStateOf(TipoCobro.OFICIAL) }
    var partes by remember { mutableStateOf(false) }
    var aviso by remember { mutableStateOf("") }
    var ajustar by remember { mutableStateOf<Cobro?>(null) }
    var cerrar by remember { mutableStateOf<Cobro?>(null) }

    fun elegirFechaHora(inicial: Long, alElegir: (Long) -> Unit) {
        val cal = Calendar.getInstance().apply { timeInMillis = inicial.coerceAtLeast(System.currentTimeMillis() + 2 * 60_000L) }
        DatePickerDialog(context, { _, y, m, d ->
            val elegido = Calendar.getInstance().apply {
                set(Calendar.YEAR, y); set(Calendar.MONTH, m); set(Calendar.DAY_OF_MONTH, d)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            TimePickerDialog(context, { _, h, min ->
                elegido.set(Calendar.HOUR_OF_DAY, h); elegido.set(Calendar.MINUTE, min)
                alElegir(elegido.timeInMillis)
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    Tarjeta(borde = Cian.copy(alpha = .35f), fondo = PanelAlto) {
        Etiqueta("CAPACIDAD DE COBROS", Cian)
        Spacer(Modifier.height(7.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pastilla("Oficiales $oficialesActivos/3", if (oficialesActivos < 3) Verde else Rojo)
            Pastilla("Rápidos $rapidosActivos/2", if (rapidosActivos < 2) Ambar else Rojo)
        }
    }
    Spacer(Modifier.height(9.dp))

    if (activos.isNotEmpty()) {
        Etiqueta("COBROS ACTIVOS")
        Spacer(Modifier.height(8.dp))
        activos.forEach { c ->
            val color = if (c.tipo == TipoCobro.RAPIDO) Ambar else Verde
            Tarjeta(borde = color.copy(alpha = .48f), fondo = PanelAlto) {
                FilaEntre {
                    Column(Modifier.weight(1f)) {
                        Etiqueta(if (c.tipo == TipoCobro.RAPIDO) "COBRO RÁPIDO" else "COBRO OFICIAL", color)
                        Spacer(Modifier.height(3.dp))
                        Text(c.titulo, color = Texto, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(soles(c.monto), color = color, fontSize = 17.sp, style = cifra)
                }
                Spacer(Modifier.height(6.dp))
                Text("Cierra ${fechaHora(c.cierra)}", color = Tenue, fontSize = 13.sp)
                if (c.extensionTexto.isNotBlank()) { Spacer(Modifier.height(6.dp)); Pastilla(c.extensionTexto, Ambar) }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Boton("Ajustar plazo", Modifier.weight(1f), relleno = false, color = color) { ajustar = c }
                    Boton("Cerrar", Modifier.weight(1f), relleno = false, color = Rojo) { cerrar = c }
                }
            }
            Spacer(Modifier.height(9.dp))
        }
    }

    Tarjeta(borde = if (tipo == TipoCobro.RAPIDO) Ambar.copy(alpha=.4f) else Verde.copy(alpha=.35f)) {
        Titulo("Abrir nuevo cobro")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pestana("Oficial", tipo == TipoCobro.OFICIAL, Verde, Modifier.weight(1f)) { tipo = TipoCobro.OFICIAL; aviso = "" }
            Pestana("Rápido", tipo == TipoCobro.RAPIDO, Ambar, Modifier.weight(1f)) { tipo = TipoCobro.RAPIDO; partes = false; aviso = "" }
        }
        Spacer(Modifier.height(10.dp))
        Campo(titulo, { titulo = it; aviso = "" }, if (tipo == TipoCobro.RAPIDO) "Ej. Copias" else "Concepto")
        Spacer(Modifier.height(8.dp))
        Campo(monto, { monto = it; aviso = "" }, if (partes) "Total a pagar · Ej. 200" else "Monto · 1.00", numerico = true)
        if (tipo == TipoCobro.OFICIAL) {
            Spacer(Modifier.height(8.dp))
            PermisoToggle(if (partes) "Se paga en partes · hasta 4" else "Pagar en partes", partes, color = Azul) { partes = !partes }
        }
        Spacer(Modifier.height(9.dp))
        Etiqueta("CIERRE DEL COBRO")
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Pestana("Min", unidad == 0, Cian, Modifier.weight(1f)) { unidad = 0; aviso = "" }
            Pestana("Horas", unidad == 1, Cian, Modifier.weight(1f)) { unidad = 1; aviso = "" }
            Pestana("Días", unidad == 2, Cian, Modifier.weight(1f)) { unidad = 2; aviso = "" }
            Pestana("Fecha", unidad == 3, Cian, Modifier.weight(1f)) { unidad = 3; aviso = "" }
        }
        Spacer(Modifier.height(8.dp))
        if (unidad == 3) {
            Boton(
                cierreExacto?.let { "${fechaHora(it)}" } ?: "Elegir fecha y hora",
                Modifier.fillMaxWidth(), relleno = false, color = Cian
            ) { elegirFechaHora(cierreExacto ?: (System.currentTimeMillis() + 24L * 60L * 60L * 1000L)) { cierreExacto = it; aviso = "" } }
        } else {
            Campo(duracion, { duracion = it.filter(Char::isDigit).take(4); aviso = "" }, when (unidad) { 0 -> "Minutos"; 1 -> "Horas"; else -> "Días" }, numerico = true)
        }
        if (aviso.isNotBlank()) { Spacer(Modifier.height(7.dp)); Text(aviso, color = Rojo, fontSize = 13.sp) }
        Spacer(Modifier.height(11.dp))
        val limiteAlcanzado = if (tipo == TipoCobro.OFICIAL) oficialesActivos >= 3 else rapidosActivos >= 2
        Boton(
            if (tipo == TipoCobro.RAPIDO) "Abrir cobro rápido" else "Abrir cobro oficial",
            Modifier.fillMaxWidth(), color = if (tipo == TipoCobro.RAPIDO) Ambar else Verde, activo = !limiteAlcanzado
        ) {
            val c = parseCentavos(monto) ?: 0L
            val d = duracion.toIntOrNull() ?: 0
            val minutos = when (unidad) { 0 -> d; 1 -> d * 60; 2 -> d * 1440; else -> 0 }
            when {
                titulo.trim().length < 2 -> aviso = "Falta el concepto"
                c <= 0 -> aviso = "Monto inválido"
                tipo == TipoCobro.OFICIAL && oficialesActivos >= 3 -> aviso = "Máximo 3 cobros oficiales activos"
                tipo == TipoCobro.RAPIDO && rapidosActivos >= 2 -> aviso = "Máximo 2 cobros rápidos activos"
                unidad == 3 && (cierreExacto == null || cierreExacto!! <= System.currentTimeMillis() + 60_000L) -> aviso = "Elige una fecha y hora futura"
                unidad == 3 && cierreExacto!! > System.currentTimeMillis() + 365L * 24L * 60L * 60L * 1000L -> aviso = "El cierre no puede superar 365 días"
                unidad != 3 && minutos <= 0 -> aviso = "Duración inválida"
                unidad != 3 && minutos > 525_600 -> aviso = "El cierre no puede superar 365 días"
                else -> {
                    if (tipo == TipoCobro.OFICIAL && partes) {
                        val cierre = if (unidad == 3) cierreExacto!! else System.currentTimeMillis() + minutos * 60_000L
                        Caja.crearCobroPorPartes(titulo.trim(), c, cierre)
                    } else if (unidad == 3) Caja.crearCobroFecha(titulo.trim(), c, cierreExacto!!, tipo)
                    else Caja.crearCobro(titulo.trim(), c, minutos, tipo)
                    partes = false
                    titulo = ""; monto = ""; duracion = if (tipo == TipoCobro.RAPIDO) "15" else "1"; cierreExacto = null; aviso = ""
                }
            }
        }
        if (limiteAlcanzado) { Spacer(Modifier.height(7.dp)); Text(if (tipo == TipoCobro.OFICIAL) "Ya tienes 3 cobros oficiales activos." else "Ya tienes 2 cobros rápidos activos.", color = Rojo, fontSize = 12.sp) }
    }

    ajustar?.let { cobro -> Hoja(onDismissRequest = { ajustar = null }) {
        var extra by remember(cobro.id) { mutableStateOf("10") }
        var exacto by remember(cobro.id) { mutableStateOf(cobro.cierra) }
        var avisoExt by remember { mutableStateOf("") }
        Tarjeta(borde = (if (cobro.tipo == TipoCobro.RAPIDO) Ambar else Verde).copy(alpha=.5f), fondo = PanelAlto) {
            Etiqueta("AJUSTAR PLAZO", if (cobro.tipo == TipoCobro.RAPIDO) Ambar else Verde)
            Spacer(Modifier.height(6.dp))
            Text("Cierre actual: ${fechaHora(cobro.cierra)}", color = Texto, fontSize = 13.5.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                Boton("-10 min", Modifier.weight(1f), relleno = false, color = Ambar) { extra = "-10" }
                Boton("+10 min", Modifier.weight(1f), relleno = false, color = Verde) { extra = "10" }
                Boton("+1 día", Modifier.weight(1f), relleno = false, color = Cian) { extra = "1440" }
            }
            Spacer(Modifier.height(7.dp))
            Campo(extra, { extra = it.filter { ch -> ch.isDigit() || ch == '-' }.take(6); avisoExt = "" }, "Minutos (+ / -)", numerico = true)
            Spacer(Modifier.height(9.dp))
            Boton("Fecha exacta · ${fechaHora(exacto)}", Modifier.fillMaxWidth(), relleno = false, color = Cian) {
                elegirFechaHora(exacto) { exacto = it; avisoExt = "" }
            }
            if (avisoExt.isNotEmpty()) { Spacer(Modifier.height(6.dp)); Text(avisoExt, color = Rojo, fontSize = 13.sp) }
            Spacer(Modifier.height(11.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Boton("Aplicar minutos", Modifier.weight(1f), color = Verde) {
                    val m = extra.toIntOrNull() ?: 0
                    if (m == 0) avisoExt = "Escribe un ajuste válido"
                    else if (cobro.cierra + m * 60_000L <= System.currentTimeMillis() + 60_000L) avisoExt = "El cierre debe quedar en el futuro"
                    else { Caja.ajustarCobro(cobro.id, m); ajustar = null }
                }
                Boton("Usar fecha", Modifier.weight(1f), color = Cian) {
                    if (exacto <= System.currentTimeMillis() + 60_000L) avisoExt = "La fecha debe quedar en el futuro"
                    else { Caja.ajustarCobroFecha(cobro.id, exacto); ajustar = null }
                }
            }
            Spacer(Modifier.height(7.dp)); Boton("Cancelar", Modifier.fillMaxWidth(), relleno=false, color=Tenue) { ajustar=null }
        }
    } }

    cerrar?.let { cobro -> Hoja(onDismissRequest = { cerrar = null }) {
        val participantes = Caja.socios.filter { it.estado == EstadoMiembro.ACTIVO && it.participaCobros }
        val estados = participantes.associate { it.numero to Caja.estadoDe(cobro.id, it.numero) }
        val aprobados = estados.count { it.value == EstadoPago.APROBADO }
        val pendientes = estados.count { it.value == EstadoPago.PENDIENTE }
        val rechazados = estados.count { it.value == EstadoPago.RECHAZADO }
        val noPagaran = estados.count { it.value == EstadoPago.NO_PAGA }
        val sinEnviar = estados.count { it.value == EstadoPago.SIN_ENVIAR }
        val recaudado = Caja.pagos.filter { it.cobroId == cobro.id && it.estado == EstadoPago.APROBADO }.sumOf { it.monto }
        Tarjeta(borde = Rojo.copy(alpha=.45f), fondo=PanelAlto) {
            Titulo(if (cobro.tipo == TipoCobro.RAPIDO) "¿Cerrar cobro rápido?" else "¿Cerrar cobro oficial?")
            Spacer(Modifier.height(8.dp))
            Etiqueta("RESUMEN FINAL", Ambar)
            Spacer(Modifier.height(6.dp))
            Text("${participantes.size} deben pagar · $aprobados aprobados", color = Texto, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(3.dp))
            Text("$pendientes por revisar · $rechazados rechazados · $sinEnviar sin enviar · $noPagaran no pagarán", color = Tenue, fontSize = 12.sp)
            Spacer(Modifier.height(5.dp))
            Text("Recaudado confirmado: ${soles(recaudado)}", color = Verde, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
            if (pendientes > 0) {
                Spacer(Modifier.height(7.dp))
                Text("Atención: hay $pendientes comprobante(s) todavía por revisar. Si cierras ahora quedarán reflejados como pendientes en el resumen.", color = Ambar, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(9.dp))
            Text(if (cobro.tipo == TipoCobro.RAPIDO) "Se generará un resumen para descargar en PDF." else "Se guardará el acta con el estado final de cada integrante y sus motivos registrados.", color=Tenue, fontSize=13.sp)
            Spacer(Modifier.height(12.dp))
            Boton("Cerrar definitivamente", Modifier.fillMaxWidth(), color=Rojo) { Caja.cerrarCobro(cobro.id); cerrar=null }
            Spacer(Modifier.height(7.dp)); Boton("Cancelar", Modifier.fillMaxWidth(), relleno=false, color=Tenue) { cerrar=null }
        }
    } }
}

@Composable
private fun GastosAdmin() {
    val yo = Caja.sesion.value
    if (!(Caja.tienePermiso(yo, Permiso.REGISTRAR_GASTOS) || Caja.esAdmin)) {
        SinPermiso()
        return
    }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var concepto by remember { mutableStateOf("") }
    var monto by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    var guardando by remember { mutableStateOf(false) }
    var comprobante by remember { mutableStateOf<ComprobanteImagen.Resultado?>(null) }
    var pendienteConfirmar by remember { mutableStateOf<ComprobanteImagen.Resultado?>(null) }
    var verGrande by remember { mutableStateOf<Bitmap?>(null) }
    var requestId by remember { mutableStateOf<String?>(null) }

    fun seleccionarComprobante(uri: Uri?) {
        if (uri != null) {
            scope.launch {
                try {
                    aviso = "Preparando imagen…"
                    pendienteConfirmar = ComprobanteImagen.leerParaGasto(context, uri)
                    aviso = ""
                } catch (e: Exception) {
                    aviso = e.message ?: "No se pudo abrir la imagen"
                }
            }
        }
    }

    val selectorFotos = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        seleccionarComprobante(uri)
    }
    val selectorArchivos = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
        }
        seleccionarComprobante(uri)
    }

    Tarjeta {
        Titulo("Registrar gasto")
        Spacer(Modifier.height(6.dp))
        Text("El comprobante es opcional y solo puede adjuntarse al registrar el gasto.", color = Tenue, fontSize = 13.sp)
        Spacer(Modifier.height(11.dp))
        Campo(concepto, { concepto = it; aviso = ""; requestId = null }, "Concepto")
        Spacer(Modifier.height(9.dp))
        Campo(monto, { monto = it; aviso = ""; requestId = null }, "Monto", numerico = true)
        Spacer(Modifier.height(12.dp))

        if (comprobante == null) {
            Etiqueta("COMPROBANTE (OPCIONAL)", Cian)
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Boton("Fotos", Modifier.weight(1f), color = Cian, activo = !guardando) {
                    selectorFotos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                Boton("Archivos", Modifier.weight(1f), relleno = false, color = Cian, activo = !guardando) {
                    selectorArchivos.launch(arrayOf("image/*"))
                }
            }
        } else {
            Tarjeta(borde = Cian.copy(alpha = .35f), fondo = PanelAlto) {
                Etiqueta("COMPROBANTE LISTO", Cian)
                Spacer(Modifier.height(7.dp))
                MiniaturaComprobante(comprobante!!.bitmap) { verGrande = comprobante!!.bitmap }
                Spacer(Modifier.height(8.dp))
                Text("La imagen todavía no se ha subido. Se enviará junto con el gasto.", color = Tenue, fontSize = 11.5.sp)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Boton("Fotos", Modifier.weight(1f), relleno = false, color = Cian, activo = !guardando) {
                        selectorFotos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    Boton("Archivos", Modifier.weight(1f), relleno = false, color = Cian, activo = !guardando) {
                        selectorArchivos.launch(arrayOf("image/*"))
                    }
                }
                Spacer(Modifier.height(7.dp))
                Boton("Quitar comprobante", Modifier.fillMaxWidth(), relleno = false, color = Rojo, activo = !guardando) {
                    comprobante = null
                    requestId = null
                }
            }
        }

        if (aviso.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            AvisoEstado(aviso, ocupado = guardando || aviso.contains("Preparando"))
        }
        Spacer(Modifier.height(12.dp))
        Boton(if (guardando) "Registrando…" else "Registrar gasto", Modifier.fillMaxWidth(), color = Rojo, activo = !guardando) {
            val c = parseCentavos(monto) ?: 0L
            when {
                concepto.isBlank() -> aviso = "Falta concepto"
                c <= 0 -> aviso = "Monto inválido"
                c > Caja.disponibleParaGastos() -> aviso = "No alcanza: ${soles(Caja.disponibleParaGastos())}"
                else -> {
                    val rid = requestId ?: UUID.randomUUID().toString().also { requestId = it }
                    guardando = true
                    aviso = if (comprobante != null) "Subiendo comprobante…" else "Registrando gasto…"
                    scope.launch {
                        try {
                            Caja.registrarGastoNuevo(concepto.trim(), c, comprobante, rid)
                            concepto = ""
                            monto = ""
                            comprobante = null
                            requestId = null
                            aviso = "✓ Gasto registrado"
                            delay(1800)
                            if (aviso == "✓ Gasto registrado") aviso = ""
                        } catch (e: Exception) {
                            aviso = e.message ?: "No se pudo registrar el gasto"
                        } finally {
                            guardando = false
                        }
                    }
                }
            }
        }
    }

    pendienteConfirmar?.let { img ->
        Hoja(onDismissRequest = { pendienteConfirmar = null }) {
            Tarjeta(borde = Cian.copy(alpha = .55f), fondo = PanelAlto) {
                Etiqueta("CONFIRMAR IMAGEN", Cian)
                Spacer(Modifier.height(7.dp))
                Text("¿Esta es la imagen correcta del recibo, boleta o Yape?", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                MiniaturaComprobante(img.bitmap) { verGrande = img.bitmap }
                Spacer(Modifier.height(10.dp))
                Text("No se subirá nada hasta que presiones Registrar gasto.", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Boton("Cancelar", Modifier.weight(1f), relleno = false, color = Tenue) { pendienteConfirmar = null }
                    Boton("Usar esta imagen", Modifier.weight(1f), color = Cian) {
                        comprobante = img
                        pendienteConfirmar = null
                        requestId = null
                    }
                }
            }
        }
    }

    verGrande?.let { b -> VisorBitmapDialog(b) { verGrande = null } }
}

@Composable
private fun YapeAdmin() {
    if (!(Caja.esOwner || Caja.tienePermiso(Caja.sesion.value, Permiso.GESTIONAR_NUMERO_YAPE) || Caja.tienePermiso(Caja.sesion.value, Permiso.GESTIONAR_YAPE))) { SinPermiso(); return }
    val config = Caja.yapeConfig.value
    var numero by remember(config.numeroYape) { mutableStateOf(config.numeroYape) }
    var guardando by remember { mutableStateOf(false) }
    var estado by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Tarjeta(borde = Verde.copy(alpha = .35f), fondo = PanelAlto) {
        Etiqueta("NÚMERO YAPE", Verde)
        Spacer(Modifier.height(10.dp))
        Campo(numero, { numero = it.filter(Char::isDigit).take(9); estado = "" }, "Ej. 987654765", numerico = true)
        if (estado.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            AvisoEstado(estado, ocupado = guardando)
        }
        Spacer(Modifier.height(13.dp))
        Boton(if (guardando) "Guardando…" else "Guardar número Yape", Modifier.fillMaxWidth(), color = Verde, activo = numero.trim().length == 9 && !guardando) {
            guardando = true; estado = "Guardando…"
            Caja.guardarConfigYape(numero) { ok, msg ->
                guardando = false
                estado = if (ok) "✓ Guardado" else msg
                if (ok) scope.launch { kotlinx.coroutines.delay(1600); if (estado == "✓ Guardado") estado = "" }
            }
        }
    }
}

@Composable
private fun MiembrosAdmin() {
    val yo = Caja.sesion.value ?: return
    val puedeMiembros = Caja.esOwner || Caja.tienePermiso(yo, Permiso.GESTIONAR_MIEMBROS) || Caja.tienePermiso(yo, Permiso.GENERAR_CODIGOS)
    if (!puedeMiembros) { SinPermiso(); return }
    val editaMiembros = Caja.esOwner || Caja.tienePermiso(yo, Permiso.GESTIONAR_MIEMBROS)

    val clipboard = LocalClipboardManager.current
    var invitar by remember { mutableStateOf<Int?>(null) }
    var editar by remember { mutableStateOf<Int?>(null) }
    var liberar by remember { mutableStateOf<Int?>(null) }
    var cantidadCodigos by remember { mutableStateOf("") }
    var estadoCodigos by remember { mutableStateOf("") }
    var codigosCopiados by remember { mutableStateOf(false) }

    if (Caja.esOwner) {
        LaunchedEffect(Caja.conectado.value) {
            if (Caja.conectado.value) while (true) {
                Caja.refrescarPresenciasAdmin()
                delay(4_000)
            }
        }
        LaunchedEffect(Caja.conectado.value) {
            if (Caja.conectado.value) while (true) {
                try { Caja.cargarCodigosMasivos() } catch (_: Exception) {}
                delay(12_000)
            }
        }
    }

    Tarjeta(fondo = PanelAlto) {
        Etiqueta("MIEMBROS Y PLAZAS 1–35")
        Spacer(Modifier.height(5.dp))
        Text(
            if (Caja.esOwner) "Como owner puedes gestionar accesos, cargos, colores, participación y permisos."
            else "Puedes administrar datos básicos, cargos y participación. No puedes otorgar administración ni ver la actividad de conexión.",
            color = Tenue, fontSize = 12.sp
        )
    }
    Spacer(Modifier.height(10.dp))

    (1..35).forEach { numero ->
        val m = Caja.socio(numero)
        val colorCargoMiembro = m?.let { colorCargo(it.cargoColor, Cian) } ?: Borde
        val colorBorde = when {
            m == null -> Borde
            m.estado == EstadoMiembro.BLOQUEADO -> Rojo.copy(alpha = .4f)
            m.nivelAcceso == NivelAcceso.OWNER -> colorCargoMiembro.copy(alpha = .62f)
            m.nivelAcceso == NivelAcceso.ADMINISTRADOR -> colorCargoMiembro.copy(alpha = .55f)
            else -> colorCargoMiembro.copy(alpha = .35f)
        }
        Tarjeta(borde = colorBorde) {
            FilaEntre {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (m == null) "${numero.toString().padStart(2, '0')} · PLAZA LIBRE"
                        else "${numero.toString().padStart(2, '0')} · ${m.nombre}",
                        color = if (m == null) Texto else colorCargoMiembro, fontSize = 13.5.sp, fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(4.dp))
                    if (m == null) {
                        Text("Sin cuenta · no participa en cobros", color = Tenue, fontSize = 11.sp)
                    } else {
                        val nivel = when (m.nivelAcceso) {
                            NivelAcceso.OWNER -> "Owner"
                            NivelAcceso.ADMINISTRADOR -> "Administrador"
                            NivelAcceso.USUARIO -> "Usuario"
                        }
                        val cargo = m.cargoNombre.ifBlank { "Sin cargo" }
                        Text("$nivel · $cargo · ${if (m.participaCobros) "Participa" else "Solo visualización"}", color = colorCargoMiembro.copy(alpha = if (m.participaCobros) .98f else .78f), fontSize = 11.sp)
                        if (Caja.esOwner) {
                            Spacer(Modifier.height(3.dp))
                            val presencia = Caja.presencias[numero]
                            val (textoConexion, colorConexion) = if (!Caja.presenciasCargadas.value) {
                                "● Consultando…" to Tenue
                            } else {
                                val estadoConexion = presencia?.estado ?: if (m.estado == EstadoMiembro.BLOQUEADO) EstadoConexionMiembro.BLOQUEADO else EstadoConexionMiembro.DESCONECTADO
                                when (estadoConexion) {
                                    EstadoConexionMiembro.CONECTADO -> "● En línea" to VerdeBrillante
                                    EstadoConexionMiembro.DESCONECTADO -> {
                                        val ultima = presencia?.ultimaActividad
                                        (if (ultima != null) "● Activo ${tiempoDesde(ultima)}" else "● Desconectado") to Rojo
                                    }
                                    EstadoConexionMiembro.SIN_ACTIVAR -> "● Sin activar" to Ambar
                                    EstadoConexionMiembro.BLOQUEADO -> "● Bloqueado" to Tenue
                                    EstadoConexionMiembro.LIBRE -> "● Libre" to Tenue
                                }
                            }
                            Text(textoConexion, color = colorConexion, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                when {
                    m == null && editaMiembros -> Boton("Invitar", Modifier.width(84.dp), color = Verde, relleno = false) { invitar = numero }
                    m != null && m.nivelAcceso != NivelAcceso.OWNER && (Caja.esOwner || (editaMiembros && m.nivelAcceso == NivelAcceso.USUARIO)) ->
                        Boton("Gestionar", Modifier.width(98.dp), color = colorCargoMiembro, relleno = false) { editar = numero }
                }
            }
            val puedeCodigo = m != null && (
                (Caja.esOwner && m.nivelAcceso != NivelAcceso.OWNER) ||
                (Caja.tienePermiso(yo, Permiso.GENERAR_CODIGOS) && m.nivelAcceso == NivelAcceso.USUARIO && m.numero != yo.numero)
            )
            if (puedeCodigo) {
                Spacer(Modifier.height(7.dp))
                val activo = Caja.reseteoAbierto(numero)
                Boton(if (activo) "Mostrar código temporal" else "Generar código 24 h", Modifier.fillMaxWidth(), relleno = false, color = Ambar) {
                    Caja.ultimoCodigoTemporal.value = Caja.codigoLocal(numero)
                    Caja.codigoTemporalPara.value = numero
                    if (activo && Caja.ultimoCodigoTemporal.value.isNullOrBlank()) Caja.resetear(numero)
                    liberar = numero
                }
            }
        }
        Spacer(Modifier.height(7.dp))
    }

    if (Caja.esOwner) {
        Spacer(Modifier.height(8.dp))
        Tarjeta(borde = Ambar.copy(alpha = .45f), fondo = PanelAlto) {
            Etiqueta("CÓDIGOS MASIVOS DE ACTIVACIÓN", Ambar)
            Spacer(Modifier.height(5.dp))
            Text("6 dígitos · 6 horas · un solo uso · solo cuentas nuevas", color = Tenue, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Campo(cantidadCodigos, { cantidadCodigos = it.filter(Char::isDigit).take(2); estadoCodigos = "" }, "Cantidad a generar · 1 a 30", numerico = true)
            Spacer(Modifier.height(9.dp))
            val cantidadValida = cantidadCodigos.toIntOrNull()?.takeIf { it in 1..30 }
            Boton(if (Caja.cargandoCodigosMasivos.value) "Generando…" else "Generar códigos", Modifier.fillMaxWidth(), color = Ambar, activo = cantidadValida != null && !Caja.cargandoCodigosMasivos.value) {
                val cantidad = cantidadValida ?: return@Boton
                Caja.generarCodigosMasivos(cantidad) { ok, msg ->
                    estadoCodigos = if (ok) "✓ $msg" else msg
                    codigosCopiados = false
                    if (ok) cantidadCodigos = ""
                }
            }

            val disponibles = Caja.codigosMasivos.filter { it.estado == EstadoCodigoMasivo.DISPONIBLE }
            val usados = Caja.codigosMasivos.count { it.estado == EstadoCodigoMasivo.USADO }
            val vencidos = Caja.codigosMasivos.count { it.estado == EstadoCodigoMasivo.VENCIDO }
            Spacer(Modifier.height(10.dp))
            Text("Disponibles: ${disponibles.size}  ·  Usados: $usados  ·  Vencidos: $vencidos", color = if (disponibles.isNotEmpty()) VerdeBrillante else Tenue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            if (disponibles.isNotEmpty()) {
                Spacer(Modifier.height(9.dp))
                Boton(if (codigosCopiados) "Disponibles copiados" else "Copiar todos los disponibles", Modifier.fillMaxWidth(), relleno = false, color = VerdeBrillante) {
                    clipboard.setText(AnnotatedString(buildString {
                        append("Códigos Tesorería · 6 horas · un solo uso\n")
                        disponibles.forEach { append(it.codigo).append('\n') }
                    }.trim()))
                    codigosCopiados = true
                }
            }
            if (Caja.codigosMasivos.isNotEmpty()) {
                Spacer(Modifier.height(12.dp)); Etiqueta("HISTORIAL DE CÓDIGOS", Cian); Spacer(Modifier.height(6.dp))
                Caja.codigosMasivos.take(60).forEach { c ->
                    val (estadoTexto, estadoColor) = when (c.estado) {
                        EstadoCodigoMasivo.DISPONIBLE -> "Disponible" to VerdeBrillante
                        EstadoCodigoMasivo.USADO -> "Usado" to Cian
                        EstadoCodigoMasivo.VENCIDO -> "Vencido" to Tenue
                        EstadoCodigoMasivo.CANCELADO -> "Cancelado" to Rojo
                    }
                    Row(
                        Modifier.fillMaxWidth().background(FondoProfundo.copy(alpha=.52f), RoundedCornerShape(12.dp))
                            .border(1.dp, Borde.copy(alpha=.7f), RoundedCornerShape(12.dp)).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(c.codigo, color = Texto, fontSize = 17.sp, style = cifra)
                            val detalle = when (c.estado) {
                                EstadoCodigoMasivo.DISPONIBLE -> "Vence ${tiempoHasta(c.vence)}"
                                EstadoCodigoMasivo.USADO -> "Usado por N.º ${c.usadoPor?.toString()?.padStart(2,'0') ?: "--"}"
                                EstadoCodigoMasivo.VENCIDO -> "Vencido"
                                EstadoCodigoMasivo.CANCELADO -> "Cancelado"
                            }
                            Text(detalle, color = estadoColor, fontSize = 11.sp)
                        }
                        Pastilla(estadoTexto, estadoColor)
                    }
                    Spacer(Modifier.height(6.dp))
                }
                Boton("Eliminar usados y vencidos", Modifier.fillMaxWidth(), relleno = false, color = Rojo) {
                    Caja.eliminarCodigosFinalizados { ok, msg -> estadoCodigos = if (ok) "✓ $msg" else msg }
                }
            }
            if (estadoCodigos.isNotBlank()) { Spacer(Modifier.height(8.dp)); AvisoEstado(estadoCodigos) }
        }
    }

    invitar?.let { n -> Hoja(onDismissRequest = { invitar = null }) { InvitarDialog(n) { invitar = null } } }
    editar?.let { n -> Hoja(onDismissRequest = { editar = null }) { GestionarMiembroDialog(n) { editar = null } } }
    liberar?.let { n -> Hoja(onDismissRequest = { liberar = null }) {
        val codigo = Caja.ultimoCodigoTemporal.value.takeIf { Caja.codigoTemporalPara.value == n }
        var copiado by remember(n, codigo) { mutableStateOf(false) }
        val vibrar = rememberVibracion()
        Tarjeta(borde = Ambar.copy(alpha = .45f), fondo = PanelAlto) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).background(Ambar.copy(alpha = .15f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Key, null, tint = Ambar, modifier = Modifier.size(24.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Código de acceso", color = Texto, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("N.º $n · ${Caja.socio(n)?.nombre.orEmpty()}", color = Tenue, fontSize = 13.sp, maxLines = 1)
                }
            }
            Spacer(Modifier.height(16.dp))
            val activo = Caja.reseteoAbierto(n)
            if (!activo) {
                Text("Sirve para crear la cuenta o cambiar la contraseña. Dura 24 horas.", color = Tenue, fontSize = 14.sp)
                Spacer(Modifier.height(14.dp))
                Boton("Generar código", Modifier.fillMaxWidth(), color = Ambar, icono = Icons.Rounded.Key) { Caja.resetear(n) }
            } else if (codigo != null) {
                CodigoAnimado(codigo, Ambar)
                Spacer(Modifier.height(14.dp))
                val vence = Caja.codigosActivos[n] ?: 0L
                val resta = (vence - System.currentTimeMillis()).coerceAtLeast(0L)
                AnilloTiempo(resta / (24f * 60f * 60f * 1000f), Ambar, "Vence ${tiempoHasta(vence)}")
                Spacer(Modifier.height(14.dp))
                Boton(
                    if (copiado) "Copiado" else "Copiar código", Modifier.fillMaxWidth(),
                    color = if (copiado) Verde else Ambar,
                    icono = if (copiado) Icons.Rounded.Check else Icons.Rounded.ContentCopy
                ) { clipboard.setText(AnnotatedString(codigo)); copiado = true; vibrar(true) }
            } else {
                Box(Modifier.fillMaxWidth().height(58.dp).brilloCarga())
            }
            Spacer(Modifier.height(8.dp)); Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { liberar = null }
        }
    } }
}


@Composable
private fun OwnerAdmin() {
    if (!Caja.esOwner) { SinPermiso(); return }
    val yo = Caja.sesion.value ?: return
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var colorPropio by remember(yo.cargoColor) { mutableStateOf(yo.cargoColor.ifBlank { "#22C55E" }) }
    var guardandoColor by remember { mutableStateOf(false) }
    var avisoColor by remember { mutableStateOf("") }
    var todo by remember { mutableStateOf(true) }
    var desde by remember { mutableStateOf(System.currentTimeMillis() - 30L * 24L * 60L * 60L * 1000L) }
    var hasta by remember { mutableStateOf(System.currentTimeMillis()) }
    var resumen by remember { mutableStateOf<org.json.JSONObject?>(null) }
    var cargando by remember { mutableStateOf(false) }
    var clave by remember { mutableStateOf("") }
    var confirmacion by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }

    fun elegirFecha(inicial: Long, finDia: Boolean, onValue: (Long) -> Unit) {
        val cal = Calendar.getInstance().apply { timeInMillis = inicial }
        DatePickerDialog(context, { _, y, m, d ->
            val c = Calendar.getInstance().apply {
                set(Calendar.YEAR,y); set(Calendar.MONTH,m); set(Calendar.DAY_OF_MONTH,d)
                set(Calendar.HOUR_OF_DAY, if (finDia) 23 else 0); set(Calendar.MINUTE, if (finDia) 59 else 0); set(Calendar.SECOND, if (finDia) 59 else 0); set(Calendar.MILLISECOND, if (finDia) 999 else 0)
            }
            onValue(c.timeInMillis); resumen = null; aviso = ""
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    MovimientosAdminCard()
    Spacer(Modifier.height(12.dp))
    val acentoPropio = colorCargo(colorPropio, Ambar)
    Tarjeta(borde = acentoPropio.copy(alpha = .48f), fondo = PanelAlto) {
        Etiqueta("MI IDENTIDAD", acentoPropio)
        Spacer(Modifier.height(6.dp))
        Text("${yo.numero.toString().padStart(2, '0')} · ${yo.nombre}", color = acentoPropio, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(3.dp))
        Text("Owner · ${yo.cargoNombre.ifBlank { "Sin cargo" }}", color = Tenue, fontSize = 12.sp)
        Spacer(Modifier.height(11.dp))
        SelectorColorCargo(colorPropio) {
            colorPropio = it
            avisoColor = ""
        }
        Spacer(Modifier.height(9.dp))
        Text("El color elegido se usará en tu identidad dentro de la app. El morado de los pagos Yape se mantiene separado.", color = Tenue, fontSize = 12.sp)
        if (avisoColor.isNotBlank()) {
            Spacer(Modifier.height(7.dp))
            AvisoEstado(avisoColor)
        }
        Spacer(Modifier.height(10.dp))
        Boton(if (guardandoColor) "Guardando…" else "Guardar mi color", Modifier.fillMaxWidth(), color = acentoPropio, activo = !guardandoColor) {
            guardandoColor = true
            avisoColor = ""
            Caja.guardarColorPropio(colorPropio) { ok, msg ->
                guardandoColor = false
                avisoColor = if (ok) "✓ $msg" else msg
            }
        }
    }
    Spacer(Modifier.height(9.dp))

    Tarjeta(borde = Rojo.copy(alpha=.38f), fondo = PanelAlto) {
        Etiqueta("HERRAMIENTAS EXCLUSIVAS DEL OWNER", Rojo)
        Spacer(Modifier.height(5.dp))
        Text("Ningún administrador puede ver esta sección ni ejecutar estas acciones.", color = Tenue, fontSize = 12.sp)
    }
    Spacer(Modifier.height(9.dp))

    Tarjeta(borde = Rojo.copy(alpha=.45f), fondo = PanelAlto) {
        Titulo("Limpiar datos del servidor")
        Spacer(Modifier.height(6.dp))
        Text("Conserva miembros, cuentas, roles, permisos, configuración, tablas y funciones. Elimina movimientos operativos y comprobantes de la nube según el rango elegido.", color = Tenue, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pestana("Todo", todo, Rojo, Modifier.weight(1f)) { todo = true; resumen = null; aviso = "" }
            Pestana("Por fechas", !todo, Cian, Modifier.weight(1f)) { todo = false; resumen = null; aviso = "" }
        }
        if (!todo) {
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Boton("Desde · ${com.tesoreria.caja.data.fechaCorta(desde)}", Modifier.weight(1f), relleno = false, color = Cian) { elegirFecha(desde, false) { desde = it } }
                Boton("Hasta · ${com.tesoreria.caja.data.fechaCorta(hasta)}", Modifier.weight(1f), relleno = false, color = Cian) { elegirFecha(hasta, true) { hasta = it } }
            }
        }
        Spacer(Modifier.height(10.dp))
        Boton(if (cargando) "Consultando…" else "Ver qué se eliminará", Modifier.fillMaxWidth(), relleno = false, color = Ambar, activo = !cargando) {
            cargando = true; aviso = ""
            scope.launch {
                try { resumen = Caja.resumenLimpieza(if (todo) null else desde, if (todo) null else hasta, todo).optJSONObject("resumen") }
                catch (e: Exception) { aviso = e.message ?: "No se pudo consultar" }
                finally { cargando = false }
            }
        }
        resumen?.let { r ->
            Spacer(Modifier.height(9.dp))
            Box(Modifier.fillMaxWidth().background(FondoProfundo, RoundedCornerShape(12.dp)).border(1.dp, Borde, RoundedCornerShape(12.dp)).padding(11.dp)) {
                Text("Cobros ${r.optInt("cobros")} · Pagos ${r.optInt("pagos")} · Comprobantes ${r.optInt("comprobantes")} · Gastos ${r.optInt("gastos")} · Actas ${r.optInt("actas")} · Bitácora ${r.optInt("bitacora")} · Códigos ${r.optInt("codigos")}", color = Texto, fontSize = 12.sp, lineHeight = 15.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Etiqueta("CONTRASEÑA DEL OWNER")
        Spacer(Modifier.height(5.dp))
        Campo(clave, { clave = it; aviso = "" }, "Tu contraseña", clave = true)
        Spacer(Modifier.height(8.dp))
        Campo(confirmacion, { confirmacion = it.uppercase().take(7); aviso = "" }, "Escribe LIMPIAR")
        if (aviso.isNotBlank()) { Spacer(Modifier.height(8.dp)); AvisoEstado(aviso) }
        Spacer(Modifier.height(11.dp))
        Boton(if (cargando) "Procesando…" else "Limpiar servidor", Modifier.fillMaxWidth(), color = Rojo, activo = !cargando && clave.length >= 6 && confirmacion == "LIMPIAR") {
            cargando = true; aviso = ""
            scope.launch {
                try {
                    Caja.limpiarServidorConClave(clave, if (todo) null else desde, if (todo) null else hasta, todo)
                    aviso = "✓ Limpieza completada"
                    resumen = null; clave = ""; confirmacion = ""
                } catch (e: Exception) { aviso = e.message ?: "No se pudo limpiar" }
                finally { cargando = false }
            }
        }
    }
}

private fun tiempoDesde(t: Long): String {
    val d = (System.currentTimeMillis() - t).coerceAtLeast(0L)
    val min = d / 60_000L
    return when {
        min < 1 -> "hace menos de 1 min"
        min < 60 -> "hace $min min"
        min < 24 * 60 -> "hace ${min / 60} h"
        else -> "hace ${min / (24 * 60)} d"
    }
}

private fun tiempoHasta(t: Long): String {
    val d = (t - System.currentTimeMillis()).coerceAtLeast(0L)
    val min = d / 60_000L
    return "en ${min / 60} h ${min % 60} min"
}

@Composable
private fun InvitarDialog(numero: Int, cerrar: () -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var cargo by remember { mutableStateOf("Invitado") }
    var color by remember { mutableStateOf("#38BDF8") }
    var participa by remember { mutableStateOf(false) }
    var guardando by remember { mutableStateOf(false) }
    var aviso by remember { mutableStateOf("") }

    Tarjeta(borde = Verde.copy(alpha = .5f), fondo = PanelAlto) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(Celeste.copy(alpha = .15f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.PersonAdd, null, tint = Celeste, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(12.dp))
            Text("Invitar en plaza $numero", color = Texto, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        Etiqueta("NOMBRE")
        Spacer(Modifier.height(5.dp))
        Campo(nombre, { nombre = it.take(80); aviso = "" }, "Nombre completo")
        Spacer(Modifier.height(9.dp))
        Etiqueta("CARGO VISIBLE")
        Spacer(Modifier.height(5.dp))
        Campo(cargo, { cargo = it.take(30) }, "Ej. Presidente, Vocal, Visitante")
        Spacer(Modifier.height(9.dp))
        SelectorColorCargo(color) { color = it }
        Spacer(Modifier.height(9.dp))
        PermisoToggle("Participa en cobros", participa, true) { participa = !participa }
        Text(
            if (participa) "Contará en el total que debe pagar." else "Solo mira la app y no cuenta como pendiente.",
            color = Tenue, fontSize = 13.sp
        )
        if (aviso.isNotBlank()) { Spacer(Modifier.height(8.dp)); AvisoEstado(aviso) }
        Spacer(Modifier.height(12.dp))
        Boton(if (guardando) "Guardando…" else "Crear usuario", Modifier.fillMaxWidth(), color = Verde, activo = nombre.trim().length >= 3 && !guardando) {
            guardando = true
            Caja.invitarMiembro(numero, nombre, cargo, color, participa) { ok, msg ->
                guardando = false
                if (ok) cerrar() else aviso = msg
            }
        }
        Spacer(Modifier.height(7.dp)); Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue, activo = !guardando) { cerrar() }
    }
}

@Composable
private fun GestionarMiembroDialog(numero: Int, cerrar: () -> Unit) {
    val m = Caja.socio(numero) ?: return
    val owner = Caja.esOwner
    var nombre by remember(m) { mutableStateOf(m.nombre) }
    var nivel by remember(m) { mutableStateOf(m.nivelAcceso) }
    var cargo by remember(m) { mutableStateOf(m.cargoNombre) }
    var color by remember(m) { mutableStateOf(m.cargoColor.ifBlank { "#22C55E" }) }
    var participa by remember(m) { mutableStateOf(m.participaCobros) }
    var manual by remember(m) { mutableStateOf(Permiso.REGISTRAR_PAGO_MANUAL in m.permisosExtra) }
    var cobros by remember(m) { mutableStateOf(Permiso.GESTIONAR_COBROS in m.permisosExtra) }
    var gastos by remember(m) { mutableStateOf(Permiso.REGISTRAR_GASTOS in m.permisosExtra) }
    var verYape by remember(m) { mutableStateOf(Permiso.VER_COMPROBANTES_YAPE in m.permisosExtra || Permiso.REVISAR_COMPROBANTES_YAPE in m.permisosExtra || Permiso.GESTIONAR_YAPE in m.permisosExtra) }
    var revisarYape by remember(m) { mutableStateOf(Permiso.REVISAR_COMPROBANTES_YAPE in m.permisosExtra || Permiso.GESTIONAR_YAPE in m.permisosExtra) }
    var numeroYape by remember(m) { mutableStateOf(Permiso.GESTIONAR_NUMERO_YAPE in m.permisosExtra || Permiso.GESTIONAR_YAPE in m.permisosExtra) }
    var miembros by remember(m) { mutableStateOf(Permiso.GESTIONAR_MIEMBROS in m.permisosExtra) }
    var actas by remember(m) { mutableStateOf(Permiso.EXPORTAR_ACTAS in m.permisosExtra) }
    var codigos by remember(m) { mutableStateOf(Permiso.GENERAR_CODIGOS in m.permisosExtra) }
    // 0 = Usuario, 1 = Admin completo, 2 = Admin personalizado
    var modoAcceso by remember(m) {
        mutableStateOf(
            when {
                m.nivelAcceso != NivelAcceso.ADMINISTRADOR -> 0
                m.permisosExtra.containsAll(Caja.permisosDelegables()) -> 1
                else -> 2
            }
        )
    }
    var guardando by remember { mutableStateOf(false) }
    var aviso by remember { mutableStateOf("") }
    var confirmarLiberar by remember { mutableStateOf(false) }
    var confirmarEstado by remember { mutableStateOf(false) }
    var liberando by remember { mutableStateOf(false) }
    val acento = colorCargo(color, if (nivel == NivelAcceso.ADMINISTRADOR) Cian else Verde)

    Tarjeta(borde = acento.copy(alpha = .40f), fondo = PanelAlto) {
        // Encabezado: número en círculo con su color, nombre y cerrar.
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).background(acento.copy(alpha = .18f), CircleShape)
                    .border(BorderStroke(2.dp, acento.copy(alpha = .7f)), CircleShape),
                contentAlignment = Alignment.Center
            ) { Text(numero.toString(), color = acento, fontSize = 18.sp, style = cifra, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(nombre.ifBlank { "N.º $numero" }, color = Texto, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(cargo.ifBlank { if (nivel == NivelAcceso.ADMINISTRADOR) "Administrador" else "Usuario" }, color = acento, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Box(
                Modifier.size(38.dp).background(Panel, CircleShape).presionable(enabled = !guardando) { cerrar() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.Close, "Cerrar", tint = Tenue, modifier = Modifier.size(20.dp)) }
        }

        BloqueHoja(Icons.Rounded.Badge, "Datos")
        Campo(nombre, { nombre = it.take(80); aviso = "" }, "Nombre completo")
        Spacer(Modifier.height(9.dp))
        Campo(cargo, { cargo = it.take(30) }, "Cargo · Ej. Presidente, Invitado")

        BloqueHoja(Icons.Rounded.Palette, "Color")
        SelectorColorCargo(color) { color = it }

        BloqueHoja(Icons.Rounded.Payments, "Cobros")
        PermisoToggle(if (participa) "Paga en los cobros" else "No paga · solo mira", participa, true) { participa = !participa }

        if (owner) {
            BloqueHoja(Icons.Rounded.AdminPanelSettings, "Acceso")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pestana("Usuario", modoAcceso == 0, Verde, Modifier.weight(1f)) {
                    modoAcceso = 0
                    nivel = NivelAcceso.USUARIO
                    manual = false; cobros = false; gastos = false; verYape = false; revisarYape = false; numeroYape = false; miembros = false; actas = false; codigos = false
                }
                Pestana("Admin completo", modoAcceso == 1, Ambar, Modifier.weight(1.3f)) {
                    modoAcceso = 1
                    nivel = NivelAcceso.ADMINISTRADOR
                    manual = true; cobros = true; gastos = true; verYape = true; revisarYape = true; numeroYape = true; miembros = true; actas = false; codigos = true
                }
                Pestana("Elegir", modoAcceso == 2, Azul, Modifier.weight(1f)) {
                    modoAcceso = 2
                    nivel = NivelAcceso.ADMINISTRADOR
                }
            }
            AnimatedVisibility(
                visible = modoAcceso == 1,
                enter = expandVertically(tween(420, easing = CurvaSuave)) + fadeIn(tween(300)),
                exit = shrinkVertically(tween(320, easing = CurvaSuave)) + fadeOut(tween(200))
            ) {
                Column(
                    Modifier.padding(top = 10.dp).fillMaxWidth()
                        .background(Ambar.copy(alpha = .08f), RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Text("Puede hacer", color = Ambar, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    LineaPermiso(true, "Abrir, cerrar y ajustar cobros")
                    LineaPermiso(true, "Registrar pagos y aprobar Yapes")
                    LineaPermiso(true, "Registrar gastos y número Yape")
                    LineaPermiso(true, "Invitar y editar usuarios")
                    LineaPermiso(true, "Generar códigos de 24 h")
                    Spacer(Modifier.height(10.dp))
                    Text("No puede", color = Rojo, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    LineaPermiso(false, "Dar administración a otros")
                    LineaPermiso(false, "Limpiar el servidor ni borrar códigos")
                    LineaPermiso(false, "Eliminar actas ni liberar plazas")
                    LineaPermiso(false, "Ver quién está conectado")
                }
            }
            AnimatedVisibility(
                visible = modoAcceso == 2,
                enter = expandVertically(tween(420, easing = CurvaSuave)) + fadeIn(tween(300)),
                exit = shrinkVertically(tween(320, easing = CurvaSuave)) + fadeOut(tween(200))
            ) {
                Column(Modifier.padding(top = 10.dp)) {
                    PermisoToggle("Registrar pagos manuales", manual, color = Azul) { manual = !manual }
                    PermisoToggle("Gestionar cobros", cobros, color = Azul) { cobros = !cobros }
                    PermisoToggle("Registrar gastos", gastos, color = Azul) { gastos = !gastos }
                    PermisoToggle("Ver comprobantes Yape", verYape, color = Azul) { verYape = !verYape; if (!verYape) revisarYape = false }
                    PermisoToggle("Aprobar y rechazar Yape", revisarYape, verYape, color = Azul) { revisarYape = !revisarYape }
                    PermisoToggle("Cambiar número Yape", numeroYape, color = Azul) { numeroYape = !numeroYape }
                    PermisoToggle("Gestionar miembros", miembros, color = Azul) { miembros = !miembros }
                    PermisoToggle("Generar códigos de 24 h", codigos, color = Azul) { codigos = !codigos }
                }
            }
        }

        if (aviso.isNotBlank()) { Spacer(Modifier.height(10.dp)); AvisoEstado(aviso) }
        Spacer(Modifier.height(16.dp))
        Boton(if (guardando) "Guardando…" else "Guardar cambios", Modifier.fillMaxWidth(), color = acento, activo = nombre.trim().length >= 3 && !guardando, icono = Icons.Rounded.Check) {
            if (owner && modoAcceso == 2 && !(manual || cobros || gastos || verYape || numeroYape || miembros || codigos)) {
                aviso = "Elige al menos un permiso o deja como Usuario"
                return@Boton
            }
            guardando = true
            if (owner) {
                val perms = buildSet {
                    if (nivel == NivelAcceso.ADMINISTRADOR) {
                        if (manual) add(Permiso.REGISTRAR_PAGO_MANUAL)
                        if (cobros) add(Permiso.GESTIONAR_COBROS)
                        if (gastos) add(Permiso.REGISTRAR_GASTOS)
                        if (verYape) add(Permiso.VER_COMPROBANTES_YAPE)
                        if (revisarYape) add(Permiso.REVISAR_COMPROBANTES_YAPE)
                        if (numeroYape) add(Permiso.GESTIONAR_NUMERO_YAPE)
                        if (miembros) add(Permiso.GESTIONAR_MIEMBROS)
                        if (codigos) add(Permiso.GENERAR_CODIGOS)
                    }
                }
                Caja.guardarMiembroOwner(numero, nombre, nivel, cargo, color, participa, perms) { ok, msg ->
                    guardando = false; if (ok) cerrar() else aviso = msg
                }
            } else {
                Caja.guardarMiembroBasico(numero, nombre, cargo, color, participa) { ok, msg ->
                    guardando = false; if (ok) cerrar() else aviso = msg
                }
            }
        }

        // Zona sensible separada para no tocarla sin querer.
        Spacer(Modifier.height(18.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Borde))
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val bloqueado = m.estado == EstadoMiembro.BLOQUEADO
            Boton(
                if (bloqueado) "Desbloquear" else "Bloquear", Modifier.weight(1f), relleno = false,
                color = if (bloqueado) Verde else Rojo.copy(alpha = .85f),
                icono = if (bloqueado) Icons.Rounded.LockOpen else Icons.Rounded.Lock
            ) { confirmarEstado = true }
            if (owner && numero in 24..35) {
                Boton("Liberar", Modifier.weight(1f), relleno = false, color = Rojo.copy(alpha = .85f), icono = Icons.Rounded.PersonRemove) { confirmarLiberar = true }
            }
        }
    }

    if (confirmarEstado) Hoja(onDismissRequest = { confirmarEstado = false }) {
        val bloquear = m.estado != EstadoMiembro.BLOQUEADO
        Tarjeta(borde = (if (bloquear) Rojo else Verde).copy(alpha = .5f), fondo = PanelAlto) {
            Titulo(if (bloquear) "¿Bloquear N.º $numero?" else "¿Desbloquear N.º $numero?")
            Spacer(Modifier.height(7.dp))
            Text(
                if (bloquear) "No podrá usar la cuenta hasta que vuelvas a habilitarla." else "La cuenta volverá a poder iniciar sesión y usar sus permisos asignados.",
                color = Tenue, fontSize = 13.sp
            )
            Spacer(Modifier.height(12.dp))
            Boton(if (bloquear) "Sí, bloquear" else "Sí, desbloquear", Modifier.fillMaxWidth(), color = if (bloquear) Rojo else Verde) {
                Caja.cambiarEstadoMiembro(numero, if (bloquear) EstadoMiembro.BLOQUEADO else EstadoMiembro.ACTIVO)
                confirmarEstado = false
            }
            Spacer(Modifier.height(7.dp))
            Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { confirmarEstado = false }
        }
    }

    if (confirmarLiberar) Hoja(onDismissRequest = { if (!liberando) confirmarLiberar = false }) {
        Tarjeta(borde = Rojo.copy(alpha=.5f), fondo = PanelAlto) {
            Titulo("¿Liberar plaza N.º $numero?")
            Spacer(Modifier.height(8.dp))
            Text("La cuenta de esta plaza se eliminará y volverá a quedar disponible. El historial financiero ya cerrado se conserva.", color = Tenue, fontSize = 13.5.sp)
            Spacer(Modifier.height(12.dp))
            Boton(if (liberando) "Liberando…" else "Sí, liberar plaza", Modifier.fillMaxWidth(), color = Rojo, activo = !liberando) {
                liberando = true
                Caja.liberarPlaza(numero) { ok, msg ->
                    liberando = false
                    if (ok) { confirmarLiberar = false; cerrar() } else aviso = msg
                }
            }
            Spacer(Modifier.height(7.dp)); Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue, activo = !liberando) { confirmarLiberar = false }
        }
    }
}

@Composable
private fun SelectorColorCargo(actual: String, onColor: (String) -> Unit) {
    val opciones = listOf(
        "#22C55E" to Verde,
        "#38BDF8" to Celeste,
        "#60A5FA" to Azul,
        "#8B5CF6" to Violeta,
        "#EF4444" to Rojo,
        "#F59E0B" to Ambar
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        opciones.forEach { (hex, c) ->
            val elegido = actual.equals(hex, true)
            val escala by animateFloatAsState(if (elegido) 1.12f else 1f, spring(dampingRatio = .5f, stiffness = 420f), label = "color$hex")
            val color = colorCargo(hex, c)
            Box(
                Modifier.size(42.dp).scale(escala)
                    .border(BorderStroke(if (elegido) 2.5.dp else 0.dp, if (elegido) Texto else Color.Transparent), CircleShape)
                    .padding(4.dp)
                    .background(color, CircleShape)
                    .presionable { onColor(hex) },
                contentAlignment = Alignment.Center
            ) {
                if (elegido) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun PermisoToggle(texto: String, activo: Boolean, habilitado: Boolean = true, color: Color = Verde, alTocar: () -> Unit) {
    val fondo by animateColorAsState(if (activo && habilitado) color.copy(alpha = .09f) else Color.Transparent, tween(260), label = "permisoFondo")
    Row(
        Modifier.fillMaxWidth().background(fondo, RoundedCornerShape(14.dp))
            .clickable(enabled = habilitado) { alTocar() }
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(texto, color = if (habilitado) Texto else Tenue, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Interruptor(activo, color, habilitado) { alTocar() }
    }
    Spacer(Modifier.height(4.dp))
}

@Composable
private fun SinPermiso() {
    Box(
        Modifier.fillMaxWidth().padding(vertical = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Text("No tienes permiso", color = Ambar, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
    }
}

fun colorSeccion(id: Int): Color = when (id) {
    0 -> Verde
    1 -> Celeste
    2 -> Rojo
    3 -> MoradoYape
    4 -> Azul
    else -> Ambar
}

fun iconoSeccion(id: Int): ImageVector = when (id) {
    0 -> Icons.Rounded.Payments
    1 -> Icons.Rounded.CalendarMonth
    2 -> Icons.Rounded.ShoppingBag
    3 -> Icons.Rounded.QrCode2
    4 -> Icons.Rounded.Groups
    else -> Icons.Rounded.AdminPanelSettings
}

@Composable
private fun SelectorAdmin(seccion: Int, secciones: List<Pair<Int, String>>, cambiar: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        secciones.chunked(3).forEach { fila ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                fila.forEach { (id, titulo) ->
                    val activo = seccion == id
                    val color = colorSeccion(id)
                    val fondo by animateColorAsState(if (activo) color.copy(alpha = .22f) else Panel, tween(220), label = "adminFondo$id")
                    val escala by animateFloatAsState(if (activo) 1.04f else 1f, spring(dampingRatio = .5f, stiffness = 500f), label = "adminEscala$id")
                    Column(
                        Modifier.weight(1f).height(78.dp).cascada(id).scale(escala)
                            .background(fondo, RoundedCornerShape(18.dp))
                            .border(BorderStroke(if (activo) 2.dp else 1.dp, if (activo) color else color.copy(alpha = .30f)), RoundedCornerShape(18.dp))
                            .presionable { cambiar(id) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(iconoSeccion(id), titulo, tint = color, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.height(5.dp))
                        Text(titulo, color = if (activo) Texto else Tenue, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }
                repeat(3 - fila.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}


@Composable
private fun BloqueHoja(icono: ImageVector, titulo: String) {
    Spacer(Modifier.height(18.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icono, null, tint = Tenue, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(7.dp))
        Text(titulo.uppercase(), color = Tenue, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
    }
    Spacer(Modifier.height(9.dp))
}

/** Los 6 números del código aparecen uno por uno, grandes. */
@Composable
private fun CodigoAnimado(codigo: String, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        codigo.forEachIndexed { i, c ->
            val aparece = remember(codigo) { Animatable(0f) }
            LaunchedEffect(codigo) {
                delay(110L * i)
                aparece.animateTo(1f, spring(dampingRatio = .55f, stiffness = 380f))
            }
            Box(
                Modifier.weight(1f).height(58.dp)
                    .graphicsLayer {
                        alpha = aparece.value.coerceIn(0f, 1f)
                        translationY = (1f - aparece.value) * 30f
                        val e = .7f + .3f * aparece.value
                        scaleX = e; scaleY = e
                    }
                    .background(color.copy(alpha = .12f), RoundedCornerShape(14.dp))
                    .border(BorderStroke(1.5.dp, color.copy(alpha = .5f)), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(c.toString(), color = Texto, fontSize = 26.sp, style = cifra, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Anillo que muestra cuánto falta del plazo del código. */
@Composable
private fun AnilloTiempo(fraccion: Float, color: Color, texto: String) {
    val f by animateFloatAsState(fraccion.coerceIn(0f, 1f), tween(1200, easing = CurvaSuave), label = "anillo")
    Row(verticalAlignment = Alignment.CenterVertically) {
        androidx.compose.foundation.Canvas(Modifier.size(44.dp)) {
            val g = 5.dp.toPx()
            drawArc(Borde, -90f, 360f, false, topLeft = androidx.compose.ui.geometry.Offset(g / 2, g / 2),
                size = androidx.compose.ui.geometry.Size(size.width - g, size.height - g),
                style = androidx.compose.ui.graphics.drawscope.Stroke(g))
            drawArc(color, -90f, 360f * f, false, topLeft = androidx.compose.ui.geometry.Offset(g / 2, g / 2),
                size = androidx.compose.ui.geometry.Size(size.width - g, size.height - g),
                style = androidx.compose.ui.graphics.drawscope.Stroke(g, cap = androidx.compose.ui.graphics.StrokeCap.Round))
        }
        Spacer(Modifier.width(12.dp))
        Text(texto, color = Texto, fontSize = 14.sp)
    }
}


@Composable
private fun LineaPermiso(si: Boolean, texto: String) {
    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (si) Icons.Rounded.Check else Icons.Rounded.Close, null, tint = if (si) Verde else Rojo, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(8.dp))
        Text(texto, color = Texto, fontSize = 13.5.sp)
    }
}

/** Lo que hicieron los administradores. Solo lo ve el owner. */
@Composable
private fun MovimientosAdminCard() {
    val scope = rememberCoroutineScope()
    var lista by remember { mutableStateOf<List<com.tesoreria.caja.data.MovimientoAdmin>>(emptyList()) }
    var cargando by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var filtro by remember { mutableStateOf<Int?>(null) }
    var abierto by remember { mutableStateOf(true) }
    fun cargar() {
        scope.launch {
            cargando = true; error = ""
            try { lista = Caja.movimientosAdmin() } catch (e: Exception) { error = e.message ?: "No se pudo cargar" }
            cargando = false
        }
    }
    LaunchedEffect(Unit) { cargar() }

    Tarjeta(borde = Azul.copy(alpha = .35f), fondo = PanelAlto) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Azul.copy(alpha = .15f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.History, null, tint = Azul, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Movimientos de admins", color = Texto, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Solo tú ves esto", color = Tenue, fontSize = 12.5.sp)
            }
            Box(
                Modifier.size(38.dp).background(Panel, CircleShape).presionable(enabled = !cargando) { cargar() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.Refresh, "Actualizar", tint = Tenue, modifier = Modifier.size(20.dp)) }
            Spacer(Modifier.width(6.dp))
            Box(
                Modifier.size(38.dp).background(Panel, CircleShape).presionable { abierto = !abierto },
                contentAlignment = Alignment.Center
            ) { Icon(if (abierto) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null, tint = Tenue, modifier = Modifier.size(22.dp)) }
        }

        AnimatedVisibility(
            visible = abierto,
            enter = expandVertically(tween(420, easing = CurvaSuave)) + fadeIn(tween(300)),
            exit = shrinkVertically(tween(320, easing = CurvaSuave)) + fadeOut(tween(200))
        ) {
            Column {
                val admins = lista.map { it.actor to it.nombre }.distinct().sortedBy { it.first }
                if (admins.size > 1) {
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ChipFiltro("Todos", filtro == null) { filtro = null }
                        admins.forEach { (n, nombre) ->
                            ChipFiltro("N.º $n · ${nombre.substringBefore(" ")}", filtro == n) { filtro = n }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                val visibles = lista.filter { filtro == null || it.actor == filtro }
                when {
                    cargando && lista.isEmpty() -> repeat(3) {
                        Box(Modifier.fillMaxWidth().height(52.dp).brilloCarga())
                        Spacer(Modifier.height(8.dp))
                    }
                    error.isNotBlank() -> AvisoEstado(error)
                    visibles.isEmpty() -> Text("Todavía no hay movimientos de administradores.", color = Tenue, fontSize = 14.sp)
                    else -> visibles.take(60).forEachIndexed { i, mv ->
                        Row(Modifier.fillMaxWidth().cascada(i).padding(vertical = 7.dp), verticalAlignment = Alignment.Top) {
                            Box(
                                Modifier.size(34.dp).background(Azul.copy(alpha = .14f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) { Text(mv.actor.toString(), color = Azul, fontSize = 13.sp, style = cifra, fontWeight = FontWeight.Bold) }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(mv.evento, color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                if (mv.detalle.isNotBlank()) Text(mv.detalle, color = Texto.copy(alpha = .8f), fontSize = 13.sp, lineHeight = 17.sp)
                                Text("${mv.nombre.substringBefore(" ")} · ${fechaHora(mv.fecha)}", color = Tenue, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChipFiltro(texto: String, activo: Boolean, alTocar: () -> Unit) {
    val fondo by animateColorAsState(if (activo) Azul.copy(alpha = .22f) else Panel, tween(220), label = "chip$texto")
    Box(
        Modifier.background(fondo, RoundedCornerShape(99.dp))
            .border(BorderStroke(1.dp, if (activo) Azul else Borde), RoundedCornerShape(99.dp))
            .presionable { alTocar() }
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) { Text(texto, color = if (activo) Texto else Tenue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
}
