package com.tesoreria.caja.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Abono
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Cobro
import com.tesoreria.caja.data.ComprobanteImagen
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.parseCentavos
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** En Inicio, debajo de "Te falta": subir tu parte, o ver la que está en revisión. */
@Composable
fun ParteUsuarioCard(cobro: Cobro, numero: Int) {
    val pendiente = Caja.abonoPendienteDe(cobro.id, numero)
    val rechazado = Caja.abonoRechazadoDe(cobro.id, numero)
    val partes = Caja.abonosDe(cobro.id, numero).size
    val falta = (cobro.monto - Caja.pagadoDe(cobro.id, numero)).coerceAtLeast(0L)
    var subir by remember { mutableStateOf(false) }
    var ver by remember { mutableStateOf<Abono?>(null) }
    var cancelando by remember { mutableStateOf(false) }
    var aviso by remember { mutableStateOf("") }

    AnimatedContent(
        targetState = pendiente?.serverId ?: "",
        transitionSpec = { fadeIn(tween(380, easing = CurvaSuave)).togetherWith(fadeOut(tween(220))) },
        label = "parteUsuario"
    ) { idPendiente ->
        val p = pendiente?.takeIf { it.serverId == idPendiente }
        if (p != null) {
            Tarjeta(borde = Naranja.copy(alpha = .55f), fondo = PanelAlto) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MiniaturaPago(p.capturaPath, Modifier.size(width = 46.dp, height = 56.dp).clickable { ver = p }, radio = 9.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.HourglassTop, null, tint = Naranja, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("En revisión", color = Naranja, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(3.dp))
                        Text("Enviaste ${soles(p.monto)} · ${fechaHora(p.fecha)}", color = Texto, fontSize = 13.sp)
                        Text("Cuando lo aprueben se suma a lo que pagaste.", color = Tenue, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Boton(
                    if (cancelando) "Cancelando…" else "Cancelar este envío", Modifier.fillMaxWidth(),
                    relleno = false, color = Rojo, icono = Icons.Rounded.Close, activo = !cancelando
                ) {
                    cancelando = true
                    Caja.anularAbono(p) { ok, m -> cancelando = false; aviso = if (ok) "✓ Envío cancelado" else m }
                }
                if (aviso.isNotBlank()) { Spacer(Modifier.height(8.dp)); AvisoEstado(aviso) }
            }
        } else {
            Tarjeta(borde = MoradoYape.copy(alpha = .55f), fondo = PanelAlto) {
                if (rechazado != null) {
                    Row(
                        Modifier.fillMaxWidth().background(Rojo.copy(alpha = .1f), RoundedCornerShape(12.dp))
                            .clickable { ver = rechazado }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Info, null, tint = Rojo, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Rechazaron tu pago de ${soles(rechazado.monto)}" + if (rechazado.motivo.isNotBlank()) ": ${rechazado.motivo}" else "",
                            color = Rojo, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                }
                when {
                    falta <= 0L -> Text("Ya completaste este cobro ✓", color = Verde, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    partes >= 4 -> Text("Ya usaste tus 4 partes. Habla con el tesorero.", color = Ambar, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                    else -> {
                        Text("¿Ya yapeaste? Sube tu captura", color = Texto, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(3.dp))
                        Text("Puedes pagar todo o una parte · te quedan ${4 - partes} de 4", color = Tenue, fontSize = 12.5.sp)
                        Spacer(Modifier.height(10.dp))
                        Boton("Subir mi pago", Modifier.fillMaxWidth(), color = MoradoYape, icono = Icons.Rounded.AddAPhoto) { subir = true }
                    }
                }
            }
        }
    }

    if (subir) Hoja(onDismissRequest = { subir = false }) { SubirParteDialog(cobro, numero) { subir = false } }
    ver?.let { a -> VisorAbonoDialog(a) { ver = null } }
}

@Composable
private fun SubirParteDialog(cobro: Cobro, numero: Int, cerrar: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val falta = (cobro.monto - Caja.pagadoDe(cobro.id, numero)).coerceAtLeast(0L)
    var monto by remember { mutableStateOf(String.format(java.util.Locale.US, "%.2f", falta / 100.0)) }
    var captura by remember { mutableStateOf<ComprobanteImagen.Resultado?>(null) }
    var verGrande by remember { mutableStateOf<Bitmap?>(null) }
    var aviso by remember { mutableStateOf("") }
    var leyendo by remember { mutableStateOf(false) }
    var enviando by remember { mutableStateOf(false) }
    var listo by remember { mutableStateOf(false) }
    var progreso by remember { mutableStateOf(0) }

    fun elegir(uri: Uri?) {
        if (uri == null) return
        leyendo = true; aviso = ""
        scope.launch {
            try { captura = ComprobanteImagen.leerParaYape(context, uri) }
            catch (e: Exception) { aviso = e.message ?: "No se pudo leer la imagen" }
            finally { leyendo = false }
        }
    }
    val selectorFotos = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { elegir(it) }
    val selectorArchivos = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { elegir(it) }

    if (enviando || listo) {
        Tarjeta(borde = MoradoYape.copy(alpha = .5f), fondo = PanelAlto) {
            AnimacionEnvio(progreso, listo, MoradoYape, if (listo) "¡Enviado! Queda en revisión" else "Enviando tu pago…")
        }
        return
    }

    Tarjeta(borde = MoradoYape.copy(alpha = .5f), fondo = PanelAlto) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Send, null, tint = MoradoYape, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
            Text("Subir mi pago", color = Texto, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Text("${cobro.titulo} · te falta ${soles(falta)}", color = Tenue, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))

        Etiqueta("¿CUÁNTO YAPEASTE?", MoradoYape)
        Spacer(Modifier.height(6.dp))
        Campo(monto, { monto = it; aviso = "" }, "Monto · máx ${soles(falta)}", numerico = true)
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(falta, falta / 2).filter { it > 0L }.distinct().forEach { v ->
                Text(
                    if (v == falta) "Todo ${soles(v)}" else "Mitad ${soles(v)}",
                    color = MoradoYape, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.border(BorderStroke(1.dp, MoradoYape.copy(alpha = .45f)), RoundedCornerShape(99.dp))
                        .clickable { monto = String.format(java.util.Locale.US, "%.2f", v / 100.0); aviso = "" }
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                )
            }
        }

        Spacer(Modifier.height(14.dp))
        Etiqueta("CAPTURA DEL YAPE", MoradoYape)
        Spacer(Modifier.height(6.dp))
        val img = captura
        if (img == null) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Boton(if (leyendo) "Abriendo…" else "Foto", Modifier.weight(1f), color = MoradoYape, icono = Icons.Rounded.PhotoLibrary, activo = !leyendo) {
                    selectorFotos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                Boton("Archivo", Modifier.weight(1f), relleno = false, color = MoradoYape, icono = Icons.Rounded.FolderOpen, activo = !leyendo) {
                    selectorArchivos.launch(arrayOf("image/*"))
                }
            }
        } else {
            Box(Modifier.height(170.dp)) { MiniaturaComprobante(img.bitmap) { verGrande = img.bitmap } }
            Spacer(Modifier.height(7.dp))
            Boton("Cambiar captura", Modifier.fillMaxWidth(), relleno = false, color = Rojo, icono = Icons.Rounded.Delete) { captura = null }
        }

        if (aviso.isNotBlank()) { Spacer(Modifier.height(10.dp)); AvisoEstado(aviso) }
        Spacer(Modifier.height(14.dp))
        Boton("Enviar pago", Modifier.fillMaxWidth(), color = MoradoYape, icono = Icons.Rounded.Send, activo = captura != null && !leyendo) {
            val m = parseCentavos(monto) ?: 0L
            val foto = captura
            when {
                foto == null -> aviso = "Sube la captura de tu Yape"
                m <= 0L -> aviso = "Escribe cuánto yapeaste"
                m > falta -> aviso = "Máximo ${soles(falta)}"
                else -> {
                    enviando = true; progreso = 0
                    scope.launch {
                        try {
                            Caja.enviarAbonoYape(cobro, m, foto) { progreso = it }
                            enviando = false; listo = true
                            delay(2100)
                            cerrar()
                        } catch (e: Exception) {
                            enviando = false; listo = false
                            aviso = e.message ?: "No se pudo enviar"
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
    verGrande?.let { b -> VisorBitmapDialog(b) { verGrande = null } }
}

/** En Panel › Pagos: partes que enviaron las personas y esperan revisión. */
@Composable
fun PartesPorRevisar(puedeRevisar: Boolean) {
    val lista = Caja.abonosPorRevisar()
    if (lista.isEmpty()) return
    val yo = Caja.sesion.value?.numero
    var ver by remember { mutableStateOf<Abono?>(null) }
    var rechazar by remember { mutableStateOf<Abono?>(null) }
    var aprobar by remember { mutableStateOf<Abono?>(null) }
    var ocupado by remember { mutableStateOf<String?>(null) }
    var aviso by remember { mutableStateOf("") }

    Etiqueta("PARTES POR REVISAR · ${lista.size}", Azul)
    Spacer(Modifier.height(8.dp))
    if (aviso.isNotBlank()) { AvisoEstado(aviso); Spacer(Modifier.height(8.dp)) }
    lista.forEach { a ->
        val cobro = Caja.cobros.firstOrNull { it.id == a.cobroId }
        val pagado = Caja.pagadoDe(a.cobroId, a.socio)
        val total = cobro?.monto ?: 0L
        val propio = a.socio == yo && !Caja.esOwner
        Tarjeta(borde = Azul.copy(alpha = .45f), modifier = Modifier.cascada(lista.indexOf(a))) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                MiniaturaPago(a.capturaPath, Modifier.size(width = 52.dp, height = 64.dp).clickable { ver = a }, radio = 10.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Etiqueta("N.º ${a.socio} · PARTE ${Caja.abonosDe(a.cobroId, a.socio).size + 1}", Azul)
                    Text(Caja.socio(a.socio)?.nombre.orEmpty(), color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("Lleva ${soles(pagado)} de ${soles(total)}", color = Tenue, fontSize = 12.sp)
                    Text(fechaHora(a.fecha), color = Tenue, fontSize = 12.sp)
                }
                Text(soles(a.monto), color = Azul, fontSize = 17.sp, style = cifra)
            }
            Spacer(Modifier.height(10.dp))
            when {
                !puedeRevisar -> Pastilla("Solo lectura · no puedes aprobar ni rechazar", Cian)
                propio -> Pastilla("Es tu pago · otro debe revisarlo", Ambar)
                else -> Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Boton(if (ocupado == a.serverId) "…" else "Aprobar", Modifier.weight(1f), color = Verde, icono = Icons.Rounded.Check, activo = ocupado == null) { aprobar = a }
                    Boton("Rechazar", Modifier.weight(1f), relleno = false, color = Rojo, activo = ocupado == null) { rechazar = a }
                }
            }
        }
        Spacer(Modifier.height(9.dp))
    }
    Spacer(Modifier.height(6.dp))

    aprobar?.let { a ->
        val total = Caja.cobros.firstOrNull { it.id == a.cobroId }?.monto ?: 0L
        val despues = Caja.pagadoDe(a.cobroId, a.socio) + a.monto
        Hoja(onDismissRequest = { aprobar = null }) {
            Tarjeta(borde = Verde.copy(alpha = .5f), fondo = PanelAlto) {
                Titulo("¿Aprobar esta parte?")
                Spacer(Modifier.height(7.dp))
                Text("N.º ${a.socio} · ${soles(a.monto)}", color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    if (despues >= total) "Con esta parte completa el cobro." else "Quedará con ${soles(despues)} de ${soles(total)}.",
                    color = Verde, fontSize = 13.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(5.dp))
                Text("Confirma solo si el Yape llegó.", color = Tenue, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Boton("Sí, aprobar", Modifier.fillMaxWidth(), color = Verde) {
                    aprobar = null; ocupado = a.serverId; aviso = ""
                    Caja.revisarAbono(a, true) { ok, m -> ocupado = null; aviso = if (ok) "✓ $m" else m }
                }
                Spacer(Modifier.height(7.dp))
                Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { aprobar = null }
            }
        }
    }
    rechazar?.let { a ->
        var motivo by remember(a.serverId) { mutableStateOf("") }
        var error by remember(a.serverId) { mutableStateOf("") }
        Hoja(onDismissRequest = { rechazar = null }) {
            Tarjeta(borde = Rojo.copy(alpha = .5f), fondo = PanelAlto) {
                Titulo("Rechazar parte")
                Spacer(Modifier.height(6.dp))
                Text("N.º ${a.socio} · ${soles(a.monto)}", color = Texto, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                Campo(motivo, { motivo = it; error = "" }, "Motivo (ej. no llegó el Yape)")
                if (error.isNotBlank()) { Spacer(Modifier.height(8.dp)); AvisoEstado(error) }
                Spacer(Modifier.height(12.dp))
                Boton("Rechazar", Modifier.fillMaxWidth(), color = Rojo) {
                    if (motivo.trim().length < 4) { error = "Escribe un motivo corto"; return@Boton }
                    rechazar = null; ocupado = a.serverId; aviso = ""
                    Caja.revisarAbono(a, false, motivo) { ok, m -> ocupado = null; aviso = if (ok) "✓ $m" else m }
                }
                Spacer(Modifier.height(7.dp))
                Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { rechazar = null }
            }
        }
    }
    ver?.let { a -> VisorAbonoDialog(a) { ver = null } }
}
