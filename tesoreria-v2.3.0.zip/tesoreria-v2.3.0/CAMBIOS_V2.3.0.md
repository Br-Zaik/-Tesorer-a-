# Versión 2.3.0

- Cobros por partes: cada persona puede subir su propio Yape desde su cuenta (todo o una parte).
- La parte queda "En revisión" y no suma a la caja hasta que el tesorero o un admin la aprueba.
- Panel › Pagos: nueva sección "Partes por revisar" con foto, aprobar y rechazar con motivo.
- Nadie puede aprobar su propio pago (solo el dueño).
- La persona puede cancelar un envío en revisión y ve el motivo si se lo rechazan.
- Aviso cuando rechazan una parte.
- Arreglo: la tabla de partes no tenía permiso de lectura y salía "No tienes permiso" al entrar.
