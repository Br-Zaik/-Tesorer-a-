package com.tesoreria.caja.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Gasto
import com.tesoreria.caja.data.MedioPago
import com.tesoreria.caja.data.Miniaturas
import com.tesoreria.caja.data.Pago
import com.tesoreria.caja.data.fechaHoraLarga
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Vista previa de una imagen local (antes de subirla). */
@Composable
fun MiniaturaComprobante(
    bitmap: Bitmap?,
    modifier: Modifier = Modifier,
    alTocar: (() -> Unit)? = null
) {
    val imagen = remember(bitmap) { bitmap?.takeIf { !it.isRecycled }?.asImageBitmap() }
    val base = modifier
        .fillMaxWidth()
        .height(184.dp)
        .clip(RoundedCornerShape(18.dp))
        .background(FondoProfundo)
        .border(1.dp, Borde, RoundedCornerShape(18.dp))
    Box(
        if (alTocar != null) base.presionable { alTocar() } else base,
        contentAlignment = Alignment.Center
    ) {
        if (imagen != null) {
            Image(
                bitmap = imagen,
                contentDescription = "Comprobante",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            if (alTocar != null) {
                Row(
                    Modifier.align(Alignment.BottomEnd).padding(10.dp)
                        .background(Color.Black.copy(alpha = .62f), RoundedCornerShape(99.dp))
                        .padding(horizontal = 11.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.ZoomIn, null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Ver", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            Icon(Icons.Rounded.ReceiptLong, null, tint = Tenue, modifier = Modifier.size(42.dp))
        }
    }
}

/** Miniatura de un comprobante guardado en el servidor (con caché). */
@Composable
fun MiniaturaPago(path: String, modifier: Modifier = Modifier, radio: Dp = 10.dp) {
    var bmp by remember(path) { mutableStateOf(Miniaturas.enMemoria(path)) }
    var fallo by remember(path) { mutableStateOf(false) }
    LaunchedEffect(path) {
        if (bmp == null && path.isNotBlank()) {
            bmp = Caja.miniaturaComprobante(path)
            fallo = bmp == null
        }
    }
    val imagen = remember(bmp) { bmp?.asImageBitmap() }
    val aparece by animateFloatAsState(if (imagen != null) 1f else 0f, tween(450, easing = CurvaSuave), label = "miniatura")
    val forma = RoundedCornerShape(radio)
    Box(
        modifier
            .clip(forma)
            .then(if (imagen == null && !fallo) Modifier.brilloCarga(forma) else Modifier.background(PanelAlto, forma)),
        contentAlignment = Alignment.Center
    ) {
        when {
            imagen != null -> Image(
                bitmap = imagen,
                contentDescription = "Captura",
                modifier = Modifier.fillMaxSize().graphicsLayer { alpha = aparece; scaleX = .9f + .1f * aparece; scaleY = .9f + .1f * aparece },
                contentScale = ContentScale.Crop
            )
            fallo -> Icon(Icons.Rounded.Photo, null, tint = Tenue, modifier = Modifier.fillMaxSize(.55f))
        }
    }
}

/**
 * Visor tipo galería: fondo negro, la imagen entra creciendo, zoom con dos dedos,
 * doble toque para acercar, deslizar hacia abajo para cerrar y datos abajo.
 */
@Composable
private fun Galeria(
    bitmap: Bitmap?,
    cargando: Boolean,
    error: String,
    titulo: String,
    cerrar: () -> Unit,
    info: (@Composable ColumnScope.() -> Unit)? = null
) {
    Dialog(
        onDismissRequest = cerrar,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        val scope = rememberCoroutineScope()
        val entrada = remember { Animatable(0f) }
        LaunchedEffect(Unit) { entrada.animateTo(1f, tween(460, easing = CurvaSuave)) }
        var escala by remember { mutableFloatStateOf(1f) }
        var desp by remember { mutableStateOf(Offset.Zero) }
        var arrastre by remember { mutableFloatStateOf(0f) }
        var mostrarInfo by remember { mutableStateOf(true) }
        val imagen = remember(bitmap) { bitmap?.asImageBitmap() }
        val fondoAlpha = (1f - abs(arrastre) / 900f).coerceIn(.35f, 1f) * entrada.value

        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = fondoAlpha))) {
            when {
                imagen != null -> Image(
                    bitmap = imagen,
                    contentDescription = titulo,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(imagen) {
                            detectTapGestures(
                                onTap = { mostrarInfo = !mostrarInfo },
                                onDoubleTap = { punto ->
                                    scope.launch {
                                        val destino = if (escala > 1.05f) 1f else 2.6f
                                        val inicioE = escala
                                        val inicioD = desp
                                        val centro = Offset(size.width / 2f, size.height / 2f)
                                        val destinoD = if (destino == 1f) Offset.Zero else (centro - punto) * (destino - 1f)
                                        animate(0f, 1f, animationSpec = tween(340, easing = CurvaSuave)) { v, _ ->
                                            escala = inicioE + (destino - inicioE) * v
                                            desp = inicioD + (destinoD - inicioD) * v
                                        }
                                    }
                                }
                            )
                        }
                        .pointerInput(imagen) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                do {
                                    val evento = awaitPointerEvent()
                                    val dedos = evento.changes.count { it.pressed }
                                    val zoom = evento.calculateZoom()
                                    val pan = evento.calculatePan()
                                    if (dedos >= 2 || escala > 1.01f) {
                                        escala = (escala * zoom).coerceIn(1f, 5f)
                                        val maxX = size.width * (escala - 1f) / 2f
                                        val maxY = size.height * (escala - 1f) / 2f
                                        desp = Offset(
                                            (desp.x + pan.x).coerceIn(-maxX, maxX),
                                            (desp.y + pan.y).coerceIn(-maxY, maxY)
                                        )
                                        evento.changes.forEach { if (it.positionChanged()) it.consume() }
                                    } else if (dedos == 1) {
                                        arrastre += pan.y
                                        if (abs(arrastre) > 8f) evento.changes.forEach { if (it.positionChanged()) it.consume() }
                                    }
                                } while (evento.changes.any { it.pressed })
                                if (escala <= 1.01f) {
                                    escala = 1f
                                    desp = Offset.Zero
                                    if (abs(arrastre) > 220f) {
                                        cerrar()
                                    } else if (arrastre != 0f) {
                                        val desde = arrastre
                                        scope.launch {
                                            animate(desde, 0f, animationSpec = spring(dampingRatio = .72f, stiffness = 360f)) { v, _ -> arrastre = v }
                                        }
                                    }
                                }
                            }
                        }
                        .graphicsLayer {
                            val e = escala * (.9f + .1f * entrada.value) * (1f - abs(arrastre) / 3200f)
                            scaleX = e
                            scaleY = e
                            translationX = desp.x
                            translationY = desp.y + arrastre
                            alpha = entrada.value
                        }
                )
                cargando -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.width(220.dp).height(300.dp).brilloCarga(RoundedCornerShape(18.dp)))
                    Spacer(Modifier.height(16.dp))
                    CircularProgressIndicator(Modifier.size(26.dp), color = Texto, strokeWidth = 2.5.dp)
                }
                else -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.BrokenImage, null, tint = Rojo, modifier = Modifier.size(44.dp))
                    Spacer(Modifier.height(10.dp))
                    Text(error.ifBlank { "No hay imagen disponible" }, color = Color.White, fontSize = 15.sp)
                }
            }

            AnimatedVisibility(
                visible = mostrarInfo,
                enter = fadeIn(tween(260)),
                exit = fadeOut(tween(200)),
                modifier = Modifier.align(Alignment.TopCenter)
            ) {
                Row(
                    Modifier.fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .75f), Color.Transparent)))
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(titulo, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                    BotonCerrar(cerrar)
                }
            }

            if (info != null) {
                AnimatedVisibility(
                    visible = mostrarInfo && arrastre == 0f,
                    enter = slideInVertically(tween(380, easing = CurvaSuave)) { it / 2 } + fadeIn(tween(300)),
                    exit = slideOutVertically(tween(240)) { it / 2 } + fadeOut(tween(200)),
                    modifier = Modifier.align(Alignment.BottomCenter)
                ) {
                    Column(
                        Modifier.fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .88f), Color.Black)))
                            .navigationBarsPadding()
                            .padding(start = 20.dp, end = 20.dp, top = 36.dp, bottom = 18.dp)
                    ) { info(this) }
                }
            }
        }
    }
}

@Composable
private fun DatoGaleria(icono: ImageVector, texto: String, color: Color = Color.White.copy(alpha = .82f)) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icono, null, tint = color, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(8.dp))
        Text(texto, color = color, fontSize = 14.sp)
    }
}

@Composable
fun VisorBitmapDialog(bitmap: Bitmap, cerrar: () -> Unit) {
    Galeria(bitmap = bitmap, cargando = false, error = "", titulo = "Imagen", cerrar = cerrar)
}

@Composable
fun VisorPagoDialog(pago: Pago, cerrar: () -> Unit) {
    var bitmap by remember(pago.serverId) { mutableStateOf<Bitmap?>(null) }
    var error by remember(pago.serverId) { mutableStateOf("") }
    var cargando by remember(pago.serverId) { mutableStateOf(true) }

    LaunchedEffect(pago.serverId) {
        cargando = true
        error = ""
        try {
            val bytes = Caja.comprobanteBytes(pago)
            bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: throw IllegalStateException("No se pudo abrir la captura")
        } catch (e: Exception) {
            error = e.message ?: "No se pudo abrir el comprobante"
        } finally {
            cargando = false
        }
    }

    val socio = Caja.socio(pago.socio)
    val numeros = if (pago.grupoNumeros.isNotEmpty()) pago.grupoNumeros.distinct().sorted() else listOf(pago.socio)
    val yape = pago.medio == MedioPago.YAPE
    Galeria(
        bitmap = bitmap,
        cargando = cargando,
        error = error,
        titulo = "Comprobante · N.º ${pago.socio}",
        cerrar = cerrar
    ) {
        Text(socio?.nombre ?: "N.º ${pago.socio}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(soles(pago.monto * numeros.size), color = if (yape) MoradoYape else Verde, fontSize = 26.sp, style = cifra)
            Spacer(Modifier.width(12.dp))
            Row(
                Modifier.background((if (yape) MoradoYape else Verde).copy(alpha = .18f), RoundedCornerShape(99.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(if (yape) Icons.Rounded.QrCode2 else Icons.Rounded.Payments, null, tint = if (yape) MoradoYape else Verde, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(5.dp))
                Text(if (yape) "Yape" else "Manual", color = if (yape) MoradoYape else Verde, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(10.dp))
        DatoGaleria(Icons.Rounded.Schedule, fechaHoraLarga(pago.enviado))
        if (numeros.size > 1) {
            Spacer(Modifier.height(6.dp))
            DatoGaleria(Icons.Rounded.Groups, "Incluye N.º " + numeros.joinToString(", ") + " · ${soles(pago.monto)} c/u")
        }
        pago.revisadoPor?.let {
            Spacer(Modifier.height(6.dp))
            DatoGaleria(Icons.Rounded.VerifiedUser, "Revisó N.º $it")
        }
        Spacer(Modifier.height(10.dp))
        Text("Desliza hacia abajo para cerrar", color = Color.White.copy(alpha = .45f), fontSize = 12.sp)
    }
}

@Composable
fun VisorGastoDialog(gasto: Gasto, cerrar: () -> Unit) {
    var bitmap by remember(gasto.serverId) { mutableStateOf<Bitmap?>(null) }
    var error by remember(gasto.serverId) { mutableStateOf("") }
    var cargando by remember(gasto.serverId) { mutableStateOf(true) }

    LaunchedEffect(gasto.serverId) {
        cargando = true
        error = ""
        try {
            val bytes = Caja.comprobanteGastoBytes(gasto)
            bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: throw IllegalStateException("No se pudo abrir la imagen")
        } catch (e: Exception) {
            error = e.message ?: "No se pudo abrir el comprobante"
        } finally {
            cargando = false
        }
    }

    Galeria(
        bitmap = bitmap,
        cargando = cargando,
        error = error,
        titulo = "Comprobante del gasto",
        cerrar = cerrar
    ) {
        Text(gasto.concepto, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("− " + soles(gasto.monto), color = Rojo, fontSize = 26.sp, style = cifra)
        Spacer(Modifier.height(10.dp))
        DatoGaleria(Icons.Rounded.ShoppingBag, "Gasto registrado")
        Spacer(Modifier.height(6.dp))
        DatoGaleria(Icons.Rounded.Schedule, fechaHoraLarga(gasto.fecha))
    }
}

@Composable
private fun BotonCerrar(cerrar: () -> Unit) {
    Box(
        Modifier.size(40.dp).background(Color.White.copy(alpha = .14f), CircleShape)
            .presionable { cerrar() },
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.Close, "Cerrar", tint = Color.White, modifier = Modifier.size(21.dp))
    }
}
