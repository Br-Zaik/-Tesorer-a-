package com.tesoreria.caja.ui

import androidx.compose.animation.animateColorAsState
import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.delay
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Base neutra gris casi negro. El color lo pone cada sección.
val Fondo = Color(0xFF0B0F14)
val FondoProfundo = Color(0xFF070A0E)
val Panel = Color(0xFF131A22)
val PanelAlto = Color(0xFF18212B)
val Borde = Color(0xFF26313D)
val Cian = Color(0xFFB7FF00) // nombre histórico para no romper otras pantallas
val VerdeNeon = Color(0xFFB7FF00)
val VerdeBrillante = Color(0xFF55F56A)
val Verde = Color(0xFF4CF58A)
val Ambar = Color(0xFFFFC940)
val Rojo = Color(0xFFFF5C68)
val Violeta = Color(0xFF7B2CBF)
val MoradoYape = Color(0xFFC084FC)
val Texto = Color(0xFFF2F5F8)
val Tenue = Color(0xFF93A1B0)
val Suave = Color(0xFF111821)
val Celeste = Color(0xFF22D3EE)
val Azul = Color(0xFF60A5FA)
val Naranja = Color(0xFFFF9F1C)

// Un color por sección para saber siempre dónde estás.
val ColorInicio = Verde
val ColorMovimientos = Azul
val ColorActas = Ambar
val ColorPanel = VerdeNeon


fun colorCargo(hex: String?, fallback: Color = Cian): Color = runCatching {
    val limpio = hex.orEmpty().trim().removePrefix("#")
    require(limpio.length == 6)
    Color(android.graphics.Color.parseColor("#$limpio"))
}.getOrDefault(fallback)

val GradientePrincipal = Brush.horizontalGradient(listOf(Color(0xFF24EE75), Color(0xFFB7FF00)))
val GradienteTarjeta = Brush.linearGradient(listOf(Color(0xFF1A2430), Color(0xFF111820)))

/** Curva suave tipo iOS: arranca rápido y frena despacio. */
val CurvaSuave = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)

private val esquema = darkColorScheme(
    primary = VerdeNeon,
    onPrimary = FondoProfundo,
    primaryContainer = PanelAlto,
    onPrimaryContainer = Texto,
    secondary = VerdeBrillante,
    background = Fondo,
    onBackground = Texto,
    surface = Panel,
    onSurface = Texto,
    surfaceVariant = PanelAlto,
    onSurfaceVariant = Tenue,
    error = Rojo,
    onError = Texto
)

@Composable
fun CajaTheme(contenido: @Composable () -> Unit) {
    MaterialTheme(colorScheme = esquema, content = contenido)
}

val cifra = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.SemiBold,
    letterSpacing = 0.sp
)

@Composable
fun Tarjeta(
    modifier: Modifier = Modifier,
    borde: Color = Borde.copy(alpha = 0.78f),
    fondo: Color = Panel,
    contenido: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(fondo, RoundedCornerShape(22.dp))
            .border(BorderStroke(1.dp, borde), RoundedCornerShape(22.dp))
            .padding(17.dp),
        content = contenido
    )
}

@Composable
fun TarjetaPremium(
    modifier: Modifier = Modifier,
    contenido: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(GradienteTarjeta, RoundedCornerShape(24.dp))
            .border(BorderStroke(1.dp, VerdeBrillante.copy(alpha = 0.28f)), RoundedCornerShape(24.dp))
            .padding(18.dp),
        content = contenido
    )
}

@Composable
fun Etiqueta(texto: String, color: Color = Tenue) {
    Text(texto, color = color, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
}

@Composable
fun Titulo(texto: String) {
    Text(texto, color = Texto, fontSize = 23.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun Subtitulo(texto: String) {
    Text(texto, color = Tenue, fontSize = 13.5.sp)
}

@Composable
fun Boton(
    texto: String,
    modifier: Modifier = Modifier,
    color: Color = VerdeNeon,
    relleno: Boolean = true,
    activo: Boolean = true,
    icono: ImageVector? = null,
    alTocar: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val escala by animateFloatAsState(if (pressed) 0.96f else 1f, spring(dampingRatio = 0.55f, stiffness = 420f), label = "buttonScale")
    val brillo by animateFloatAsState(if (pressed) 0.72f else 1f, label = "buttonGlow")
    val fondoModifier = when {
        !activo -> Modifier.background(Color.Transparent, RoundedCornerShape(16.dp))
        relleno && color == VerdeNeon -> Modifier.background(GradientePrincipal, RoundedCornerShape(16.dp))
        relleno -> Modifier.background(color.copy(alpha = brillo), RoundedCornerShape(16.dp))
        else -> Modifier.background(Color.Transparent, RoundedCornerShape(16.dp))
    }
    val base = Modifier
        .scale(escala)
        .height(54.dp)
        .then(fondoModifier)
        .border(BorderStroke(1.dp, if (activo) color.copy(alpha = if (relleno) 0.85f else 0.55f) else Borde), RoundedCornerShape(16.dp))
        .clickable(interactionSource = interaction, indication = null, enabled = activo) { alTocar() }

    val colorTexto = if (!activo) Tenue else if (relleno) FondoProfundo else color
    Box(modifier.then(base), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icono != null) {
                Icon(icono, null, tint = colorTexto, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text(
                texto,
                color = colorTexto,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun Campo(
    valor: String,
    alCambiar: (String) -> Unit,
    pista: String,
    modifier: Modifier = Modifier,
    numerico: Boolean = false,
    clave: Boolean = false,
    focusRequester: FocusRequester? = null
) {
    var enfocado by remember { mutableStateOf(false) }
    var mostrarClave by remember { mutableStateOf(false) }
    val colorBorde by animateColorAsState(
        targetValue = if (enfocado) VerdeBrillante else Borde,
        label = "campoBorde"
    )
    val escala by animateFloatAsState(if (enfocado) 1.01f else 1f, label = "campoEscala")

    Row(
        modifier = modifier
            .fillMaxWidth()
            .scale(escala)
            .height(58.dp)
            .background(FondoProfundo.copy(alpha = 0.76f), RoundedCornerShape(16.dp))
            .border(BorderStroke(1.dp, colorBorde), RoundedCornerShape(16.dp))
            .padding(start = 15.dp, end = if (clave) 8.dp else 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .weight(1f)
                .onFocusChanged { enfocado = it.hasFocus },
            contentAlignment = Alignment.CenterStart
        ) {
            if (valor.isEmpty()) Text(pista, color = Tenue.copy(alpha = 0.70f), fontSize = 15.sp)
            BasicTextField(
                value = valor,
                onValueChange = alCambiar,
                singleLine = true,
                textStyle = TextStyle(color = Texto, fontSize = 16.sp, fontWeight = FontWeight.Medium),
                cursorBrush = SolidColor(VerdeNeon),
                visualTransformation = if (clave && !mostrarClave) PasswordVisualTransformation() else VisualTransformation.None,
                keyboardOptions = KeyboardOptions(
                    keyboardType = when {
                        clave -> KeyboardType.Password
                        numerico -> KeyboardType.Decimal
                        else -> KeyboardType.Text
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            )
        }
        if (clave) {
            val interaction = remember { MutableInteractionSource() }
            Box(
                Modifier
                    .size(42.dp)
                    .clickable(interactionSource = interaction, indication = null) { mostrarClave = !mostrarClave },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (mostrarClave) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                    contentDescription = if (mostrarClave) "Ocultar contraseña" else "Mostrar contraseña",
                    tint = if (enfocado) VerdeBrillante else Tenue,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun Pastilla(texto: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.11f), RoundedCornerShape(999.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.36f)), RoundedCornerShape(999.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(texto, color = color, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MiniDato(etiqueta: String, valor: String, color: Color) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.07f), RoundedCornerShape(15.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.20f)), RoundedCornerShape(15.dp))
            .padding(horizontal = 13.dp, vertical = 11.dp)
    ) {
        Text(etiqueta, color = Tenue, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(3.dp))
        Text(valor, color = color, fontSize = 16.sp, style = cifra)
    }
}

@Composable
fun FilaEntre(contenido: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        content = contenido
    )
}


/** Encabezado corto con ícono y color de la sección. */
@Composable
fun CabeceraSeccion(icono: ImageVector, titulo: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(40.dp).background(color.copy(alpha = .16f), RoundedCornerShape(13.dp))
                .border(BorderStroke(1.dp, color.copy(alpha = .45f)), RoundedCornerShape(13.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icono, null, tint = color, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(11.dp))
        Text(titulo, color = Texto, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    }
}

/** Vibración corta de confirmación (sin permisos especiales). */
@Composable
fun rememberVibracion(): (Boolean) -> Unit {
    val view = LocalView.current
    return remember(view) {
        { exito: Boolean ->
            val tipo = when {
                exito && Build.VERSION.SDK_INT >= 30 -> HapticFeedbackConstants.CONFIRM
                !exito && Build.VERSION.SDK_INT >= 30 -> HapticFeedbackConstants.REJECT
                else -> HapticFeedbackConstants.VIRTUAL_KEY
            }
            view.performHapticFeedback(tipo)
            Unit
        }
    }
}

/** Se hunde un poquito al tocar, con rebote suave al soltar. */
fun Modifier.presionable(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val escala by animateFloatAsState(
        if (pressed) 0.965f else 1f,
        spring(dampingRatio = 0.55f, stiffness = 420f),
        label = "presion"
    )
    this
        .graphicsLayer { scaleX = escala; scaleY = escala }
        .clickable(interactionSource = interaction, indication = null, enabled = enabled) { onClick() }
}

/** Entrada en cascada: cada elemento aparece un poquito después del anterior. */
fun Modifier.cascada(indice: Int, desplazamiento: Dp = 18.dp): Modifier = composed {
    val progreso = remember { Animatable(0f) }
    val px = with(LocalDensity.current) { desplazamiento.toPx() }
    LaunchedEffect(Unit) {
        delay(45L * indice.coerceIn(0, 10))
        progreso.animateTo(1f, tween(520, easing = CurvaSuave))
    }
    this.graphicsLayer {
        alpha = progreso.value
        translationY = (1f - progreso.value) * px
    }
}

/** Brillo que pasa encima mientras algo carga (en vez de un texto). */
fun Modifier.brilloCarga(forma: androidx.compose.ui.graphics.Shape = RoundedCornerShape(14.dp)): Modifier = composed {
    val t by rememberInfiniteTransition(label = "brillo").animateFloat(
        initialValue = -1f, targetValue = 2f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
        label = "brilloX"
    )
    this.background(
        Brush.linearGradient(
            listOf(Panel, PanelAlto.copy(alpha = 1f), Color(0xFF243140), PanelAlto, Panel),
            start = Offset(t * 700f, 0f),
            end = Offset(t * 700f + 500f, 260f)
        ),
        forma
    )
}

/**
 * Ventana que sube desde abajo, se acomoda al teclado y se desplaza si es larga.
 * Reemplaza a los diálogos que aparecían de golpe en el centro.
 */
@Composable
fun Hoja(onDismissRequest: () -> Unit, contenido: @Composable () -> Unit) {
    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        val visible = remember { MutableTransitionState(false) }.apply { targetState = true }
        val sinEfecto = remember { MutableInteractionSource() }
        val bloqueo = remember { MutableInteractionSource() }
        Box(
            Modifier
                .fillMaxSize()
                .clickable(interactionSource = sinEfecto, indication = null) { onDismissRequest() }
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding(),
            contentAlignment = Alignment.BottomCenter
        ) {
            AnimatedVisibility(
                visibleState = visible,
                enter = slideInVertically(tween(480, easing = CurvaSuave)) { it / 3 } +
                    fadeIn(tween(320)) +
                    scaleIn(tween(480, easing = CurvaSuave), initialScale = 0.96f),
                exit = fadeOut(tween(150))
            ) {
                Column(
                    Modifier
                        .widthIn(max = 560.dp)
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 10.dp)
                        .clickable(interactionSource = bloqueo, indication = null) { }
                        .verticalScroll(rememberScrollState())
                ) {
                    Box(
                        Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp)
                            .width(42.dp).height(5.dp)
                            .background(Texto.copy(alpha = .25f), RoundedCornerShape(99.dp))
                    )
                    contenido()
                }
            }
        }
    }
}

/** Monto que sube contando hasta su valor. */
@Composable
fun DineroAnimado(
    centavos: Long,
    color: Color = Texto,
    tamano: androidx.compose.ui.unit.TextUnit = 34.sp,
    modifier: Modifier = Modifier
) {
    val inicio = remember { Animatable(0f) }
    LaunchedEffect(centavos) {
        inicio.animateTo(centavos.toFloat(), tween(1100, easing = CurvaSuave))
    }
    Text(soles(inicio.value.toLong()), color = color, fontSize = tamano, style = cifra, modifier = modifier)
}

/** Interruptor limpio con perilla que se desliza con rebote. */
@Composable
fun Interruptor(activo: Boolean, color: Color = Verde, habilitado: Boolean = true, alTocar: () -> Unit) {
    val x by animateDpAsState(if (activo) 22.dp else 2.dp, spring(dampingRatio = 0.62f, stiffness = 520f), label = "perilla")
    val pista by animateColorAsState(
        when { !habilitado -> Borde.copy(alpha = .5f); activo -> color; else -> Borde },
        tween(260), label = "pista"
    )
    val perilla by animateColorAsState(if (activo) Color.White else Tenue, tween(260), label = "perillaColor")
    Box(
        Modifier.width(50.dp).height(30.dp)
            .background(pista, RoundedCornerShape(99.dp))
            .clickable(enabled = habilitado, interactionSource = remember { MutableInteractionSource() }, indication = null) { alTocar() }
    ) {
        Box(
            Modifier.offset(x = x, y = 2.dp).size(26.dp)
                .background(perilla.copy(alpha = if (habilitado) 1f else .5f), CircleShape)
        )
    }
}

/** Mensaje corto con ícono real (en vez de un ✓ escrito). */
@Composable
fun AvisoEstado(texto: String, ocupado: Boolean = false) {
    if (texto.isBlank()) return
    val ok = texto.startsWith("✓")
    val limpio = texto.removePrefix("✓").trim()
    val color = when { ok -> Verde; ocupado -> Ambar; else -> Rojo }
    val aparece = remember(texto) { Animatable(0f) }
    LaunchedEffect(texto) { aparece.animateTo(1f, tween(360, easing = CurvaSuave)) }
    Row(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { alpha = aparece.value; translationY = (1f - aparece.value) * 12f }
            .background(color.copy(alpha = .10f), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            when { ok -> Icons.Rounded.CheckCircle; ocupado -> Icons.Rounded.Schedule; else -> Icons.Rounded.ErrorOutline },
            null, tint = color, modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(9.dp))
        Text(limpio, color = Texto, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

/** Círculo que se completa y un check que se dibuja solo. */
@Composable
fun CheckDibujado(color: Color = Verde, tamano: Dp = 72.dp) {
    val anillo = remember { Animatable(0f) }
    val trazo = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        anillo.animateTo(1f, tween(520, easing = CurvaSuave))
        trazo.animateTo(1f, tween(380, easing = CurvaSuave))
    }
    val pathDestino = remember { Path() }
    val medidor = remember { PathMeasure() }
    Canvas(Modifier.size(tamano)) {
        val grosor = size.minDimension * 0.075f
        drawCircle(color.copy(alpha = .14f), radius = size.minDimension / 2f)
        drawArc(
            color = color, startAngle = -90f, sweepAngle = 360f * anillo.value, useCenter = false,
            topLeft = Offset(grosor / 2, grosor / 2),
            size = androidx.compose.ui.geometry.Size(size.width - grosor, size.height - grosor),
            style = Stroke(width = grosor, cap = StrokeCap.Round)
        )
        val check = Path().apply {
            moveTo(size.width * .28f, size.height * .52f)
            lineTo(size.width * .44f, size.height * .67f)
            lineTo(size.width * .73f, size.height * .37f)
        }
        medidor.setPath(check, false)
        pathDestino.reset()
        medidor.getSegment(0f, medidor.length * trazo.value, pathDestino, true)
        drawPath(pathDestino, color, style = Stroke(width = grosor * 1.1f, cap = StrokeCap.Round))
    }
}

/**
 * Animación de envío: el avión despega en un arco suave mientras sube el archivo;
 * al terminar se dibuja el check y el celular vibra un poquito.
 */
@Composable
fun AnimacionEnvio(progreso: Int, listo: Boolean, color: Color = VerdeBrillante, texto: String = "Enviando…") {
    val vibrar = rememberVibracion()
    LaunchedEffect(listo) { if (listo) vibrar(true) }
    val infinita = rememberInfiniteTransition(label = "envio")
    val vuelo by infinita.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1700, easing = CurvaSuave), RepeatMode.Restart),
        label = "vuelo"
    )
    val halo by infinita.animateFloat(
        initialValue = .45f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "halo"
    )
    val p by animateFloatAsState(progreso.coerceIn(0, 100) / 100f, tween(600, easing = CurvaSuave), label = "progresoEnvio")
    val colorFinal by animateColorAsState(if (listo) Verde else color, tween(400), label = "colorEnvio")

    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(110.dp), contentAlignment = Alignment.Center) {
            if (listo) {
                CheckDibujado(Verde, 96.dp)
            } else {
                Box(
                    Modifier.size(104.dp).graphicsLayer { scaleX = .9f + .1f * halo; scaleY = .9f + .1f * halo; alpha = halo }
                        .background(color.copy(alpha = .10f), CircleShape)
                        .border(BorderStroke(1.5.dp, color.copy(alpha = .35f)), CircleShape)
                )
                // Arco: sube y avanza, se achica y se desvanece al "salir".
                val x = -26f + 52f * vuelo
                val y = 16f - 34f * vuelo + 10f * (vuelo * vuelo)
                Icon(
                    Icons.Rounded.Send, null, tint = color,
                    modifier = Modifier
                        .size(42.dp)
                        .offset(x = x.dp, y = y.dp)
                        .graphicsLayer {
                            rotationZ = -24f - 10f * vuelo
                            val s = 1f - .25f * vuelo
                            scaleX = s; scaleY = s
                            alpha = when {
                                vuelo < .12f -> vuelo / .12f
                                vuelo > .78f -> ((1f - vuelo) / .22f).coerceIn(0f, 1f)
                                else -> 1f
                            }
                        }
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(if (listo) "¡Listo!" else texto, color = colorFinal, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).background(Borde, RoundedCornerShape(99.dp))) {
            Box(
                Modifier.fillMaxWidth(if (listo) 1f else p.coerceAtLeast(.04f)).fillMaxHeight()
                    .background(colorFinal, RoundedCornerShape(99.dp))
            )
        }
    }
}
