package com.tesoreria.caja.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Miniaturas de comprobantes con caché en memoria y en disco.
 * Cada captura se baja una sola vez; luego se lee del celular sin gastar datos.
 */
object Miniaturas {
    private const val LADO = 220
    private val memoria = LruCache<String, Bitmap>(64)
    private val completas = object : LruCache<String, ByteArray>(6 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ByteArray): Int = value.size
    }
    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val candado = Mutex()
    private val enCurso = mutableMapOf<String, Deferred<Bitmap?>>()
    private var carpeta: File? = null

    fun inicializar(context: Context) {
        carpeta = File(context.cacheDir, "miniaturas").apply { mkdirs() }
    }

    fun enMemoria(path: String): Bitmap? = if (path.isBlank()) null else memoria.get(path)

    private fun archivo(path: String): File? =
        carpeta?.let { File(it, path.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".jpg") }

    /** Bytes completos de la captura (con caché corta en memoria). */
    suspend fun bytesCompletos(path: String, descargar: suspend () -> ByteArray): ByteArray {
        completas.get(path)?.let { return it }
        val bytes = descargar()
        completas.put(path, bytes)
        return bytes
    }

    suspend fun cargar(path: String, descargar: suspend () -> ByteArray): Bitmap? {
        if (path.isBlank()) return null
        memoria.get(path)?.let { return it }
        val tarea = candado.withLock {
            enCurso[path] ?: alcance.async {
                try {
                    val disco = archivo(path)
                    val desdeDisco = disco?.takeIf { it.exists() && it.length() > 0 }?.let { BitmapFactory.decodeFile(it.absolutePath) }
                    val bmp = desdeDisco ?: run {
                        val bytes = bytesCompletos(path, descargar)
                        val reducido = reducir(bytes) ?: return@run null
                        disco?.let { f ->
                            runCatching {
                                val out = ByteArrayOutputStream()
                                reducido.compress(Bitmap.CompressFormat.JPEG, 82, out)
                                f.writeBytes(out.toByteArray())
                            }
                        }
                        reducido
                    }
                    if (bmp != null) memoria.put(path, bmp)
                    bmp
                } catch (_: Exception) {
                    null
                } finally {
                    candado.withLock { enCurso.remove(path) }
                }
            }.also { enCurso[path] = it }
        }
        return tarea.await()
    }

    private fun reducir(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var muestra = 1
        while (bounds.outWidth / (muestra * 2) >= LADO && bounds.outHeight / (muestra * 2) >= LADO) muestra *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = muestra }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }
}
