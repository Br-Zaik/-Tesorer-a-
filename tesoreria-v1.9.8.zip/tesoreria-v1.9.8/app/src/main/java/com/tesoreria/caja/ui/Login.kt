package com.tesoreria.caja.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.LockReset
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Login
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.R
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Socio
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun PantallaLogin(avisoInicial: String? = null, alEntrar: (Socio) -> Unit) {
    var numero by remember { mutableStateOf("") }
    var clave by remember { mutableStateOf("") }
    var codigo by remember { mutableStateOf("") }
    var clave2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var cargando by remember { mutableStateOf(false) }
    // 0 = entrar, 1 = crear cuenta, 2 = cambiar contraseña
    var modo by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current
    val vibrar = rememberVibracion()
    var exito by remember { mutableStateOf(false) }
    // Entrada: el logo aparece y luego sube el formulario.
    val logo = remember { Animatable(0f) }
    val formulario = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { logo.animateTo(1f, tween(700, easing = CurvaSuave)) }
        delay(180)
        formulario.animateTo(1f, tween(650, easing = CurvaSuave))
    }
    // Temblor del formulario cuando algo está mal.
    val temblor = remember { Animatable(0f) }
    var errores by remember { mutableIntStateOf(0) }
    LaunchedEffect(errores) {
        if (errores > 0) {
            vibrar(false)
            for (x in listOf(14f, -12f, 9f, -6f, 3f, 0f)) temblor.animateTo(x, tween(55))
        }
    }
    fun fallar(mensaje: String) { error = mensaje; errores++ }

    fun limpiarFormulario(modoNuevo: Int) {
        modo = modoNuevo
        error = ""
        clave = ""
        clave2 = ""
        codigo = ""
    }

    val tituloModo = when (modo) {
        1 -> "CREAR CUENTA"
        2 -> "CAMBIAR CONTRASEÑA"
        else -> "ACCESO PERSONAL"
    }
    val ayudaModo = when (modo) {
        1 -> "Usa uno de los códigos de activación compartidos por Tesorería."
        2 -> "Usa el código temporal generado para tu número de lista."
        else -> "Ingresa con tu número de lista y contraseña."
    }

    Box(Modifier.fillMaxSize().background(Fondo)) {
        FondoEstaticoLogin()
        // Mantener el contenido anclado arriba evita el “salto” visual al cerrar
        // el teclado durante el inicio de sesión. Antes se centraba con Arrangement.Center;
        // al desaparecer el IME cambiaba la altura disponible y toda la pantalla (incluido
        // el logo) se recolocaba durante unos fotogramas.
        Column(
            Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(top = 22.dp, bottom = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.graphicsLayer {
                    alpha = logo.value
                    val e = .8f + .2f * logo.value
                    scaleX = e; scaleY = e
                    translationY = (1f - logo.value) * 30f
                }
            ) {
                Image(painter = painterResource(R.drawable.tesoreria_logo_hd), contentDescription = "Tesorería", modifier = Modifier.size(92.dp))
                Spacer(Modifier.height(10.dp))
                Text("Tesorería", color = Texto, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(3.dp))
                Text("Caja del grupo", color = Tenue, fontSize = 14.sp)
            }
            Spacer(Modifier.height(20.dp))

            if (!avisoInicial.isNullOrBlank()) {
                Box(
                    Modifier.fillMaxWidth().background(Ambar.copy(alpha = .09f), RoundedCornerShape(14.dp))
                        .border(1.dp, Ambar.copy(alpha = .30f), RoundedCornerShape(14.dp)).padding(12.dp)
                ) { Text(avisoInicial, color = Texto, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
                Spacer(Modifier.height(10.dp))
            }

            val acento = when (modo) { 1 -> Celeste; 2 -> Ambar; else -> VerdeBrillante }
            val acentoAnimado by animateColorAsState(acento, tween(420), label = "acentoLogin")
            Tarjeta(
                Modifier.graphicsLayer {
                    alpha = formulario.value
                    translationY = (1f - formulario.value) * 80f
                    translationX = temblor.value * density
                },
                borde = acentoAnimado.copy(alpha = .35f), fondo = PanelAlto
            ) {
                AnimatedContent(
                    targetState = modo,
                    transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1
                        (slideInHorizontally(tween(420, easing = CurvaSuave)) { dir * it / 3 } + fadeIn(tween(320)))
                            .togetherWith(slideOutHorizontally(tween(320, easing = CurvaSuave)) { -dir * it / 3 } + fadeOut(tween(200)))
                            .using(SizeTransform(clip = false))
                    },
                    label = "modoLogin"
                ) { m ->
                Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).background(acento.copy(alpha = .14f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(when (m) { 1 -> Icons.Rounded.PersonAdd; 2 -> Icons.Rounded.LockReset; else -> Icons.Rounded.Login }, null, tint = acento, modifier = Modifier.size(24.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(when (m) { 1 -> "Crear cuenta"; 2 -> "Cambiar contraseña"; else -> "Iniciar sesión" }, color = Texto, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(2.dp))
                        Text(when (m) { 1 -> "Con el código que te dio el tesorero."; 2 -> "Con tu código temporal de 6 dígitos."; else -> "Con tu número de lista." }, color = Tenue, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))

                Etiqueta("NÚMERO DE LISTA")
                Spacer(Modifier.height(6.dp))
                Campo(numero, { numero = it.filter(Char::isDigit).take(2); error = "" }, "Ej. 12", numerico = true)
                Spacer(Modifier.height(11.dp))

                if (m != 0) {
                    Etiqueta(if (m == 1) "CÓDIGO DE ACTIVACIÓN" else "CÓDIGO TEMPORAL")
                    Spacer(Modifier.height(6.dp))
                    Campo(codigo, { codigo = it.filter(Char::isDigit).take(6); error = "" }, "6 dígitos", numerico = true)
                    Spacer(Modifier.height(11.dp))
                    Etiqueta("NUEVA CONTRASEÑA")
                    Spacer(Modifier.height(6.dp))
                    Campo(clave, { clave = it; error = "" }, "Nueva contraseña", clave = true)
                    Spacer(Modifier.height(11.dp))
                    Etiqueta("REPETIR CONTRASEÑA")
                    Spacer(Modifier.height(6.dp))
                    Campo(clave2, { clave2 = it; error = "" }, "Repite la contraseña", clave = true)
                } else {
                    Etiqueta("CONTRASEÑA")
                    Spacer(Modifier.height(6.dp))
                    Campo(clave, { clave = it; error = "" }, "Tu contraseña", clave = true)
                }
                }
                }

                if (error.isNotBlank()) { Spacer(Modifier.height(12.dp)); AvisoEstado(error) }
                Spacer(Modifier.height(16.dp))
                Boton(
                    if (cargando) "Verificando…" else when (modo) { 1 -> "Crear cuenta y entrar"; 2 -> "Guardar contraseña"; else -> "Entrar" },
                    Modifier.fillMaxWidth(), activo = !cargando,
                    color = if (modo == 0) VerdeNeon else acento,
                    icono = when (modo) { 1 -> Icons.Rounded.PersonAdd; 2 -> Icons.Rounded.LockReset; else -> Icons.Rounded.Login }
                ) {
                    val n = numero.toIntOrNull()
                    when {
                        n == null || n !in 1..35 -> fallar("Escribe tu número de lista (1 al 35)")
                        clave.length < 6 -> fallar("La contraseña debe tener al menos 6 caracteres")
                        modo != 0 && codigo.length != 6 -> fallar("Escribe el código de 6 dígitos")
                        modo != 0 && clave != clave2 -> fallar("Las contraseñas no coinciden")
                        modo != 0 && (clave == n.toString() || clave == n.toString().padStart(2, '0')) -> fallar("No uses tu número de lista como contraseña")
                        else -> {
                            keyboard?.hide(); focus.clearFocus(); cargando = true; error = ""
                            scope.launch {
                                try {
                                    val socio = if (modo == 0) Caja.iniciarSesion(n, clave) else Caja.activarCuenta(n, codigo, clave)
                                    exito = true
                                    vibrar(true)
                                    delay(950)
                                    alEntrar(socio)
                                } catch (ex: Exception) {
                                    fallar(mensajeLogin(ex, when (modo) { 1 -> "No se pudo crear la cuenta"; 2 -> "No se pudo cambiar la contraseña"; else -> "No se pudo iniciar sesión" }))
                                    cargando = false
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                if (modo == 0) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Boton("Crear cuenta", Modifier.weight(1f), relleno = false, color = Celeste, activo = !cargando, icono = Icons.Rounded.PersonAdd) { limpiarFormulario(1) }
                        Boton("Contraseña", Modifier.weight(1f), relleno = false, color = Ambar, activo = !cargando, icono = Icons.Rounded.LockReset) { limpiarFormulario(2) }
                    }
                } else {
                    Boton("Volver", Modifier.fillMaxWidth(), relleno = false, color = Tenue, activo = !cargando, icono = Icons.Rounded.ArrowBack) { limpiarFormulario(0) }
                }
            }

            Spacer(Modifier.height(13.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Shield, null, tint = VerdeBrillante.copy(alpha = .75f), modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(6.dp))
                Text("Conexión segura con Tesorería", color = Tenue.copy(alpha = .78f), fontSize = 12.sp)
            }
        }
        AnimatedVisibility(visible = exito, enter = fadeIn(tween(300)), exit = fadeOut(tween(200))) {
            Box(Modifier.fillMaxSize().background(Fondo.copy(alpha = .94f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CheckDibujado(Verde, 104.dp)
                    Spacer(Modifier.height(16.dp))
                    Text(if (modo == 0) "¡Bienvenido!" else "¡Listo!", color = Texto, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun mensajeLogin(ex: Exception, fallback: String): String {
    val raw = ex.message.orEmpty()
    val n = raw.lowercase(Locale.ROOT)
    return when {
        "permission denied" in n || "row-level security" in n || "not authorized" in n -> "No tienes permiso"
        "sin conexión" in n -> "Sin conexión a Internet"
        "tardó" in n || "timeout" in n || "temporalmente" in n || "servidor" in n -> "El servidor tardó en responder. Inténtalo nuevamente"
        "contraseña incorrecta" in n || "invalid login" in n || "invalid credentials" in n -> "Número o contraseña incorrectos"
        raw.isBlank() -> fallback
        else -> raw
    }
}

@Composable
private fun FondoEstaticoLogin() {
    androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawCircle(VerdeBrillante.copy(alpha = .030f), size.minDimension * .60f, center = androidx.compose.ui.geometry.Offset(w * .80f, h * .13f))
        drawCircle(VerdeNeon.copy(alpha = .020f), size.minDimension * .46f, center = androidx.compose.ui.geometry.Offset(w * .07f, h * .86f))
        val paso = w / 7f
        for (i in 1..6) {
            drawLine(VerdeBrillante.copy(alpha = .014f), androidx.compose.ui.geometry.Offset(i * paso, 0f), androidx.compose.ui.geometry.Offset(i * paso, h), 1f)
        }
    }
}
