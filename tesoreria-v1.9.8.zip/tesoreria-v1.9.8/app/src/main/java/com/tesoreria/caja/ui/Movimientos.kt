package com.tesoreria.caja.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.rounded.Inbox
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Acta
import com.tesoreria.caja.data.TipoCobro
import com.tesoreria.caja.data.EstadoPago
import com.tesoreria.caja.data.MedioPago
import com.tesoreria.caja.data.Pago
import com.tesoreria.caja.data.PdfExporter
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.fechaLarga
import com.tesoreria.caja.data.horaCorta
import com.tesoreria.caja.data.PE
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.launch

@Composable
fun PantallaMovimientos() {
    var verGastos by remember { mutableStateOf(false) }
    var verComprobante by remember { mutableStateOf<Pago?>(null) }
    var verComprobanteGasto by remember { mutableStateOf<com.tesoreria.caja.data.Gasto?>(null) }

    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(2.dp))
        CabeceraSeccion(Icons.Rounded.SwapVert, "Libro de caja", ColorMovimientos)
        Spacer(Modifier.height(12.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(13.dp))
                .border(BorderStroke(1.dp, Borde), RoundedCornerShape(13.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Pestana("Ingresos", !verGastos, Verde, Modifier.weight(1f)) { verGastos = false }
            Pestana("Gastos", verGastos, Rojo, Modifier.weight(1f)) { verGastos = true }
        }

        Spacer(Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 8.dp)
        ) {
            if (!verGastos) {
                val propios = Caja.pagos.filter { it.socio == Caja.sesion.value?.numero && it.medio == MedioPago.YAPE && Caja.cobros.firstOrNull { c -> c.id == it.cobroId }?.tipo != TipoCobro.RAPIDO }
                    .sortedByDescending { it.enviado }
                if (propios.isNotEmpty()) {
                    item {
                        Tarjeta(borde = Azul.copy(alpha = .25f), fondo = PanelAlto) {
                            Etiqueta("MIS COMPROBANTES", Azul)
                            Spacer(Modifier.height(4.dp))
                            Text("Puedes volver a abrir exactamente lo que enviaste.", color = Tenue, fontSize = 12.sp)
                        }
                    }
                    items(propios) { p ->
                        Row(
                            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(13.dp))
                                .border(BorderStroke(1.dp, Borde), RoundedCornerShape(13.dp))
                                .clickable(enabled = p.capturaPath.isNotBlank()) { verComprobante = p }
                                .padding(13.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(soles(p.monto), color = Texto, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(3.dp))
                                Text("${fechaLarga(p.enviado)} · ${horaCorta(p.enviado)}", color = Tenue, fontSize = 12.sp)
                            }
                            Pastilla(
                                when (p.estado) {
                                    EstadoPago.APROBADO -> "Aprobado"
                                    EstadoPago.PENDIENTE -> "Pendiente"
                                    EstadoPago.RECHAZADO -> "Rechazado"
                                    EstadoPago.SIN_ENVIAR -> "No enviado"
                                    EstadoPago.NO_PAGA -> "No participa"
                                },
                                colorDe(p.estado)
                            )
                        }
                    }
                }
                item { ResumenIngresosCard() }
                val lista = Caja.pagos.filter { it.estado == EstadoPago.APROBADO && Caja.cobros.firstOrNull { c -> c.id == it.cobroId }?.tipo != TipoCobro.RAPIDO }.sortedByDescending { it.enviado }
                if (lista.isEmpty()) item { Vacio("Todavía no hay ingresos aprobados.") }
                itemsIndexed(lista, key = { _, p -> p.serverId }) { i, p ->
                    FilaIngreso(p, Modifier.cascada(i)) { if (p.capturaPath.isNotBlank()) verComprobante = p }
                }
            } else {
                item { ResumenGastosCard() }
                val gastos = Caja.gastos.sortedByDescending { it.fecha }
                if (gastos.isEmpty()) item { Vacio("Todavía no hay gastos registrados.") }
                itemsIndexed(gastos, key = { _, g -> g.serverId }) { i, g ->
                    val estado = if (g.anulado) "ANULADO" else "REGISTRADO"
                    val color = if (g.anulado) Tenue else Rojo
                    MovimientoCard(
                        modifier = Modifier.cascada(i),
                        titulo = g.concepto,
                        detalle = "${fechaLarga(g.fecha)} · ${horaCorta(g.fecha)}",
                        monto = "− ${soles(g.monto)}",
                        color = color,
                        estado = estado,
                        accionTexto = if (g.comprobantePath.isNotBlank()) "Ver comprobante" else null,
                        alTocar = if (g.comprobantePath.isNotBlank()) ({ verComprobanteGasto = g }) else null
                    )
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
    }
    verComprobante?.let { p -> VisorPagoDialog(p) { verComprobante = null } }
    verComprobanteGasto?.let { g -> VisorGastoDialog(g) { verComprobanteGasto = null } }
}

@Composable
private fun ResumenIngresosCard() {
    val lista = Caja.pagos.filter { it.estado == EstadoPago.APROBADO && Caja.cobros.firstOrNull { c -> c.id == it.cobroId }?.tipo != TipoCobro.RAPIDO }
    Column(
        Modifier.fillMaxWidth()
            .background(Brush.linearGradient(listOf(Azul.copy(alpha = .22f), Panel)), RoundedCornerShape(22.dp))
            .border(BorderStroke(1.dp, Azul.copy(alpha = .35f)), RoundedCornerShape(22.dp))
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.TrendingUp, null, tint = Azul, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Etiqueta("TOTAL INGRESADO", Azul)
        }
        Spacer(Modifier.height(8.dp))
        DineroAnimado(Caja.ingresos(), Texto, 30.sp)
        Spacer(Modifier.height(4.dp))
        Text("${lista.size} ${if (lista.size == 1) "pago aprobado" else "pagos aprobados"}", color = Tenue, fontSize = 13.sp)
    }
}

@Composable
private fun ResumenGastosCard() {
    Tarjeta(borde = Rojo.copy(alpha = 0.24f)) {
        FilaEntre {
            Column {
                Etiqueta("TOTAL DESCONTADO", Rojo)
                Spacer(Modifier.height(3.dp))
                Text("Gastos registrados", color = Tenue, fontSize = 13.sp)
            }
            Text(soles(Caja.egresos()), color = Rojo, fontSize = 21.sp, style = cifra)
        }
        if (Caja.comprometidoPendiente() > 0) {
            Spacer(Modifier.height(10.dp))
            Pastilla("Pendiente ${soles(Caja.comprometidoPendiente())}", Ambar)
        }
    }
}

@Composable
fun PantallaArchivo() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var seccion by remember { mutableStateOf(0) } // 0 oficial, 1 rápido, 2 bitácora
    var borrarActa by remember { mutableStateOf<Acta?>(null) }
    var actaExpandida by remember { mutableStateOf<String?>(null) }
    var grupoExpandido by remember { mutableStateOf<String?>(null) }
    var verComprobante by remember { mutableStateOf<Pago?>(null) }
    var verComprobanteGasto by remember { mutableStateOf<com.tesoreria.caja.data.Gasto?>(null) }
    var pdfGuardado by remember { mutableStateOf<PdfExporter.PdfGuardado?>(null) }
    var errorPdf by remember { mutableStateOf("") }
    val puedeDetalleActas = Caja.esOwner || Caja.tienePermiso(Caja.sesion.value, com.tesoreria.caja.data.Permiso.EXPORTAR_ACTAS)

    val tipoSeleccionado = if (seccion == 1) TipoCobro.RAPIDO else TipoCobro.OFICIAL
    val actasSeleccionadas = Caja.actas.filter { it.tipo == tipoSeleccionado }.sortedByDescending { it.cierre }

    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(2.dp))
        CabeceraSeccion(
            Icons.Rounded.FolderOpen,
            when (seccion) {
                0 -> "Actas oficiales"
                1 -> "Actas rápidas"
                else -> "Bitácora"
            },
            ColorActas
        )
        Spacer(Modifier.height(10.dp))

        // Esta barra queda fija mientras se desplaza el contenido.
        Row(
            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(13.dp))
                .border(BorderStroke(1.dp, Borde), RoundedCornerShape(13.dp)).padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Pestana("Oficiales", seccion == 0, Ambar, Modifier.weight(1f)) { seccion = 0 }
            Pestana("Rápidas", seccion == 1, Ambar, Modifier.weight(1f)) { seccion = 1 }
            Pestana("Bitácora", seccion == 2, Ambar, Modifier.weight(1f)) { seccion = 2 }
        }
        Spacer(Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 12.dp)
        ) {
            if (seccion != 2) {
                item {
                    Text(
                        when {
                            seccion == 1 -> "Resúmenes de cobros rápidos. Puedes guardarlos en PDF y limpiarlos después."
                            puedeDetalleActas -> "Cobros oficiales cerrados y detalle autorizado de pagos."
                            else -> "Cobros oficiales cerrados. Los nombres permanecen privados."
                        },
                        color = Tenue,
                        fontSize = 13.sp
                    )
                }

                if (actasSeleccionadas.isEmpty()) {
                    item { Vacio(if (seccion == 1) "Aún no hay actas rápidas." else "Aún no hay actas oficiales.") }
                }

                items(actasSeleccionadas, key = { it.serverId }) { a ->
                    ActaArchivoCard(
                        acta = a,
                        expandida = actaExpandida == a.serverId,
                        grupoExpandido = grupoExpandido,
                        onGrupo = { clave -> grupoExpandido = if (grupoExpandido == clave) null else clave },
                        onExpandir = { actaExpandida = if (actaExpandida == a.serverId) null else a.serverId },
                        onVerComprobante = { verComprobante = it },
                        onGuardarPdf = {
                            runCatching { PdfExporter.guardarActa(context, a, puedeDetalleActas) }
                                .onSuccess { pdfGuardado = it; errorPdf = "" }
                                .onFailure { errorPdf = it.message ?: "No se pudo guardar el PDF" }
                        },
                        onEliminar = if (Caja.esOwner) ({ borrarActa = a }) else null
                    )
                }
            } else {
                item {
                    FilaEntre {
                        Text(if (Caja.esOwner) "Historial completo" else "Eventos importantes", color = Tenue, fontSize = 13.sp)
                        Pastilla("${if (Caja.esOwner) Caja.bitacora.size else Caja.bitacoraPublica().size} eventos", Ambar)
                    }
                    Spacer(Modifier.height(8.dp))
                    Boton("Guardar bitácora en PDF", Modifier.fillMaxWidth(), relleno = false, color = Ambar) {
                        runCatching { PdfExporter.guardarBitacora(context, Caja.esOwner) }
                            .onSuccess { pdfGuardado = it; errorPdf = "" }
                            .onFailure { errorPdf = it.message ?: "No se pudo guardar el PDF" }
                    }
                    if (errorPdf.isNotBlank()) {
                        Spacer(Modifier.height(7.dp))
                        Text(errorPdf, color = Rojo, fontSize = 13.sp)
                    }
                }

                val eventos = if (Caja.esOwner) Caja.bitacora.take(80) else Caja.bitacoraPublica().take(40)
                if (eventos.isEmpty()) {
                    item { Vacio("Todavía no hay acciones registradas.") }
                } else {
                    eventos.mapNotNull(::parseEventoBitacora).groupBy { it.fechaKey }.forEach { (_, grupo) ->
                        item(key = "bit-${grupo.first().fechaKey}") {
                            Text(grupo.first().fechaTitulo, color = Texto, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            grupo.forEach { e ->
                                EventoBitacoraLinea(e)
                                Spacer(Modifier.height(3.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    borrarActa?.let { acta ->
        Hoja(onDismissRequest = { borrarActa = null }) {
            var clave by remember(acta.serverId) { mutableStateOf("") }
            var borrando by remember(acta.serverId) { mutableStateOf(false) }
            var error by remember(acta.serverId) { mutableStateOf("") }
            Tarjeta(borde = Rojo.copy(alpha=.5f), fondo = PanelAlto) {
                Etiqueta("ELIMINAR ACTA", Rojo)
                Spacer(Modifier.height(6.dp))
                Text(acta.titulo, color = Texto, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Guarda el PDF si quieres conservar una copia. Para eliminar, confirma tu contraseña.", color = Tenue, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Boton("Guardar PDF primero", Modifier.fillMaxWidth(), relleno = false, color = Verde) {
                    runCatching { PdfExporter.guardarActa(context, acta, true) }
                        .onSuccess { pdfGuardado = it; error = "" }
                        .onFailure { error = it.message ?: "No se pudo guardar el PDF" }
                }
                Spacer(Modifier.height(9.dp))
                Campo(clave, { clave = it; error = "" }, "Tu contraseña", clave = true)
                if (error.isNotBlank()) { Spacer(Modifier.height(7.dp)); Text(error, color = Rojo, fontSize = 13.sp) }
                Spacer(Modifier.height(11.dp))
                Boton(if (borrando) "Eliminando…" else "Eliminar definitivamente", Modifier.fillMaxWidth(), color = Rojo, activo = clave.length >= 6 && !borrando) {
                    borrando = true
                    error = ""
                    scope.launch {
                        try {
                            Caja.eliminarActaConClave(acta, clave)
                            borrarActa = null
                        } catch (e: Exception) {
                            error = e.message ?: "No se pudo eliminar"
                            borrando = false
                        }
                    }
                }
                Spacer(Modifier.height(7.dp))
                Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue, activo = !borrando) { borrarActa = null }
            }
        }
    }

    pdfGuardado?.let { pdf ->
        Hoja(onDismissRequest = { pdfGuardado = null }) {
            Tarjeta(borde = Verde.copy(alpha = .5f), fondo = PanelAlto) {
                Etiqueta("PDF GUARDADO", Verde)
                Spacer(Modifier.height(7.dp))
                Text(pdf.nombre, color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(5.dp))
                Text("Guardado en Descargas/Tesoreria.", color = Tenue, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Boton("Abrir", Modifier.weight(1f), color = Verde) { PdfExporter.abrir(context, pdf) }
                    Boton("Cerrar", Modifier.weight(1f), relleno = false, color = Tenue) { pdfGuardado = null }
                }
            }
        }
    }

    verComprobante?.let { p -> VisorPagoDialog(p) { verComprobante = null } }
}

@Composable
private fun ActaArchivoCard(
    acta: Acta,
    expandida: Boolean,
    grupoExpandido: String?,
    onGrupo: (String) -> Unit,
    onExpandir: () -> Unit,
    onVerComprobante: (Pago) -> Unit,
    onGuardarPdf: () -> Unit,
    onEliminar: (() -> Unit)?
) {
    val aprobados = acta.estados.filterValues { it == EstadoPago.APROBADO }.keys.sorted()
    val pendientes = acta.estados.filterValues { it == EstadoPago.PENDIENTE }.keys.sorted()
    val rechazados = acta.estados.filterValues { it == EstadoPago.RECHAZADO }.keys.sorted()
    val noEnviaron = acta.estados.filterValues { it == EstadoPago.SIN_ENVIAR }.keys.sorted()
    val noPagan = acta.estados.filterValues { it == EstadoPago.NO_PAGA }.keys.sorted()
    val cobroOriginal = Caja.cobros.firstOrNull { it.id == acta.cobroId }
    val color = if (acta.tipo == TipoCobro.RAPIDO) Naranja else Ambar

    Tarjeta(borde = color.copy(alpha = .34f)) {
        FilaEntre {
            Column(Modifier.weight(1f)) {
                Etiqueta(if (acta.tipo == TipoCobro.RAPIDO) "ACTA RÁPIDA" else "ACTA OFICIAL", color)
                Spacer(Modifier.height(3.dp))
                Text(acta.titulo, color = Texto, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(soles(acta.recaudado), color = Verde, fontSize = 16.sp, style = cifra)
        }
        Spacer(Modifier.height(8.dp))
        Text(fechaLarga(acta.cierre), color = Texto, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(3.dp))
        if (cobroOriginal != null) {
            Text("Abierto ${horaCorta(cobroOriginal.creado)} · Cerrado ${horaCorta(acta.cierre)} · Duró ${duracionArchivo(acta.cierre - cobroOriginal.creado)}", color = Tenue, fontSize = 12.sp)
        } else {
            Text("Cerrado ${horaCorta(acta.cierre)} · Cuota ${soles(acta.monto)}", color = Tenue, fontSize = 12.sp)
        }
        Spacer(Modifier.height(10.dp))

        GrupoNumerosActa("Pagaron", aprobados, Verde, grupoExpandido == "${acta.serverId}:pagaron") { onGrupo("${acta.serverId}:pagaron") }
        GrupoNumerosActa("Pendientes", pendientes, Ambar, grupoExpandido == "${acta.serverId}:pendientes") { onGrupo("${acta.serverId}:pendientes") }
        GrupoNumerosActa("Rechazados", rechazados, Rojo, grupoExpandido == "${acta.serverId}:rechazados") { onGrupo("${acta.serverId}:rechazados") }
        GrupoNumerosActa("No enviaron", noEnviaron, Tenue, grupoExpandido == "${acta.serverId}:no") { onGrupo("${acta.serverId}:no") }
        GrupoNumerosActa("No participan", noPagan, Cian, grupoExpandido == "${acta.serverId}:nopaga") { onGrupo("${acta.serverId}:nopaga") }
        if (grupoExpandido == "${acta.serverId}:nopaga" && noPagan.isNotEmpty()) {
            Spacer(Modifier.height(5.dp))
            noPagan.forEach { n ->
                val motivo = acta.detalles[n]?.motivoNoPago.orEmpty()
                if (motivo.isNotBlank()) {
                    Text("N° $n · Motivo: $motivo", color = Cian, fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp, bottom = 3.dp))
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Boton("Guardar acta en PDF", Modifier.fillMaxWidth(), relleno = false, color = Verde) { onGuardarPdf() }

        if (onEliminar != null) {
            Spacer(Modifier.height(7.dp))
            Boton("Eliminar acta", Modifier.fillMaxWidth(), relleno = false, color = Rojo) { onEliminar() }
        }

        if (Caja.esOwner || Caja.tienePermiso(Caja.sesion.value, com.tesoreria.caja.data.Permiso.EXPORTAR_ACTAS)) {
            Spacer(Modifier.height(7.dp))
            Boton(if (expandida) "Ocultar detalle" else "Ver detalle del acta", Modifier.fillMaxWidth(), relleno = false, color = Ambar) { onExpandir() }
            if (expandida) {
                Spacer(Modifier.height(9.dp))
                acta.detalles.values.sortedBy { it.socioNumero }.forEach { d ->
                    val pago = Caja.pagos.filter { it.cobroId == acta.cobroId && it.socio == d.socioNumero }.maxByOrNull { it.enviado }
                    val nombre = d.nombreSnapshot.ifBlank { Caja.socio(d.socioNumero)?.nombre ?: "Socio" }
                    val estadoTexto = when (d.estado) {
                        EstadoPago.APROBADO -> "APROBADO"
                        EstadoPago.PENDIENTE -> "PENDIENTE"
                        EstadoPago.RECHAZADO -> "RECHAZADO"
                        EstadoPago.SIN_ENVIAR -> "NO ENVIÓ"
                        EstadoPago.NO_PAGA -> "NO PARTICIPA"
                    }
                    val info = buildList {
                        d.monto?.let { add(soles(it)) }
                        d.medio?.let { add(if (it == MedioPago.MANUAL) "Manual" else "Yape") }
                        pago?.let { add("${fechaLarga(it.enviado)} ${horaCorta(it.enviado)}") }
                    }.joinToString(" · ")
                    Row(
                        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(11.dp))
                            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(11.dp))
                            .clickable(enabled = pago?.capturaPath?.isNotBlank() == true) { if (pago != null) onVerComprobante(pago) }
                            .padding(11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("N° ${d.socioNumero} · $nombre", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            if (info.isNotBlank()) { Spacer(Modifier.height(3.dp)); Text(info, color = Tenue, fontSize = 11.sp) }
                            if (d.estado == EstadoPago.NO_PAGA && d.motivoNoPago.isNotBlank()) { Spacer(Modifier.height(3.dp)); Text("Motivo: ${d.motivoNoPago}", color = Cian, fontSize = 11.sp) }
                            if (pago?.capturaPath?.isNotBlank() == true) { Spacer(Modifier.height(3.dp)); Text("Toca para ver el comprobante completo", color = Cian, fontSize = 11.sp) }
                        }
                        Spacer(Modifier.width(8.dp))
                        Pastilla(estadoTexto, colorDe(d.estado))
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
    }
}

private data class EventoBitacoraUi(val fechaKey: String, val fechaTitulo: String, val hora: String, val texto: String)

private fun parseEventoBitacora(raw: String): EventoBitacoraUi? {
    val m = Regex("^(\\d{2}/\\d{2}/\\d{4}) (\\d{2}:\\d{2})\\s+·\\s+(.*)$").find(raw) ?: return null
    val fecha = m.groupValues[1]
    val hora = m.groupValues[2]
    val resto = m.groupValues[3].replace(Regex("\\s+·\\s+"), " · ")
    val millis = runCatching { java.text.SimpleDateFormat("dd/MM/yyyy", PE).parse(fecha)?.time }.getOrNull() ?: return null
    return EventoBitacoraUi(fecha, fechaLarga(millis), hora, resto)
}

@Composable
private fun EventoBitacoraLinea(e: EventoBitacoraUi) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
        Text(e.hora, color = Ambar, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(42.dp))
        Spacer(Modifier.width(8.dp))
        Text(e.texto, color = Texto, fontSize = 13.sp, lineHeight = 16.sp, modifier = Modifier.weight(1f))
    }
}

private fun duracionArchivo(ms: Long): String {
    val min = (ms / 60000L).coerceAtLeast(0L)
    val dias = min / 1440
    val horas = (min % 1440) / 60
    val minutos = min % 60
    return buildList {
        if (dias > 0) add("$dias d")
        if (horas > 0) add("$horas h")
        if (minutos > 0 || isEmpty()) add("$minutos min")
    }.joinToString(" ")
}

@Composable
private fun GrupoNumerosActa(titulo: String, numeros: List<Int>, color: Color, expandido: Boolean, alTocar: () -> Unit) {
    Spacer(Modifier.height(7.dp))
    Row(
        Modifier.fillMaxWidth()
            .background(color.copy(alpha = .07f), RoundedCornerShape(11.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = .20f)), RoundedCornerShape(11.dp))
            .clickable { alTocar() }
            .padding(horizontal = 11.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$titulo (${numeros.size})", color = color, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(if (expandido) "Ocultar" else "Ver", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
    if (expandido) {
        Spacer(Modifier.height(5.dp))
        Box(
            Modifier.fillMaxWidth().background(FondoProfundo, RoundedCornerShape(10.dp)).border(BorderStroke(1.dp, Borde), RoundedCornerShape(10.dp)).padding(10.dp)
        ) {
            Text(if (numeros.isEmpty()) "Ninguno" else numeros.joinToString(", ") { "N° $it" }, color = Texto, fontSize = 13.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
fun Pestana(
    texto: String,
    activa: Boolean,
    color: Color,
    modifier: Modifier = Modifier,
    alTocar: () -> Unit
) {
    Box(
        modifier
            .height(44.dp)
            .background(
                if (activa) color.copy(alpha = 0.18f) else Color.Transparent,
                RoundedCornerShape(10.dp)
            )
            .clickable { alTocar() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            texto,
            color = if (activa) color else Tenue,
            fontSize = 13.5.sp,
            fontWeight = if (activa) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
private fun MovimientoCard(
    modifier: Modifier = Modifier,
    titulo: String,
    detalle: String,
    monto: String,
    color: Color,
    estado: String,
    acentoCargo: Color? = null,
    accionTexto: String? = null,
    alTocar: (() -> Unit)? = null
) {
    val base = modifier
        .fillMaxWidth()
        .background(Panel, RoundedCornerShape(16.dp))
        .border(BorderStroke(1.dp, acentoCargo?.copy(alpha = .42f) ?: Borde), RoundedCornerShape(16.dp))
    Row(
        (if (alTocar != null) base.presionable { alTocar() } else base)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(titulo, color = acentoCargo ?: Texto, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Text(detalle, color = Tenue, fontSize = 13.sp)
            Spacer(Modifier.height(7.dp))
            Pastilla(estado, color)
            if (!accionTexto.isNullOrBlank()) {
                Spacer(Modifier.height(7.dp))
                Text(accionTexto, color = Cian, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Text(monto, color = color, fontSize = 14.sp, style = cifra)
    }
}

@Composable
private fun EventoBitacoraCard(evento: String) {
    val visual = visualEvento(evento)
    Row(
        Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(10.dp))
            .border(BorderStroke(1.dp, visual.color.copy(alpha = 0.20f)), RoundedCornerShape(10.dp))
            .padding(horizontal = 11.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(visual.icono, color = visual.color, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Column(Modifier.weight(1f)) {
            Text(visual.titulo, color = visual.color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(2.dp))
            Text(evento, color = Texto, fontSize = 12.5.sp, lineHeight = 15.sp)
        }
    }
}

private data class EventoVisual(val titulo: String, val color: Color, val icono: String)

private fun visualEvento(evento: String): EventoVisual {
    val e = evento.lowercase()
    return when {
        "rechazó" in e || "anul" in e -> EventoVisual("Evento crítico", Rojo, "!")
        "corrig" in e || "ajustó" in e || "extend" in e || "liber" in e -> EventoVisual("Cambio importante", Ambar, "↺")
        "aprobó" in e || "pagó" in e || "envió comprobante" in e -> EventoVisual("Movimiento confirmado", Verde, "✓")
        "abrió el cobro" in e || "cerró el cobro" in e -> EventoVisual("Gestión de cobro", Cian, "▣")
        "sistema" in e -> EventoVisual("Sistema", Tenue, "•")
        else -> EventoVisual("Actividad", Cian, "•")
    }
}

@Composable
fun Vacio(texto: String) {
    Column(
        Modifier.fillMaxWidth().cascada(0).background(Suave, RoundedCornerShape(20.dp)).padding(vertical = 26.dp, horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(54.dp).background(Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Inbox, null, tint = Tenue, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(texto, color = Tenue, fontSize = 14.sp)
    }
}


/** Fila de ingreso: miniatura de la captura, nombre, fecha y monto. */
@Composable
private fun FilaIngreso(p: Pago, modifier: Modifier = Modifier, alTocar: () -> Unit) {
    val socio = Caja.socio(p.socio)
    val yape = p.medio == MedioPago.YAPE
    val colorMedio = if (yape) MoradoYape else Verde
    Row(
        modifier.fillMaxWidth()
            .background(Panel, RoundedCornerShape(16.dp))
            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(16.dp))
            .presionable(enabled = p.capturaPath.isNotBlank()) { alTocar() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (p.capturaPath.isNotBlank()) {
            MiniaturaPago(p.capturaPath, Modifier.size(width = 46.dp, height = 54.dp), radio = 11.dp)
        } else {
            Box(
                Modifier.size(width = 46.dp, height = 54.dp).background(colorMedio.copy(alpha = .12f), RoundedCornerShape(11.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(if (yape) Icons.Rounded.QrCode2 else Icons.Rounded.Payments, null, tint = colorMedio, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(socio?.nombre ?: "N.º ${p.socio}", color = Texto, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Spacer(Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("N.º ${p.socio}", color = Tenue, fontSize = 12.5.sp)
                Text("  ·  ", color = Tenue, fontSize = 12.5.sp)
                Text("${fechaCorta(p.enviado)} ${horaCorta(p.enviado)}", color = Tenue, fontSize = 12.5.sp)
            }
            Spacer(Modifier.height(5.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(colorMedio, RoundedCornerShape(99.dp)))
                Spacer(Modifier.width(5.dp))
                Text(if (yape) "Yape" else "Manual", color = colorMedio, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                if (p.capturaPath.isNotBlank()) {
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Rounded.Photo, null, tint = Tenue, modifier = Modifier.size(14.dp))
                }
            }
        }
        Text("+ ${soles(p.monto)}", color = Verde, fontSize = 16.sp, style = cifra)
    }
}

private fun fechaCorta(ms: Long): String =
    java.text.SimpleDateFormat("dd/MM", java.util.Locale("es", "PE")).format(java.util.Date(ms))
