package com.tesoreria.caja.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.tesoreria.caja.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Actualizaciones directas desde el último GitHub Release del mismo repositorio
 * que compila la APK. Android sigue siendo quien valida/autoriza la instalación.
 */
object UpdateManager {
    data class UpdateInfo(
        val versionCode: Int,
        val versionName: String,
        val downloadUrl: String,
        val notas: String,
        val obligatoria: Boolean
    )

    private const val USER_AGENT = "Tesoreria-Android-Updater"

    suspend fun buscarActualizacion(): UpdateInfo? = withContext(Dispatchers.IO) {
        val repo = BuildConfig.GITHUB_REPOSITORY.trim()
        if (repo.isBlank() || !repo.contains('/')) return@withContext null

        val conn = (URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 10_000
            instanceFollowRedirects = true
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        }

        try {
            if (conn.responseCode !in 200..299) return@withContext null
            val root = JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            if (root.optBoolean("draft", false) || root.optBoolean("prerelease", false)) return@withContext null

            val tag = root.optString("tag_name")
            val remoteCode = Regex("-vc(\\d+)$").find(tag)?.groupValues?.getOrNull(1)?.toIntOrNull()
                ?: return@withContext null
            if (remoteCode <= BuildConfig.VERSION_CODE) return@withContext null

            val assets = root.optJSONArray("assets") ?: return@withContext null
            var apkUrl = ""
            for (i in 0 until assets.length()) {
                val asset = assets.optJSONObject(i) ?: continue
                val name = asset.optString("name")
                if (name.endsWith(".apk", ignoreCase = true)) {
                    apkUrl = asset.optString("browser_download_url")
                    if (apkUrl.isNotBlank()) break
                }
            }
            if (apkUrl.isBlank()) return@withContext null

            val nombre = root.optString("name")
            val versionName = Regex("Tesorería\\s+([^\\s]+)", RegexOption.IGNORE_CASE)
                .find(nombre)?.groupValues?.getOrNull(1)
                ?: tag.substringAfter("tesoreria-v", remoteCode.toString()).substringBefore("-vc")
            val body = root.optString("body").trim()
            val config = runCatching { SupabaseApi.configuracionActualizacion() }.getOrNull()
            val minima = config?.optInt("min_version_code", 0) ?: 0
            val mensajeServidor = config?.optString("mensaje").orEmpty().trim()
            val obligatoria = BuildConfig.VERSION_CODE < minima || body.contains("[OBLIGATORIA]", ignoreCase = true)

            UpdateInfo(
                versionCode = remoteCode,
                versionName = versionName.ifBlank { remoteCode.toString() },
                downloadUrl = apkUrl,
                notas = (mensajeServidor.ifBlank { body }).take(800),
                obligatoria = obligatoria
            )
        } finally {
            conn.disconnect()
        }
    }

    fun puedeInstalarPaquetes(context: Context): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.O || context.packageManager.canRequestPackageInstalls()
    }

    fun abrirPermisoInstalacion(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val intent = Intent(
            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    suspend fun descargar(
        context: Context,
        info: UpdateInfo,
        progreso: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "updates").apply { mkdirs() }
        val destino = File(dir, "tesoreria-${info.versionCode}.apk")
        if (destino.exists()) destino.delete()

        val conn = (URL(info.downloadUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 30_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/octet-stream")
        }

        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("No se pudo descargar la actualización ($code)")
            val total = conn.contentLengthLong
            var leidos = 0L

            conn.inputStream.use { input ->
                FileOutputStream(destino).use { output ->
                    val buffer = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        leidos += n
                        if (total > 0L) progreso((leidos.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f))
                    }
                    output.flush()
                }
            }
        } finally {
            conn.disconnect()
        }

        if (!destino.exists() || destino.length() < 50_000L) {
            destino.delete()
            throw IllegalStateException("La descarga quedó incompleta")
        }

        verificarApk(context, destino, info.versionCode)
        progreso(1f)
        destino
    }

    fun instalar(context: Context, apk: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            apk
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    @Suppress("DEPRECATION")
    private fun verificarApk(context: Context, apk: File, esperado: Int) {
        val pm = context.packageManager
        val archive = pm.getPackageArchiveInfo(apk.absolutePath, 0)
            ?: throw IllegalStateException("El archivo descargado no es una APK válida")

        if (archive.packageName != context.packageName) {
            throw IllegalStateException("La actualización pertenece a otra aplicación")
        }
        if (versionCode(archive) < esperado.toLong()) {
            throw IllegalStateException("La APK descargada no corresponde a la versión anunciada")
        }

        // Android comprueba de nuevo la firma criptográfica al intentar instalar
        // una actualización encima de esta app. Si la firma no coincide, el
        // instalador del sistema la rechaza automáticamente.
    }

    @Suppress("DEPRECATION")
    private fun versionCode(info: PackageInfo): Long {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode else info.versionCode.toLong()
    }
}
