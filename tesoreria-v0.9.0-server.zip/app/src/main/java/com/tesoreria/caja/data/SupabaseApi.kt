package com.tesoreria.caja.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object SupabaseApi {
    const val BASE_URL = "https://kgglijozytmbauehmvpq.supabase.co"
    const val PUBLISHABLE_KEY = "sb_publishable_XZKYZY-aPKnXAz3g3aTR1A_s0Aik4k4"

    private var appContext: Context? = null
    @Volatile var accessToken: String? = null
        private set
    @Volatile private var refreshToken: String? = null

    fun initialize(context: Context) {
        appContext = context.applicationContext
        val p = prefs()
        refreshToken = p?.getString("refresh_token", null)
    }

    private fun prefs() = appContext?.getSharedPreferences("tesoreria_auth", Context.MODE_PRIVATE)

    private fun saveTokens(access: String?, refresh: String?) {
        accessToken = access
        refreshToken = refresh
        prefs()?.edit()?.apply {
            if (refresh == null) remove("refresh_token") else putString("refresh_token", refresh)
        }?.apply()
    }

    data class HttpResponse(val code: Int, val body: String) {
        val ok: Boolean get() = code in 200..299
    }

    private suspend fun request(
        method: String,
        url: String,
        body: String? = null,
        auth: Boolean = false,
        contentType: String = "application/json; charset=utf-8",
        extraHeaders: Map<String, String> = emptyMap(),
        bytes: ByteArray? = null
    ): HttpResponse = withContext(Dispatchers.IO) {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("apikey", PUBLISHABLE_KEY)
            setRequestProperty("Accept", "application/json")
            if (auth) accessToken?.let { setRequestProperty("Authorization", "Bearer $it") }
            extraHeaders.forEach { (k, v) -> setRequestProperty(k, v) }
            if (body != null || bytes != null) {
                doOutput = true
                setRequestProperty("Content-Type", contentType)
            }
        }
        if (bytes != null) {
            conn.outputStream.use { it.write(bytes) }
        } else if (body != null) {
            conn.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.let { s -> BufferedReader(InputStreamReader(s, Charsets.UTF_8)).use { it.readText() } }.orEmpty()
        conn.disconnect()
        HttpResponse(code, text)
    }

    suspend fun estadoCuenta(numero: Int): JSONObject {
        val r = request("POST", "$BASE_URL/functions/v1/estado-cuenta", JSONObject().put("numero", numero).toString())
        val j = if (r.body.isBlank()) JSONObject() else JSONObject(r.body)
        if (!r.ok) throw IllegalStateException(j.optString("error", "No se pudo consultar la cuenta"))
        return j
    }

    suspend fun activarCuenta(numero: Int, codigo: String, password: String) {
        val body = JSONObject().put("numero", numero).put("codigo", codigo).put("password", password)
        val r = request("POST", "$BASE_URL/functions/v1/activar-cuenta", body.toString())
        val j = if (r.body.isBlank()) JSONObject() else JSONObject(r.body)
        if (!r.ok || !j.optBoolean("ok", false)) throw IllegalStateException(j.optString("error", "No se pudo activar la cuenta"))
    }

    suspend fun iniciarSesion(numero: Int, password: String) {
        val email = "lista${numero}@tesoreria.app"
        val body = JSONObject().put("email", email).put("password", password)
        val r = request("POST", "$BASE_URL/auth/v1/token?grant_type=password", body.toString())
        val j = if (r.body.isBlank()) JSONObject() else JSONObject(r.body)
        if (!r.ok) throw IllegalStateException(j.optString("msg", j.optString("error_description", "Contraseña incorrecta")))
        val access = j.optString("access_token")
        val refresh = j.optString("refresh_token")
        if (access.isBlank() || refresh.isBlank()) throw IllegalStateException("No se recibió una sesión válida")
        saveTokens(access, refresh)
    }

    suspend fun restaurarSesion(): Boolean {
        val rt = refreshToken ?: return false
        val body = JSONObject().put("refresh_token", rt)
        val r = request("POST", "$BASE_URL/auth/v1/token?grant_type=refresh_token", body.toString())
        if (!r.ok) {
            saveTokens(null, null)
            return false
        }
        val j = JSONObject(r.body)
        val access = j.optString("access_token")
        val refresh = j.optString("refresh_token", rt)
        if (access.isBlank()) return false
        saveTokens(access, refresh)
        return true
    }

    suspend fun cerrarSesion() {
        try { request("POST", "$BASE_URL/auth/v1/logout", "{}", auth = true) } catch (_: Exception) {}
        saveTokens(null, null)
    }

    suspend fun getArray(resourceAndQuery: String): JSONArray {
        val r = request("GET", "$BASE_URL/rest/v1/$resourceAndQuery", auth = true)
        if (!r.ok) throw IllegalStateException(errorText(r.body, "Error consultando datos"))
        return if (r.body.isBlank()) JSONArray() else JSONArray(r.body)
    }

    suspend fun rpc(name: String, params: JSONObject = JSONObject()): String {
        val r = request("POST", "$BASE_URL/rest/v1/rpc/$name", params.toString(), auth = true)
        if (!r.ok) throw IllegalStateException(errorText(r.body, "No se pudo completar la operación"))
        return r.body
    }

    suspend fun generarCodigo(numero: Int): JSONObject {
        val r = request(
            "POST", "$BASE_URL/functions/v1/generar-codigo",
            JSONObject().put("numero", numero).toString(), auth = true
        )
        val j = if (r.body.isBlank()) JSONObject() else JSONObject(r.body)
        if (!r.ok || !j.optBoolean("ok", false)) throw IllegalStateException(j.optString("error", "No se pudo generar el código"))
        return j
    }

    suspend fun uploadComprobante(path: String, data: ByteArray, mime: String) {
        val encodedPath = path.split('/').joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
        val r = request(
            "POST",
            "$BASE_URL/storage/v1/object/comprobantes-yape/$encodedPath",
            auth = true,
            contentType = mime,
            extraHeaders = mapOf("x-upsert" to "false"),
            bytes = data
        )
        if (!r.ok) throw IllegalStateException(errorText(r.body, "No se pudo subir el comprobante"))
    }

    private fun errorText(raw: String, fallback: String): String = try {
        val j = JSONObject(raw)
        j.optString("message", j.optString("error", j.optString("hint", fallback))).ifBlank { fallback }
    } catch (_: Exception) { fallback }
}
