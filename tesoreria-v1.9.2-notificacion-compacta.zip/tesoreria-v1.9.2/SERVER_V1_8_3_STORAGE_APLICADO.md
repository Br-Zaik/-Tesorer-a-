# Servidor v1.8.3 aplicado

Se añadió una política DELETE limitada al bucket `comprobantes-yape` que permite a cada usuario borrar solamente archivos de su propia carpeta y únicamente cuando la ruta no está asociada a `pagos_privados`.

Esto permite limpiar capturas huérfanas sin dar permiso para borrar comprobantes válidos.
