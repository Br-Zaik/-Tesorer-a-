# Tesorería v1.8.0 · Owner, permisos y cobros múltiples

Versión Android: **1.8.0**  
versionCode: **34**  
applicationId: **com.tesoreria.caja**

## Acceso
- Inicio de sesión separado en **Entrar**, **Crear cuenta** y **Cambiar contraseña**.
- El aviso de cierre por inactividad solo aparece cuando realmente ocurrió ese cierre.
- La creación de cuenta usa código de activación; el cambio de contraseña usa código temporal.

## Cobros
- Hasta **3 cobros oficiales activos** y **2 cobros rápidos activos**.
- Cierre configurable por minutos, horas, días o **fecha y hora exactas**.
- Ajuste posterior del plazo por minutos/días o fecha exacta.
- Límite máximo de cierre: 365 días.

## Participación
- Un usuario participante puede indicar **No quiero pagar este cobro** y registrar un motivo.
- El estado queda diferenciado de “No envió”.
- El motivo se conserva en el acta cerrada y aparece en el PDF para dejar constancia transparente de la decisión.
- Un usuario en modo **solo visualización** no cuenta en el total de personas que deben pagar ni aparece como pendiente.
- Owner o un administrador con permiso de gestión de miembros puede activar/desactivar la participación en cobros.

## Acceso y cargos
Se separan dos conceptos:
- **Nivel real:** Owner / Administrador / Usuario.
- **Cargo visible:** texto libre (Presidente, Vocal, Delegado, Visitante, etc.) con color personalizado.

Solo el Owner puede:
- conceder o retirar nivel Administrador;
- asignar permisos administrativos;
- ver presencia/última actividad;
- liberar plazas;
- generar/limpiar códigos masivos;
- eliminar actas;
- corregir asignaciones de pago;
- limpiar datos del servidor.

Un administrador nunca puede convertir a otra persona en administrador ni ver su última actividad.

## Permisos delegables
- Registrar pagos manuales.
- Gestionar cobros.
- Registrar gastos.
- Ver comprobantes Yape.
- Aprobar/rechazar Yape (separado de solo ver).
- Cambiar el número Yape del grupo.
- Gestionar datos básicos de miembros.
- Ver detalle privado/exportar actas.

## Pagos
- **Yape:** marca `Y` en morado.
- **Manual:** marca `M` en verde.
- Se conserva pago Yape individual y en conjunto.
- Los pagos en conjunto siguen registrando un pago individual por cada miembro incluido.

## Códigos masivos
- 6 dígitos, 6 horas, un solo uso, máximo 30 disponibles.
- Historial con disponible/usado/vencido/cancelado.
- El Owner puede limpiar códigos usados, vencidos o cancelados.
- La generación queda en bitácora administrativa, no como acta financiera.

## Limpieza del servidor
Nueva herramienta exclusiva del Owner:
- limpieza completa o por rango de fechas;
- vista previa de cantidades a borrar;
- exige contraseña del Owner y escribir `LIMPIAR`;
- elimina movimientos operativos y comprobantes almacenados en la nube;
- conserva miembros, cuentas Auth, roles/permisos, configuración y estructura del backend.

## Compatibilidad
- Se mantiene package/applicationId/namespace y la firma configurada por GitHub Actions.
- Se mantienen el bucket privado de comprobantes, actualizador, flujo de Yape, PDF, actas y bitácora existentes.
