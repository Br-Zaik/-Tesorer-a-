# Tesorería v1.8.2

- El Owner ahora puede cambiar su propio color desde **Panel → Owner → Mi identidad**.
- El selector conserva los colores existentes: Verde, Cian, Morado, Rojo y Dorado.
- El cambio se guarda en el servidor real y se refleja en la app tras guardar.
- No modifica permisos, nivel Owner, nombre, cargo ni participación.
- No cambia el color morado reservado para los pagos Yape.
