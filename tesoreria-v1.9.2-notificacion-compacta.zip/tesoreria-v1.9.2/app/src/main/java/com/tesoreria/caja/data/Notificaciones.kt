package com.tesoreria.caja.data

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.tesoreria.caja.MainActivity
import com.tesoreria.caja.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Notificaciones locales sincronizadas con Supabase.
 *
 * - Detecta cobros nuevos.
 * - Avisa si el comprobante propio cambia a aprobado o rechazado.
 * - Recuerda una sola vez cuando faltan ~30 min para cerrar y aún falta resolver el pago.
 * - WorkManager mantiene la comprobación en segundo plano sin dejar servicios permanentes.
 */
object Notificaciones {
    private const val CHANNEL_ID = "tesoreria_cobros_pagos"
    private const val CHANNEL_NAME = "Cobros y pagos"
    private const val PREFS = "tesoreria_notificaciones_v1"
    private const val KEY_BASELINE = "baseline_creada"
    private const val KEY_SEEN_COBROS = "cobros_vistos"
    private const val KEY_PERMISSION_ASKED = "permiso_solicitado"
    private const val KEY_ENABLED = "habilitadas"
    private const val WORK_NAME = "tesoreria_notificaciones_periodicas"

    /**
     * Al arrancar solo prepara el canal. El trabajo periódico se programa cuando
     * ya sabemos qué usuario inició sesión y cuál es SU preferencia.
     */
    fun inicializar(context: Context) {
        crearCanal(context.applicationContext)
        WorkManager.getInstance(context.applicationContext).cancelUniqueWork(WORK_NAME)
    }

    fun habilitadas(context: Context, numero: Int): Boolean {
        if (numero !in 1..35) return false
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean("u${numero}_$KEY_ENABLED", false)
    }

    fun permisoSistemaConcedido(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < 33) return true
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Aplica la preferencia del usuario actual. Si no hay sesión, cancela el
     * trabajo para no hacer comprobaciones innecesarias en segundo plano.
     */
    fun configurarUsuario(context: Context, numero: Int?) {
        val app = context.applicationContext
        if (numero != null && numero in 1..35 && habilitadas(app, numero)) {
            programarTrabajo(app)
        } else {
            WorkManager.getInstance(app).cancelUniqueWork(WORK_NAME)
        }
    }

    /**
     * Preferencia individual por número de lista y por dispositivo. Al volver a
     * activar se crea una línea base silenciosa para no lanzar avisos atrasados.
     */
    fun cambiarHabilitadas(context: Context, numero: Int, activas: Boolean) {
        if (numero !in 1..35) return
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val prefijo = "u${numero}_"
        val editor = prefs.edit().putBoolean(prefijo + KEY_ENABLED, activas)
        if (activas) editor.putBoolean(prefijo + KEY_BASELINE, false)
        editor.apply()

        if (activas) {
            crearCanal(app)
            programarTrabajo(app)
        } else {
            WorkManager.getInstance(app).cancelUniqueWork(WORK_NAME)
            runCatching { NotificationManagerCompat.from(app).cancelAll() }
        }
    }

    private fun programarTrabajo(context: Context) {
        val restricciones = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val trabajo = PeriodicWorkRequestBuilder<NotificationSyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(restricciones)
            .build()
        WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
            WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            trabajo
        )
    }

    fun debeSolicitarPermiso(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < 33) return false
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return false
        return !context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_PERMISSION_ASKED, false)
    }

    fun marcarPermisoSolicitado(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_PERMISSION_ASKED, true).apply()
    }

    suspend fun procesarSnapshot(context: Context, snapshot: JSONObject) = withContext(Dispatchers.IO) {
        val miNumero = if (snapshot.has("mi_numero") && !snapshot.isNull("mi_numero")) snapshot.optInt("mi_numero", 0) else 0
        if (miNumero !in 1..35) return@withContext
        if (!habilitadas(context, miNumero)) return@withContext

        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val prefijo = "u${miNumero}_"
        val baseline = prefs.getBoolean(prefijo + KEY_BASELINE, false)
        val editor = prefs.edit()
        val ahora = System.currentTimeMillis()

        val miembros = snapshot.optJSONArray("miembros")
        var participa = true
        var cuentaActiva = true
        if (miembros != null) {
            for (i in 0 until miembros.length()) {
                val m = miembros.optJSONObject(i) ?: continue
                if (m.optInt("numero") == miNumero) {
                    participa = m.optBoolean("participa_cobros", true)
                    cuentaActiva = m.optString("estado", "activo") == "activo"
                    break
                }
            }
        }
        if (!cuentaActiva) return@withContext

        val pagos = snapshot.optJSONArray("pagos")
        val ultimoPagoPorCobro = mutableMapOf<String, Pair<String, String>>() // cobro -> enviado_at, estado
        if (pagos != null) {
            for (i in 0 until pagos.length()) {
                val p = pagos.optJSONObject(i) ?: continue
                if (p.optInt("socio_numero") != miNumero) continue
                val cobroId = p.optString("cobro_id")
                if (cobroId.isBlank()) continue
                val enviado = p.optString("enviado_at")
                val estado = p.optString("estado", "sin_enviar")
                val previo = ultimoPagoPorCobro[cobroId]
                if (previo == null || enviado >= previo.first) ultimoPagoPorCobro[cobroId] = enviado to estado
            }
        }

        val noPaga = mutableSetOf<String>()
        snapshot.optJSONArray("decisiones")?.let { arr ->
            for (i in 0 until arr.length()) {
                val d = arr.optJSONObject(i) ?: continue
                if (d.optInt("socio_numero") == miNumero) d.optString("cobro_id").takeIf { it.isNotBlank() }?.let(noPaga::add)
            }
        }

        val vistos = prefs.getStringSet(prefijo + KEY_SEEN_COBROS, emptySet()).orEmpty().toMutableSet()
        val cobros = snapshot.optJSONArray("cobros")
        if (cobros != null) {
            for (i in 0 until cobros.length()) {
                val c = cobros.optJSONObject(i) ?: continue
                val id = c.optString("id")
                if (id.isBlank()) continue
                val cerrado = !c.isNull("cerrado_at")
                val cierra = isoMillis(c.optString("cierra_at")) ?: continue
                if (cerrado || cierra <= ahora) continue

                val titulo = c.optString("titulo", "Cobro")
                val monto = c.optLong("monto_centavos", 0L)
                if (baseline && participa && id !in vistos) {
                    notificar(
                        context,
                        miNumero,
                        "Nuevo cobro",
                        "$titulo · ${soles(monto)}",
                        "nuevo:$id"
                    )
                }
                vistos += id

                val estadoActual = ultimoPagoPorCobro[id]?.second ?: if (id in noPaga) "no_paga" else "sin_enviar"
                val estadoKey = prefijo + "estado_pago_$id"
                val estadoAnterior = prefs.getString(estadoKey, null)
                if (baseline && estadoAnterior != null && estadoAnterior != estadoActual) {
                    when (estadoActual) {
                        "aprobado" -> notificar(context, miNumero, "Pago aprobado", "$titulo · Tu pago fue confirmado.", "aprobado:$id")
                        "rechazado" -> notificar(context, miNumero, "Comprobante rechazado", "$titulo · Abre Tesorería para revisar el motivo y volver a enviarlo.", "rechazado:$id")
                    }
                }
                editor.putString(estadoKey, estadoActual)

                val restante = cierra - ahora
                val reminderKey = prefijo + "recordatorio_30_$id"
                val resuelto = estadoActual == "aprobado" || estadoActual == "pendiente" || estadoActual == "no_paga"
                if (baseline && participa && !resuelto && restante in 1..(35L * 60L * 1000L) && !prefs.getBoolean(reminderKey, false)) {
                    notificar(context, miNumero, "Cobro por vencer", "$titulo · Faltan menos de 35 min para pagar ${soles(monto)}.", "vence:$id")
                    editor.putBoolean(reminderKey, true)
                }
            }
        }

        // Conservar IDs vistos para que un refresco no vuelva a anunciar cobros antiguos.
        editor.putStringSet(prefijo + KEY_SEEN_COBROS, vistos)
        if (!baseline) editor.putBoolean(prefijo + KEY_BASELINE, true)
        editor.apply()
    }

    private fun crearCanal(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val canal = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Avisos de cobros, vencimientos y estado de comprobantes"
            enableVibration(true)
        }
        manager.createNotificationChannel(canal)
    }

    private fun notificar(context: Context, numero: Int, titulo: String, texto: String, clave: String) {
        if (!habilitadas(context, numero)) return
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        crearCanal(context)
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pending = PendingIntent.getActivity(
            context,
            clave.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(titulo)
            .setContentText(texto)
            .setStyle(NotificationCompat.BigTextStyle().bigText(texto))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(clave.hashCode(), n) }
    }

    private fun isoMillis(v: String): Long? {
        if (v.isBlank()) return null
        val normalizado = v.replace(Regex("(\\.\\d{3})\\d+"), "$1")
        val patrones = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss.SSSX",
            "yyyy-MM-dd'T'HH:mm:ssX"
        )
        for (patron in patrones) {
            val t = runCatching {
                java.text.SimpleDateFormat(patron, java.util.Locale.US).apply { isLenient = false }.parse(normalizado)?.time
            }.getOrNull()
            if (t != null) return t
        }
        return null
    }
}

class NotificationSyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            SupabaseApi.initialize(applicationContext)
            if (!SupabaseApi.restaurarSesion()) return Result.success()
            val snapshot = SupabaseApi.snapshotApp()
            Notificaciones.procesarSnapshot(applicationContext, snapshot)
            Result.success()
        } catch (_: SesionInvalidaException) {
            Result.success()
        } catch (_: SinConexionException) {
            Result.retry()
        } catch (_: ServidorTemporalException) {
            Result.retry()
        } catch (_: Exception) {
            Result.success()
        }
    }
}
