package com.tesoreria.caja

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.tesoreria.caja.R
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Permiso
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.data.NivelAcceso
import com.tesoreria.caja.data.Notificaciones
import com.tesoreria.caja.data.SessionSecurity
import com.tesoreria.caja.data.SupabaseApi
import com.tesoreria.caja.data.UpdateManager
import com.tesoreria.caja.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Caja.initialize(this)
        SessionSecurity.initialize(this)
        Notificaciones.inicializar(this)
        setContent { CajaTheme { App() } }
    }

    override fun onStart() {
        super.onStart()
        Caja.appEnPrimerPlano.value = true
    }

    override fun onStop() {
        Caja.appEnPrimerPlano.value = false
        Caja.marcarDesconectadoAsync()
        super.onStop()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN || ev.actionMasked == MotionEvent.ACTION_MOVE) {
            SessionSecurity.recordInteraction()
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) SessionSecurity.recordInteraction()
        return super.dispatchKeyEvent(event)
    }

    override fun onResume() {
        super.onResume()
        if (Caja.sesion.value != null && SessionSecurity.expired()) {
            SessionSecurity.markInactivityLogout()
            Caja.cerrarSesion()
        } else if (Caja.sesion.value != null) {
            SessionSecurity.recordInteraction(forcePersist = true)
        }
    }
}

private enum class Vista { INICIO, SUBIR, MOVIMIENTOS, ARCHIVO, PANEL }

@Composable
fun App() {
    val yo = Caja.sesion.value
    val conectado = Caja.conectado.value
    val enPrimerPlano = Caja.appEnPrimerPlano.value
    val errorGlobal = Caja.ultimoError.value
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var notificacionesActivas by remember(yo?.numero) {
        mutableStateOf(yo?.numero?.let { Notificaciones.habilitadas(context, it) } ?: false)
    }
    var permisoNotificaciones by remember(yo?.numero) {
        mutableStateOf(Notificaciones.permisoSistemaConcedido(context))
    }
    val pedirPermisoNotificaciones = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { concedido ->
        val numeroActual = Caja.sesion.value?.numero
        permisoNotificaciones = concedido || Notificaciones.permisoSistemaConcedido(context)
        if (numeroActual != null) {
            notificacionesActivas = permisoNotificaciones
            Notificaciones.cambiarHabilitadas(context, numeroActual, permisoNotificaciones)
        }
    }
    var vista by remember { mutableStateOf(Vista.INICIO) }
    var restaurando by remember { mutableStateOf(true) }
    var actualizacion by remember { mutableStateOf<UpdateManager.UpdateInfo?>(null) }
    var descargandoActualizacion by remember { mutableStateOf(false) }
    var progresoActualizacion by remember { mutableFloatStateOf(0f) }
    var errorActualizacion by remember { mutableStateOf<String?>(null) }
    var avisoSesion by remember { mutableStateOf<String?>(null) }
    var mostrarSinConexion by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        // Primero se verifica versión. Una versión vieja no restaura la sesión ni
        // entra a la aplicación: debe actualizar antes de continuar.
        // No dependemos del estado instantáneo de ConnectivityManager: al abrir
        // Android puede tardar en marcar la red aunque ya funcione. Intentamos
        // el servidor directamente y dejamos que la petición determine el estado.
        val config = runCatching { SupabaseApi.configuracionActualizacion() }.getOrNull()
        SessionSecurity.configureTimeout(config?.optInt("sesion_inactividad_segundos", 300) ?: 300)

        runCatching { UpdateManager.buscarActualizacion(config) }
            .onSuccess { actualizacion = it }

        if (actualizacion?.obligatoria != true) {
            if (SessionSecurity.hasTrackedSession() && SessionSecurity.expired()) {
                SessionSecurity.markInactivityLogout()
                Caja.cerrarSesion()
                avisoSesion = SessionSecurity.consumeReason()
            } else {
                Caja.restaurarSesion()
                if (Caja.sesion.value != null) SessionSecurity.markLogin()
            }
        }
        restaurando = false
    }

    // Si la app permanece abierta durante una publicación nueva, la detecta sin
    // obligar al usuario a cerrarla y abrirla de nuevo.
    LaunchedEffect(conectado) {
        if (!conectado) return@LaunchedEffect
        while (true) {
            delay(10 * 60 * 1000L)
            val config = runCatching { SupabaseApi.configuracionActualizacion() }.getOrNull()
            SessionSecurity.configureTimeout(config?.optInt("sesion_inactividad_segundos", 300) ?: 300)
            runCatching { UpdateManager.buscarActualizacion(config) }
                .onSuccess { if (it != null) actualizacion = it }
        }
    }

    actualizacion?.let { info ->
        DialogoActualizacion(
            context = context,
            info = info,
            descargando = descargandoActualizacion,
            progreso = progresoActualizacion,
            error = errorActualizacion,
            onActualizar = {
                if (!UpdateManager.puedeInstalarPaquetes(context)) {
                    errorActualizacion = "Activa “Permitir desde esta fuente” y vuelve a tocar Actualizar."
                    UpdateManager.abrirPermisoInstalacion(context)
                } else if (!descargandoActualizacion) {
                    descargandoActualizacion = true
                    progresoActualizacion = 0f
                    errorActualizacion = null
                    scope.launch {
                        try {
                            val archivo = UpdateManager.descargar(context, info) { p ->
                                android.os.Handler(android.os.Looper.getMainLooper()).post {
                                    progresoActualizacion = p
                                }
                            }
                            descargandoActualizacion = false
                            UpdateManager.instalar(context, archivo)
                        } catch (e: Exception) {
                            descargandoActualizacion = false
                            errorActualizacion = e.message ?: "No se pudo instalar la actualización"
                        }
                    }
                }
            },
            onMasTarde = {
                if (!descargandoActualizacion) actualizacion = null
            }
        )
    }

    LaunchedEffect(yo) {
        if (yo == null && avisoSesion.isNullOrBlank()) {
            avisoSesion = SessionSecurity.consumeReason()
        }
    }

    LaunchedEffect(yo?.numero) {
        val numero = yo?.numero
        if (numero == null) {
            notificacionesActivas = false
            permisoNotificaciones = Notificaciones.permisoSistemaConcedido(context)
        } else {
            val preferencia = Notificaciones.habilitadas(context, numero)
            permisoNotificaciones = Notificaciones.permisoSistemaConcedido(context)
            // Si Android revocó el permiso, el control no debe fingir que está ON.
            if (preferencia && !permisoNotificaciones && Build.VERSION.SDK_INT >= 33) {
                Notificaciones.cambiarHabilitadas(context, numero, false)
                notificacionesActivas = false
            } else {
                notificacionesActivas = preferencia
            }
        }
    }

    LaunchedEffect(yo?.numero) {
        // El ON/OFF es individual. Al cambiar de cuenta se programa o cancela
        // WorkManager según la preferencia de ese número de lista.
        Notificaciones.configurarUsuario(context, yo?.numero)
    }

    LaunchedEffect(yo?.numero) {
        if (yo == null) return@LaunchedEffect
        while (true) {
            delay(2_000)
            if (Caja.sesion.value != null && SessionSecurity.expired()) {
                SessionSecurity.markInactivityLogout()
                Caja.cerrarSesion()
                avisoSesion = SessionSecurity.consumeReason()
                vista = Vista.INICIO
                break
            }
        }
    }

    LaunchedEffect(errorGlobal) {
        if (!errorGlobal.isNullOrBlank() && errorGlobal != "Sin conexión a Internet") {
            delay(4500)
            if (Caja.ultimoError.value == errorGlobal) Caja.ultimoError.value = null
        }
    }

    LaunchedEffect(yo?.numero, conectado, enPrimerPlano) {
        if (yo != null && conectado && enPrimerPlano) {
            Caja.registrarPresenciaAhora()
            while (Caja.sesion.value != null && Caja.appEnPrimerPlano.value) {
                delay(7_000)
                if (Caja.conectado.value && Caja.appEnPrimerPlano.value) Caja.registrarPresenciaAhora()
            }
        }
    }

    LaunchedEffect(yo?.numero, conectado) {
        if (yo != null && conectado) {
            // Al volver Internet sincroniza inmediatamente y luego mantiene el refresco periódico.
            Caja.refrescar()
            while (true) {
                delay(30_000)
                if (Caja.conectado.value) Caja.refrescar()
            }
        }
    }

    // Pantalla tipo app financiera: solo aparece cuando la conexión está realmente
    // caída durante un momento sostenido. Se cierra sola al recuperar Internet.
    LaunchedEffect(conectado) {
        if (conectado) {
            mostrarSinConexion = false
        } else {
            delay(900)
            if (!Caja.conectado.value) mostrarSinConexion = true
            while (!Caja.conectado.value) {
                if (SupabaseApi.verificarConexionRapida()) break
                delay(2_000)
            }
            mostrarSinConexion = false
        }
    }

    if (restaurando) {
        Box(Modifier.fillMaxSize().background(Fondo), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(R.drawable.tesoreria_logo_hd),
                    contentDescription = "Tesorería",
                    modifier = Modifier.size(136.dp)
                )
                Spacer(Modifier.height(14.dp))
                Text("Conectando con Tesorería…", color = Tenue, fontSize = 12.sp)
            }
        }
        if (mostrarSinConexion) DialogoSinConexion()
        return
    }

    if (yo == null) {
        PantallaLogin(avisoInicial = avisoSesion) { s ->
            Caja.sesion.value = s
            avisoSesion = null
            SessionSecurity.markLogin()
            vista = Vista.INICIO
        }
        if (mostrarSinConexion) DialogoSinConexion()
        return
    }

    val conPanel = Caja.puedeAbrirPanel(yo)
    val rolTexto = yo.cargoNombre.ifBlank {
        when (yo.nivelAcceso) {
            NivelAcceso.OWNER -> "Owner"
            NivelAcceso.ADMINISTRADOR -> "Administrador"
            NivelAcceso.USUARIO -> "Usuario"
        }
    }

    Column(Modifier.fillMaxSize().background(Fondo)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 14.dp, top = 18.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Hola, ${yo.nombre.substringBefore(" ")}", color = Texto, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(3.dp))
                Text("N.º ${yo.numero} · $rolTexto", color = Tenue, fontSize = 11.sp)
            }
            if (vista == Vista.INICIO) {
                val colorNotificacion = if (notificacionesActivas) Verde else Rojo
                Row(
                    Modifier
                        .background(colorNotificacion.copy(alpha = .08f), RoundedCornerShape(14.dp))
                        .padding(start = 8.dp, end = 5.dp, top = 5.dp, bottom = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Notificación",
                        color = colorNotificacion,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.width(5.dp))
                    Box(
                        Modifier
                            .width(38.dp)
                            .height(22.dp)
                            .background(colorNotificacion, RoundedCornerShape(11.dp))
                            .clickable {
                                val activar = !notificacionesActivas
                                if (!activar) {
                                    notificacionesActivas = false
                                    Notificaciones.cambiarHabilitadas(context, yo.numero, false)
                                } else {
                                    permisoNotificaciones = Notificaciones.permisoSistemaConcedido(context)
                                    if (Build.VERSION.SDK_INT < 33 || permisoNotificaciones) {
                                        notificacionesActivas = true
                                        Notificaciones.cambiarHabilitadas(context, yo.numero, true)
                                    } else {
                                        Notificaciones.marcarPermisoSolicitado(context)
                                        pedirPermisoNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (notificacionesActivas) "ON" else "OFF",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
                Spacer(Modifier.width(7.dp))
            }
            Box(
                Modifier.size(43.dp).background(Panel, CircleShape).clickable {
                    Caja.cerrarSesion()
                    SessionSecurity.markLogout()
                    avisoSesion = null
                    vista = Vista.INICIO
                },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Logout, "Cerrar sesión", tint = Tenue, modifier = Modifier.size(20.dp))
            }
        }

        if (!errorGlobal.isNullOrBlank() && errorGlobal != "Sin conexión a Internet") {
            Row(
                Modifier.fillMaxWidth().background(Ambar.copy(alpha = .10f))
                    .padding(horizontal = 18.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Info, null, tint = Ambar, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text(errorGlobal, color = Texto, fontSize = 10.sp)
            }
        }

        if (mostrarSinConexion) {
            Row(
                Modifier.fillMaxWidth().background(Rojo.copy(alpha = .12f))
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.CloudOff, null, tint = Rojo, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("Sin conexión", color = Texto, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Los datos pueden estar desactualizados. Se reconectará automáticamente.", color = Tenue, fontSize = 9.sp)
                }
                CircularProgressIndicator(modifier = Modifier.size(15.dp), strokeWidth = 2.dp, color = Rojo)
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth().background(Fondo)) {
            when (vista) {
                Vista.MOVIMIENTOS -> Box(
                    Modifier.fillMaxSize().padding(horizontal = 18.dp)
                ) { PantallaMovimientos() }
                Vista.ARCHIVO -> Box(
                    Modifier.fillMaxSize().padding(horizontal = 18.dp)
                ) { PantallaArchivo() }
                else -> Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                        .padding(horizontal = 18.dp).padding(bottom = 22.dp)
                ) {
                    when (vista) {
                        Vista.INICIO -> PantallaInicio { vista = Vista.SUBIR }
                        Vista.SUBIR -> PantallaSubir { vista = Vista.INICIO }
                        Vista.PANEL -> PantallaPanel()
                        Vista.ARCHIVO, Vista.MOVIMIENTOS -> Unit
                    }
                }
            }
        }

        BarraInferior(
            vista = vista,
            conPanel = conPanel,
            onInicio = { vista = Vista.INICIO },
            onMovimientos = { vista = Vista.MOVIMIENTOS },
            onArchivo = { vista = Vista.ARCHIVO },
            onPanel = { vista = Vista.PANEL }
        )
    }

}

@Composable
private fun DialogoSinConexion() {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = { },
        properties = androidx.compose.ui.window.DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false
        )
    ) {
        Box(
            Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(28.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(modifier = Modifier.size(30.dp), strokeWidth = 3.dp, color = Color(0xFF12CDB4))
                Spacer(Modifier.height(18.dp))
                Text("Verifica tu conexión a Internet", color = Color(0xFF25194A), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Se reconectará automáticamente", color = Color(0xFF6F6A7C), fontSize = 11.sp)
            }
        }
    }
}


@Composable
private fun BarraInferior(
    vista: Vista,
    conPanel: Boolean,
    onInicio: () -> Unit,
    onMovimientos: () -> Unit,
    onArchivo: () -> Unit,
    onPanel: () -> Unit
) {
    val indice = when (vista) {
        Vista.INICIO, Vista.SUBIR -> 0
        Vista.MOVIMIENTOS -> 1
        Vista.ARCHIVO -> 2
        Vista.PANEL -> if (conPanel) 3 else 2
    }
    val total = if (conPanel) 4 else 3
    Row(
        Modifier.fillMaxWidth().background(FondoProfundo).navigationBarsPadding().height(72.dp).padding(horizontal = 5.dp)
    ) {
        NavItem("Inicio", Icons.Rounded.Home, indice == 0, Modifier.weight(1f), onInicio)
        NavItem("Movimientos", Icons.Rounded.ReceiptLong, indice == 1, Modifier.weight(1f), onMovimientos)
        NavItem("Actas", Icons.Rounded.FolderOpen, indice == 2, Modifier.weight(1f), onArchivo)
        if (conPanel) NavItem("Panel", Icons.Rounded.Tune, indice == 3, Modifier.weight(1f), onPanel)
    }
}

@Composable
private fun NavItem(texto: String, icono: ImageVector, activa: Boolean, modifier: Modifier, alTocar: () -> Unit) {
    Column(
        modifier.fillMaxHeight()
            .background(if (activa) VerdeNeon.copy(alpha = .075f) else Color.Transparent, RoundedCornerShape(18.dp))
            .clickable { alTocar() },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icono, texto, tint = if (activa) VerdeNeon else Tenue, modifier = Modifier.size(21.dp))
        Spacer(Modifier.height(3.dp))
        Text(texto, color = if (activa) VerdeNeon else Tenue, fontSize = 9.sp, fontWeight = if (activa) FontWeight.Bold else FontWeight.Medium)
    }
}
