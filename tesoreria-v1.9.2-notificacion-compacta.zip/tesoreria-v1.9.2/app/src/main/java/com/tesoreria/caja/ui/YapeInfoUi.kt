package com.tesoreria.caja.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import kotlinx.coroutines.delay

@Composable
fun YapeInfoUsuarioCard(compacta: Boolean = false) {
    val numero = Caja.yapeConfig.value.numeroYape.trim()
    if (numero.isBlank()) return

    val clipboard = LocalClipboardManager.current
    var aviso by remember { mutableStateOf("") }

    fun copiarNumero() {
        clipboard.setText(AnnotatedString(numero))
        aviso = "✓ Número copiado"
    }

    LaunchedEffect(aviso) {
        if (aviso.isNotBlank()) {
            delay(2200)
            aviso = ""
        }
    }

    Tarjeta(borde = MoradoYape.copy(alpha = .55f), fondo = PanelAlto) {
        Etiqueta("PAGA POR YAPE", MoradoYape)
        Spacer(Modifier.height(7.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { copiarNumero() }
                .padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(numero, color = Texto, fontSize = if (compacta) 22.sp else 24.sp, style = cifra, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(10.dp))
            Icon(Icons.Rounded.ContentCopy, "Copiar número Yape", tint = MoradoYape, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(10.dp))
        Boton("Copiar número", Modifier.fillMaxWidth(), relleno = false, color = MoradoYape) {
            copiarNumero()
        }
        if (aviso.isNotBlank()) {
            Spacer(Modifier.height(7.dp))
            Text(aviso, color = Verde, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
