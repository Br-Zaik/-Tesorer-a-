# Tesorería v1.8.1

- Corrige compilación Kotlin en el selector superior del panel.
- Ventana de permisos con desplazamiento vertical completo.
- Pestañas del panel Owner mejor distribuidas y desplazables.
- Color de cargo más visible en tarjetas y gestión de miembros.
- Pagos Yape aprobados con cuadro más morado en el estado de pagos.
