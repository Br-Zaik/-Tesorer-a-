# Tesorería v1.9.1

## Notificaciones individuales ON/OFF

- Se añadió un interruptor visible en **Inicio** para activar o desactivar las notificaciones.
- La preferencia se guarda por número de lista en el dispositivo: apagar las notificaciones del N.º 5 no modifica al N.º 6.
- Por defecto cada usuario empieza con notificaciones activadas.
- Al desactivar: se cancela el trabajo periódico de WorkManager y se retiran los avisos visibles de Tesorería.
- Al activar: se vuelve a programar WorkManager y se crea una línea base silenciosa para evitar notificaciones antiguas.
- En Android 13+ el control distingue entre ON real y ON bloqueado por el permiso del sistema.
- Si el permiso todavía no fue solicitado, se pide al usuario al entrar a Inicio.
- El worker y el procesamiento de snapshots verifican la preferencia antes de generar avisos.
- Si no hay una sesión activa, el trabajo periódico queda cancelado.

VersionCode: 39  
VersionName: 1.9.1
