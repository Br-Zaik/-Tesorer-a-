-- APLICADO en Supabase Tesorería para v1.9.0
-- 1) Cerrar RPC SECURITY DEFINER a usuarios anónimos.
do $$
declare r record;
begin
  for r in
    select p.oid::regprocedure::text as firma
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public' and p.prosecdef = true
  loop
    execute format('revoke execute on function %s from public, anon', r.firma);
    execute format('grant execute on function %s to authenticated, service_role', r.firma);
  end loop;
end $$;

-- 2) Evitar search_path mutable en el helper de dHash.
alter function public.distancia_dhash(bigint,bigint)
  set search_path = public, pg_catalog;

-- 3) El helper dHash tampoco queda invocable por anon.
revoke execute on function public.distancia_dhash(bigint,bigint) from public, anon;
grant execute on function public.distancia_dhash(bigint,bigint) to authenticated, service_role;
