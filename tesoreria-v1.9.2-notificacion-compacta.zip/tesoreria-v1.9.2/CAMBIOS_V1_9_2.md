# Tesorería v1.9.2

## Notificación compacta e individual

- Se eliminó la tarjeta grande de notificaciones de Inicio.
- El control ahora está arriba, inmediatamente a la izquierda de Cerrar sesión.
- Solo muestra `Notificación` y un botón compacto `ON/OFF`.
- OFF es rojo y ON es verde.
- Por defecto las notificaciones vienen desactivadas para cada usuario.
- La preferencia sigue siendo individual por número de lista y dispositivo.
- En Android 13+ al activar se solicita permiso del sistema. Si Android no lo concede, vuelve a OFF y no mantiene trabajo en segundo plano.
- Si Android revoca el permiso, el control se corrige a OFF al volver a entrar.
- Al apagar se cancela WorkManager y se retiran los avisos visibles de Tesorería.
- Al encender se reactiva WorkManager y se conserva la protección contra avisos antiguos.

VersionCode: 40  
VersionName: 1.9.2
