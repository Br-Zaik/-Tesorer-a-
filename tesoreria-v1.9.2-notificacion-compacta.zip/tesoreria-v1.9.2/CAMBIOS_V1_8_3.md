# Tesorería v1.8.3

- Zona **Paga por Yape** en morado llamativo y separada visualmente de los estados verdes.
- Número Yape copiable tocando el número/ícono o el botón; aviso temporal “✓ Número copiado”.
- **Pagar en conjunto** y selección de personas pasan a morado para reconocer la acción de Yape.
- Confirmación final obligatoria para pagos conjuntos mostrando total y números incluidos.
- **Comprobante enviado** permanece verde para conservar el significado de éxito.
- Limpieza segura de capturas huérfanas cuando Storage sube la imagen pero el servidor rechaza definitivamente el pago.
- En pérdidas de conexión o timeout no se borra la captura automáticamente, para evitar eliminar un pago que pudo haberse confirmado en el servidor.
- El panel administrativo ahora oculta pestañas sin permiso: un Visitante con solo `ver_comprobantes_yape` ve únicamente **Pagos**, no Cobro/Gastos/Yape/Miembros.
