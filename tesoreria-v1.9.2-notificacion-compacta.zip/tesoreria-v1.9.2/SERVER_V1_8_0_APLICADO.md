# Servidor v1.8.0 · APLICADO

Los cambios de backend de Tesorería v1.8.0 ya fueron aplicados al proyecto Supabase de producción usado por la app.

## Migraciones aplicadas
- `v1_8_0_schema_accesos_participacion`
- `v1_8_0_access_owner_permissions`
- `v1_8_0_cobros_multiples_no_pago`
- `v1_8_0_pagos_participacion`
- `v1_8_0_yape_permisos_owner`
- `v1_8_0_snapshot_cleanup_operations`
- `v1_8_0_miembro_basico_delegado`
- `v1_8_0_owner_member_atomic`
- `v1_8_0_lock_direct_payment_writes`
- `v1_8_0_security_and_indexes`
- `v1_8_0_ajuste_plazo_dias`
- `v1_8_0_motivo_no_pago_publico`
- `v1_8_0_codigos_sin_reutilizacion`

## Edge Function
- `owner-limpiar` versión 2.
- Valida Bearer token y exige nivel `owner`.
- Puede previsualizar o eliminar datos por rango/completo.
- Elimina también los comprobantes del bucket privado `comprobantes-yape`.

## Reglas principales del servidor
- N.º 22 permanece como Owner principal.
- Máximo 3 cobros oficiales activos y 2 rápidos.
- Los miembros con `participa_cobros=false` quedan fuera del universo de pago.
- La decisión `no_paga` guarda motivo y se incorpora al acta al cerrar; el motivo queda disponible en el resumen del acta/PDF para transparencia del grupo.
- Ver comprobantes y aprobar/rechazar Yape son permisos distintos.
- Presencia y última actividad son exclusivas del Owner.
- Las escrituras directas autenticadas sobre `pagos` fueron bloqueadas; las operaciones pasan por RPCs validados.
- Limpieza destructiva y limpieza de códigos finalizados son exclusivas del Owner.
- Al limpiar códigos usados/vencidos se conserva únicamente una huella no visible para impedir que ese mismo código pueda volver a emitirse en el futuro.

## Prueba de servidor realizada
Se realizó una transacción temporal con un cobro oficial y una decisión `no_paga`; al cerrar el cobro, el detalle de acta quedó con estado `no_paga` y conservó correctamente el motivo. La transacción se revirtió después de comprobar el resultado, por lo que no dejó datos de prueba.

Este archivo es informativo: **no es necesario volver a ejecutar estas migraciones** para usar el ZIP v1.8.0 con el servidor actual.
