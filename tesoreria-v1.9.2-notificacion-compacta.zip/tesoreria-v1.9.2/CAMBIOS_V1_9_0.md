# Tesorería v1.9.0 · versionCode 38

## Pagos y avisos
- Notificaciones Android para cobro nuevo, pago propio aprobado/rechazado y recordatorio cuando faltan menos de ~35 minutos para un cobro pendiente.
- Sin servicios permanentes: WorkManager comprueba en segundo plano con red disponible y la app también detecta cambios durante su refresco normal.
- En Android 13+ se solicita una sola vez permiso para notificaciones.
- El historial de avisos queda separado por número de lista para no mezclar usuarios en un mismo celular.
- Estado propio más claro: Enviado → Revisión → Aprobado/Rechazado.

## Conexión y prevención de errores
- La sesión abierta muestra una franja visible "Sin conexión" en vez de bloquear toda la app; se retira sola al recuperar Internet.
- Aprobar un Yape ahora exige confirmación mostrando integrantes y total.
- Cerrar cobro muestra resumen final: participantes, aprobados, pendientes, rechazados, sin enviar, no pagarán y total confirmado.
- Si quedan comprobantes pendientes al cerrar, aparece una advertencia explícita.
- Bloquear/desbloquear usuario exige confirmación.

## Seguridad Supabase aplicada
- Se retiró EXECUTE anónimo de todas las funciones SECURITY DEFINER del esquema public.
- Se conserva ejecución para authenticated/service_role porque la app y las funciones protegidas la necesitan; las funciones mantienen sus comprobaciones internas de owner/permisos.
- distancia_dhash ahora usa search_path fijo (public, pg_catalog) y tampoco queda ejecutable por usuarios anónimos.
- La política de borrado de comprobante huérfano de v1.8.3 se mantiene.

## Nota
- El aviso "Leaked Password Protection Disabled" de Supabase Auth es una opción del panel de Auth y no es modificable por la conexión de administración disponible desde este proyecto. La app no depende de ese ajuste para funcionar.
