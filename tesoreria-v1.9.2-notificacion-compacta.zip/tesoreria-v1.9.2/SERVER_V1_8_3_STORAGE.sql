-- Tesorería v1.8.3
-- Permite limpiar únicamente capturas propias que todavía no estén asociadas a un pago.

drop policy if exists "borrar comprobante huerfano propio" on storage.objects;
create policy "borrar comprobante huerfano propio"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'comprobantes-yape'
  and (storage.foldername(name))[1] = (public.mi_numero())::text
  and not exists (
    select 1
    from public.pagos_privados pp
    where pp.captura_path = objects.name
  )
);
