# Validación v1.8.0

## Revisiones realizadas
- Balance de llaves, paréntesis y corchetes de todos los archivos Kotlin modificados.
- Revisión de todos los estados de pago, incluyendo `NO_PAGA`.
- Revisión de permisos Owner/Administrador/Usuario en interfaz y servidor.
- Prueba transaccional del cierre de acta con motivo de no participación.
- Comprobación de que el proyecto conserva `applicationId`/`namespace` `com.tesoreria.caja`.
- Comprobación de versión: `versionCode 34`, `versionName 1.8.0`.

## Compilación
Este entorno de edición no incluye Android SDK/Gradle, por lo que el APK no se compiló localmente aquí. El ZIP mantiene los workflows de GitHub Actions del proyecto para la compilación real con Gradle 8.10.2 y Java 17.
