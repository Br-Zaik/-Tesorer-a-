# Servidor v1.7.6 aplicado

Aplicado al proyecto Supabase de Tesorería.

- Se corrigieron los permisos de `service_role` sobre `codigos_activacion_masivos`.
- La Edge Function `codigos-masivos` quedó en versión 2.
- Genera únicamente cuando el tesorero pulsa el botón y solicita una cantidad de 1 a 30.
- Mantiene como máximo 30 códigos disponibles a la vez.
- Cada código tiene 6 dígitos, dura 6 horas y se consume una sola vez.
- Los códigos masivos solo sirven para primera activación.
- La respuesta del servidor incluye historial: disponible, usado, vencido/cancelado y número que lo utilizó.
- El sistema individual de códigos de 24 h permanece separado para recuperación/restablecimiento.
