# Tesorería v1.7.4 — corrección de compilación

Se corrigen referencias `onFin` fuera de alcance introducidas en `Caja.kt`.
No cambia versionCode (31) ni versionName (1.7.4), porque la compilación anterior falló y no llegó a publicarse.
Se mantiene el flujo de pago manual rápido de v1.7.4.
