-- Tesorería v1.7.5
-- Códigos masivos de primera activación (6 h, un solo uso)
-- Pagos manuales en conjunto y Yape grupal con un solo comprobante.

create table if not exists public.codigos_activacion_masivos (
  id uuid primary key,
  codigo_hash text not null unique,
  liberado_por smallint not null references public.miembros(numero),
  vence_at timestamptz not null,
  usado_at timestamptz,
  usado_por smallint references public.miembros(numero),
  cancelado_at timestamptz,
  creado_at timestamptz not null default now()
);

create index if not exists codigos_activacion_masivos_activos_idx
  on public.codigos_activacion_masivos(vence_at)
  where usado_at is null and cancelado_at is null;

alter table public.codigos_activacion_masivos enable row level security;
revoke all on table public.codigos_activacion_masivos from anon, authenticated;

create or replace function public.registrar_pago_manual_grupo(
  p_cobro_id uuid,
  p_socios smallint[]
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_actor smallint;
  v_cobro public.cobros%rowtype;
  v_socios smallint[];
  v_numero smallint;
  v_pago public.pagos%rowtype;
  v_id uuid;
  v_ids uuid[] := '{}'::uuid[];
begin
  v_actor := public.mi_numero();
  if v_actor is null then raise exception 'Usuario no autorizado'; end if;
  if not public.tiene_permiso('registrar_pago_manual') then
    raise exception 'No tienes permiso para registrar pagos manuales';
  end if;

  select array_agg(distinct x order by x)
  into v_socios
  from unnest(coalesce(p_socios, '{}'::smallint[])) as x;

  if v_socios is null or cardinality(v_socios) < 1 then
    raise exception 'Selecciona al menos una persona';
  end if;
  if cardinality(v_socios) > 35 then raise exception 'Demasiadas personas seleccionadas'; end if;

  select * into v_cobro
  from public.cobros
  where id=p_cobro_id
  for update;

  if not found or v_cobro.cerrado_at is not null or v_cobro.cierra_at <= now() then
    raise exception 'No hay un cobro activo';
  end if;

  -- Validamos a todos antes de tocar un solo pago: todo o nada.
  foreach v_numero in array v_socios loop
    if not exists (
      select 1 from public.miembros
      where numero=v_numero and estado not in ('libre','retirado')
    ) then
      raise exception 'El N.º % no es un socio válido', v_numero;
    end if;
    if exists (
      select 1 from public.pagos
      where cobro_id=p_cobro_id and socio_numero=v_numero and vigente=true and estado='aprobado'
    ) then
      raise exception 'El N.º % ya tiene el pago aprobado', v_numero;
    end if;
  end loop;

  foreach v_numero in array v_socios loop
    select * into v_pago
    from public.pagos
    where cobro_id=p_cobro_id and socio_numero=v_numero and vigente=true
    limit 1 for update;

    if found then
      v_id := v_pago.id;
      update public.pagos
      set medio='manual', estado='aprobado', monto_centavos=v_cobro.monto_centavos,
          enviado_at=now(), revisado_at=now(), revisado_por=v_actor, recibido_por=v_actor
      where id=v_id;
    else
      insert into public.pagos(
        cobro_id,socio_numero,medio,estado,monto_centavos,revisado_at,revisado_por,recibido_por
      ) values (
        p_cobro_id,v_numero,'manual','aprobado',v_cobro.monto_centavos,now(),v_actor,v_actor
      ) returning id into v_id;
    end if;
    v_ids := array_append(v_ids, v_id);
  end loop;

  insert into public.bitacora(actor_numero,nivel,publico,evento,entidad,entidad_id,detalle)
  values(
    v_actor,'importante',true,'Pago manual en conjunto','pago',coalesce(v_ids[1]::text,''),
    'Se registró un pago manual en conjunto para los N.º ' || array_to_string(v_socios, ', ') || '.'
  );

  return jsonb_build_object('ok',true,'cantidad',cardinality(v_socios),'numeros',to_jsonb(v_socios));
end;
$function$;

revoke all on function public.registrar_pago_manual_grupo(uuid,smallint[]) from public, anon;
grant execute on function public.registrar_pago_manual_grupo(uuid,smallint[]) to authenticated;

create or replace function public.enviar_pago_yape_foto_grupo(
  p_cobro_id uuid,
  p_socios smallint[],
  p_captura_path text,
  p_captura_sha256 text,
  p_captura_dhash bigint default null
)
returns uuid
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_pagador smallint;
  v_cobro public.cobros%rowtype;
  v_socios smallint[];
  v_numero smallint;
  v_pago public.pagos%rowtype;
  v_pago_id uuid;
  v_hash text;
  v_grupo_id uuid := gen_random_uuid();
  v_meta jsonb;
begin
  v_pagador := public.mi_numero();
  if v_pagador is null then raise exception 'Debes iniciar sesión'; end if;
  if not exists(select 1 from public.miembros where numero=v_pagador and estado='activo') then
    raise exception 'Cuenta no habilitada';
  end if;

  select array_agg(distinct x order by x)
  into v_socios
  from unnest(coalesce(p_socios, '{}'::smallint[]) || array[v_pagador]::smallint[]) as x;

  if v_socios is null or cardinality(v_socios) < 1 then v_socios := array[v_pagador]::smallint[]; end if;
  if cardinality(v_socios) > 35 then raise exception 'Demasiadas personas seleccionadas'; end if;

  select * into v_cobro from public.cobros where id=p_cobro_id for update;
  if not found or v_cobro.cerrado_at is not null or v_cobro.cierra_at<=now() then
    raise exception 'El cobro está cerrado';
  end if;

  v_hash := lower(trim(coalesce(p_captura_sha256,'')));
  if v_hash !~ '^[a-f0-9]{64}$' then raise exception 'Huella de comprobante inválida'; end if;
  if trim(coalesce(p_captura_path,''))='' or split_part(p_captura_path,'/',1)<>v_pagador::text then
    raise exception 'Ruta de comprobante inválida';
  end if;
  if not exists(
    select 1 from storage.objects where bucket_id='comprobantes-yape' and name=p_captura_path
  ) then
    raise exception 'El comprobante no existe en el almacenamiento';
  end if;

  -- La misma imagen no puede pertenecer a otro pago vigente/histórico.
  if exists (
    select 1
    from public.pagos_privados pp
    join public.pagos p on p.id=pp.pago_id
    where lower(trim(pp.captura_sha256))=v_hash
      and not (p.cobro_id=p_cobro_id and p.socio_numero=v_pagador and p.vigente=true)
  ) then
    raise exception 'Esta misma captura ya fue utilizada en otro pago';
  end if;

  -- Validación previa: si uno no puede entrar al grupo, no se registra ninguno.
  foreach v_numero in array v_socios loop
    if not exists(select 1 from public.miembros where numero=v_numero and estado='activo') then
      raise exception 'El N.º % no está activo', v_numero;
    end if;
    select * into v_pago
    from public.pagos
    where cobro_id=p_cobro_id and socio_numero=v_numero and vigente=true
    limit 1 for update;
    if found and v_pago.estado='aprobado' then raise exception 'El N.º % ya tiene el pago aprobado', v_numero; end if;
    if found and v_pago.estado='pendiente' then raise exception 'El N.º % ya tiene un pago pendiente', v_numero; end if;
  end loop;

  v_meta := jsonb_build_object(
    'modo','foto_sin_ocr',
    'grupo_id',v_grupo_id::text,
    'pagador_numero',v_pagador,
    'numeros',to_jsonb(v_socios)
  );

  foreach v_numero in array v_socios loop
    select * into v_pago
    from public.pagos
    where cobro_id=p_cobro_id and socio_numero=v_numero and vigente=true
    limit 1 for update;

    if found then
      v_pago_id := v_pago.id;
      update public.pagos
      set medio='yape',estado='pendiente',monto_centavos=v_cobro.monto_centavos,
          enviado_at=now(),revisado_at=null,revisado_por=null,recibido_por=null
      where id=v_pago_id;
    else
      insert into public.pagos(cobro_id,socio_numero,medio,estado,monto_centavos)
      values(p_cobro_id,v_numero,'yape','pendiente',v_cobro.monto_centavos)
      returning id into v_pago_id;
    end if;

    insert into public.pagos_privados(
      pago_id,operacion,fecha_operacion,ocr_monto_centavos,ocr_operacion,
      ocr_fecha_operacion,ocr_codigo_seguridad,captura_path,captura_sha256,
      captura_dhash,motivo_rechazo,metadata_ocr
    ) values(
      v_pago_id,null,null,null,null,null,null,p_captura_path,
      case when v_numero=v_pagador then v_hash else null end,
      case when v_numero=v_pagador then p_captura_dhash else null end,
      null,v_meta
    )
    on conflict (pago_id) do update set
      operacion=null,fecha_operacion=null,ocr_monto_centavos=null,ocr_operacion=null,
      ocr_fecha_operacion=null,ocr_codigo_seguridad=null,captura_path=excluded.captura_path,
      captura_sha256=excluded.captura_sha256,captura_dhash=excluded.captura_dhash,
      motivo_rechazo=null,metadata_ocr=excluded.metadata_ocr;
  end loop;

  insert into public.bitacora(actor_numero,nivel,publico,evento,entidad,entidad_id,detalle)
  values(
    v_pagador,'info',false,'Comprobante Yape conjunto','pago',v_grupo_id::text,
    'El N.º ' || v_pagador || ' envió una captura Yape para los N.º ' || array_to_string(v_socios, ', ') || '.'
  );

  return v_grupo_id;
exception when unique_violation then
  raise exception 'Esta captura ya fue utilizada';
end;
$function$;

revoke all on function public.enviar_pago_yape_foto_grupo(uuid,smallint[],text,text,bigint) from public, anon;
grant execute on function public.enviar_pago_yape_foto_grupo(uuid,smallint[],text,text,bigint) to authenticated;

create or replace function public.revisar_pago_yape_grupo(
  p_grupo_id uuid,
  p_aprobar boolean,
  p_motivo_rechazo text default null
)
returns void
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_actor smallint;
  v_count integer;
  v_numeros text;
begin
  v_actor := public.mi_numero();
  if v_actor is null or not public.puede_gestionar_yape() then
    raise exception 'No tienes permiso para revisar Yape';
  end if;

  perform 1
  from public.pagos p
  join public.pagos_privados pp on pp.pago_id=p.id
  where p.vigente=true and p.medio='yape'
    and pp.metadata_ocr->>'grupo_id'=p_grupo_id::text
  for update of p;

  select count(*), string_agg(p.socio_numero::text, ', ' order by p.socio_numero)
  into v_count, v_numeros
  from public.pagos p
  join public.pagos_privados pp on pp.pago_id=p.id
  where p.vigente=true and p.medio='yape'
    and pp.metadata_ocr->>'grupo_id'=p_grupo_id::text;

  if v_count=0 then raise exception 'Grupo de pago no encontrado'; end if;
  if exists(
    select 1 from public.pagos p
    join public.pagos_privados pp on pp.pago_id=p.id
    where p.vigente=true and p.medio='yape'
      and pp.metadata_ocr->>'grupo_id'=p_grupo_id::text
      and p.estado<>'pendiente'
  ) then raise exception 'Este pago ya fue revisado'; end if;

  if p_aprobar then
    update public.pagos p
    set estado='aprobado',revisado_at=now(),revisado_por=v_actor
    from public.pagos_privados pp
    where pp.pago_id=p.id and p.vigente=true and p.medio='yape'
      and pp.metadata_ocr->>'grupo_id'=p_grupo_id::text;

    update public.pagos_privados
    set motivo_rechazo=null
    where metadata_ocr->>'grupo_id'=p_grupo_id::text;
  else
    if char_length(trim(coalesce(p_motivo_rechazo,''))) < 4 then
      raise exception 'Escribe un motivo de rechazo';
    end if;
    update public.pagos p
    set estado='rechazado',revisado_at=now(),revisado_por=v_actor
    from public.pagos_privados pp
    where pp.pago_id=p.id and p.vigente=true and p.medio='yape'
      and pp.metadata_ocr->>'grupo_id'=p_grupo_id::text;

    update public.pagos_privados
    set motivo_rechazo=trim(p_motivo_rechazo)
    where metadata_ocr->>'grupo_id'=p_grupo_id::text;
  end if;

  insert into public.bitacora(actor_numero,nivel,publico,evento,entidad,entidad_id,detalle)
  values(
    v_actor,'importante',true,
    case when p_aprobar then 'Pago conjunto aprobado' else 'Pago conjunto rechazado' end,
    'pago',p_grupo_id::text,
    case when p_aprobar
      then 'Se aprobó el pago conjunto de los N.º ' || v_numeros || '.'
      else 'Se rechazó el pago conjunto de los N.º ' || v_numeros || '.'
    end
  );
end;
$function$;

revoke all on function public.revisar_pago_yape_grupo(uuid,boolean,text) from public, anon;
grant execute on function public.revisar_pago_yape_grupo(uuid,boolean,text) to authenticated;

create or replace function public.cargar_app_snapshot_v1()
returns jsonb
language sql
set search_path to 'public','pg_temp'
as $function$
select jsonb_build_object(
  'mi_numero', public.mi_numero(),
  'miembros', coalesce((select jsonb_agg(to_jsonb(x) order by x.numero) from (
      select numero,nombre,rol,estado from public.miembros where estado <> 'libre' order by numero
  ) x), '[]'::jsonb),
  'permisos', coalesce((select jsonb_agg(to_jsonb(x) order by x.socio_numero,x.permiso) from (
      select socio_numero,permiso from public.permisos_miembro order by socio_numero,permiso
  ) x), '[]'::jsonb),
  'cobros', coalesce((select jsonb_agg(to_jsonb(x) order by x.creado_at desc) from (
      select * from public.cobros order by creado_at desc
  ) x), '[]'::jsonb),
  'pagos', coalesce((select jsonb_agg(to_jsonb(x) order by x.enviado_at desc) from (
      select id,cobro_id,socio_numero,medio,estado,monto_centavos,enviado_at,revisado_at,revisado_por,recibido_por
      from public.pagos where vigente=true order by enviado_at desc
  ) x), '[]'::jsonb),
  'privados', coalesce((select jsonb_agg(to_jsonb(x)) from (
      select pago_id,motivo_rechazo,captura_path,captura_sha256,metadata_ocr from public.pagos_privados
  ) x), '[]'::jsonb),
  'gastos', coalesce((select jsonb_agg(to_jsonb(x) order by x.registrado_at desc) from (
      select * from public.gastos order by registrado_at desc
  ) x), '[]'::jsonb),
  'actas', coalesce((select jsonb_agg(to_jsonb(x) order by x.cerrado_at desc) from (
      select * from public.actas order by cerrado_at desc
  ) x), '[]'::jsonb),
  'detalle_publico', coalesce((select jsonb_agg(to_jsonb(x)) from (
      select acta_id,socio_numero,estado from public.acta_detalle_publico
  ) x), '[]'::jsonb),
  'detalle_privado', coalesce((select jsonb_agg(to_jsonb(x)) from (
      select acta_id,socio_numero,nombre_snapshot,estado,medio,monto_centavos from public.acta_detalle
  ) x), '[]'::jsonb),
  'bitacora', coalesce((select jsonb_agg(to_jsonb(x) order by x.creado_at desc) from (
      select * from public.bitacora order by creado_at desc limit 120
  ) x), '[]'::jsonb),
  'yape_config', coalesce((select jsonb_agg(to_jsonb(x)) from (
      select numero_yape,actualizado_at from public.yape_config where id='principal' limit 1
  ) x), '[]'::jsonb),
  'reseteos', coalesce((select jsonb_agg(to_jsonb(x) order by x.vence_at desc) from (
      select socio_numero,vence_at,usado_at,cancelado_at from public.reseteos_contrasena order by vence_at desc
  ) x), '[]'::jsonb),
  'servidor_at', now()
);
$function$;

revoke all on function public.cargar_app_snapshot_v1() from public, anon;
grant execute on function public.cargar_app_snapshot_v1() to authenticated;
