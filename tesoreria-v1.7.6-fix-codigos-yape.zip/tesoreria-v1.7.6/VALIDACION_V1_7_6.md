# Validación v1.7.6

- `versionCode 33`, `versionName 1.7.6`.
- El servidor Supabase recibió la migración de permisos para `service_role`.
- Se comprobó dentro de una transacción con rollback que `service_role` puede insertar en `codigos_activacion_masivos`.
- No se dejó ningún código de prueba en producción.
- La Edge Function `codigos-masivos` está activa en versión 2.
- El visor de comprobante conjunto calcula el total como monto individual × cantidad de números incluidos.
- El campo de cantidad de códigos inicia vacío y el botón solo se habilita con un valor entre 1 y 30.
- La lista de códigos muestra disponibles, usados por número, vencidos y cancelados.
