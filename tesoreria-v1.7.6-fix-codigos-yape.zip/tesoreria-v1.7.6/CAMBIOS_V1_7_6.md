# Tesorería v1.7.6

- Corrige la generación masiva de códigos en Supabase (permisos del service role).
- La cantidad se escribe manualmente; no se generan códigos hasta tocar “Generar códigos”.
- El botón de generación ocupa el ancho completo.
- Códigos masivos: 6 dígitos, 6 horas, un uso, solo primera activación.
- Historial visible: disponible, usado por N.º, vencido o cancelado.
- “Copiar todos los disponibles” copia únicamente códigos todavía utilizables.
- El visor de Yape conjunto muestra números incluidos, cantidad de personas, monto individual y total real del grupo.
