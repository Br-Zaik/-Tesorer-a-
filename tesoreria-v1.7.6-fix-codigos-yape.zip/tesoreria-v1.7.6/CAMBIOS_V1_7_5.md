# Tesorería v1.7.5 — códigos masivos y pagos en conjunto

Versión Android: `1.7.5` (`versionCode 32`).

## Códigos masivos de activación

- Nuevo bloque al final del panel del tesorero.
- Genera hasta 30 códigos genéricos numéricos de 6 dígitos.
- No están ligados a un número de lista.
- Validez: 6 horas desde que se genera cada código.
- Un solo uso: el servidor reserva el código de forma atómica y, tras una activación correcta, queda consumido.
- Si la creación de la cuenta falla, la reserva se libera para no perder el código por un error técnico.
- Solo sirven para primera activación de cuentas que todavía no tienen usuario Auth.
- Las cuentas ya creadas siguen usando el código individual de 24 h para restablecer contraseña.
- El tesorero puede ver los códigos todavía disponibles y copiar todos de una vez.

## Pago manual en conjunto

- La ventana “Registrar pago manual” ahora permite alternar entre “Un pago” y “Pagar en conjunto”.
- Se pueden seleccionar varios números antes de confirmar.
- El servidor valida el grupo completo antes de registrar nada.
- Cada integrante conserva su propio registro de pago para mantener actas, recaudación y estados por socio.
- La ventana permanece abierta después de registrar para seguir cobrando rápidamente.

## Yape en conjunto

- El socio que sube el comprobante puede agregar otros números al mismo pago.
- Su propio número siempre queda incluido.
- Se sube una sola imagen y se crea un grupo común en el servidor.
- En el panel de revisión se muestra quién envió el Yape y todos los números incluidos.
- Aprobar o rechazar el grupo aplica la decisión a todos sus integrantes en una sola operación.
- No se puede incluir a un socio que ya tenga el cobro aprobado o pendiente.

## Presencia del panel

- El tesorero conserva el estado en línea del servidor.
- Cuando un usuario ya no está en línea, el panel muestra “Activo hace X min/h/d” usando `ultima_actividad` de Supabase.
- “Sin activar”, bloqueados y plazas libres siguen diferenciados.
