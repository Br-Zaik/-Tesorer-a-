package com.tesoreria.caja.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.Cobro
import com.tesoreria.caja.data.EstadoConexionMiembro
import com.tesoreria.caja.data.EstadoCodigoMasivo
import com.tesoreria.caja.data.EstadoMiembro
import com.tesoreria.caja.data.MedioPago
import com.tesoreria.caja.data.Pago
import com.tesoreria.caja.data.Permiso
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.data.TipoCobro
import com.tesoreria.caja.data.fechaHora
import com.tesoreria.caja.data.parseCentavos
import com.tesoreria.caja.data.soles
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PantallaPanel() {
    val yo = Caja.sesion.value ?: return
    if (!Caja.puedeAbrirPanel(yo)) {
        Tarjeta {
            Titulo("Sin permisos administrativos")
            Spacer(Modifier.height(6.dp))
            Text("Tu rol actual no tiene herramientas asignadas.", color = Tenue, fontSize = 12.sp)
        }
        return
    }

    var seccion by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxWidth()) {
        Etiqueta("ADMINISTRACIÓN")
        Spacer(Modifier.height(5.dp))
        Titulo(if (yo.rol == Rol.TESORERO) "Panel del tesorero" else "Panel administrativo")
        Spacer(Modifier.height(4.dp))
        Spacer(Modifier.height(12.dp))

        SelectorAdmin(seccion) { seccion = it }
        Spacer(Modifier.height(12.dp))
        when (seccion) {
            0 -> PagosAdmin()
            1 -> CobroAdmin()
            2 -> GastosAdmin()
            3 -> YapeAdmin()
            else -> MiembrosAdmin()
        }
    }
}

@Composable
private fun PagosAdmin() {
    val yo = Caja.sesion.value
    val puedeManual = Caja.tienePermiso(yo, Permiso.REGISTRAR_PAGO_MANUAL)
    val puedeYape = Caja.tienePermiso(yo, Permiso.GESTIONAR_YAPE)
    if (!puedeManual && !puedeYape) { SinPermiso(); return }

    var mostrarManual by remember { mutableStateOf(false) }
    var corregir by remember { mutableStateOf<Pago?>(null) }
    var rechazar by remember { mutableStateOf<Pago?>(null) }
    var rechazarGrupo by remember { mutableStateOf<Pair<String, List<Pago>>?>(null) }
    var verComprobante by remember { mutableStateOf<Pago?>(null) }

    if (puedeManual) {
        Boton("Registrar pago manual", Modifier.fillMaxWidth(), color = Verde) { mostrarManual = true }
        Spacer(Modifier.height(12.dp))
    }

    if (puedeYape) {
        Etiqueta("YAPES POR REVISAR", Ambar)
        Spacer(Modifier.height(8.dp))
        val pendientes = Caja.pendientes()
        val grupos = pendientes.groupBy { p -> p.grupoId.takeIf { it.isNotBlank() } ?: "p:${p.serverId}" }
        if (grupos.isEmpty()) Vacio("No hay comprobantes por revisar.")

        grupos.values.sortedByDescending { g -> g.maxOfOrNull { it.enviado } ?: 0L }.forEach { grupo ->
            val rep = grupo.firstOrNull { it.capturaPath.isNotBlank() } ?: grupo.first()
            val cobro = Caja.cobros.firstOrNull { it.id == rep.cobroId }
            val esGrupo = rep.grupoId.isNotBlank() && (rep.grupoNumeros.size > 1 || grupo.size > 1)
            val numeros = if (rep.grupoNumeros.isNotEmpty()) rep.grupoNumeros else grupo.map { it.socio }.distinct().sorted()
            val pagador = rep.pagadorNumero ?: rep.socio
            val fuera = cobro != null && rep.enviado > cobro.cierra
            Tarjeta(borde = if (fuera) Ambar.copy(alpha = .55f) else Borde) {
                FilaEntre {
                    Column(Modifier.weight(1f)) {
                        Etiqueta(if (esGrupo) "YAPE EN CONJUNTO" else "N.º ${rep.socio} · YAPE")
                        Spacer(Modifier.height(3.dp))
                        if (esGrupo) {
                            Text("Enviado por N.º $pagador · ${Caja.socio(pagador)?.nombre.orEmpty()}", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(3.dp))
                            Text("Incluye: ${numeros.joinToString(", ") { it.toString().padStart(2, '0') }}", color = Cian, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        } else {
                            Text(Caja.socio(rep.socio)?.nombre.orEmpty(), color = Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                        cobro?.let { c ->
                            Spacer(Modifier.height(3.dp))
                            Text("${if (c.tipo == TipoCobro.RAPIDO) "Rápido" else "Oficial"} · ${c.titulo}", color = if (c.tipo == TipoCobro.RAPIDO) Ambar else Cian, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Text(soles(grupo.sumOf { it.monto }), color = Verde, fontSize = 17.sp, style = cifra)
                }
                Spacer(Modifier.height(6.dp))
                Text(fechaHora(rep.enviado), color = Tenue, fontSize = 10.sp)
                if (fuera) { Spacer(Modifier.height(7.dp)); Pastilla("Fuera del plazo", Ambar) }
                if (rep.capturaPath.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Boton("Ver comprobante", Modifier.fillMaxWidth(), relleno = false, color = Cian) { verComprobante = rep }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Boton("Aprobar", Modifier.weight(1f), color = Verde) {
                        if (esGrupo) Caja.aprobarGrupoYape(rep.grupoId) else Caja.aprobarPago(rep.id)
                    }
                    Boton("Rechazar", Modifier.weight(1f), relleno = false, color = Rojo) {
                        if (esGrupo) rechazarGrupo = rep.grupoId to grupo else rechazar = rep
                    }
                    if (!esGrupo) Boton("Corregir", Modifier.weight(1f), relleno = false, color = Ambar) { corregir = rep }
                }
            }
            Spacer(Modifier.height(9.dp))
        }
    }

    if (mostrarManual) Dialog(onDismissRequest = { mostrarManual = false }) { PagoManualDialog { mostrarManual = false } }
    corregir?.let { p -> Dialog(onDismissRequest = { corregir = null }) { CorregirPagoDialog(p) { corregir = null } } }
    rechazar?.let { p -> Dialog(onDismissRequest = { rechazar = null }) { RechazarDialog(p) { rechazar = null } } }
    rechazarGrupo?.let { item -> Dialog(onDismissRequest = { rechazarGrupo = null }) { RechazarGrupoDialog(item.first, item.second) { rechazarGrupo = null } } }
    verComprobante?.let { p -> VisorPagoDialog(p) { verComprobante = null } }
}

@Composable
private fun PagoManualDialog(cerrar: () -> Unit) {
    val activos = Caja.cobrosActivos()
    var cobroId by remember { mutableStateOf<Int?>(activos.firstOrNull()?.id) }
    val cobro = activos.firstOrNull { it.id == cobroId }
    var buscar by remember { mutableStateOf("") }
    var enConjunto by remember { mutableStateOf(false) }
    var seleccionados by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var aviso by remember { mutableStateOf("") }
    var guardando by remember { mutableStateOf(false) }
    val focusBuscar = remember { FocusRequester() }
    val q = buscar.trim()
    val resultados = if (q.isBlank()) emptyList() else Caja.socios.filter {
        it.estado != EstadoMiembro.RETIRADO && (it.numero.toString() == q || it.nombre.contains(q, ignoreCase = true))
    }.take(8)

    Tarjeta(borde = Verde.copy(alpha = .5f), fondo = PanelAlto) {
        Etiqueta("REGISTRAR PAGO MANUAL", Verde)
        Spacer(Modifier.height(10.dp))

        if (activos.isEmpty()) {
            Vacio("No hay cobros activos.")
        } else {
            Etiqueta("ELIGE EL COBRO")
            Spacer(Modifier.height(6.dp))
            activos.forEach { c ->
                val elegido = c.id == cobroId
                val color = if (c.tipo == TipoCobro.RAPIDO) Ambar else Verde
                Row(
                    Modifier.fillMaxWidth()
                        .background(if (elegido) color.copy(alpha = .12f) else Fondo, RoundedCornerShape(11.dp))
                        .border(BorderStroke(1.dp, if (elegido) color.copy(alpha = .55f) else Borde), RoundedCornerShape(11.dp))
                        .clickable { cobroId = c.id; seleccionados = emptySet(); aviso = "" }
                        .padding(horizontal = 11.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(if (c.tipo == TipoCobro.RAPIDO) "Rápido · ${c.titulo}" else "Oficial · ${c.titulo}", color = Texto, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(2.dp)); Text(soles(c.monto), color = color, fontSize = 11.sp)
                    }
                    if (elegido) Pastilla("Elegido", color)
                }
                Spacer(Modifier.height(5.dp))
            }

            Spacer(Modifier.height(7.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Pestana("Un pago", !enConjunto, Verde, Modifier.weight(1f)) { enConjunto = false; seleccionados = seleccionados.firstOrNull()?.let { setOf(it) } ?: emptySet(); aviso = "" }
                Pestana("Pagar en conjunto", enConjunto, Cian, Modifier.weight(1f)) { enConjunto = true; aviso = "" }
            }
            Spacer(Modifier.height(8.dp))
            Campo(buscar, { buscar = it; aviso = "" }, if (enConjunto) "Agregar número o nombre" else "Número o nombre", focusRequester = focusBuscar)

            if (resultados.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                resultados.forEach { socio ->
                    val elegido = socio.numero in seleccionados
                    Row(
                        Modifier.fillMaxWidth().background(if (elegido) Verde.copy(alpha = .11f) else Fondo, RoundedCornerShape(10.dp))
                            .border(BorderStroke(1.dp, if (elegido) Verde.copy(alpha = .45f) else Borde), RoundedCornerShape(10.dp))
                            .clickable {
                                seleccionados = if (enConjunto) {
                                    if (elegido) seleccionados - socio.numero else seleccionados + socio.numero
                                } else setOf(socio.numero)
                                buscar = ""; aviso = ""
                            }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(socio.numero.toString().padStart(2, '0'), color = Verde, fontSize = 13.sp, style = cifra)
                        Spacer(Modifier.width(10.dp))
                        Text(socio.nombre, color = Texto, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        if (elegido) Pastilla("Incluido", Verde)
                    }
                    Spacer(Modifier.height(5.dp))
                }
            }

            if (seleccionados.isNotEmpty()) {
                Spacer(Modifier.height(9.dp))
                Etiqueta(if (seleccionados.size > 1) "INCLUIDOS · ${seleccionados.size}" else "SELECCIONADO", if (seleccionados.size > 1) Cian else Verde)
                Spacer(Modifier.height(5.dp))
                seleccionados.sorted().forEach { n ->
                    val socio = Caja.socio(n)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("${n.toString().padStart(2, '0')} · ${socio?.nombre.orEmpty()}", color = Texto, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        if (enConjunto) Text("Quitar", color = Rojo, fontSize = 10.sp, modifier = Modifier.clickable { seleccionados = seleccionados - n })
                    }
                    Spacer(Modifier.height(3.dp))
                }
                cobro?.let { c ->
                    Spacer(Modifier.height(4.dp))
                    Text("Total registrado: ${soles(c.monto * seleccionados.size)}", color = if (c.tipo == TipoCobro.RAPIDO) Ambar else Verde, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        if (aviso.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(aviso, color = when { aviso.startsWith("✓") -> Verde; guardando -> Ambar; else -> Rojo }, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(14.dp))
        Boton(
            if (guardando) "Registrando…" else if (seleccionados.size > 1) "✓ Confirmar ${seleccionados.size} pagos" else "✓ Confirmar pago manual",
            Modifier.fillMaxWidth(), color = Verde,
            activo = seleccionados.isNotEmpty() && cobro != null && !guardando
        ) {
            val c = cobro
            val nums = seleccionados.sorted()
            if (c == null) aviso = "Selecciona el cobro"
            else if (nums.isEmpty()) aviso = "Selecciona a la persona"
            else {
                guardando = true; aviso = "Registrando pago…"
                val fin: (Boolean, String) -> Unit = { ok, mensaje ->
                    guardando = false
                    if (ok) {
                        aviso = if (nums.size > 1) "✓ ${nums.size} pagos registrados" else "✓ Pago registrado · N.º ${nums.first()}"
                        buscar = ""; seleccionados = emptySet(); focusBuscar.requestFocus()
                    } else aviso = mensaje.ifBlank { "No se pudo registrar el pago" }
                }
                if (nums.size > 1 || enConjunto) Caja.registrarPagoManualGrupo(c.id, nums, fin)
                else Caja.registrarPagoManual(c.id, nums.first(), c.monto, fin)
            }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
}

@Composable
private fun CorregirPagoDialog(pago: Pago, cerrar: () -> Unit) {
    var destino by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    val n = destino.toIntOrNull()
    val s = n?.let(Caja::socio)
    Tarjeta(borde = Ambar.copy(alpha = .5f), fondo = PanelAlto) {
        Etiqueta("CORREGIR PERSONA DEL PAGO", Ambar)
        Spacer(Modifier.height(7.dp))
        Text("Ahora está asignado al N.º ${pago.socio} · ${Caja.socio(pago.socio)?.nombre}", color = Texto, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Campo(destino, { destino = it.filter(Char::isDigit).take(2); aviso = "" }, "Número correcto", numerico = true)
        if (s != null) {
            Spacer(Modifier.height(9.dp))
            Text("¿Es ${s.nombre}?", color = Texto, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("N.º ${s.numero}", color = Tenue, fontSize = 11.sp)
        }
        if (aviso.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(aviso, color = Rojo, fontSize = 11.sp) }
        Spacer(Modifier.height(14.dp))
        Boton("Sí, corregir asignación", Modifier.fillMaxWidth(), color = Ambar, activo = s != null && n != pago.socio) {
            if (n == null || s == null) aviso = "Selecciona un número válido" else { Caja.corregirAsignacionPago(pago.id, n); cerrar() }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
}

@Composable
private fun RechazarDialog(pago: Pago, cerrar: () -> Unit) {
    var motivo by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    Tarjeta(borde = Rojo.copy(alpha = .45f), fondo = PanelAlto) {
        Etiqueta("RECHAZAR YAPE", Rojo)
        Spacer(Modifier.height(8.dp))
        Text("N.º ${pago.socio} · ${Caja.socio(pago.socio)?.nombre}", color = Texto, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Campo(motivo, { motivo = it; aviso = "" }, "Motivo")
        if (aviso.isNotEmpty()) { Spacer(Modifier.height(7.dp)); Text(aviso, color = Rojo, fontSize = 11.sp) }
        Spacer(Modifier.height(12.dp))
        Boton("Confirmar rechazo", Modifier.fillMaxWidth(), color = Rojo) {
            if (motivo.trim().length < 4) aviso = "Escribe un motivo claro" else { Caja.rechazarPago(pago.id, motivo); cerrar() }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
}

@Composable
private fun RechazarGrupoDialog(grupoId: String, pagos: List<Pago>, cerrar: () -> Unit) {
    var motivo by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    val numeros = pagos.flatMap { if (it.grupoNumeros.isNotEmpty()) it.grupoNumeros else listOf(it.socio) }.distinct().sorted()
    Tarjeta(borde = Rojo.copy(alpha = .45f), fondo = PanelAlto) {
        Etiqueta("RECHAZAR YAPE EN CONJUNTO", Rojo)
        Spacer(Modifier.height(8.dp))
        Text("Incluye N.º ${numeros.joinToString(", ")}", color = Texto, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Campo(motivo, { motivo = it; aviso = "" }, "Motivo")
        if (aviso.isNotEmpty()) { Spacer(Modifier.height(7.dp)); Text(aviso, color = Rojo, fontSize = 11.sp) }
        Spacer(Modifier.height(12.dp))
        Boton("Confirmar rechazo", Modifier.fillMaxWidth(), color = Rojo) {
            if (motivo.trim().length < 4) aviso = "Escribe un motivo claro" else { Caja.rechazarGrupoYape(grupoId, motivo); cerrar() }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
}

@Composable
private fun CobroAdmin() {
    val yo = Caja.sesion.value
    if (!(Caja.tienePermiso(yo, Permiso.GESTIONAR_COBROS) || Caja.esAdmin)) {
        SinPermiso()
        return
    }

    val activos = Caja.cobrosActivos()
    var titulo by remember { mutableStateOf("") }
    var monto by remember { mutableStateOf("") }
    var duracion by remember { mutableStateOf("60") }
    var enHoras by remember { mutableStateOf(false) }
    var tipo by remember { mutableStateOf(TipoCobro.OFICIAL) }
    var aviso by remember { mutableStateOf("") }
    var ajustar by remember { mutableStateOf<Cobro?>(null) }
    var cerrar by remember { mutableStateOf<Cobro?>(null) }

    if (activos.isNotEmpty()) {
        Etiqueta("COBROS ACTIVOS")
        Spacer(Modifier.height(8.dp))
        activos.forEach { c ->
            val color = if (c.tipo == TipoCobro.RAPIDO) Ambar else Verde
            Tarjeta(borde = color.copy(alpha = .48f), fondo = PanelAlto) {
                FilaEntre {
                    Column(Modifier.weight(1f)) {
                        Etiqueta(if (c.tipo == TipoCobro.RAPIDO) "COBRO RÁPIDO" else "COBRO OFICIAL", color)
                        Spacer(Modifier.height(3.dp))
                        Text(c.titulo, color = Texto, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(soles(c.monto), color = color, fontSize = 17.sp, style = cifra)
                }
                Spacer(Modifier.height(6.dp))
                Text("Cierra ${fechaHora(c.cierra)}", color = Tenue, fontSize = 11.sp)
                if (c.extensionTexto.isNotBlank()) {
                    Spacer(Modifier.height(6.dp)); Pastilla(c.extensionTexto, Ambar)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Boton("Ajustar plazo", Modifier.weight(1f), relleno = false, color = color) { ajustar = c }
                    Boton("Cerrar", Modifier.weight(1f), relleno = false, color = Rojo) { cerrar = c }
                }
            }
            Spacer(Modifier.height(9.dp))
        }
    }

    Tarjeta(borde = if (tipo == TipoCobro.RAPIDO) Ambar.copy(alpha=.4f) else Verde.copy(alpha=.35f)) {
        Titulo("Abrir nuevo cobro")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pestana("Oficial", tipo == TipoCobro.OFICIAL, Verde, Modifier.weight(1f)) { tipo = TipoCobro.OFICIAL; aviso = "" }
            Pestana("Rápido", tipo == TipoCobro.RAPIDO, Ambar, Modifier.weight(1f)) { tipo = TipoCobro.RAPIDO; aviso = "" }
        }
        Spacer(Modifier.height(10.dp))
        Campo(titulo, { titulo = it; aviso = "" }, if (tipo == TipoCobro.RAPIDO) "Ej. Copias" else "Concepto")
        Spacer(Modifier.height(8.dp))
        Campo(monto, { monto = it; aviso = "" }, "Monto · 1.00", numerico = true)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { Campo(duracion, { duracion = it.filter(Char::isDigit).take(5); aviso = "" }, if (enHoras) "Horas" else "Minutos", numerico = true) }
            Boton(if (enHoras) "Horas" else "Minutos", Modifier.width(112.dp), relleno = false, color = if (tipo == TipoCobro.RAPIDO) Ambar else Verde) { enHoras = !enHoras }
        }
        if (aviso.isNotBlank()) { Spacer(Modifier.height(7.dp)); Text(aviso, color = Rojo, fontSize = 11.sp) }
        Spacer(Modifier.height(11.dp))
        Boton(if (tipo == TipoCobro.RAPIDO) "Abrir cobro rápido" else "Abrir cobro oficial", Modifier.fillMaxWidth(), color = if (tipo == TipoCobro.RAPIDO) Ambar else Verde) {
            val c = parseCentavos(monto) ?: 0L
            val d = duracion.toIntOrNull() ?: 0
            val minutos = if (enHoras) d * 60 else d
            when {
                titulo.trim().length < 2 -> aviso = "Falta el concepto"
                c <= 0 -> aviso = "Monto inválido"
                minutos <= 0 -> aviso = "Duración inválida"
                activos.size >= 3 -> aviso = "Ya hay 3 cobros activos"
                tipo == TipoCobro.OFICIAL && activos.any { it.tipo == TipoCobro.OFICIAL } -> aviso = "Ya existe un cobro oficial activo"
                else -> {
                    Caja.crearCobro(titulo.trim(), c, minutos, tipo)
                    titulo = ""; monto = ""; duracion = if (tipo == TipoCobro.RAPIDO) "15" else "60"; aviso = ""
                }
            }
        }
    }

    ajustar?.let { cobro -> Dialog(onDismissRequest = { ajustar = null }) {
        var extra by remember(cobro.id) { mutableStateOf("10") }
        var avisoExt by remember { mutableStateOf("") }
        Tarjeta(borde = (if (cobro.tipo == TipoCobro.RAPIDO) Ambar else Verde).copy(alpha=.5f), fondo = PanelAlto) {
            Etiqueta("AJUSTAR PLAZO", if (cobro.tipo == TipoCobro.RAPIDO) Ambar else Verde)
            Spacer(Modifier.height(6.dp))
            Text("Cierre actual: ${fechaHora(cobro.cierra)}", color = Texto, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                Boton("-10 min", Modifier.weight(1f), relleno = false, color = Ambar) { extra = (((extra.toIntOrNull() ?: 0) - 10).coerceAtLeast(-999)).toString() }
                Boton("+10 min", Modifier.weight(1f), relleno = false, color = Verde) { extra = (((extra.toIntOrNull() ?: 0) + 10).coerceAtMost(999)).toString() }
            }
            Spacer(Modifier.height(7.dp))
            Campo(extra, { extra = it.filter { ch -> ch.isDigit() || ch == '-' }.take(4); avisoExt = "" }, "Minutos (+ / -)", numerico = true)
            if (avisoExt.isNotEmpty()) { Spacer(Modifier.height(6.dp)); Text(avisoExt, color = Rojo, fontSize = 11.sp) }
            Spacer(Modifier.height(11.dp))
            Boton("Guardar plazo", Modifier.fillMaxWidth(), color = Verde) {
                val m = extra.toIntOrNull() ?: 0
                if (m == 0) avisoExt = "Escribe un ajuste válido" else if (cobro.cierra + m * 60_000L <= System.currentTimeMillis() + 60_000L) avisoExt = "El cierre debe quedar en el futuro"
                else { Caja.ajustarCobro(cobro.id, m); ajustar = null }
            }
            Spacer(Modifier.height(7.dp)); Boton("Cancelar", Modifier.fillMaxWidth(), relleno=false, color=Tenue) { ajustar=null }
        }
    } }

    cerrar?.let { cobro -> Dialog(onDismissRequest = { cerrar = null }) {
        Tarjeta(borde = Rojo.copy(alpha=.45f), fondo=PanelAlto) {
            Titulo(if (cobro.tipo == TipoCobro.RAPIDO) "¿Cerrar cobro rápido?" else "¿Cerrar cobro oficial?")
            Spacer(Modifier.height(8.dp))
            Text(if (cobro.tipo == TipoCobro.RAPIDO) "Se generará un resumen para descargar en PDF." else "Se guardará el acta con el estado actual.", color=Tenue, fontSize=12.sp)
            Spacer(Modifier.height(12.dp))
            Boton("Sí, cerrar", Modifier.fillMaxWidth(), color=Rojo) { Caja.cerrarCobro(cobro.id); cerrar=null }
            Spacer(Modifier.height(7.dp)); Boton("Cancelar", Modifier.fillMaxWidth(), relleno=false, color=Tenue) { cerrar=null }
        }
    } }
}

@Composable
private fun GastosAdmin() {
    val yo = Caja.sesion.value
    if (!(Caja.tienePermiso(yo, Permiso.REGISTRAR_GASTOS) || Caja.esAdmin)) {
        SinPermiso()
        return
    }
    var concepto by remember { mutableStateOf("") }
    var monto by remember { mutableStateOf("") }
    var aviso by remember { mutableStateOf("") }
    Tarjeta {
        Titulo("Registrar gasto")
        Spacer(Modifier.height(6.dp))
        Text("El gasto se registra directamente. No requiere firma del presidente.", color = Tenue, fontSize = 11.sp)
        Spacer(Modifier.height(11.dp))
        Campo(concepto, { concepto = it; aviso = "" }, "Concepto")
        Spacer(Modifier.height(9.dp))
        Campo(monto, { monto = it; aviso = "" }, "Monto", numerico = true)
        if (aviso.isNotEmpty()) { Spacer(Modifier.height(7.dp)); Text(aviso, color = Rojo, fontSize = 11.sp) }
        Spacer(Modifier.height(12.dp))
        Boton("Registrar gasto", Modifier.fillMaxWidth(), color = Ambar) {
            val c = parseCentavos(monto) ?: 0L
            when { concepto.isBlank() -> aviso = "Falta concepto"; c <= 0 -> aviso = "Monto inválido"; c > Caja.disponibleParaGastos() -> aviso = "No alcanza: ${soles(Caja.disponibleParaGastos())}"; else -> { Caja.crearGasto(concepto.trim(), c); concepto = ""; monto = "" } }
        }
    }
}

@Composable
private fun YapeAdmin() {
    if (!Caja.tienePermiso(Caja.sesion.value, Permiso.GESTIONAR_YAPE)) { SinPermiso(); return }
    val config = Caja.yapeConfig.value
    var numero by remember(config.numeroYape) { mutableStateOf(config.numeroYape) }
    var guardando by remember { mutableStateOf(false) }
    var estado by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Tarjeta(borde = Verde.copy(alpha = .35f), fondo = PanelAlto) {
        Etiqueta("NÚMERO YAPE", Verde)
        Spacer(Modifier.height(10.dp))
        Campo(numero, { numero = it.filter(Char::isDigit).take(9); estado = "" }, "Ej. 987654765", numerico = true)
        if (estado.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(estado, color = if (estado.startsWith("✓")) Verde else if (guardando) Ambar else Rojo, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(13.dp))
        Boton(if (guardando) "Guardando…" else "Guardar número Yape", Modifier.fillMaxWidth(), color = Verde, activo = numero.trim().length == 9 && !guardando) {
            guardando = true; estado = "Guardando…"
            Caja.guardarConfigYape(numero) { ok, msg ->
                guardando = false
                estado = if (ok) "✓ Guardado" else msg
                if (ok) scope.launch { kotlinx.coroutines.delay(1600); if (estado == "✓ Guardado") estado = "" }
            }
        }
    }
}

@Composable
private fun MiembrosAdmin() {
    val clipboard = LocalClipboardManager.current
    if (!Caja.esAdmin) {
        Vacio("Solo el tesorero puede gestionar miembros y roles.")
        return
    }
    var invitar by remember { mutableStateOf<Int?>(null) }
    var editar by remember { mutableStateOf<Int?>(null) }
    var liberar by remember { mutableStateOf<Int?>(null) }
    var cantidadCodigos by remember { mutableStateOf("") }
    var estadoCodigos by remember { mutableStateOf("") }
    var codigosCopiados by remember { mutableStateOf(false) }

    LaunchedEffect(Caja.conectado.value) {
        if (Caja.conectado.value) {
            while (true) {
                Caja.refrescarPresenciasAdmin()
                delay(4_000)
            }
        }
    }

    LaunchedEffect(Caja.conectado.value) {
        if (Caja.conectado.value) {
            while (true) {
                try { Caja.cargarCodigosMasivos() } catch (_: Exception) {}
                delay(12_000)
            }
        }
    }

    Tarjeta(fondo = PanelAlto) {
        Etiqueta("PLAZAS 1–35")
    }
    Spacer(Modifier.height(10.dp))

    (1..35).forEach { numero ->
        val s = Caja.socio(numero)
        Tarjeta(borde = if (s == null) Borde else if (s.estado == EstadoMiembro.BLOQUEADO) Rojo.copy(alpha = .4f) else Borde) {
            FilaEntre {
                Column(Modifier.weight(1f)) {
                    Text(if (s == null) "${numero.toString().padStart(2, '0')} · PLAZA LIBRE" else "${numero.toString().padStart(2, '0')} · ${s.nombre}", color = Texto, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(4.dp))
                    if (s == null) {
                        Text("Bloqueada hasta invitación", color = Tenue, fontSize = 9.sp)
                    } else {
                        val presencia = Caja.presencias[numero]
                        val (textoConexion, colorConexion) = if (!Caja.presenciasCargadas.value) {
                            "● Consultando…" to Tenue
                        } else {
                            val estadoConexion = presencia?.estado ?: if (s.estado == EstadoMiembro.BLOQUEADO) EstadoConexionMiembro.BLOQUEADO else EstadoConexionMiembro.DESCONECTADO
                            when (estadoConexion) {
                                EstadoConexionMiembro.CONECTADO -> "● En línea" to VerdeBrillante
                                EstadoConexionMiembro.DESCONECTADO -> {
                                    val ultima = presencia?.ultimaActividad
                                    (if (ultima != null) "● Activo ${tiempoDesde(ultima)}" else "● Desconectado") to Rojo
                                }
                                EstadoConexionMiembro.SIN_ACTIVAR -> "● Sin activar" to Ambar
                                EstadoConexionMiembro.BLOQUEADO -> "● Bloqueado" to Tenue
                                EstadoConexionMiembro.LIBRE -> "● Libre" to Tenue
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "${s.rol.name.lowercase().replaceFirstChar { it.uppercase() }} · ${s.estado.name.lowercase().replaceFirstChar { it.uppercase() }}",
                                color = if (s.estado == EstadoMiembro.BLOQUEADO) Rojo else Verde,
                                fontSize = 9.sp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(textoConexion, color = colorConexion, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                when {
                    s == null -> Boton("Invitar", Modifier.width(84.dp), color = Verde, relleno = false) { invitar = numero }
                    s.rol != Rol.TESORERO -> Boton("Gestionar", Modifier.width(98.dp), color = Cian, relleno = false) { editar = numero }
                }
            }
            if (s != null && s.rol != Rol.TESORERO) {
                Spacer(Modifier.height(7.dp))
                val activo = Caja.reseteoAbierto(numero)
                Boton(if (activo) "Mostrar código" else "Generar código 24 h", Modifier.fillMaxWidth(), relleno = false, color = Ambar) {
                    Caja.ultimoCodigoTemporal.value = Caja.codigoLocal(numero)
                    Caja.codigoTemporalPara.value = numero
                    if (activo && Caja.ultimoCodigoTemporal.value.isNullOrBlank()) Caja.resetear(numero)
                    liberar = numero
                }
                if (activo) {
                    Spacer(Modifier.height(5.dp))
                    val min = (Caja.horasDeReseteo(numero) / 60000L).coerceAtLeast(0L)
                    Text("Código activo · vence en ${min / 60} h ${min % 60} min", color = Ambar, fontSize = 9.sp)
                }
            }
        }
        Spacer(Modifier.height(7.dp))
    }

    Spacer(Modifier.height(8.dp))
    Tarjeta(borde = Ambar.copy(alpha = .45f), fondo = PanelAlto) {
        Etiqueta("CÓDIGOS MASIVOS DE ACTIVACIÓN", Ambar)
        Spacer(Modifier.height(5.dp))
        Text("6 dígitos · 6 horas · un solo uso · solo cuentas nuevas", color = Tenue, fontSize = 10.sp)
        Spacer(Modifier.height(10.dp))

        Campo(
            valor = cantidadCodigos,
            alCambiar = { cantidadCodigos = it.filter(Char::isDigit).take(2); estadoCodigos = "" },
            pista = "Cantidad a generar · 1 a 30",
            numerico = true
        )
        Spacer(Modifier.height(9.dp))
        val cantidadValida = cantidadCodigos.toIntOrNull()?.takeIf { it in 1..30 }
        Boton(
            if (Caja.cargandoCodigosMasivos.value) "Generando…" else "Generar códigos",
            Modifier.fillMaxWidth(),
            color = Ambar,
            activo = cantidadValida != null && !Caja.cargandoCodigosMasivos.value
        ) {
            val cantidad = cantidadValida ?: return@Boton
            Caja.generarCodigosMasivos(cantidad) { ok, msg ->
                estadoCodigos = if (ok) "✓ $msg" else msg
                codigosCopiados = false
                if (ok) cantidadCodigos = ""
            }
        }

        val disponibles = Caja.codigosMasivos.filter { it.estado == EstadoCodigoMasivo.DISPONIBLE }
        val usados = Caja.codigosMasivos.count { it.estado == EstadoCodigoMasivo.USADO }
        val vencidos = Caja.codigosMasivos.count { it.estado == EstadoCodigoMasivo.VENCIDO }
        Spacer(Modifier.height(10.dp))
        Text(
            "Disponibles: ${disponibles.size}  ·  Usados: $usados  ·  Vencidos: $vencidos",
            color = if (disponibles.isNotEmpty()) VerdeBrillante else Tenue,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )

        if (disponibles.isNotEmpty()) {
            Spacer(Modifier.height(9.dp))
            Boton(if (codigosCopiados) "Disponibles copiados" else "Copiar todos los disponibles", Modifier.fillMaxWidth(), relleno = false, color = VerdeBrillante) {
                val texto = buildString {
                    append("Códigos Tesorería · 6 horas · un solo uso\n")
                    disponibles.forEach { append(it.codigo).append('\n') }
                }.trim()
                clipboard.setText(AnnotatedString(texto))
                codigosCopiados = true
            }
        }

        if (Caja.codigosMasivos.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Etiqueta("HISTORIAL DE CÓDIGOS", Cian)
            Spacer(Modifier.height(6.dp))
            Caja.codigosMasivos.take(60).forEach { c ->
                val (estadoTexto, estadoColor) = when (c.estado) {
                    EstadoCodigoMasivo.DISPONIBLE -> "Disponible" to VerdeBrillante
                    EstadoCodigoMasivo.USADO -> "Usado" to Cian
                    EstadoCodigoMasivo.VENCIDO -> "Vencido" to Tenue
                    EstadoCodigoMasivo.CANCELADO -> "Cancelado" to Rojo
                }
                Column(
                    Modifier.fillMaxWidth()
                        .background(FondoProfundo.copy(alpha = .52f), RoundedCornerShape(13.dp))
                        .border(1.dp, Borde.copy(alpha = .7f), RoundedCornerShape(13.dp))
                        .padding(horizontal = 12.dp, vertical = 9.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(c.codigo, color = Texto, fontSize = 18.sp, style = cifra, modifier = Modifier.weight(1f))
                        Pastilla(estadoTexto, estadoColor)
                    }
                    Spacer(Modifier.height(4.dp))
                    val detalle = when (c.estado) {
                        EstadoCodigoMasivo.DISPONIBLE -> "Vence ${tiempoHasta(c.vence)}"
                        EstadoCodigoMasivo.USADO -> {
                            val n = c.usadoPor?.toString()?.padStart(2, '0') ?: "--"
                            val cuando = c.usadoAt?.let { fechaHora(it) } ?: ""
                            "Usado por N.º $n${if (cuando.isNotBlank()) " · $cuando" else ""}"
                        }
                        EstadoCodigoMasivo.VENCIDO -> "Venció ${if (c.vence > 0L) fechaHora(c.vence) else ""}"
                        EstadoCodigoMasivo.CANCELADO -> "Código cancelado"
                    }
                    Text(detalle, color = estadoColor, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(6.dp))
            }
        } else {
            Spacer(Modifier.height(9.dp))
            Text("Todavía no hay códigos generados.", color = Tenue, fontSize = 10.sp)
        }

        if (estadoCodigos.isNotBlank()) {
            Spacer(Modifier.height(7.dp))
            Text(estadoCodigos, color = if (estadoCodigos.startsWith("✓")) Verde else Rojo, fontSize = 10.sp)
        }
    }
    Spacer(Modifier.height(8.dp))

    invitar?.let { n -> Dialog(onDismissRequest = { invitar = null }) { InvitarDialog(n) { invitar = null } } }
    editar?.let { n -> Dialog(onDismissRequest = { editar = null }) { GestionarMiembroDialog(n) { editar = null } } }
    liberar?.let { n -> Dialog(onDismissRequest = { liberar = null }) {
        val codigo = Caja.ultimoCodigoTemporal.value.takeIf { Caja.codigoTemporalPara.value == n }
        var copiado by remember(n, codigo) { mutableStateOf(false) }
        Tarjeta(borde = Ambar.copy(alpha = .45f), fondo = PanelAlto) {
            Etiqueta("CÓDIGO TEMPORAL", Ambar)
            Spacer(Modifier.height(6.dp))
            Text("N.º $n · ${Caja.socio(n)?.nombre}", color = Texto, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Text("El código dura 24 horas y sirve para activar o cambiar la contraseña desde la app.", color = Tenue, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            val activo = Caja.reseteoAbierto(n)
            if (!activo) {
                Boton("Generar código 24 h", Modifier.fillMaxWidth(), color = Ambar) { Caja.resetear(n) }
            } else if (codigo != null) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(codigo, color = VerdeBrillante, fontSize = 30.sp, style = cifra, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(10.dp))
                    Boton(if (copiado) "Copiado" else "Copiar", Modifier.width(92.dp), relleno = false, color = VerdeBrillante) {
                        clipboard.setText(AnnotatedString(codigo))
                        copiado = true
                    }
                }
                Spacer(Modifier.height(6.dp))
                val min = (Caja.horasDeReseteo(n) / 60000L).coerceAtLeast(0L)
                Text("Activo por ${min / 60} h ${min % 60} min más. Dale este código únicamente al socio N.º $n.", color = Tenue, fontSize = 10.sp)
            } else {
                Pastilla("Código activo", Ambar)
                Spacer(Modifier.height(6.dp))
                val min = (Caja.horasDeReseteo(n) / 60000L).coerceAtLeast(0L)
                Text("Recuperando código… · vence en ${min / 60} h ${min % 60} min", color = Tenue, fontSize = 10.sp)
            }
            Caja.ultimoError.value?.let { err -> Spacer(Modifier.height(8.dp)); Text(err, color = Rojo, fontSize = 10.sp) }
            Spacer(Modifier.height(10.dp))
            Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { liberar = null }
        }
    } }
}

private fun tiempoDesde(t: Long): String {
    val d = (System.currentTimeMillis() - t).coerceAtLeast(0L)
    val min = d / 60_000L
    return when {
        min < 1 -> "hace menos de 1 min"
        min < 60 -> "hace $min min"
        min < 24 * 60 -> "hace ${min / 60} h"
        else -> "hace ${min / (24 * 60)} d"
    }
}

private fun tiempoHasta(t: Long): String {
    val d = (t - System.currentTimeMillis()).coerceAtLeast(0L)
    val min = d / 60_000L
    return "en ${min / 60} h ${min % 60} min"
}

@Composable
private fun InvitarDialog(numero: Int, cerrar: () -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var rol by remember { mutableStateOf(Rol.SOCIO) }
    Tarjeta(borde = Verde.copy(alpha = .5f), fondo = PanelAlto) {
        Etiqueta("INVITAR EN PLAZA $numero", Verde)
        Spacer(Modifier.height(10.dp))
        Campo(nombre, { nombre = it }, "Nombre completo")
        Spacer(Modifier.height(10.dp))
        Text("Rol inicial", color = Tenue, fontSize = 10.sp)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pestana("Socio", rol == Rol.SOCIO, Verde, Modifier.weight(1f)) { rol = Rol.SOCIO }
            Pestana("Presidente", rol == Rol.PRESIDENTE, Verde, Modifier.weight(1f)) { rol = Rol.PRESIDENTE }
            Pestana("Personal", rol == Rol.PERSONALIZADO, Verde, Modifier.weight(1f)) { rol = Rol.PERSONALIZADO }
        }
        Spacer(Modifier.height(12.dp))
        Boton("Crear invitación", Modifier.fillMaxWidth(), color = Verde, activo = nombre.trim().length >= 3) { Caja.invitarMiembro(numero, nombre, rol, emptySet()); cerrar() }
        Spacer(Modifier.height(7.dp)); Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }
}

@Composable
private fun GestionarMiembroDialog(numero: Int, cerrar: () -> Unit) {
    val s = Caja.socio(numero) ?: return
    var nombre by remember(s) { mutableStateOf(s.nombre) }
    var rol by remember(s) { mutableStateOf(s.rol) }
    var manual by remember(s) { mutableStateOf(Permiso.REGISTRAR_PAGO_MANUAL in s.permisosExtra) }
    var cobros by remember(s) { mutableStateOf(Permiso.GESTIONAR_COBROS in s.permisosExtra) }
    var gastos by remember(s) { mutableStateOf(Permiso.REGISTRAR_GASTOS in s.permisosExtra) }
    var yape by remember(s) { mutableStateOf(Permiso.GESTIONAR_YAPE in s.permisosExtra) }
    var confirmarLiberar by remember { mutableStateOf(false) }
    var liberando by remember { mutableStateOf(false) }
    var avisoLiberar by remember { mutableStateOf("") }
    Tarjeta(borde = Cian.copy(alpha = .45f), fondo = PanelAlto) {
        Etiqueta("ROL Y ACCESO", Cian)
        Spacer(Modifier.height(5.dp))
        Text("N.º $numero", color = Texto, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        Etiqueta("NOMBRE")
        Spacer(Modifier.height(5.dp))
        Campo(nombre, { nombre = it.take(80) }, "Nombre completo")
        Spacer(Modifier.height(10.dp))
        Etiqueta("ROL")
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Pestana("Socio", rol == Rol.SOCIO, Cian, Modifier.weight(1f)) {
                rol = Rol.SOCIO; manual = false; cobros = false; gastos = false; yape = false
            }
            Pestana("Presid.", rol == Rol.PRESIDENTE, Cian, Modifier.weight(1f)) {
                rol = Rol.PRESIDENTE; manual = false; cobros = false; gastos = false; yape = false
            }
            Pestana("Personal", rol == Rol.PERSONALIZADO, Cian, Modifier.weight(1f)) { rol = Rol.PERSONALIZADO }
        }
        Spacer(Modifier.height(10.dp))
        PermisoToggle("Registrar pagos manuales", manual, rol == Rol.PERSONALIZADO) { manual = !manual }
        PermisoToggle("Gestionar cobros", cobros, rol == Rol.PERSONALIZADO) { cobros = !cobros }
        PermisoToggle("Registrar gastos", gastos, rol == Rol.PERSONALIZADO) { gastos = !gastos }
        PermisoToggle("Gestionar Yape", yape, rol == Rol.PERSONALIZADO) { yape = !yape }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Boton(if (s.estado == EstadoMiembro.BLOQUEADO) "Desbloquear" else "Bloquear", Modifier.weight(1f), relleno = false, color = if (s.estado == EstadoMiembro.BLOQUEADO) Verde else Rojo) {
                Caja.cambiarEstadoMiembro(numero, if (s.estado == EstadoMiembro.BLOQUEADO) EstadoMiembro.ACTIVO else EstadoMiembro.BLOQUEADO)
            }
            Boton("Guardar", Modifier.weight(1f), color = Cian, activo = nombre.trim().length >= 3) {
                val permisos = buildSet {
                    if (rol == Rol.PERSONALIZADO) {
                        if (manual) add(Permiso.REGISTRAR_PAGO_MANUAL)
                        if (cobros) add(Permiso.GESTIONAR_COBROS)
                        if (gastos) add(Permiso.REGISTRAR_GASTOS)
                        if (yape) add(Permiso.GESTIONAR_YAPE)
                    }
                }
                Caja.guardarMiembro(numero, nombre.trim(), rol, permisos)
                cerrar()
            }
        }
        if (numero in 31..35) {
            Spacer(Modifier.height(7.dp))
            Boton("Liberar plaza", Modifier.fillMaxWidth(), relleno = false, color = Rojo) { confirmarLiberar = true }
        }
        Spacer(Modifier.height(7.dp))
        Boton("Cerrar", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { cerrar() }
    }

    if (confirmarLiberar) Dialog(onDismissRequest = { if (!liberando) confirmarLiberar = false }) {
        Tarjeta(borde = Rojo.copy(alpha=.5f), fondo = PanelAlto) {
            Titulo("¿Liberar plaza N.º $numero?")
            Spacer(Modifier.height(8.dp))
            Text("La plaza volverá a estar libre. El historial anterior se conserva.", color = Tenue, fontSize = 12.sp)
            if (avisoLiberar.isNotBlank()) { Spacer(Modifier.height(7.dp)); Text(avisoLiberar, color = Rojo, fontSize = 11.sp) }
            Spacer(Modifier.height(12.dp))
            Boton(if (liberando) "Liberando…" else "Sí, liberar plaza", Modifier.fillMaxWidth(), color = Rojo, activo = !liberando) {
                liberando = true; avisoLiberar = ""
                Caja.liberarPlaza(numero) { ok, msg ->
                    liberando = false
                    if (ok) { confirmarLiberar = false; cerrar() } else avisoLiberar = msg
                }
            }
            Spacer(Modifier.height(7.dp))
            Boton("Cancelar", Modifier.fillMaxWidth(), relleno = false, color = Tenue, activo = !liberando) { confirmarLiberar = false }
        }
    }
}

@Composable
private fun PermisoToggle(texto: String, activo: Boolean, habilitado: Boolean = true, alTocar: () -> Unit) {
    val fondo by animateColorAsState(
        if (activo && habilitado) Verde.copy(alpha = .095f) else Fondo,
        tween(220),
        label = "permisoFondo"
    )
    val borde by animateColorAsState(
        if (activo && habilitado) Verde.copy(alpha = .45f) else if (habilitado) Borde else Borde.copy(alpha = .55f),
        tween(220),
        label = "permisoBorde"
    )
    val thumbX by animateDpAsState(if (activo) 24.dp else 3.dp, tween(260, easing = FastOutSlowInEasing), label = "switchThumb")
    val glow by animateFloatAsState(if (activo) 1f else .28f, tween(220), label = "switchGlow")

    Row(
        Modifier.fillMaxWidth().background(fondo, RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, borde), RoundedCornerShape(12.dp))
            .clickable(enabled = habilitado) { alTocar() }.padding(horizontal = 11.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(texto, color = if (habilitado) Texto else Tenue, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Box(
            Modifier.width(52.dp).height(29.dp)
                .background(if (!habilitado) Panel.copy(alpha = .75f) else if (activo) Verde.copy(alpha = .17f) else Panel, RoundedCornerShape(99.dp))
                .border(BorderStroke(1.dp, if (!habilitado) Borde.copy(alpha = .55f) else if (activo) Verde.copy(alpha = .55f) else Borde), RoundedCornerShape(99.dp))
        ) {
            if (activo) {
                Box(
                    Modifier.offset(x = 15.dp, y = 8.dp).width(24.dp).height(12.dp)
                        .background(VerdeBrillante.copy(alpha = .10f * glow), RoundedCornerShape(99.dp))
                )
            }
            Box(
                Modifier.offset(x = thumbX, y = 3.dp).size(23.dp)
                    .background(if (!habilitado) Tenue.copy(alpha = .25f) else if (activo) VerdeBrillante else Tenue.copy(alpha = .55f), RoundedCornerShape(99.dp))
                    .border(BorderStroke(1.dp, if (!habilitado) Borde.copy(alpha = .55f) else if (activo) VerdeNeon.copy(alpha = .75f) else Borde), RoundedCornerShape(99.dp))
            )
        }
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun SinPermiso() {
    Box(
        Modifier.fillMaxWidth().padding(vertical = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Text("No tienes permiso", color = Ambar, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SelectorAdmin(seccion: Int, cambiar: (Int) -> Unit) {
    val titulos = listOf("Pagos", "Cobro", "Gastos", "Yape", "Miembros")
    BoxWithConstraints(
        Modifier.fillMaxWidth().height(48.dp).background(Panel, RoundedCornerShape(14.dp))
            .border(BorderStroke(1.dp, Borde), RoundedCornerShape(14.dp)).padding(4.dp)
    ) {
        val ancho = (maxWidth - 8.dp) / titulos.size.toFloat()
        val x by animateDpAsState(ancho * seccion.toFloat(), tween(280, easing = FastOutSlowInEasing), label = "adminSelector")
        Box(
            Modifier.offset(x = x).width(ancho).fillMaxHeight()
                .background(GradientePrincipal, RoundedCornerShape(11.dp))
        )
        Row(Modifier.fillMaxSize()) {
            titulos.forEachIndexed { i, titulo ->
                val color by animateColorAsState(if (seccion == i) FondoProfundo else Tenue, tween(200), label = "adminText$i")
                Box(
                    Modifier.weight(1f).fillMaxHeight().clickable { cambiar(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(titulo, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

