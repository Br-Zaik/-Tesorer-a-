# Servidor v1.7.5 aplicado

Los cambios de backend de esta versión ya fueron aplicados al proyecto Supabase de Tesorería.

- Tabla interna `codigos_activacion_masivos`, protegida con RLS y sin acceso directo del cliente.
- Edge Function `codigos-masivos` para listar/generar el lote del tesorero.
- `activar-cuenta` actualizado para aceptar códigos masivos genéricos solo en primera activación y consumirlos una sola vez.
- RPC `registrar_pago_manual_grupo` para registrar varios pagos manuales de forma transaccional.
- RPC `enviar_pago_yape_foto_grupo` para un comprobante Yape con varios socios.
- RPC `revisar_pago_yape_grupo` para aprobar/rechazar el grupo completo.
- `cargar_app_snapshot_v1` incluye la metadata del grupo Yape necesaria para reconstruirlo en la app.
- El sistema individual de códigos de 24 horas se mantiene para recuperación/restablecimiento de cuentas existentes.
