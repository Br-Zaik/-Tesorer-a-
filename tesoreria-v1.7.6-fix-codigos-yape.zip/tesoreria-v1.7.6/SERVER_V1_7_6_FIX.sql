-- Tesorería v1.7.6
-- Corrección necesaria para que las Edge Functions con service role puedan
-- listar, crear y consumir códigos masivos bajo RLS.
grant select, insert, update, delete
on table public.codigos_activacion_masivos
to service_role;
