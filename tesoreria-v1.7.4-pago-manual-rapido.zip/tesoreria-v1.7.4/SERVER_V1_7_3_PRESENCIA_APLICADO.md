# Servidor v1.7.3 aplicado

Se agregó presencia de miembros respaldada por Supabase:

- `presencia_miembros`: heartbeat interno, sin acceso directo para clientes.
- `registrar_presencia`: solo una sesión autenticada puede actualizar su propia presencia.
- `marcar_desconectado`: marca salida explícita de la app.
- `presencia_admin`: solo el tesorero puede consultar estados de conexión.
- Verde si el heartbeat llegó en los últimos 18 segundos.
- Rojo si la cuenta existe pero ya no tiene presencia reciente.
- Amarillo si el miembro todavía no tiene cuenta Auth vinculada.
- Bloqueados y plazas libres se distinguen aparte.
- Al cambiar/liberar una plaza se limpia automáticamente su presencia anterior.
