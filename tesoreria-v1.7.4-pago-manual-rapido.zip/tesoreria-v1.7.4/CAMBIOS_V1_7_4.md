# Tesorería v1.7.4

- El registro de pago manual ya no cierra la ventana después de cada pago.
- Mantiene seleccionado el mismo cobro para registrar una cola rápidamente.
- Tras registrar: muestra confirmación, limpia persona/búsqueda y vuelve a enfocar el campo.
- Bloquea el botón mientras se registra para evitar dobles toques.
- Si el servidor rechaza el pago, la ventana permanece abierta mostrando el error.
- Botón inferior renombrado a “Cerrar”.
