# Tesorería v1.7.3

- Estado de conexión visible únicamente para el tesorero en Miembros.
- Verde: conectado a Tesorería y al servidor en los últimos segundos.
- Rojo: cuenta creada pero sin presencia activa.
- Amarillo: cuenta todavía sin activar.
- Gris: bloqueado.
- Las plazas libres no muestran conexión.
- Presencia respaldada por Supabase con heartbeat cada 7 s mientras la app está en primer plano.
- Al salir de la app se marca desconectado; si el proceso muere o se pierde Internet, el servidor lo considera desconectado automáticamente al vencer el heartbeat.
- Consulta de estados reservada al tesorero.
