# Tesorería v1.7.2

- Bitácora: elimina la duplicación del actor (`N.º 22 · N.º 22 ...`).
- Cuadrículas: elimina el fondo partido por medio de pago.
- En vista de administrador, un pago aprobado por Yape muestra `Y` morada.
- En vista de administrador, un pago aprobado manual muestra `M` verde oscuro.
- Los estados pendiente, rechazado, no enviado y libre mantienen su representación normal.
- Se aplica a cobros oficiales y rápidos.
